############################################################################################################
################## MOVE THE BOARD / POST QUIZ
screen ex_postquiz:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "tn_menu_idle"
        hover "tn_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### DUMPVIEW
    imagebutton:
        xpos 455
        ypos 680
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_dumpview')]

    ### PIPIS
    imagebutton:
        xpos 1330
        ypos 840
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_pipis')]



############################################################################################################
################## SPAMTON SHOP OUTSIDE
screen ex_spamshop:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### SPAMTON'S SHOP
    if not persistent.spamroute_fin:
        imagebutton:
            xpos 480
            ypos 750
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('trns_shop_spam')]

    ### SPAMTON INTERACT
    else:
        if spam_success and not end_triple_spam:
            imagebutton:
                xpos 585
                ypos 705
                idle "spam_button"
                hover "spam_buttonH"
                hovered Play("sfx", menuhover)
                action [Play("sfx", select), Jump('spam_interact')]

    ### SHOVEL PILE
    if not ex_memory:
        imagebutton:
            xpos 1670
            ypos 550
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_shovels')]

    ### TO NORTH
    imagebutton:
        xpos 900
        ypos 640
        idle "arrow_upW"
        hover "arrow_up"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_spam_north')]

    ### TO DIRT LUMP
    imagebutton:
        xpos 1760
        ypos 900
        idle "arrow_rightW"
        hover "arrow_right"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_spam_lump')]



############################################################################################################
################## DIRT LUMP ROOM
screen ex_lumproom:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### DIRT LUMP!!
    if not ex_memory:
        imagebutton:
            xpos 1290
            ypos 800
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_dirtlump')]

    ### MEMORYSHARD
    if ex_memory and not persistent.spamroute_fin:
        imagebutton:
            xpos 140
            ypos 920
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_lumpshard')]

    ### TO SPAMSHOP
    imagebutton:
        xpos 105
        ypos 620
        idle "arrow_leftW"
        hover "arrow_left"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_lump_spam')]

    ### TO MATTRESS
    imagebutton:
        xpos 660
        ypos 650
        idle "arrow_upW"
        hover "arrow_up"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_lump_matt')]



############################################################################################################
################## NORTH SPAM ROOM
screen ex_north:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### TENNA INTERACT
    if ten_success and end_battenna == "started":
        imagebutton:
            xpos 1285
            ypos 580
            idle "ten_button_sm"
            hover "ten_button_smH"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ten_interact')]

    ### TO SPAMSHOP
    imagebutton:
        xpos 830
        ypos 950
        idle "arrow_downW"
        hover "arrow_down"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_north_spam')]

    ### TO MATTRESS
    imagebutton:
        xpos 1730
        ypos 720
        idle "arrow_rightW"
        hover "arrow_right"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_north_matt')]

    ### TO DARKNESS
    imagebutton:
        xpos 110
        ypos 720
        idle "arrow_leftW"
        hover "arrow_left"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_north_dark')]

    ### TO GAMEROOM
    imagebutton:
        xpos 830
        ypos 700
        idle "arrow_upW"
        hover "arrow_up"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_north_game')]



############################################################################################################
################## MATTRESS ROOM
screen ex_mattroom:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### MATTRESS
    imagebutton:
        xpos 550
        ypos 740
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_mattress')]

    ### CREEPY HAND
    if not ex_memory:
        imagebutton:
            xpos 1725
            ypos 900
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_creepyhand')]

    ### TO DIRT LUMP
    imagebutton:
        xpos 920
        ypos 940
        idle "arrow_downW"
        hover "arrow_down"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_matt_lump')]

    ### TO STARWALKER
    imagebutton:
        xpos 1045
        ypos 605
        idle "arrow_upW"
        hover "arrow_up"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_matt_star')]

    ### TO NORTH SPAM SHOP
    imagebutton:
        xpos 50
        ypos 630
        idle "arrow_leftW"
        hover "arrow_left"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_matt_north')]



############################################################################################################
################## STARWALKER ROOM
screen ex_starroom:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### STARWALKER
    if itm_debit not in inventory and not vex_debithand:
        imagebutton:
            xpos 1415
            ypos 610
            idle "images/sprites/starwalker smol.png"
            hover "images/sprites/starwalker smol h.png"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_starwalker')]

    ### EYE MEMSHARD
    if ex_memory and not persistent.spamroute_fin:
        imagebutton:
            xpos 865
            ypos 615
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_eyeshard')]
    
    ### TO MATTRESS
    imagebutton:
        xpos 715
        ypos 905
        idle "arrow_downW"
        hover "arrow_down"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_star_matt')]



############################################################################################################
################## GAME ROOM
screen ex_gameroom:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "sp_menu_idle"
        hover "sp_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### TV
    imagebutton:
        xpos 555
        ypos 675
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_tv')]

    ### SECRET GAME UNLOCK
    if itm_cartridge2 in inventory or mke_unlock or mke_date:
        pass
    else:
        imagebutton:
            xpos 680
            ypos 775
            idle "secret_button1"
            hover "secret_button2"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_secretgame')]

    ### TO NORTH (which is actually south)
    if not mke_special:
        imagebutton:
            xpos 1025
            ypos 955
            idle "arrow_downW"
            hover "arrow_down"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('trns_game_north')]

    ### TO MIKE
    if mke_unlock and not mke_date:
        imagebutton:
            xpos 50
            ypos 660
            idle "arrow_leftW"
            hover "arrow_left"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('trns_game_mike')]

    ### MIKE INTERACT
    if mke_success and not end_triple_mke:
        imagebutton:
            xpos 1090
            ypos 615
            idle "mike_button"
            hover "mike_buttonH"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('mike_interact')]



############################################################################################################
################## OG ROOM
screen ex_ogroom:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "tn_menu_idle"
        hover "tn_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### PIPIS
    if not vex_keepis and not vex_pipis2:
        imagebutton:
            xpos 1330
            ypos 840
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_pipis2')]

    ### TO TENNA'S HOUSE
    imagebutton:
        xpos 455
        ypos 680
        idle "arrow_leftW"
        hover "arrow_left"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_og_ten')]

    ### TO DARKNESS
    imagebutton:
        xpos 1760
        ypos 700
        idle "arrow_rightW"
        hover "arrow_right"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_og_dark')]



############################################################################################################
################## TENNA'S HOUSE
screen ex_tenhouse:
    modal True

    ### MENU BUTTON (ALWAYS USE THIS)
    imagebutton:
        xalign 0.01
        yalign 0.01
        idle "tn_menu_idle"
        hover "tn_menu_hover"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), ShowMenu('rightclick')]

    ### DARK CANDY TREE
    imagebutton:
        xpos 780
        ypos 340
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_darkcandy')]

    ### FRIDGE
    imagebutton:
        xpos 1720
        ypos 700
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_fridge')]

    ### FLOWERBOX
    imagebutton:
        xpos 490
        ypos 670
        idle "soul_sketchyWS"
        hover "soul_sketchyS"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('ex_flowerbox')]

    ### FRONT DOOR
    if not ten_success:
        imagebutton:
            xpos 1420
            ypos 480
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_tendoor')]

    ### WINDOW
    if vex_window and not ten_success:
        imagebutton:
            xpos 1100
            ypos 450
            idle "soul_sketchyWS"
            hover "soul_sketchyS"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ex_window')]

    ### TENNA INTERACT
    if ten_success and end_battenna != "started" and not end_triple_ten and not end_triple == "started":
        imagebutton:
            xpos 1180
            ypos 325
            idle "ten_button"
            hover "ten_buttonH"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump('ten_interact')]

    ### TO OG ROOM
    imagebutton:
        xpos 1330
        ypos 940
        idle "arrow_downW"
        hover "arrow_down"
        hovered Play("sfx", menuhover)
        action [Play("sfx", select), Jump('trns_ten_og')]