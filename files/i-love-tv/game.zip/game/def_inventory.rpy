############################################################################################################
################## INVENTORY
init -2 python:
    class Item:
        def __init__(self, name, desc, img, money):
            self.name = name
            self.desc = desc
            self.img = img
            self.money = money

default inventory = []
default money = 0

######################################################
##### INVENTORY SCREEN MENU
default imghover = False
default which_desc = ""
default which_item = ""
default date_item = False # if in screen from date

screen inv_view:
    on 'show' action PauseAudio('sound', value=True)

    modal True
    tag menu

    frame:
        background "gui/item menu.png"
        xfill True
        yfill True

        grid 6 5:
            xpos 695
            ypos 60
            maximum(1152,960)

            for i in inventory:
                if not date_item:
                    imagebutton:
                        idle i.img
                        hover i.img + "H"
                        hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", i.name), SetVariable("which_desc", i.desc)]
                        unhovered SetVariable("imghover", False)
                        action NullAction()
                
                else:
                    if currentdate == "park":
                        imagebutton:
                            idle i.img
                            hover i.img + "H"
                            hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", i.name), SetVariable("which_desc", i.desc)]
                            unhovered SetVariable("imghover", False)
                            action [Play("sfx", select), SetVariable("which_item", i), SetVariable("date_item", False), SetVariable("imghover", False), Jump("tendate_item_react")]

                    elif currentdate == "shop" or currentdate == "eye":
                        imagebutton:
                            idle i.img
                            hover i.img + "H"
                            hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", i.name), SetVariable("which_desc", i.desc)]
                            unhovered SetVariable("imghover", False)
                            action [Play("sfx", select), SetVariable("which_item", i), SetVariable("date_item", False), SetVariable("imghover", False), Jump("spamdate_item_react")]

                    elif currentdate == "secret":
                        imagebutton:
                            idle i.img
                            hover i.img + "H"
                            hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", i.name), SetVariable("which_desc", i.desc)]
                            unhovered SetVariable("imghover", False)
                            action [Play("sfx", select), SetVariable("which_item", i), SetVariable("date_item", False), SetVariable("imghover", False), Jump("mikedate_item_react")]

    if date_item:
        textbutton _("[[RETURN]"):
            style "return_button"
            action [SetVariable("date_item", False), Return()]
    
    else:
        textbutton _("[[RETURN]"):
            style "return_button"
            action Return()

    frame:
        xpos 25
        ypos 30
        padding(30,20,30,20)
        text "D$[money]"

    if imghover: # size changes for the text based on if the name is too long for the basic ver or not
        if which_item in [itm_figlove.name, itm_fighate.name]:
            text "{size=-13}[which_item]" xpos 30 ypos 215 textalign 0.5
        elif which_item in [itm_loveletter.name, itm_pie.name]:
            text "{size=-10}[which_item]" xpos 30 ypos 215 textalign 0.5
        else:
            text "[which_item]" xpos 30 ypos 204 textalign 0.5
    
        frame:
            background None
            padding(30,20,30,20)

            hbox:
                xpos 29
                ypos 265
                xmaximum 463
                ymaximum 682
                text "[which_desc]"



############################################################################################################
################## ITEMS
### default
default itm_shadow = Item("???", "{noalt}*{/noalt} It feels like there's something in your pocket.{p}{noalt}*{/noalt} But there's nothing there?", "shadow", 0)
# When known: "Shadow Crystal", "{noalt}*{/noalt} It feels like there's something in your pocket.{p}{noalt}*{/noalt} But even when you look closely, there's nothing more than a shadow."

### tenna
default itm_pipis = Item("???", "{noalt}*{/noalt} A certain person's special \"???\"{p}{noalt}*{/noalt} Who knows what this actually is.", "pipis", 0)
default itm_nes = Item("Game Controller", "{noalt}*{/noalt} A controller that can be used to play games.{p}{noalt}*{/noalt} It's a little slimy to the touch.", "nes", 0)

default itm_pie = Item("Cinnamon-Butterscotch Pie Slice", "{noalt}*{/noalt} A freshly-made slice of something in a pie shape.{p}{noalt}*{/noalt} It doesn't taste like food.", "baked goods", 0)
default itm_candy = Item("Dark Candy", "{noalt}*{/noalt} A piece of Dark Candy that grew in improper conditions.{p}{noalt}*{/noalt} It doesn't taste like food.", "candy", 0)
default itm_fries = Item("French Fries", "{noalt}*{/noalt} A freshly-made dish of something cut into fry-shapes.{p}{noalt}*{/noalt} It doesn't taste like food.", "fries", 0)
default itm_pretzel = Item("Large Pretzel", "{noalt}*{/noalt} A freshly-made something in the shape of a pretzel.{p}{noalt}*{/noalt} It doesn't taste like food.", "pretzels", 0)
default itm_cocoa = Item("Cup of Hot Cocoa", "{noalt}*{/noalt} A cracked red mug containing something vaguely scented like chocolate.{p}{noalt}*{/noalt} It doesn't taste like food.", "chocolate", 0)
default itm_coffee = Item("Cup of Coffee", "{noalt}*{/noalt} A cracked yellow mug containing something vaguely scented like coffee.{p}{noalt}*{/noalt} It doesn't taste like food.", "coffee", 0)

### tenshop
default itm_flower = Item("Special Flower", "{noalt}*{/noalt} A small flower in your favorite color (probably).{p}{noalt}*{/noalt} The edges of its  petals appear to be wilting.", "flower", 0)
default itm_dvd = Item("Partially Soggy DVD", "{noalt}*{/noalt} A DVD that (presumably) has your favorite shows.{p}{noalt}*{/noalt} The cover seems to be water damaged and there's no disc inside.", "dvd", 0)
default itm_figlove = Item("Mr. \"Ant\" Tenna Figure for TV Lovers", "{noalt}*{/noalt} A figure depicting Mr. \"Ant\" Tenna as he appeared on \"TV Time!\"{p}{noalt}*{/noalt} It's in good condition.", "figlove", 0)
default itm_fighate = Item("Mr. \"Ant\" Tenna Figure for TV Haters", "{noalt}*{/noalt} A figure depicting Mr. \"Ant\" Tenna as he appeared on \"TV Time!\"{p}{noalt}*{/noalt} The arms have fallen off.", "fighate", 0)

### spamton
default itm_loveletter = Item("[[LOVE-LETTER-FOR-YOU.TXT.vbs]]", "{noalt}*{/noalt} Digital data that you have no way of reading.{p}{noalt}*{/noalt} Seems interacting with it might overwrite the whole game...", "loveletter", 0)

### spamshop
default itm_shovel = Item("Shovel", "{noalt}*{/noalt} A remnant of a DDoS (Dozens and Dozens of Shovels) attack.{p}{noalt}*{/noalt} Its strength can pierce even the strongest of dirt lumps.", "shovel", 10)
default itm_freecard = Item("Board Game Playing Card", "{noalt}*{/noalt} A flimsy piece of paper that looks like it was colored on with crayon.{p}{noalt}*{/noalt} It doesn't do anything.", "freecard", 50)
default itm_ring = Item("\"Commemorative\" Ring", "{noalt}*{/noalt} A silver ring with a large sapphire on it that appears real.{p}{noalt}*{/noalt} It has some engraved words inside the band.", "ring", 1997)

### explore/solving puzzles
default itm_shovel2 = Item("Lesser Shovel", "{noalt}*{/noalt} A remnant of a DDoS (Dozens and Dozens of Shovels) attack.{p}{noalt}*{/noalt} It's incredibly weak, only able to shuffle loose dirt.", "shovel2", 0)
default itm_debit = Item("Starwalker's Debit Card", "{noalt}*{/noalt} A debit card that foolishly has the pin number written on the back.{p}{noalt}*{/noalt} He probably won't need this anymore.", "debit", 100)
default itm_cartridge1 = Item("Game Cartridge", "{noalt}*{/noalt} A cartridge for an old game system.{p}{noalt}*{/noalt} The label looks like it was written on in pen.", "cartridge1", 0)
default itm_cartridge2 = Item("Game Cartridge", "{noalt}*{/noalt} A cartridge for an old game system.{p}{noalt}*{/noalt} It's missing its label.", "cartridge2", 0)

### endings map
default itm_notes = Item("Sketch-Covered Paper", "{noalt}*{/noalt} It's a strange note.\n{noalt}*{/noalt} The crumpled paper depicts several crude drawings of a red star, green heart, and blue cube.\n(View in FP/LP Menu)", "notes", 0)

### memoryshards
# (#/6) is representative of CHRONOLOGICAL ORDER.
default itm_redshard1 = Item("Red Shard", "{noalt}*{/noalt} A semi-translucent red shard.{p}{noalt}*{/noalt} When you peer inside, it looks like the meeting of two stars.", "redshard1", 0) # label memoryshard1
# When known: "MemoryShard (1/6)"
default itm_redshard2 = Item("Red Shard", "{noalt}*{/noalt} A semi-translucent red shard.{p}{noalt}*{/noalt} When you peer inside, it looks like a deal is being discussed.", "redshard2", 0) # label memoryshard2
# When known: "MemoryShard (5/6)"
default itm_redshard3 = Item("Red Shard", "{noalt}*{/noalt} A semi-translucent red shard.{p}{noalt}*{/noalt} When you peer inside, it looks like someone running away.", "redshard3", 0) # label memoryshard3
# When known: "MemoryShard (6/6)"

default itm_greenshard1 = Item("Green Shard", "{noalt}*{/noalt} A semi-translucent green shard.{p}{noalt}*{/noalt} When you peer inside, it looks like two people arguing.", "greenshard1", 100) # label memoryshard4
# When known: "MemoryShard (4/6)"
default itm_greenshard2 = Item("MemoryShard (2/6)", "{noalt}*{/noalt} A semi-translucent green shard.{p}{noalt}*{/noalt} When you peer inside, it looks like some kind of confession.", "greenshard2", 0) # label memoryshard5
default itm_greenshard3 = Item("MemoryShard (3/6)", "{noalt}*{/noalt} A semi-translucent green shard.{p}{noalt}*{/noalt} When you peer inside, it looks like someone is laughing.", "greenshard3", 0) # label memoryshard6

default itm_blueshard = Item("Blue Shard", "{noalt}*{/noalt} A semi-translucent blue shard that is undamaged.{p}{noalt}*{/noalt} When you peer inside, it looks like an unsettling conversation.", "blueshard", 0) # label memoryshard9
# When known: "MemoryShard (7/6)"