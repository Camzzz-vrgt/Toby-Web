############################################################################################################
################## SPAMTON ENDINGS
label ending_spamton:
    $ currentend = "spamton"

    if persistent.playthru:
        pause 1.0
        play sfx bump
        show blackpng zorder 3
        if persistent.glitches:
            pass
        else:
            with vpunch
        pause 1.0
        spamton "WHaT THE[[] ARE YOU DOING?!{p=0.5}{noalt}*{/noalt} DON'T JUST [[shove your] ME [[aside]!!"
        show spamton standing up frowne at spampos_center
        hide blackpng with Dissolve(0.2)
        if persistent.glitches:
            pass
        else:
            show spamton at shakingcg
        spamton "THE DEAL, [persistent.mc!u],{w=0.2} THE [[ DEAL ]!!!!"
        spamton "WHAT DO YOU [[want] WHAT DO YOU [[WANT]????"
        show spamton standing up stare
        spamton "WHATEVER YOU [[want] I WILL [[hand over everything I own]{p=0.2}{noalt}*{/noalt} I [[need] THIS!!!"
        pause 1.0

    else:
        play music digitalroots fadein 2.0
        pause 3.0
        spamton "WHERE.{w=0.2} WHERE."
        spamton "WHERE {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}."
        spamton "THE [[[[ Light. ]]"
        spamton "WHERE DID {color=[c_passion]}YOU{/color} GO,{w=0.2} [[my light] ?"
        pause 1.0
        "You fall deeper into the Darkness..."
        scene junkyard6 with Dissolve(2.0)
        pause 1.0
        show spamton standing up stare at spampos_center with Dissolve(0.2)
        show spamton at jump
        spamton "THERE {noalt}IT{/noalt}{alt}it{/alt} {noalt}IS{/noalt}{alt}is{/alt}!"
        if persistent.glitches:
            show spamton crazy laugh
            spamton "[persistent.mc!u].{p=0.2}{noalt}*{/noalt} HAND {noalt}IT{/noalt}{alt}it{/alt} OVER."
            show spamton standing up stare
            spamton "HAND.{w=0.5} {noalt}IT{/noalt}{alt}it{/alt}.{w=0.5} OVER."
        else:
            show spamton crazy laugh glitch
            spamton "[persistent.mc!u].{p=0.2}{noalt}*{/noalt} HAND {noalt}IT{/noalt}{alt}it{/alt} OVER."
            show spamton standing up stare at shakingcg
            spamton "{sc=3}HAND.{w=0.5} IT.{w=0.5} OVER.{/sc}"
        "You keep your hand close to your chest..."
        pause 1.0

    menu:
        "Why do you need two SOULs?":
            pass

        "Give it to him":
            "Your arm resisted fervently."
            show spamton standing up frowne
            spamton "WHAT'S THE [[Hold Up!] [[the 2nd] ?!?!?!"
    
    "You demanded to know why Spamton wants your SOUL if he already has one."
    show spamton panic up screame at jump
    spamton "WHAT [[WHAT?!]"
    if persistent.glitches:
        show spamton crazy angry
    else:
        show spamton crazy angry at shakingcg 
    spamton "I {noalt}DON''T{/noalt}{alt}don't{/alt} WANT [[2-for-1 Sale] ???"
    show spamton standing up smile
    spamton "YOU {noalt}AR3{/noalt}{alt}are{/alt} [[[[ {color=[c_passion]}Freedom{/color} ]] {noalt}AR E{/noalt}{alt}are{/alt} YOU NoT?!"
    show spamton standing up frowne
    if s_sillystrings:
        spamton "YOU HAVE TO BE{p=0.2}{noalt}*{/noalt} YOU [[must-have items] TO BE!!!!"
    else:
        spamton "YOU SAID YOU ARE [[silly strings] [[Absolutely FREE!]!!"
    show spamton standing down panic
    spamton "LIGHTNERS {noalt}HA> E{/noalt}{alt}have{/alt} [[[[ The Light ]]"
    spamton "{noalt}r 1GHT, RIG HT HT???1!?{/noalt}{alt}right, right?{/alt}"
    show spamton crazy frantic
    spamton "IF YOU {noalt}dddONnnnt'{/noalt}{alt}don't{/alt} THEN,{p=0.2}{noalt}*{/noalt} Then,{p=0.2}{noalt}*{/noalt} THEN, ,"
    show spamton slouch down static glitch at droop
    pause 2.0
    spamton "[[[[ {w=0.5}{cps=25}... can anyone hear me?{/cps} ]]"
    spamton "[[ {cps=25}Help{/cps} ]]"
    if persistent.glitches:
        spamton "[[ Help. ]"
        spamton "I CAn'T {noalt}T4KE IT ANYM@rE{/noalt}{alt}take it anymore{/alt}!"
        spamton "{noalt}[[ LEt M3 ] 0UT!!!!!!!{/noalt}{alt}let me out!!{/alt}"
        play sfx spamlaughL
        show spamton standing tilt laugh
        pause 1.0
        show spamton crazy angry flipped
        pause 0.35
        show spamton panic up screame
        pause 0.35
        show spamton standing tilt laugh flipped  
        pause 0.4
        show spamton standing down panic flipped
        pause 1.0
        show spamton standing up stare
    else:
        spamton "{sc=2}H{/sc}e{sc=5}l{/sc}{sc=1}p{/sc}." # SELF VOICING FIX 
        spamton "{sc=3}I CAn'T T4KE IT ANYM@rE!{/sc}" # SELF VOICING FIX
        spamton "[[{sc=5}LEt M3{/sc}] {sc=5}0UT!!!!!!!{/sc}" # SELF VOICING FIX 
        play sfx spamlaughL
        show spamton standing tilt laugh glitch at shakingcg
        pause 1.0
        show spamton crazy angry flipped glitch
        pause 0.35
        show spamton panic up screame glitch
        pause 0.35
        show spamton standing tilt laugh flipped glitch  
        pause 0.4
        show spamton standing down panic flipped at yreset
        pause 1.0
        show spamton standing up stare at shaking
    spamton "I{p=0.2}{noalt}*{/noalt} I{p=0.2}{noalt}*{/noalt} I{p=0.2}{noalt}{noalt}*{/noalt} I DIDnN'T T{/noalt}{alt}didn't{/alt}{nw=0.2}"
    show spamton slouch down panic flipped
    spamton "I {noalt}DON' T{/noalt}{alt}don't{/alt} [[you need our]{nw=0.5}"
    show spamton standing down static flipped
    spamton "I {noalt}DIDn''T WA Nn T{/noalt}{alt}didn't want{/alt}{nw=0.5}"
    if persistent.glitches:
        show spamton slouch down static
    else:
        show spamton slouch down static glitch at droop
    pause 2.0

    ## DEBUG ONLY
    if debugtesting:
        $ spam.fp = 0
        $ spam.lp = 0

    ## if "won" route 
    if spam.fp <= 0 and spam.lp <= 0:
        menu:
            "{size=-10}{color=#aaaaaa}(This may affect your ending.){/color}{/size}\nComfort him":
                $ spam_success = True
                jump ending_spamton_good
            
            "Do not":
                $ spam_failed = True
                jump ending_spamton_bad

    ## if "failed" route
    else:
        $ spam_failed = True
        jump ending_spamton_bad


######################################################
##### SPAMTON GOOD END
label ending_spamton_good:
    play sfx plop
    stop music
    scene black
    if persistent.glitches:
        pass
    else:
        with vpunch
    spamton "{noalt}WHAaT THE--[[]!?1?!{/noalt}{alt}WHAt the--??{/alt}{p=0.2}{noalt}*{/noalt} HEY [[Hey!] {noalt}h hHEY{/noalt}{alt}hey!{/alt}"
    show spamend fail 1 with Dissolve(2.0)
    alt "[persistent.mc] hugged Spamton."
    pause 0.5
    play sfx bump
    show spamend fail 2
    if persistent.glitches:
        pass
    else:
        with vpunch
    alt "Spamton shoved [persistent.mc] off of him."
    pause 0.5
    show spamend fail 3
    spamton "WHO SAID YOU COULD [[hold me] [[To Your Heart's Content] ?!?"
    scene black with Dissolve(0.5)
    scene junkyard6 with Dissolve(0.5)
    show spamton panic up screame at spampos_center with Dissolve(0.2)
    spamton "{noalt}WH4T'S{/noalt}{alt}what's{/alt} YOUR {nw}"
    if persistent.glitches:
        show spamton at jump
    else:
        show spamton at shock
    extend "[[Problem?]??"
    if persistent.glitches:
        show spamton standing up stare
    else:
        show spamton standing up stare at shakingcg
    spamton "WHAT DO YOU WANT FROM ME?!"
    menu:
        rq "WHAT DO YOU WANT FROM ME?!"
        "I wanted to show you I care.":
            show spamton standing tilt laugh at xwiggle
            spamton "HAHEHHEHA!!!{p=0.5}{noalt}*{/noalt} NO ONE [[Give A] DAMN ABOUT ME."
            if persistent.glitches:
                show spamton standing up stare at yreset
            else:
                show spamton standing up stare at shakingcg
            spamton "NOT EVEN YOU!!!!!{p=0.5}{noalt}*{/noalt} SO DON'T TRY TO [[lie to my face] LIKE [[Everybody Else Is Doing It!] ."

        "I wanted to help you.":
            show spamton crazy frantic
            spamton "I DON'T NEED YOUR [[HELP]!!!!!{p=0.5}{noalt}*{/noalt} {noalt}[[&$#!]{/noalt}{alt}beep{/alt} YOU,{w=0.2} MAN!!{w=0.2} {noalt}[[&$#!]{/noalt}{alt}beep{/alt} YOU!!"
            spamton "I'M [[in perfect condition] ON MY OWN!!!!"

        "...":
            spamton "SPILL THE {noalt}[[3am]{/noalt}{alt}3 A M{/alt} BEANS, [persistent.mc!u]!!!{p=0.2}{noalt}*{/noalt} YOU CAN'T JUST [[Comfort him] A GUY OUT OF NOWHERE LIKE THAT!!"
            if persistent.glitches:
                show spamton crazy angry at jump
            else:
                show spamton crazy angry at shock
            spamton "{noalt}AUGHH!!{/noalt}{alt}ugh!!{/alt}"

    show spamton standing down frown at yreset
    spamton "I..."
    show spamton slouch down frown
    pause 1.0
    show spamton at droop
    spamton "I{w=1.0} need to sit down."
    hide spamton with Dissolve(0.2)
    pause 1.0
    play sfx plop
    scene black
    pause 2.0
    play music faintcourageSo
    show spamend 1 frown with Dissolve(2.0)
    pause 1.0
    spamton "THIS {noalt}IS{/noalt}{alt}is{/alt} ALL [[Boob {noalt}Tube]'S{/noalt}{alt}tube's{/alt} FAULT."
    spamton "[[CRTs] PUSHED THINGS [[as far as you can see]"
    show spamend 1 angrye with Dissolve(0.5)
    spamton "HAHEHAHAHEHAH!{p=0.5}{noalt}*{/noalt} [[If it weren't for him, I wouldn't be as] {noalt}[[#X&K]ED{/noalt}{alt}beeped{/alt} UP [[as I am today!]."
    spamton "DON'T TRusT HIM!!{p=0.5}{noalt}*{/noalt} NO MATTER HOW [[handsomeGuy] HE {noalt}IS{/noalt}{alt}is{/alt}!!!!"
    show spamend 1 deadpan with Dissolve(0.5)
    pause 2.0
    show spamend 1 struggle with Dissolve(0.2)
    spamton "... {noalt}[[$#!#]{/noalt}{alt}beep{/alt} YOU!!!!{p=0.5}{noalt}*{/noalt} I HATE HIM!!!!"
    spamton "[[Cathode] CAN GO {noalt}[[$#!$]{/noalt}{alt}beep{/alt} HIMSELF SIDEWAYS WITH A\n{noalt}[[$!#$]{/noalt}{alt}beep{/alt} AND A {noalt}[[@#$!]{/noalt}{alt}beep{/alt} IN A {noalt}[[$#&!#]{/noalt}{alt}beep{/alt} DURING A {noalt}[[#@X&^]{/noalt}{alt}beep{/alt}\n[[Texas Rodeo]!!!!"
    show spamend 1 smilee with Dissolve(0.5)
    spamton "IT'S NOT LIKE HE EVER [[cared] ABOUT ME ANYWAY!!"
    spamton "I WAS JUST A [[Massive Discounts on Tools] TO HIM LIKE EVERYONE ELSE!!"
    show spamend 1 frown with Dissolve(0.5)
    spamton "[[fuzzface] DOESN'T GIVE A FLYING{w=0.2} {noalt}[[#^!#&!]G{/noalt}{alt}beeping{/alt}{w=0.2} {noalt}[[$#!^]{/noalt}{alt}beep{/alt}{w=0.2} ABOUT {noalt}[[$^!#]ING{/noalt}{alt}beeping{/alt} ANYTHING OTHER THAN {noalt}HIm SE LF{/noalt}{alt}himself{/alt}!!!!"
    spamton "I [[wanted to] TRUST HIM."
    show spamend 1 pained with Dissolve(0.5)
    spamton "I [[shouldn't have] TRUsT HIM."
    spamton "A {noalt}GODD[[dam]{/noalt}{alt}goddamn{/alt} CONTRACT RIGHT AT [[The Good Part]?!"
    show spamend 1 smile with Dissolve(0.5)
    spamton "EHAHAHHAH!!{p=0.5}{noalt}*{/noalt} I'M THE [[egg on my face] FOR"
    show spamend 1 frown with Dissolve(0.5)
    pause 2.0
    show spamend 1 strugglee with Dissolve(0.5)
    spamton "AND YOU!!!{p=0.5}{noalt}*{/noalt} [[[[ {color=[c_passion]}YOU{/color} ]]!!!!!!"
    spamton "WHAT {noalt}IS{/noalt}{alt}is{/alt} YOUR PROBLEM????"
    spamton "YOU COME HERE LOOKING FOR THAT [[Couch Potato],{w=0.5}\nAND NOW YOU'RE STANDING HERE TRYING TO [[Comfort him] ME???"
    show spamend 1 angrye with Dissolve(0.5)
    spamton "YOU THINK I'LL JUST{p=0.2}{noalt}*{/noalt} I'LL JUST{p=0.2}{noalt}*{/noalt} I'LL JUST{nw=0.2}"
    spamton "I'LL JUST{w=0.5} [[Trust] YOU LIKE THAT?????{p=0.5}{noalt}*{/noalt} H-E [[double hockey sticks] NO!!!"
    show spamend 1 frown with Dissolve(0.5)
    spamton "IF YOU'RE NOT GOING TO [[show-off] [[Your Heart] THEN GET OUT OF MY [[Reputable Business]."
    pause 2.0
    show spamend 1 glare with Dissolve(0.5)
    spamton "WHY {noalt}AREN''T{/noalt}{alt}aren't{/alt} YOU LEAVING."
    spamton "WHAT {noalt}IS IT{/noalt}{alt}is it{/alt}??{w=0.2} WHAT????{w=0.2} {noalt}[[W H A T ]??????{/noalt}{alt}what??{/alt}"
    show spamend 1 struggle with Dissolve(0.2)
    spamton "WHAT DO YOU [[want] FROM ME ?!?!"
    menu:
        rq "WHAT DO YOU [[want] FROM ME ?!?!"
        "I don't want anything.":
            show spamend 1 strugglee with Dissolve(0.2)
            spamton "LIAR!!!!!!!!!"
            spamton "EVERY{space=80} {w=0.2}WANTS SOMETHING!!"
            spamton "YOU WOULD HAVE [[press left] LIKE A GOOD\n[[gender redacted] ALREADY IF YOU DIDN'T!!!!"
            
        "I don't need anything.":
            show spamend 1 angrye with Dissolve(0.2)
            spamton "THAT'S NOT [[what I asked], {noalt}[[$#!^]{/noalt}{alt}beep{/alt}FACE!"
            spamton "ARE YoU AVOIDINg [[the Question] ??{p=0.5}{noalt}*{/noalt} {noalt}WOWo W{/noalt}{alt}wowow{/alt} DOES THAT REMIND ME OF [[Nobody In Particular] !!!!!!!!"

    show spamend 1 struggle with Dissolve(0.5)
    spamton "JUST [[spit it out] ALREADY!!{p=0.5}{noalt}*{/noalt} WHAT {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}??{w=0.2} A [[Brand-New Car]???{w=0.5} A [[kiss on the cheek]????"
    spamton "DO YOU WANT [[commemorative ring] ????{w=0.5} ME ????{p=0.5}{noalt}*{/noalt} [[[[Hyperlink Blocked]] ????"
    spamton "I DON'T CARE!!!{p=0.5}{noalt}*{/noalt} I [[Do Not] CARE ANYMORE!!"
    show spamend 1 pained with Dissolve(0.5)
    spamton "JUST [[[[ TELL ME ]]..."
    spamton "JUST [[Tell me,{w=0.2} Please]"
    show spamend 1 static with Dissolve(0.5)
    spamton "CAN I [[ trust ] YOU TO [[ Just tell me the truth ],{w=0.2} OR NOT?"
    spamton "{cps=25}WhAt do You WANT [[From: Me]?{/cps}"
    pause 2.0

    menu end_menu_wants:
        "I want your love":
            $ spam_want = "love"
            show spamend 1 deadpan with Dissolve(0.5)
            pause 0.5
            spamton "WHAT."
            show spamend 1 glaree with Dissolve(0.5)
            spamton "I WAS KIDDING?????{p=0.5}{noalt}*{/noalt} YOuRE NOT {noalt}[[/srs]{/noalt}{alt}serious{/alt} ARE YOU???????"
            pause 2.0
            show spamend 1 frown with Dissolve(0.5)
            spamton "YOU.{w=0.5} ARE SERIOUS."
            spamton "..."
            pause 2.0
            show spamend 1 pained with Dissolve(0.5)
            $ _history = False
            spamton "I DONT KNOW{nw}"
            $ _history = True
            spamton "I DONT KNOW{w=0.5} HOW I FEEL ABOUT THAT."
            pause 1.0
            menu:
                "I don't want to force you":
                    show spamend 1 strugglee with Dissolve(0.2)
                    spamton "[[force you] ME TO WHAT???"
                    spamton "DON'T EVEN THINK ABOUT A RELATION[[shipping] {noalt}WTIH{/noalt}{alt}with{/alt} ME WHEN I HAVEN'T EVEN KNOWN YOU FOR [[1 Year Guarenteed]."
                    show spamend 1 frown with Dissolve(0.5)
                    spamton "[[I'm not making that mistake again...]"

                "You told me to be honest":
                    show spamend 1 strugglee with Dissolve(0.2)
                    spamton "DOESN'T MEAN I'M [[happi] ABOUT THE [[Show Results] !!"
                    spamton "I..."
                    show spamend 1 static with Dissolve(0.5)
                    spamton "... don't want to talk about this."

        "I want a distraction":
            $ spam_want = "distraction"
            show spamend 1 strugglee with Dissolve(0.5)
            spamton "A [[distraction]?{p=0.5}{noalt}*{/noalt} FROM WHAT???"
            spamton "YOUR [[[[Freedom]] LIFE????"
            spamton "IF YOU DONT WANT {noalt}IT{/noalt}{alt}it{/alt} THEN >GIVE {noalt}IT{/noalt}{alt}it{/alt} TO [[Your old pal,] SPAMTON INSTEAD!!"
            pause 1.0
            show spamend 1 glaree with Dissolve(0.2)
            if persistent.deals:
                spamton "WHY DO YOU LOOK SO [[frustrated by things that just don't work] ?"
                spamton "IF YOU {noalt}DIDNN'T{/noalt}{alt}didn't{/alt} WANT TO [[Hand it over] YOUR {noalt}[[Heart-ShapedObject]{/noalt}{alt}heart-shaped object{/alt} THEN WHY DID YOU [[[[Take the Deal]] ?"
            else:
                spamton "{noalt}DON''T{/noalt}{alt}don't{/alt} LOOK [[@me] LIKE THAT!"
                spamton "YOU KNOW YOUR {noalt}[[Heart-ShapedObject]{/noalt}{alt}heart-shaped object{/alt} {noalt}IS{/noalt}{alt}is{/alt} [[The One and Only] REASON I'M HERE."
                spamton "YOU HAVE TO KNOW.{w=0.5} YOU HAVE TO HAVE [[Help Wanted] TO TAKE THE DEAL."
                spamton "WHY ELSE WOULD YOU [[return] ?"
            show spamend 1 pained with Dissolve(0.5)
            spamton "DID YOU [[Lier] TO ME THEN, {noalt}TO0{/noalt}{alt}too{/alt}?"
            spamton "OR {noalt}IS IT{/noalt}{alt}is it{/alt}..."
            pause 1.0
            show spamend 1 glare with Dissolve(0.2)
            spamton "...{w=0.5} [[silly strings]."
            pause 1.0
            menu:
                "I'd talk to you {color=#FF54A6}myself{/color} if I could":
                    show spamend 1 smilee with Dissolve(0.5)
                    spamton "WHAT'S THAT SUPPOSED TO MEAN?!?"
                    spamton "WHO'S TALKING TO ME RIGHT NOW??"
                    pause 1.0
                    show spamend 1 static with Dissolve(0.2)
                    spamton "[[[[ Heaven ]],{w=0.5} ARE YOU WATCHING..>?"

                "I'd give you my life if I could":
                    show spamend 1 frown with Dissolve(0.5)
                    spamton "DON'T SAY {noalt}IT{/noalt}{alt}it{/alt} SO [[Unbelievable Discounts]."
                    spamton "ACTUALLY.{p=0.5}{noalt}*{/noalt} DON'T SAY {noalt}IT{/noalt}{alt}it{/alt} [[at all]."
                    show spamend 1 pained with Dissolve(0.5)
                    spamton "{noalt}IT{/noalt}{alt}it{/alt} SOUNDS [[Call Your Doctor About ] WHEN YOU'RE THE ONE SAYING {noalt}IT{/noalt}{alt}it{/alt}"

        "I want to feel valued":
            $ spam_want = "valued"
            show spamend 1 deadpan with Dissolve(0.5)
            spamton "... YOU CAME TO [[Number One Rated Salesman 1997] FOR THAT????"
            show spamend 1 smilee with Dissolve(0.5)
            spamton "DO YOU WANT ME TO STICK A {noalt}[[$9.99{/noalt}{alt}nine ninety-nine{/alt} Sale] [[Price Tag] ON YOUR FACE????"
            spamton "I DON'T DO [[motivational speeches] OR [[heartwarming friendships] YOU [[desperate little ],"
            show spamend 1 glaree with Dissolve(0.5)
            spamton "OR DO YOU JUST WANT TO [[Rock 'em Sock 'em] [[the little guy] SO YOU CAN [[Do You Feel Better About Yourself]??"
            spamton "[[desperate little ] WHAT DO YOU EVEN MEAN."
            pause 1.0
            menu:
                "I want to be happy":
                    show spamend 1 glare with Dissolve(0.5)
                    spamton "[[Join the club], [persistent.mc!u]{p=0.5}{noalt}*{/noalt} EVERYBODY THINKS THEY WANT [[Unlimited] HAPPINESS."
                    show spamend 1 smile with Dissolve(0.2)
                    spamton "FIRST RULE OF [[Customer Service Jobs]:{p=0.2}{noalt}*{/noalt} [[[[ The Customer(tm) is Always Right! ]]"
                    spamton "AND IF THEY'RE [[Always Right!] THEY'RE NEVER [[depressed.]?!"
                    show spamend 1 angrye with Dissolve(0.5)
                    spamton "EAHAHEHAH!!{w=0.5} [[pretend] EVERYTHING'S [[Perfection!],{w=0.2} AND SUDDENLY YOU [[can't feel anything anymore]"

                "I want to know someone cares":
                    show spamend 1 smilee with Dissolve(0.2)
                    spamton "EAHAEHAHAHAH!!{p=0.2}{noalt}*{/noalt} HOW [[cheese] CAN YOU GET?!"
                    show spamend 1 frown with Dissolve(0.5)
                    spamton "NOBODY [[cares].{p=0.2}{noalt}*{/noalt} EVERY{space=80}{w=0.2} PUTS THEMSELVES [[First Place!]."
                    show spamend 1 smile with Dissolve(0.5)
                    spamton "EVEN IF THEY SAY THEY DON'T,{w=0.2} THEY'RE {noalt}[[$#!$]ING{/noalt}{alt}beeping{/alt} [[lie]ING!!!"
                    spamton "LYEING TO [[themself], LYING TO [[you]..."
                    pause 1.0
                    show spamend 1 static with Dissolve(0.5)
                    spamton "[[Always] LYING..."
                    
        "I want you to stop this":
            show spamend 1 glaree with Dissolve(0.5)
            spamton "WHAT?"
            spamton "[[stopsign.png] WHAT??"
            show spamend 1 angrye with Dissolve(0.2)
            spamton "YOU'RE THE ONE WHO{p=0.2}{noalt}*{/noalt} THE ONE WHO{p=0.2}{noalt}*{/noalt} THE ONE WHO"
            spamton "THE ONE WHO [[Press {noalt}START]ED{/noalt}{alt}started{/alt} THIS!!"
            menu:
                rq "THE ONE WHO [[Press {noalt}START]ED{/noalt}{alt}started{/alt} THIS!!"
                "I don't want to give you my SOUL":
                    $ spam_want = "stoplove"
                    show spamend 1 glaree with Dissolve(0.5)
                    spamton "SO YOU OFFER YOUR [[Heart] INSTEAD?!{p=0.2}{noalt}*{/noalt} YOU THINK I'LL ACCEPT A [[Substitution in the recipe]?!"
                    spamton "YOU WANT A [[Commemorative Ring {noalt}(c){/noalt}{alt}copyright{/alt}1997] FROM SPAMTON G. SPAMTON AT THE PRICE OF [[looking] AND [[sounding] PRETTY?!"
                    show spamend 1 angrye with Dissolve(0.2)
                    spamton "YOUR [[pretty] WORDS ARE WORTH [[Absolutely] NOTHING!!!"

                "I want to be with someone else":
                    $ spam_want = "stop"
                    if persistent.deals:
                        show spamend 1 strugglee with Dissolve(0.2) 
                        spamton "YOU'RE [[breaking up with] THE DEAL?!"
                        spamton "YOU DON'T EVEN WANT [[complimentary] [[Commemorative Ring {noalt}(c){/noalt}{alt}copyright{/alt}1997] ?!"
                        show spamend 1 glaree with Dissolve(0.2) 
                        spamton "WHATEVER I DIDN'T REALLY CARE THAT MUCH ANYWAY."
                        spamton "YOU'RE LUCKY THIS WASN'T A [[The contract] !!"
                    else:
                        show spamend 1 angry with Dissolve(0.2)
                        spamton "EAHEHAHEH!!{w=0.2} YOU THINK THAT I CARE?!"
                        spamton "I DON'T WANT [[you] ANYWAY!!"
                        show spamend 1 pained with Dissolve(0.5)
                        spamton "YOU'RE TOO [[I miss{space=100}.] ALL THE TIME"

        "Nothing" if spam_want != "nothing":
            $ spam_want = "nothing"
            show spamend 1 struggle with Dissolve(0.5)
            spamton "STOP {noalt}[[$#!^]ING{/noalt}{alt}beeping{/alt} LYING TO ME!"
            show spamend 1 pained with Dissolve(0.5)
            spamton "OR ARE YOU [[Lyeing] TO [[Yourself] ?"
            spamton "YOU CAN'T WANT [[nothing.]{p=0.5}{noalt}*{/noalt} NOBODY WANTS [[nothing.]"
            pause 1.0
            show spamend 1 frown with Dissolve(0.5)
            spamton "EVERYTHING {noalt}IS{/noalt}{alt}is{/alt} A [[Deal or No ]{p=0.5}{noalt}*{/noalt} EVERYTHING {noalt}IS{/noalt}{alt}is{/alt} A [[Business Transaction]"
            spamton "YOU [[want] SOMETHING,{w=0.5} YOU DO SOMETHING TO\n[[Get It.]"
            spamton "IF YOU WANT NOTHING,{w=0.5} YOU [[Do Nothing]."
            show spamend 1 angrye with Dissolve(0.5)
            spamton "BUT YOU'RE [[Here.],{w=0.2} DOING [[something]!!"
            spamton "WHICH MEANS YOU [[Want.]{w=0.5} [[[[Something.]]"
            pause 1.0
            jump end_menu_wants

    pause 2.0
    show spamend 1 glaree with Dissolve(0.5)
    spamton "WHAT ARE YOU DOING [[standing there like a fool]{p=0.2}{noalt}*{/noalt} YOU CAN SIT DOWN."
    play sfx cloth
    pause 1.0
    show spamend 2 glaree with Dissolve(1.0)
    pause 3.0
    spamton "[persistent.mc!u]."
    show spamend 2 frown with Dissolve(0.5)
    spamton "DO YOU KNOW WHY{p=0.5}{noalt}*{/noalt} THE REASON I NEED YOUR [[[[ Light. ]]"
    menu:
        rq "DO YOU KNOW WHY\n{noalt}*{/noalt} THE REASON I NEED YOUR [[[[ Light. ]]"
        "I don't know.":
            spamton "OK."
            spamton "LET ME.{w=0.2} TELL YOU"

        "I already know." if persistent.playthru:
            $ spam_noexplain = True
            show spamend 2 deadpan with Dissolve(0.5)
            spamton "YOU [[do]??"
            spamton "HOW????"
            show spamend 2 strugglee with Dissolve(0.2)
            spamton "{noalt}IS{/noalt}{alt}is{/alt} [[[[ He ]] JUST MAKING A LAUGHING STOCK OF MY [[You Failed] ?!?!"
            spamton "TELLING EVERYONE HOW MUCH OF A [[joyride] MY LIFE {noalt}IS{/noalt}{alt}is{/alt}?!"
        
        "I don't want to know.":
            $ spam_noexplain = True
            show spamend 2 glaree with Dissolve(0.2)
            spamton "WOW OK."
            spamton "I GUESS I WON'T [[pour my heart out] FOR YOU!!"
    
    if not spam_noexplain:
        show spamend 2 smile with Dissolve(0.5)
        spamton "I USED TO BE A [[{color=[c_power]}BIG SHOT{/color}]] !"
        spamton "THE BIGGEST...{w=0.5} [[Bigger and better than Ever!]"
        show spamend 2 angrye with Dissolve(0.5)
        spamton "EAHEHAEH!{p=0.5}{noalt}*{/noalt} [[Website Advertisements] NEVER THOUGHT I COULD DO {noalt}IT{/noalt}{alt}it{/alt}."
        spamton "THOSE [[sloppy sams] ALWAYS BRUSHED ME ASIDE."
        show spamend 2 struggle with Dissolve(0.2)
        spamton "THEY JUST PITIED ME!!"
        spamton "THEY DIDN'T [[cared] ABOUT ME ONE BIT!!!"
        show spamend 2 angry with Dissolve(0.5)
        spamton "I PROVED THEM WRONG!!{w=0.2} FOR A YEAR!!"
        show spamend 2 struggle with Dissolve(0.5)
        spamton "...{w=0.2} WITH SOME [[]{p=0.5}{noalt}*{/noalt} WITH SOME [[[[ Help ]]"
        pause 1.0
        show spamend 2 frown with Dissolve(0.5)
        pause 1.0
        spamton "{noalt}B{/noalt} BUT NOW..."
        spamton "THANKS TO [[deals with the devil] [[Gone Wrong],"
        show spamend 2 static with Dissolve(0.5)
        spamton "I'M JUST ONE OF THE [[little guys]"
        spamton "I'M JUST ONE OF THE [[Delete Files?] THAT CALLS THE [[Recycle Bin] [[Home Sweet Home.]"
        show spamend 2 angrye with Dissolve(0.5)
        spamton "I TRIED TO [[Press [[F1] for] MORE [[[[ Help. ]]"
        spamton "BUT [[[[ He ]] LEFT ME,{p=0.5}{noalt}*{/noalt} [[he] LEFT ME,{p=0.5}{noalt}*{/noalt} [[They all]{w=0.2} LEFT "
        show spamend 2 static with Dissolve(0.2)
        pause 3.0
        show spamend 2 struggle with Dissolve(0.2)
        spamton "{color=[c_vessel]}[[{space=80}]{/color}{alt}redacted{/alt} LEFT ME IN THE DUST, TOO!!"
        spamton "[[Beat me up] LIKE I WAS SOME KIND OF [[salami]!!{w=0.2} CAN YOU BELIEVE THEM??"
        show spamend 2 smile with Dissolve(0.5)
        spamton "I FOLLOWED THEM AFTER THAT THOUGH."
        spamton "I SNUCK BACK INTO THAT [[immense maison] WHILE THEY KEPT EVERYONE [[Occupied!]"
        spamton "I JUST NEEDED TO GET...{w=0.5} MY HANDS ON......"
        pause 1.0
        show spamend 2 frown with Dissolve(0.5)
        spamton "...{w=0.2} BUT {noalt}IT{/noalt}{alt}it{/alt} [[{noalt}0/5{/noalt}{alt}zero out of five{/alt} Stars, Didn't Work].{p=0.5}{noalt}*{/noalt} I GOT STUCK IN [[LoadedDisk] [[with no escape]"
        spamton "THE ONE WHO {noalt}UN[[Loaded]{/noalt}{alt}unloaded{/alt} ME..."
        show spamend 2 pained with Dissolve(0.5)
        spamton "I THOUGHT {noalt}IT{/noalt}{alt}it{/alt} WAS [[[[ Him. ]]"
        spamton "BUT [[ He's ]] DIFFERENT.{p=0.2}{noalt}*{/noalt} HE'S DIFFERENT."
        spamton "HE OFFERED ME [[[[ {color=[c_kindness]}Freedom{/color} ]]..."
        show spamend 2 smile with Dissolve(0.5)
        spamton "AND THE [[desperate little {noalt}&!^(#]{/noalt}{alt}beep{/alt} THAT I AM I TOOK {noalt}IT{/noalt}{alt}it{/alt} [[No questions asked] !!"
        show spamend 2 pained with Dissolve(0.5)
        spamton "[[Haven't I learned anything...?]?!"
        spamton "[[Never take candy from] SHADY FREAKS IN THE [[[[ Void ]] !!"
        pause 1.0
        show spamend 2 glaree with Dissolve(0.2)
        spamton "...{w=0.2} WHAT ARE YOU LOOKING AT ME FOR??"
    
    show spamend 2 glare with Dissolve(0.5)
    spamton "WHATEVER."
    spamton "[persistent.mc!u].{w=0.2} MY POINT {noalt}IS{/noalt}{alt}is{/alt}.{p=0.5}{noalt}*{/noalt} YOU CAN'T DEPEND ON ANYONE.{p=0.5}{noalt}*{/noalt} YOU CAN'T [[trust] ANYONE."
    show spamend 2 angry with Dissolve(0.5)
    spamton "THE ONLY [[Feel Good{noalt}, Inc.]{/noalt}{alt}ink{/alt} HERE {noalt}IS{/noalt}{alt}is{/alt} THE [[D.I.Y.] KIND."
    spamton "ALL ANY[[one] CARES ABOUT {noalt}IS{/noalt}{alt}is{/alt} [[\"Me, Myself, and I\"].{p=0.5}{noalt}*{/noalt} NOBODY [[actually] WANTS TO HELP [[the little guy]"
    spamton "[[[[ BIG {noalt}SHOT ]]S{/noalt}{alt}shots{/alt} SPEND SO MUCH TIME [[kissing their own ass] ABOUT {noalt}IT{/noalt}{alt}it{/alt}..."
    show spamend 2 struggle with Dissolve(0.5)
    spamton "THEY DON'T CARE!!{p=0.5}{noalt}*{/noalt} THEY JUST CARE ABOUT YOUR [[money] !!"
    spamton "[[Got] NO MONEY?!{w=0.2} [[Look no further,{w=0.2} you ] WILL BE THROWN STRAIGHT INTO {noalt}[[h3llfire]{/noalt}{alt}hellfire{/alt} WITH EVERYTHING ELSE!!!"
    show spamend 2 pained with Dissolve(0.5)
    spamton "YOUR [[Friends],{w=0.2} YOUR [[Time],{w=0.2} YOUR [[Effort],{w=0.2} YOUR [[Passion],{p=0.5}{noalt}*{/noalt} {noalt}IT{/noalt}{alt}it{/alt} MEANS NOTHING!"
    show spamend 2 smile with Dissolve(0.5)
    spamton "EAHEAHEH,{w=0.2} SO IF {noalt}IT{/noalt}{alt}it{/alt} DOESN'T MATTER HOW [[Nice Guy] OR [[HonestMan] I AM--"
    show spamend 2 frown with Dissolve(0.5)
    spamton "THEN WHY SHOULD I DO ANYTHING DIFFERENT"
    show spamend 2 pained with Dissolve(0.5)
    spamton "IF TRYING TO [[cared] JUST GETS ME [[used],{w=0.5}\nWHY EVEN BOTHER"
    pause 1.0
    show spamend 2 glaree with Dissolve(0.5)
    spamton "EVERY[[1] WANTS SOMETHING."
    show spamend 2 static with Dissolve(0.5)
    spamton "NOTHING {noalt}IS{/noalt}{alt}is{/alt}{w=0.2}.{w=0.2}.{w=0.2}.{w=0.5} [[[[ free ]]."
    pause 3.0
    show spamend 2 angrye with Dissolve(0.2)
    if persistent.glitches:
        spamton "AND IF ACCEPTING THAT MAKES ME A [[Greedy] [[Heartless] {noalt}[[&!^(#]{/noalt}{alt}beep{/alt} SO BE {noalt}IT{/noalt}{alt}it{/alt}!!!"
    else:
        spamton "{sc=2}AND IF ACCEPTING THAT MAKES ME A {/sc}[[{sc=2}Greedy{/sc}]\n[[{sc=2}Heartless{/sc}] [[{sc=2}&!^(#{/sc}],{w=0.2} {sc=3}SO BE IT!!!{/sc}"
    pause 2.0
    show spamend 2 frown with Dissolve(0.5)
    pause 1.0
    spamton "[persistent.mc!u]."
    show spamend 2 deadpan with Dissolve(0.5)
    spamton "YOU'RE [[not] A LiGHTNER,{w=0.2} ARE YOU?"
    spamton "YOURE [[Something Else]."
    spamton "YOU ARE [[{color=[c_passion]}Even Bigger Than{/color} ],{w=0.5} aREN'T YOU ?"
    pause 2.0
    show spamend 2 glare with Dissolve(0.5)
    spamton "THIS {noalt}[[$&#!]ING{/noalt}{alt}beeping{/alt} BLOWS."
    spamton "{cps=25}[[How far does it go?]{/cps}"
    spamton "HOW LONG UNTIL I'M [[a Real Boy]?!"
    show spamend 2 pained with Dissolve(0.5)
    spamton "I'M SO [[tired of life dragging ] [[[[Down the Drain, Drain]]."
    spamton "I'VE TRIED [[everything you can imagine] !!!!"
    show spamend 2 angrye with Dissolve(0.5)
    spamton "AND I'M STILL [[[[Living in a Goddamn Garbage Can]]"
    show spamend 2 static with Dissolve(0.2)
    spamton "[[it's so dark.]"
    spamton "[[[[What does the Light even look like?]]"
    spamton "IF I REACH [[[[ Heaven ]]...{w=1.0} would I even be happy?"
    show spamend 2 pained with Dissolve(0.5)
    spamton "Would anything actually change at all?"
    spamton "Is this SOUL fake,{w=1.0} or is it something else...?"
    pause 2.0

    scene black with Dissolve(2.0)
    pause 2.0
    scene junkyard6 with Dissolve(2.0)
    pause 1.0
    show spamton standing down frown at spampos_center with Dissolve(1.0)
    spamton "[persistent.mc!u]."
    spamton "HOW DO {color=[c_passion]}YOU{/color} DEFINE.{w=0.5} \"FREEDOM.\""
    menu:
        rq "HOW DO {color=[c_passion]}YOU{/color} DEFINE. \"FREEDOM.\""
        "Making your own choices":
            spamton "CALLING YOUR OWN [[Shots]?{nw=0.2}"
            show spamton crazy laugh at jump
            extend "{p=0}{noalt}*{/noalt} YEAH,{w=0.2} I THOUGHT THAT [[2]"
            show spamton standing down panic
            spamton "I THOUGHT [[the Dark] WAS [[[[ Prewritten ]] [[silly strings]"
            show spamton slouch down frown
            spamton "BUT IF THIS [[[[ {color=[c_kindness]}Light{/color} ]] {noalt}IS{/noalt}{alt}is{/alt} [[Mirror Match]"
            spamton "AND IF [[Cathode] {noalt}IS{/noalt}{alt}is{/alt} STILL{p=0.2}{noalt}*{/noalt} {noalt}IS{/noalt}{alt}is{/alt} STILL{p=0.2}{noalt}*{/noalt} Is still{w=0.2}.{w=0.2}.{w=0.2}."
            show spamton slouch down static at droop
            spamton "Then...{w=0.5} is that really true?"

        "Doing anything you want without consequence":
            show spamton standing up glaree
            pause 1.0
            show spamton standing tilt laugh at jump
            spamton "DOES THAT EVEN {noalt}EXIXsT??/{/noalt}{alt}exixt?{/alt}"
            show spamton slouch down smile
            spamton "{noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt} REALLY FREEDOM IF [[Nothing happens.]?"
            spamton "I THINK THAT'S CALLED [[Nothing ]."
            show spamton slouch down panic
            spamton "MAYBE THAT'S WHY"
            pause 1.0
            show spamton slouch down frown at droop
            spamton "MAYBE THAT'S WHY [[There's no such thing as a free lunch.]"

        "The absence of fear":
            show spamton standing up frown at xwiggle
            spamton "REALLY???{p=0.5}{noalt}*{/noalt} HUH I WOULDN'T HAVE GUESSED [[you thought] THAT."
            show spamton at yreset
            pause 1.0
            show spamton standing down frown
            spamton "...{w=0.2} BUT IT'S NOT [[Wrong!]"
            show spamton slouch down panic
            spamton "AM I JUST [[Afraid of ]"
            show spamton slouch down frown
            pause 2.0
            $ _history = False
            spamton_shh ".{w=0.2}.{w=0.2}.{nw=0.2}"
            $ _history = True
            show spamton at droop
            spamton "...{fast} WHAT, EXACTLY."
            if persistent.glitches:
                show spamton crazy frantic
            else:
                show spamton crazy frantic at shakingcg
            spamton "[[Change] ?{w=0.5} BUT I WANT [[[[ Change ]] ???"
            show spamton at yreset
            pause 1.0
            show spamton slouch down frown at droop
            pause 1.0
            spamton "THIS MAKES NO SENSE."
            show spamton slouch down smile
            spamton "BUT.{w=0.2} THEN AGAIN,"
            show spamton standing down panic
            spamton "WHAT DOES??"
        
        "It's not real":
            show spamton standing tilt laugh at jump
            spamton "EAHEHAHAH!!{p=0.2}{noalt}*{/noalt} I CAN'T [[Disagree]"
            show spamton standing down panic
            spamton "SURE AS {noalt}[[$#!]T{/noalt}{alt}beep{/alt} SEEMS THAT WAY."
            show spamton slouch down frown
            spamton "{noalt}IS{/noalt}{alt}is{/alt} ANY OF THIS [[real]?"
            show spamton slouch down panic
            spamton "IF {color=[c_kindness]}THIS SOUL{/color} ISN'T EVEN [[Real],{w=0.2} WHAT {noalt}IS{/noalt}{alt}is{/alt}"
            show spamton slouch down static
            spamton "[[I wanna be a] [[RealBoy],{w=0.2} BUT WHAT THE [[dump] DOES THAT EVEN MEAN?!"

    pause 2.0
    show spamton standing down frown
    spamton "FINE.{w=0.5} [persistent.mc!u]?"
    show spamton standing up glaree
    spamton "[[You win!]."
    show spamton crazy laugh at xwiggle
    spamton "EVEN I DON'T KNOW WHAT I [[want]"
    show spamton standing down panic at yreset
    spamton "[[{color=[c_passion]}Your Heart-ShapedObject{/color}] WOULD NOT FIX THAT."
    spamton "[[{color=[c_kindness]}mine{/color}] DID NOT FIX THAT."
    show spamton standing tilt laugh at jump
    spamton "SO I GUESS WE'RE JUST STUCK HERE!!!{w=0.2} [[Deal's Off]!!!{w=0.2} EAHEHAHE!!!"
    show spamton standing up frown flipped at jump
    spamton "JUST{p=0.5}{noalt}*{/noalt} ONE MORE THING,"
    play sfx plop
    pause 1.0
    "Spamton pulled the ring out from his pocket."
    "He stared at it in his hand for a while..."
    pause 1.0
    show spamton standing down frown at jump
    spamton "I'LL LET YOU [[[[take this off my hands]] [[At no cost to you!]."
    show spamton standing up smile
    spamton "[[You heard that right:] JUST TAKE {noalt}IT{/noalt}{alt}it{/alt}!!"
    show spamton standing down frown
    spamton "AT ONE POINT THIS WAS IMPORTANT TO ME.{p=0.5}{noalt}*{/noalt} BUT I DON'T GIVE A RAT'S [[patootie] ABOUT THAT ANYMORE."
    show spamton standing down panic
    spamton "I [[Do not] CARE WHAT YOU DO WITH {noalt}IT{/noalt}{alt}it{/alt}.{p=0.5}{noalt}*{/noalt} [[Drown] {noalt}IT{/noalt}{alt}it{/alt} IN [[apple juise] OR [[cow juice] OR [[boiling juice] OR [[whatever] [[Juice.]"
    show spamton panic up screame at jump
    spamton "BUT {noalt}DONn''T{/noalt}{alt}don't{/alt} GET ANY [[silly goose] IDEAS!!{p=0.5}{noalt}*{/noalt} THIS ISN'T FOR [[merry]AGE!!"
    show spamton crazy frantic at xwiggle
    if spam_want == "love" or spam_want == "stoplove":
        spamton "I\"M A [[Business Loving Businessman] BUT YOUR TOO [[so serious?] ABOUT THIS!!"
    elif spam_want == "stop":
        spamton "JUST SO WE'RE [[Crystal Clear] !!!{p=0.2}{noalt}*{/noalt} I KNOW YOU DON'T WANT THAT, AND NEITHER DO I!!"
    else:
        spamton "I'M JUST GIVING YOU A [[good ol'] PIECE OF TRASH!!"
    show spamton slouch down frown at droop
    pause 2.0
    show spamton slouch down panic
    spamton "I'M NOT A [[touchy-feely] [[kinda guy],{w=0.2} BY THE WAY"
    spamton "SO YOU'RE NOT GETTING THAT [[Comfort him] HUG FROM EARLIER."
    show spamton standing down frown at jump
    spamton "[[This is my final offer!]."
    play sfx sparkleglock
    show itemframe i_ring at truecenter with easeinbottom
    "Spamton gave you [itm_ring.name]."
    play sfx item
    $ inventory.append(itm_ring)
    "You put it on your finger for safe keeping.{w=0.2} It was added to your ITEMS."
    hide itemframe with easeoutbottom
    pause 1.0
    show spamton standing up glare
    spamton "SO."
    show spamton standing up glaree
    spamton "[[What now]."
    show spamton standing tilt laugh at jump
    spamton "WE'RE TRAPPED IN [[metapohrical] {noalt}[[H3LL]{/noalt}{alt}hell{/alt} SO??"
    "An idea crosses your mind..."

    ## AUTOSAVE
    $ renpy.save("mainfile")

    menu spamend_choice:
        rq "(An idea crosses your mind...)"

        ### GO BACK TO EXPLORE / SEE TENNA ENDING
        "Try to find Tenna":
            "If you choose this option,{w=0.2} you will be able to explore around more."
            menu:
                rq "(If you choose this option, you will be able to explore around more.)"
                "Yes":
                    "You tell Spamton you're going to try and keep looking for Tenna."
                    show spamton standing up glare
                    spamton "REALLY??{p=0.2}{noalt}*{/noalt} SEEMS LIKE A [[Waste Management] OF TIME TO ME BUT I CAN'T STOP YOU"
                    show spamton crazy smirk at xwiggle
                    spamton "WHO KNOWS??{p=0.2}{noalt}*{/noalt} MAYBE HE'S [[deceased] BY NOW"
                    show spamton crazy laugh
                    spamton "EAEHAHEHAHEH!!"
                    show spamton standing up smile at jump
                    pause 1.0
                    show spamton standing up glaree
                    spamton "WOW YOU REALLY [[anon {noalt}hate]D{/noalt}{alt}hated{/alt} THAT ONE."
                    show spamton standing up glare
                    spamton "WHATEVER,{w=0.2} [[desperate little ].{p=0.5}{noalt}*{/noalt} DO WHATEVER YOU WANT."
                    spamton "I'M GOING BACK TO [[my humble little shop] OF TRASH.{p=0.2}{noalt}*{/noalt} IF YOU NEED ME."

                "No":
                    jump spamend_choice
        
        ### SPAMTAT ENDING
        "Bring \"Mike\" here" if mke_success:
            "If you choose this option,{w=0.2} you may get the ending with Spamton and \"Mike\" or pivot to another ending."
            menu:
                rq "(If you choose this option, you may get the ending with Spamton and \"Mike\" or pivot to another ending.)"
                "Yes":
                    $ end_spamtat = "started"

                    "You told Spamton there was someone other than Tenna you wanted to introduce to him."
                    show spamton standing up stare at jump
                    spamton "[[Who] NOW??"
                    show spamton panic up screame at jump
                    spamton "YOU'RE TELLING ME THERE'S OTHER [[reanimated corpses] IN THIS [[scrap pile] ?!"
                    show spamton crazy angry
                    spamton "YIKES!!{p=0.5}{noalt}*{/noalt} THAT'S [[disgustang]!!"
                    show spamton standing up smile at jump
                    spamton "BUT I'M [[board] ENOUGH SO, SURE,{w=0.2} [[Knock yourself out]."
                    if persistent.glitches:
                        show spamton standing up stare
                    else:
                        show spamton standing up stare at shakingcg
                    spamton "I'LL GO BACK TO MY [[Little Shop of] JUNK [[In the meantime,]"
                    spamton "YOU'LL HAVE TO [[drag and drop] THEIR {noalt}@$${/noalt}{alt}beep{/alt} OVER THERE YOURSELF!!"

                "No":
                    jump spamend_choice

        ### SPAMTON ONLY ENDING
        "Tell Spamton about the plan":
            "If you choose this option,{w=0.2} you will lock into the ending with only Spamton."
            menu:
                rq "(If you choose this option, you will lock into the ending with only Spamton.)"
                "Yes":
                    jump ending_spamton_only

                "No":
                    jump spamend_choice
    
    stop music fadeout 2.0
    play sfx waterwalk
    hide spamton with Dissolve(1.0)
    stop sfx fadeout 3.0
    pause 2.0
    jump pickup_endings


######################################################
##### SPAMTON ONLY END
label ending_spamton_only:
    "You tell Spamton that you might know a way to get him out of here."
    if spam_cancel:
        play music faintcourageSo
    show spamton standing up frown at jump
    spamton "YOU [[what]?"
    show spamton standing up glare
    spamton "SINCE WHEN ARE YOU [[Interested in our new products?] ABOUT MY [[Place of Residence]?"
    menu:
        rq "SINCE WHEN ARE YOU [[Interested in our new products?] ABOUT MY [[Place of Residence]?"
        "I don't want to be here either":
            "You say that you're not really a fan of this place,{w=0.2} either."
            pause 1.0
            show spamton slouch down frown
            spamton "{w=0.2}.{w=0.2}.{w=0.2}."
            pause 2.0

        "Do you want to be here?":
            "You ask Spamton if he actually wants to be here."
            pause 1.0
            show spamton slouch down frown
            spamton "{w=0.2}.{w=0.2}.{w=0.2}."
            pause 1.0
            show spamton standing down smile
            spamton "WELL.{p=0.5}{noalt}*{/noalt} [[No way!]?"
            show spamton standing up smile at xwiggle
            spamton "HAVE YOU [[Look around] THIS PLACE??{p=0.5}{noalt}*{/noalt} IT'S WORSE THAN A [[toilet that just won't flush]!"
            show spamton slouch down frown at droop
            spamton "[[However]..."

    show spamton slouch down static
    spamton "I THOUGHT YOU WANTED TO [[X marks the spot] {noalt}[[Cathode]'s{/noalt}{alt}cathode's{/alt} [[Current Location]."
    show spamton slouch down panic at jump
    spamton "YOU DIDN'T [[Changed your mind?],{w=0.5} DID YOU?"
    pause 2.0
    show spamton standing up stare at jump
    spamton "OH [[Good Gravy]."
    show spamton crazy laugh at jump
    spamton "[[YOU'RE telling ME] THAT YOU'D [[actually] RATHER SPEND TIME WITH SPAMTON G. SPAMTON INSTEAD OF{space=100}?"
    show spamton at xwiggle
    spamton "I'M [[The very same] GUY WHO TRIED TO [[rip] YOUR [[heart] OUT OF YOUR [[still-beating chest] !?"
    if persistent.glitches:
        show spamton crazy frantic
    else:
        show spamton crazy frantic at shakingcg
    spamton "OR ARE YOU JUST COMPLETELY [[Tired of ] [[begging and pleading for] HIM TO CRAWL OUT OF THE [[wet and soggy] [[Dirt] ?!"
    show spamton standing tilt laugh at xwiggle
    spamton "EAHAHEAHEH!!{p=0.5}{noalt}*{/noalt} [[That makes two of us.]"
    if persistent.glitches:
        show spamton slouch down static at yreset
    else:
        show spamton slouch down static glitch at yreset
    pause 2.0
    show spamton at droop
    spamton "...{w=0.5} [[buy MORE] OR [[spend LESS],{w=0.2} ANYWAY."
    pause 2.0
    show spamton standing down static at droop
    spamton "AFTER ALL THAT I DID{p=0.5}{noalt}*{/noalt} [persistent.mc!u]...{w=0.5} YOU STILL WANT TO [[send assistance] ME?"
    show spamton standing down smile
    spamton "YOU'RE REPAYING MY [[violent tendencies] WITH [[Genorisity] ??"
    show spamton crazy laugh at xwiggle
    spamton "EAHAHEAHEH!!{w=0.2} [persistent.mc!u]!{p=0.5}{noalt}*{/noalt} YOU'RE [[a real] STRANGE [[one]."
    show spamton standing down frown at yreset
    spamton "BUT"
    pause 1.0
    show spamton standing down panic
    spamton "I CAN'T SAY I DON'T [[Endless Appreciation] {noalt}IT{/noalt}{alt}it{/alt}."
    pause 2.0
    show spamton standing up frown at jump
    spamton "OK.{p=0.5}{noalt}*{/noalt} FINE."
    show spamton standing up frowne
    spamton "LET'S [[ditch this popsicle stand]."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    "You guide Spamton to where you found that mattress and met the mystery man earlier."

    ### TRANSITION TO UNIVERSAL ENDING 
    $ end_spamton = True
    jump ending_universal



######################################################
##### SPAMTON BAD END
label ending_spamton_bad:
    show spamton crazy angry at xwiggle zorder 1
    spamton "EAHEHEHAHAH!!!"
    show spamton crazy frantic
    spamton "I SHOULD HAVE KNOWN!!{p=0.2}{noalt}*{/noalt} {noalt}IT{/noalt}{alt}it{/alt} WAS ALWAYS A [[Lie] !!"
    if persistent.glitches:
        show spamton standing down panic flipped
    else:
        show spamton standing down panic flipped at shakingcg
    spamton "[[[[ Heaven ]] LIED TO ME!{p=0.2}{noalt}*{/noalt} [[[[ He ]] LIED TO ME!!{p=0.2}{noalt}*{/noalt} [[ CRTs ] LIED TO ME!!!"
    show spamton standing up frowne
    spamton "[[ {color=[c_passion]}YOU{/color} ] LIED TO ME!!!!"
    show spamton standing up stare at yreset
    spamton "[[Get lost.]"
    if persistent.glitches:
        show spamton crazy angry at jump
    else:
        show spamton crazy angry at shock
    spamton "YOU WERE JUST [[Use ]ING ME,{w=0.2} LIKE EVERY[[1] ELSe!!"
    if persistent.glitches:
        show spamton crazy frantic
    else:
        show spamton crazy frantic at shakingcg
    spamton "EAHEHAAHEHA!!{p=0.2}{noalt}*{/noalt} YOU DON'T EVEN HAVE [[Freedom] DO YOU?!?!"
    show spamton standing up frowne at yreset
    spamton "WITHOUT [[ FREEDOM ] YOU ARE [[nothing] TO ME"
    show spamton standing up stare
    spamton "I''m NOT [[For You Page] AMUSEMENT!!!"
    spamton "I'M NOt [[Here.] TO MAKE YOU [[Fameus]!!"
    show spamton crazy avert at jump
    spamton "I {noalt}w W wwWANT{/noalt}{alt}wwant,{/alt}{nw=0.1}"
    show strings zorder 0:
        xalign 0.52
    if persistent.glitches:
        show spamton slouch down static at jump
        show soulgrn_whole zorder 2:
            xpos 0.47
            ypos 0.54
    else:
        show spamton slouch down static glitch at shock
        show strings at shakingcg
        show soulgrn_whole at shaking zorder 2:
            xpos 0.47
            ypos 0.54
    spamton "[[KLKCHD4, 04,]--"

    ### TRIPLE HEARTBREAK
    call heartbreak_triple_ani from _call_heartbreak_triple_ani_2
    
    hide soulgrn_whole
    hide strings
    spamton "{noalt}$&#X{/noalt}{alt}beep{/alt} !!{nw=0.2}"
    if persistent.glitches:
        show spamton at jump
        extend " DAMMIT !!"
        show spamton crazy angry
    else:
        show spamton at shock
        extend " DAMMIT !!"
        show spamton crazy angry at shakingcg
    spamton "{noalt}[[&#!X]{/noalt}{alt}beep{/alt} YOU!{p=0.2}{noalt}*{/noalt} {noalt}[[&#!X]{/noalt}{alt}beep{/alt} YOU!!!"
    stop music fadeout 2.0
    play sfx runaway
    hide spamton with easeoutleft
    pause 1.5
    "Spamton ran away."
    "He might never return..."
    jump pickup_endings