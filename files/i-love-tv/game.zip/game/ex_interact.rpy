############################################################################################################
################## TENNA INTERACTS
label ten_interact:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse
    hide screen ex_north
    
    ### BEFORE TRIPLE ENDING
    if not end_triple == "done":
        show tenna upright chest neutral at tenpos_center with Dissolve(0.2)
        show tenna at jump
        tenna "Oh!{p=0.5}{noalt}*{/noalt} [persistent.mc], you're back...{w=0.2} alone?"
        show tenna upright chest panic at jump
        tenna "Haha,{w=0.2} did you forget something?"
        menu ten_menu:
            rq "Haha, did you forget something?"
            "Talk":
                jump ten_talk

            "Act":
                menu ten_act:
                    rq "Act"
                    "Lead him to \"Mike\" instead" if mke_success and end_battenna != "started" and end_spamtenna == "started":
                        "If you choose this option,{w=0.2} you may get the ending with Tenna and \"Mike.\""
                        menu:
                            rq "(If you choose this option, you may get the ending with Tenna and \"Mike.\")"
                            "Yes":
                                $ end_spamtenna = None
                                $ end_battenna = "started"
                                $ ten_swap += 1

                                "You tell Tenna that there's a change of plans,{w=0.2} and that he should follow you to the other side of the Dark World."
                                call ten_interact_swap from _call_ten_interact_swap
                                show tenna upright pointing oh at jump
                                tenna "Lead the way, [persistent.mc]."
                                scene black with Dissolve(1.0)
                                play sfx waterwalk
                                pause 1.0
                                "You led Tenna back to the side of the Dark World where you met \"Mike,\"{w=0.2} but told Tenna to wait out of sight for a bit."
                                pause 1.0
                                scene junkyard5 with Dissolve(1.0)
                                pause 1.0
                                jump mike_interact
                            
                            "No":
                                jump ten_act

                    "Show him Spamton instead" if end_battenna == "started":
                        "If you choose this option,{w=0.2} you may get the ending with Tenna and Spamton or another ending."
                        menu:
                            rq "(If you choose this option, you may get the ending with Tenna and Spamton or another ending.)"
                            "Yes":
                                $ end_battenna = None
                                $ end_spamtat = None
                                $ end_spamtenna = "started"
                                $ ten_swap += 1
                                
                                "You tell Tenna that there's a change of plans,{w=0.2} and that he should go back to his side of the Dark World."
                                call ten_interact_swap from _call_ten_interact_swap_1
                                show tenna upright pointing oh at jump
                                tenna "I'll see you in a little bit, then."
                                scene black with Dissolve(1.0)
                                play sfx waterwalk
                                pause 1.0
                                "You trudged off to meet Spamton at his shop."
                                pause 1.0
                                scene junkspam with Dissolve(1.0)
                                pause 1.0
                                jump spam_interact
                            
                            "No":
                                jump ten_act

                    "Bring Spamton here" if end_spamtat == "started" or cont_reload:
                        "If you choose this option,{w=0.2} you may get the ending with Tenna and Spamton or another ending."
                        menu:
                            rq "(If you choose this option, you may get the ending with Tenna and Spamton or another ending.)"
                            "Yes":
                                $ end_spamtenna = "started"
                                $ end_battenna = None
                                $ end_spamtat = None

                                "You said you'll be right back with someone else."
                                show tenna upright back awkward at jump
                                tenna "Oh,{w=0.2} no worries,{w=0.2} [persistent.mc]!!{p=0.5}{noalt}*{/noalt} Take all the time in the world you need, haha!"
                                tenna "I'll just be right here...{w=0.5} waiting..."
                                show tenna at wiggle
                                tenna "Alone{w=0.2}.{w=0.2}.{w=0.2}."
                                scene black with Dissolve(1.0)
                                play sfx waterwalk
                                pause 1.0
                                "You trudged off to find Spamton at his shop."
                                pause 1.0
                                scene junkspam with Dissolve(1.0)
                                pause 1.0
                                jump spam_interact
                            
                            "No":
                                jump ten_act

                    "Lead him to \"Mike\"" if end_spamtat == "started" or cont_reload:
                        "If you choose this option,{w=0.2} you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\""
                        menu:
                            rq "(If you choose this option, you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\")"
                            "Yes":
                                $ end_battenna = "started"
                                $ end_spamtenna = None
                                $ end_spamtat = None

                                "You told Tenna to follow you."
                                call tenna_waiting from _call_tenna_waiting_3
                                "You led Tenna back to the side of the Dark World where you met \"Mike,\"{w=0.2} but told Tenna to wait out of sight for a bit."
                                pause 1.0
                                scene junkyard5 with Dissolve(1.0)
                                play music dump
                                pause 1.0
                                jump mike_interact

                            "No":
                                jump ten_act

                    "Say you lost everyone":
                        "If you choose this option,{w=0.2} you will lock into the ending with only Tenna."
                        menu:
                            rq "(If you choose this option, you will lock into the ending with only Tenna.)"
                            "Yes":
                                $ end_battenna = None
                                $ end_spamtenna = None
                                $ ten_cancel = True
                                jump ten_interact_cancel
                            
                            "No":
                                jump ten_act
                    
                    "Return":
                        jump ten_menu

            "Not quite":
                "You said you'll be right back."
                show tenna upright back awkward at jump
                tenna "Oh,{w=0.2} no worries,{w=0.2} [persistent.mc]!!{p=0.5}{noalt}*{/noalt} Take all the time in the world you need, haha!"
                tenna "I'll just be right here...{w=0.5} waiting..."
                show tenna at wiggle
                tenna "Alone{w=0.2}.{w=0.2}.{w=0.2}."
                hide tenna with Dissolve(0.2)
                if end_battenna == "started":
                    jump ex_north
                else:
                    jump ex_tenhouse

    ### AFTER TRIPLE ENDING
    else:
        $ end_triple_ten = True
        show tenna slouch claw angry flipped at tenpos_center with Dissolve(0.2)
        if persistent.glitches:
            show tenna at jump
        else:
            show tenna at shock
        tenna "WHAT is Mike's problem?!"
        show tenna upright chest angry flipped at wiggle
        tenna "I can't believe him...{p=0.5}{noalt}*{/noalt} After ALL THAT and he STILL has the GALL to--"
        "You make your presence known with an aggressive wave."
        show tenna upright chest blank at jump
        tenna "Huh-- {nw=0.2}"
        show tenna panic panic at jump
        extend "Oh,{w=0.2} [persistent.mc]!"
        show tenna upright back panic at wiggle
        tenna "I didn't see you there,{w=0.2} haha..."
        show tenna upright pointing oh at jump
        tenna "Well,{w=0.2} what did you need?{p=0.2}{noalt}*{/noalt} Anything I can offer,{w=0.2} you can rely on good ol' Mr. Tenna to do it for you!"
        menu tenint_triple:
            rq "Well, what did you need?\n{noalt}*{/noalt} Anything I can offer, you can rely on good ol' Mr. Tenna to do it for you!"
            "Why are you mad at Mike?" if not ten_tripleswap:
                "You asked Tenna why he got so mad at Mike."
                show tenna upright chest panic at jump
                tenna "..."
                show tenna upright back nose at jump
                tenna "Don't...{w=0.5} open that can of worms right now,{w=0.2} [persistent.mc]..."
                show tenna upright back nosed at wiggle
                tenna "I don't even want to THINK about it.{p=0.2}{noalt}*{/noalt} Much less lash out at you...{w=0.5} AGAIN."
                pause 1.0
                menu:
                    "Everyone needs an outlet.":
                        "You remind Tenna that he can tell you anything."
                        pause 1.0
                        show tenna upright back nose at jump
                        tenna "Haha,{w=0.5} what ISN'T there to be mad about?"
                        show tenna slouch claw angry at jump
                        tenna "The Mike I used to know is just{nw=0.2}"
                        if persistent.glitches:
                            show tenna at jump
                        else:
                            show tenna at shock
                        extend " GONE?!{p=0.2}{noalt}*{/noalt} AND I'M JUST SUPPOSED TO ACCEPT THAT??"
                        show tenna upright chest angry at rise
                        tenna "On top of that,{w=0.2} that slimy DICE BOY is the one who took his damn place?!{p=0.2}{noalt}*{/noalt} Isn't that rich!!"
                        show tenna slouch claw angry
                        tenna "He{nw}"
                        if persistent.glitches:
                            show tenna at jump
                        else:
                            show tenna at shock
                        extend " LIED to me for{nw}"
                        if persistent.glitches:
                            show tenna at jump
                        else:
                            show tenna at shock
                        extend " YEARS!{nw=0.2}"
                        if persistent.glitches:
                            pass
                        else:
                            show tenna at shaking
                        extend "{p=0}{noalt}*{/noalt} A DECADE, even!"
                        show tenna upright chest angry
                        tenna "He acted like, for a moment,{w=0.2} he didn't want to lie anymore..."
                        show tenna slouch claw angry
                        tenna "But{nw}"
                        if persistent.glitches:
                            show tenna at jump
                        else:
                            show tenna at shock
                        extend " WHAT WAS THAT?{nw=0.2}"
                        show tenna stretch shrug weak flipped at jump
                        extend "{p=0}{noalt}*{/noalt} \"Just wants to get used to it,\" he says,{w=0.2} haha,{w=0.2} boy!{p=0.2}{noalt}*{/noalt} He's lying through his teeth,{w=0.2} STILL!"
                        show tenna upright chest angry flipped at wiggle
                        tenna "Nobody ever wants to tell me the truth...{p=0.5}{noalt}*{/noalt} Why,{w=0.2} WHY can no one ever just TELL ME the TRUTH?"
                        show tenna upright back frown at jump
                        tenna "Oh,{w=0.2} don't worry about it,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} YOU didn't do anything wrong."
                        show tenna upright chest frown
                        tenna "This is why I didn't want to say anything..."
                        pause 1.0
                        show tenna upright chest panic at rise
                        tenna "Well,{w=0.2} in other news..."
                        show tenna upright pressed smile at jump
                        tenna "I'm pleasantly surprised at how nice it was to sit and talk with Spamton for a while!{p=0.2}{noalt}*{/noalt} It's been so...{w=0.5} SO long,{w=0.2} haha."
                    
                    "...":
                        $ ten_tripleswap = True
                        jump tenint_triple

            "How were things going with Spamton?":
                if ten_tripleswap:
                    "You instead ask how things were going with him and Spamton."
                else:
                    "You asked how things are going with Spamton."
                show tenna upright chest blank at jump
                tenna "Huh?{w=0.2} Oh!"
                show tenna upright back frown at droop
                tenna "Actually...{nw=0.5}"
                show tenna upright pressed smile at rise
                extend "{p=0}{noalt}*{/noalt} BETTER THAN EVER!"
                show tenna at wiggle
                tenna "SIGNIFICANTLY better than I thought it would ever go,{w=0.2} if I'm going to be honest with you,{w=0.2} haha."
        
        show tenna upright back panic at jump
        tenna "It's obvious he still doesn't like me.{p=0.5}{noalt}*{/noalt} I suppose I can't really blame him for that..."
        show tenna upright chest smile at jump
        tenna "But I want to do my best for him!{p=0.5}{noalt}*{/noalt} I'll be a brand-new man,{w=0.2} better than I've ever been before!"
        show tenna upright pointing weak at jump
        tenna "Oh,{w=0.2} for you, too,{w=0.2} [persistent.mc],{w=0.2} haha..."
        show tenna upright back awkward at wiggle
        tenna "...{w=0.5} Gosh,{w=0.2} I really did miss him,{w=0.2} huh..."
        pause 1.0
        if persistent.glitches:
            show tenna upright pointing weak at jump
        else:
            show tenna upright pointing weak at shaking
        tenna "B-{w=0.1} but that's not important!{p=0.5}{noalt}*{/noalt} What'd you come over here to ask me about,{w=0.2} again?"
        show tenna upright back panic at wiggle
        tenna "Don't wanna take the spotlight away from you for too long,{w=0.2} haha!"
        pause 1.0
        quiet "{w=0.2}.{w=0.2}.{w=0.2}."
        menu:
            rq "..."
            "Are you actually interested in me?":
                $ ten_triplespam = True
                "You ask Tenna if he was ever actually interested in you."
                show tenna slouch claw panic at jump
                tenna "Wh--{w=0.2} [persistent.mc]!?{p=0.5}{noalt}*{/noalt} Wh-{w=0.1} where is this accusation coming from,{w=0.2} haha?!"
                if not ten_care:
                    show tenna upright pointing weak at jump
                    tenna "I already told you,{w=0.2} I'm respecting your boundaries!!"
                    show tenna upright back frown at wiggle
                    tenna "You're not interested in me,{w=0.2} so I'm not going to..."
                else:
                    show tenna upright pointing weak at wiggle
                    tenna "Of course!! I..."
                    tenna "I..."
                pause 1.0
                show tenna upright back nosed at jump
                tenna "...{w=0.5} haha."
                if ten_care:
                    show tenna at droop
                    tenna "Is it really that obvious...?"
                    show tenna at wiggle
                    tenna "I'm sorry.{w=0.5} I'm so sorry,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} Can you ever forgive me?"
                    show tenna upright chest frown at jump
                else:
                    show tenna at droop
                    tenna "This is such a strange feeling,{w=0.2} [persistent.mc]."
                    show tenna upright chest frown
                tenna "I want to love you so much.{p=0.5}{noalt}*{/noalt} You're such a wonderful person in every possible, conceivable way!"
                show tenna upright back frown
                tenna "But I barely know you.{p=0.5}{noalt}*{/noalt} I already told you--{w=0.2} I know I was trying to use you to fill the void of being alone."
                show tenna upright back panic at wiggle
                tenna "I just want to be wanted...{p=0.5}{noalt}*{/noalt} Is that really so wrong?"
                show tenna upright back frown
                tenna "Haha,{w=0.2} I suppose if I'm just treating you like a toy...{w=0.5} it's at least a little wrong."

            "Do you want to get back with Spamton?":
                $ ten_triplespam = True
                "You ask if Tenna wants to date Spamton again."
                if persistent.glitches:
                    show tenna panic flustered at jump
                else:
                    show tenna panic flustered at shock
                tenna "HUH?{nw=0.5}"
                show tenna slouch claw panic at wiggle
                extend "{p=0}{noalt}*{/noalt} Oh, no, no, no!!"
                show tenna upright chest panic
                tenna "You heard him,{w=0.2} he doesn't want ANYTHING to do with me like that...{w=0.5} ever again,{w=0.2} haha!"
                show tenna upright back frown
                tenna "Even if he's just okay with being friends,{w=0.2} that's fine!{p=0.5}{noalt}*{/noalt} That's more than enough for me!"
                show tenna upright back panic
                tenna "I can live with that..."

            "...":
                $ ten_triplesilence = True
                "You figure it's not worth asking about."
        
        if ten_triplespam:
            show tenna upright back frown at yreset
            tenna "..."
            pause 1.0
            show tenna at droop
            tenna "You know, [persistent.mc].{p=0.5}{noalt}*{/noalt} About...{w=0.5} Spamton."
            show tenna upright chest frown
            tenna "He's changed.{w=0.2} A LOT,{w=0.2} since I last knew him, at least."
            show tenna stretch shrug weak at wiggle
            tenna "Even his body is completely different!{p=0.5}{noalt}*{/noalt} It's...{w=0.5} It's like his skin got burned off!"
            show tenna upright back panic flipped
            tenna "Eugh,{w=0.2} I don't want to think about THAT, haha,{w=0.2} but..."
            show tenna upright chest frown at jump
            tenna "He also used to be a lot more caring...{p=0.5}{noalt}*{/noalt} Now,{w=0.2} he just seems{w=0.5} almost apathetic?"
            show tenna upright back frown
            tenna "I think, anyway.{p=0.5}{noalt}*{/noalt} He's missing some kind of passionate spark."
            show tenna upright pointing oh at jump
            tenna "When you walked away,{w=0.2} he was much less interested in talking to me."
            show tenna upright pointing weak at droop
            tenna "He either gave me one-word responses,{w=0.2} or it was one of those phrases where it sounds like someone else's voice cutting in."
            show tenna upright back frown
            tenna "I don't know for sure,{w=0.2} but...{p=0.5}{noalt}*{/noalt} There might be something he appreciates about you more than he does me."
            show tenna upright pointing weak at jump
            tenna "Don't take this the wrong way,{w=0.2} either!{p=0.5}{noalt}*{/noalt} I just think things might be better if the three of us{w=0.5} stick together as some kind of trio?"
            show tenna upright back panic at jump
            tenna "Only if you want to!{p=0.2}{noalt}*{/noalt} I don't want to use you AGAIN,{w=0.2} JUST to be closer to HIM..."
            menu:
                rq "Only if you want to!\n{noalt}*{/noalt} I don't want to use you AGAIN, JUST to be closer to HIM..."
                "I don't mind":
                    "You say you don't mind."
                    show tenna slouch claw panic at jump
                    tenna "R-{w=0.1} really?"
                    show tenna upright pressed smile at wiggle
                    tenna "[persistent.mc],{w=0.2} are you an ANGEL?{p=0.5}{noalt}*{/noalt} Because you have the patience of a SAINT, haha!!"
                    show tenna upright pointing smile at jump
                    tenna "I owe you my life and then some for doing something like this,{w=0.2} haha."
                    if ten_care:
                        show tenna upright pointing weak at droop
                        tenna "D-{w=0.1} don't think I'm just going to leave you in the dust now,{w=0.2} though!!"
                        show tenna upright back frown
                        tenna "You're both incredibly important to me...{p=0.5}{noalt}*{/noalt} I don't think I could pick between you two,{w=0.2} even at the cost of both my arms."
                        show tenna upright back panic at jump
                        tenna "Again.{w=0.5} Haha."

                "I'm not doing that":
                    "You shake your head and tell Tenna you will not be doing that."
                    if not ten_care:
                        show tenna upright back nose at droop
                        tenna "Oh."
                        show tenna stretch shrug weak at wiggle
                        tenna "Well, okay.{p=0.5}{noalt}*{/noalt} I can't force you to do anything."
                        show tenna upright back panic
                        tenna "But...{w=0.5} Not even as a favor for your friend...?"
                        pause 1.0
                        show tenna panic panic at jump
                        tenna "Okay,{w=0.2} I GET {noalt}IT{/noalt}{alt}it{/alt}!!{p=0.2}{noalt}*{/noalt} PLEASE stop glaring at me like that,{w=0.2} haha...!"
                    else:
                        show tenna upright back panic at wiggle
                        tenna "Haha,{w=0.2} that's understandable...!"
                        show tenna upright back frown flipped at jump
                        tenna "It {noalt}IS{/noalt}{alt}is{/alt} using you,{w=0.2} isn't it?{w=0.2} Only to break your heart further...{w=0.5} after I've already done it once today."
                        show tenna stretch shrug weak flipped at wiggle
                        tenna "Why'd I even bring this up?!{p=0.5}{noalt}*{/noalt} I'm the absolute WORST,{w=0.2} aren't I?!"
                        show tenna upright back panic at jump
                        tenna "Haha!! You know what?!{p=0.2}{noalt}*{/noalt} Let's talk about ANYTHING else!!"

                "What about Mike?":
                    "You ask Tenna how Mike's supposed to fit into all of this."
                    show tenna slouch claw panic at jump
                    tenna "M-{w=0.1} Mike?!"
                    show tenna upright chest frown at jump
                    tenna "I...{w=0.5} hadn't really thought about it,{w=0.2} haha..."
                    pause 1.0
                    show tenna upright back angry
                    tenna "I'm{w=0.5} still a bit peeved at him,{w=0.2} [persistent.mc]."
                    show tenna upright chest angry at jump
                    tenna "If he can figure out how to explain himself to me,{w=0.2} then maybe I'll...{w=0.5} CONSIDER something."
                    show tenna upright pointing weak at jump
                    tenna "But right now,{w=0.2} I'm NOT worried about it!!"
                    show tenna upright back frown at jump
                    tenna "Even if...{w=0.5} he's been here for me more than...{w=0.2} anyone else I've ever known,{w=0.2} haha..."
                    show tenna at droop
                    tenna "..."

        if not ten_triplesilence:
            show tenna upright chest panic at jump
            tenna "Anyway...{w=0.2} Um.{p=0.5}{noalt}*{/noalt} [persistent.mc],{w=0.2} was there anything else you needed me for?"
        "You explain to Tenna that you know a way you can help him get out of here."
        show tenna slouch claw panic at jump
        tenna "WHAT?{w=0.2} You thought to bring that up only NOW?"
        show tenna upright pressed smile at rise
        tenna "I've been waiting ALL DAY to hear you say that, [persistent.mc]!{p=0.2}{noalt}*{/noalt} What a{nw}"
        play sfx ten_surprise
        if persistent.glitches:
            extend " {image=txt_surpriseG}{alt}surprise{/alt}!!"
        else:
            extend " {image=txt_surprise}{alt}surprise{/alt}!!"
        show tenna at wiggle
        tenna "Where are we going?{w=0.2} How is this happening??{p=0.5}{noalt}*{/noalt} Oh,{w=0.2} I can hardly contain myself!!"
        "You tell Tenna there's a mattress on the other side of the Dark World.{w=0.2} He should head that way."
        show tenna upright back blank at yreset
        tenna_shh "........................"
        show tenna upright back awkward at jump
        tenna "Oh my."
        show tenna slouch whisper smug at jump
        tenna "Why didn't you say so sooner,{w=0.2} [persistent.mc]?"
        pause 2.0
        show tenna upright chest awkward at wiggle
        tenna "Haha.{p=0.5}{noalt}*{/noalt} You... don't have to stare at me so blankly."
        show tenna stretch shrug weak flipped
        tenna "Alright,{w=0.2} maybe I read into that a bit much!!{p=0.2}{noalt}*{/noalt} Can you really blame me?"
        show tenna upright back frown at jump
        tenna "But, still.{nw=0.5}"
        show tenna upright pointing oh at jump
        extend " I'll head over there,{w=0.2} okay?"
        show tenna upright pressed smile at rise
        tenna "See you in a little bit,{w=0.2} [persistent.mc]!"
        show tenna upright chest neutral flipped
        hide tenna with easeoutright
        pause 1.0
        "Tenna wandered off."

        ## AUTOSAVE
        $ renpy.save("mainfile")

        if end_triple_mke and end_triple_spam:
            "Better make your own way over to that mattress, now."
            
            ### UNIVERSAL ENDING TRANSITION
            stop music fadeout 2.0
            scene black with Dissolve(1.0)
            play sfx waterwalk
            pause 3.0
            jump ending_universal

        elif end_triple_mke or end_triple_spam:
            "Just one more left to talk to."
        else:
            "Just two more left to talk to."
        jump ex_tenhouse


######################################################
##### TENNA SWAPPING AROUND
label ten_interact_swap:
    if ten_swap == 1:
        show tenna slouch claw panic at jump
        tenna "A change in plans?!"
        show tenna upright chest confused
        tenna "Well,{w=0.2} alright.{p=0.5}{noalt}*{/noalt} If you say so,{w=0.2} [persistent.mc]."
    elif ten_swap == 2:
        show tenna slouch claw panic at jump
        tenna "AGAIN?"
        show tenna upright back nose at jump
        tenna "[persistent.mc],{w=0.2} how many times are you going to make me run around...?"
        show tenna stretch shrug smile at jump
        tenna "Haha,{w=0.2} oh, nevermind!{p=0.5}{noalt}*{/noalt} It's really not that big of a deal!"
        show tenna stretch raised cheer at jump
        tenna "I probably haven't gotten enough exercise lately as it is!"
    elif ten_swap == 3:
        show tenna upright chest neutral
        tenna "..."
        show tenna upright pointing smile at jump
        tenna "Haha,{w=0.2} oh,{w=0.2} sure,{w=0.2} [persistent.mc]!"
        show tenna upright pointing oh at droop
        tenna "But I get the feeling you're being a bit indecisive...."
    elif ten_swap == 4:
        show tenna upright chest blank
        tenna ".{w=0.2}.{w=0.2}."
        show tenna upright back blank
        tenna "Are you messing with me?{p=0.5}{noalt}*{/noalt} This is starting to get a little tedious."
        pause 1.0
        show tenna upright chest panic at jump
        tenna "Oh,{w=0.2} nevermind!{p=0.5}{noalt}*{/noalt} It's not that big of a deal, anyway,{w=0.2} haha..."
    else:
        show tenna upright back nose at droop
        tenna_shh ".........................."
        show tenna upright chest blank at rise
        tenna "Okay,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} Whatever you say."
    return

label ten_interact_cancel:
    "You told Tenna that you lost the person you were going to introduce to him."
    show tenna upright chest confused at droop
    tenna "You...{w=0.2} LOST them?"
    show tenna upright chest frown
    tenna "..."
    show tenna upright back neutral at jump
    tenna "Well!{p=0.5}{noalt}*{/noalt} That's a bit of a pickle,{w=0.2} ain't it?"
    show tenna upright back confused
    tenna "Haha..."
    show tenna upright back frown
    pause 1.0
    show tenna upright chest frown at droop
    tenna "I'm sorry about that,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} I'm sure you're devistated by this..."
    show tenna upright pointing smile at jump
    tenna "I know it's not the same, but--{w=0.2} I'm still here,{w=0.2} right?"
    show tenna upright pressed smile at wiggle
    tenna "I'm not going anywhere at all,{w=0.2} so don't you worry your{nw}"
    play sfx ten_aww
    if persistent.glitches:
        extend " {image=txt_lovelyG}{alt}lovely{/alt}{w=0.2} little head!"
    else:
        extend " {image=txt_lovely}{alt}lovely{/alt}{w=0.2} little head!"
    pause 1.0
    show tenna upright chest frown at jump
    pause 1.0
    stop music fadeout 1.0
    show tenna upright back frown
    tenna "But..."
    jump ending_tenna_only


######################################################
##### TENNA TALKING
default ten_convo = 0 # random roll when you hit "talk"
default ten_random = False # refreshed for randomization

default ten_convo1 = False # brought up reality
default ten_convo2 = False # brought up memoryshards
default ten_convo3 = False # brought up passion
default ten_convo4 = False # brought up mike

label ten_talk:
    ## check what player hasn't seen yet
    if not ten_convo1:
        $ ten_convo = 1
    elif not ten_convo2:
        $ ten_convo = 2
    elif not ten_convo3:
        $ ten_convo = 3
    elif ten_random:
        $ ten_random = False # reset randomization
    else:
        $ ten_convo = 0 # reset number

    pause 0.5

    ## convo 1
    if ten_convo == 1:
        $ ten_convo1 = True
        show tenna upright back smile at jump
        tenna "I need to tell you,{w=0.2} [persistent.mc],{w=0.2} I'm incredibly thankful to have met you!"
        show tenna upright back frown at droop
        tenna "I really hope you can understand the reason behind my decision..."
        tenna "You know,{w=0.2} to call things off for a while?"
        show tenna upright chest panic at jump
        tenna "I don't hate you,{w=0.2} not in the slightest!"
        if not ten_care:
            show tenna upright back panic flipped at jump
            tenna "Well,{w=0.2} I guess you don't...{w=0.5} quite feel the same way,{w=0.2} haha."
            show tenna panic panic at jump
            tenna "Not that there's anything wrong with that!!{p=0.5}{noalt}*{/noalt} You do you and all that,{w=0.2} [persistent.mc]!"
        else:
            show tenna upright back awkward at jump
            tenna "I really hope we can grow closer over time..."
            show tenna upright pressed smile at rise
            tenna "You're really something special,{w=0.2} [persistent.mc]."
        show tenna upright chest frown at droop
        tenna "I just think it would be a better idea for me to sort out some things within myself before dragging you down further,{w=0.2} haha."
        if not ten_care:
            show tenna upright back panic at jump
            tenna "And, whatever you do,{w=0.2} with whoever it may be..."
            show tenna upright pointing oh at jump
            tenna "You can always trust that good ol' Tenna will be here,{w=0.2} watching and supporting you from the sidelines!"
            show tenna upright back panic at wiggle
            tenna "Haha..."
        else:
            show tenna upright chest neutral at jump
            tenna "Wouldn't you rather have that,{w=0.2} too?"
            show tenna upright back smile at jump
            tenna "One day,{w=0.2} we'll figure out everything,{w=0.2} and it can be as perfect as we{nw}"
            play sfx ten_hope
            if persistent.glitches:
                extend " {image=txt_dreamG}{alt}dream{/alt}..."
            else:
                extend " {image=txt_dream}{alt}dream{/alt}..."
            show tenna upright back panic at jump
            tenna "Or,{w=0.2} maybe it won't be.{nw=0.5}"
            show tenna upright pressed smile at rise
            extend "{p=0}{noalt}*{/noalt} But we'll do it together,{w=0.2} and that's really what matters!"

    ## convo 2
    elif ten_convo == 2:
        $ ten_convo2 = True
        show tenna upright chest frown at droop
        tenna "I wonder what the Dreemurrs have been up to since I've been gone."
        tenna "I haven't seen them in...{nw=0.5}"
        show tenna stretch shrug weak at jump
        extend " well, probably days,{w=0.2} I'd imagine!"
        show tenna upright back panic at wiggle
        tenna "Hard to tell the time in a place like this,{w=0.2} haha."
        show tenna upright pointing oh at jump
        tenna "Oh,{w=0.2} [persistent.mc],{w=0.2} since you probably don't know--{w=0.2} the Dreemurrs are the family I lived with before...{nw=0.5}"
        show tenna upright pointing weak at droop
        extend " before being left here, haha."
        show tenna upright pressed smile at rise
        tenna "I was the beloved family television set that sat front and center in their living room!"
        tenna "...{nw=0.2}"
        show tenna upright back frown at droop
        extend " You know,{w=0.5} when they actually WANTED to watch TV,{w=0.2} that is."
        show tenna upright chest panic
        tenna "Haha,{w=0.2} I hope they're doing alright, still.{p=0.5}{noalt}*{/noalt} They're the sweetest people,{w=0.2} I promise you!"
        show tenna upright back panic
        tenna "Even if they don't want me as...{w=0.5} part of the family anymore..."
        show tenna upright back neutral
        tenna "...{w=0.5} I still want the best for them."

    ## convo 3
    elif ten_convo == 3:
        $ ten_convo3 = True
        show tenna upright chest panic at jump
        tenna "[persistent.mc]...{w=0.5} You can't possibly be perfect,{w=0.2} can you?"
        show tenna panic flustered at jump
        tenna "Oh,{w=0.2} that's a really bizarre question,{w=0.2} isn't it?{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} my bad!"
        show tenna upright pointing smile at jump
        tenna "What I meant is...{w=0.5} You really SEEM perfect to me in every way,{w=0.2} and it's hard to believe something like that can exist!"
        show tenna upright pressed smile at wiggle
        tenna "You're so kind, forgiving, accepting, dashing...{p=0.5}{noalt}*{/noalt} Golly,{w=0.2} I don't know how I'm supposed to keep all this happiness to myself,{w=0.2} haha!"
        if not ten_care:
            show tenna slouch claw panic at jump
            tenna "O-{w=0.1} of course, platonically!!{p=0.5}{noalt}*{/noalt} You made yourself LOUD and CLEAR before, [persistent.mc],{w=0.2} so I don't want to disrespect that."
            show tenna upright back panic at wiggle
            tenna "Haha.{p=0.5}{noalt}*{/noalt} Ahem.{p=0.5}{noalt}*{/noalt} Well...!"
            show tenna upright pressed smile
            tenna "There's nothing wrong with expressing {nw}"
            play sfx ten_aww
            if persistent.glitches:
                extend "{image=txt_loveG}{alt}love{/alt}{w=0.2} for your friends!{p=0.5}{noalt}*{/noalt} I'd say it's downright important,{w=0.2} actually!"
            else:
                extend "{image=txt_love}{alt}love{/alt}{w=0.2} for your friends!{p=0.5}{noalt}*{/noalt} I'd say it's downright important,{w=0.2} actually!"
            show tenna upright back panic at jump
            tenna "So...{w=0.5} That's all I meant!!"
        else:
            show tenna upright chest confused at jump
            tenna "Every part of me really,{w=0.2} really wants to just...{w=0.5} Just give you a big ol' hug!!"
            show tenna upright back panic at jump
            tenna "Haha,{w=0.2} but I also don't want to push things along too quickly...{p=0.5}{noalt}*{/noalt} Not again."
            show tenna upright pointing smile at jump
            tenna "It's okay!{w=0.2} I can handle it!{p=0.5}{noalt}*{/noalt} We'll take things bit by bit, and I promise,{w=0.2} it'll be the happiest ending you can dream of."

    ## if all seen, randomly generate
    elif ten_convo == 0:
        $ ten_random = True
        $ ten_convo = renpy.random.randint(1,3)
        jump ten_talk

    show tenna upright chest panic at yreset
    jump ten_menu



############################################################################################################
################## SPAMTON INTERACTS
label spam_interact:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_spamshop
    
    ### BEFORE TRIPLE ENDING
    if not end_triple == "done":
        show spamton standing up smile at spampos_center with Dissolve(0.2)
        spamton "[[hotshot] !!{p=0.5}{noalt}*{/noalt} DID YOU [[See search results] [[[[Cathode]] YET?"

        menu spam_menu:
            rq "[[hotshot] !!\n{noalt}*{/noalt} DID YOU [[See search results] [[[[Cathode]] YET?"
            "Talk":
                jump spam_talk

            "Act":
                menu spam_act:
                    rq "Act"
                    "Lead to Tenna's house" if end_spamtenna == "started":
                        "If you choose this option,{w=0.2} you may get the ending with Spamton and Tenna or another ending."
                        menu:
                            rq "(If you choose this option, you may get the ending with Spamton and Tenna or another ending.)"
                            "Yes":
                                "You tell Spamton that you found Tenna."
                                show spamton standing up frowne at jump
                                spamton "[[But wait!] YOU WERE SERIOUS ABOUT LOOKING FOR HIM??"
                                show spamton standing tilt laugh at xwiggle
                                spamton "THEN GO LIVE OUT YOUR [[nightmare] LIFE AND [[Leave Me Alone]"
                                "You invite Spamton to come see Tenna for himself."
                                show spamton standing up stare at yreset
                                pause 1.0
                                spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} NO???"
                                show spamton crazy laugh at jump
                                spamton "WHAT [[nonsense] DO YOU {noalt}THINK'LL{/noalt}{alt}think'll{/alt} HAPPEN???{p=0.5}{noalt}*{/noalt} [[forecast predicts:] [[Rainbows AND Sunshine] ???"
                                if persistent.glitches:
                                    show spamton standing up stare
                                else:
                                    show spamton standing up stare at shakingcg
                                spamton "I WANT TO [[smack] HIM AND [[thwack] HIM AND [[milk] HIM FOR [[all he's worth]!!!"
                                show spamton standing down panic
                                spamton "HE WAS SUPPOSED TO{p=0.5}{p=0.5}{noalt}*{/noalt} HE WAS {noalt}SUPPOSE,D{space=50} T O...{/noalt}{alt}supposed to{/alt}"
                                show spamton slouch down panic
                                spamton "{noalt}wHHY DidN'T?..?? HE??{/noalt}{alt}why didn't...? he?{/alt}{p=0.5}{noalt}*{/noalt} {noalt}WH Y haASN''t,.. h<33..<..??{/noalt}{alt}why hasn't... he?{/alt}"
                                if persistent.glitches:
                                    show spamton slouch down static
                                else:
                                    show spamton slouch down static glitch
                                spamton "{noalt}W-EHN I1S IS h eSSS US PO,S<<SED,,,,? ? //{/noalt}{alt}when is he supposed...?{/alt}"
                                spamton "[[[[ Heaven ]] ?"
                                "You tried to get Spamton to calm down..."
                                show spamton standing down static at yreset
                                spamton "...{w=0.2} {noalt}iiiIIT'S{/noalt}{alt}it's{/alt} FINE.{p=0.5}{noalt}*{/noalt} DON'T WORRY ABOUT [[stupid {noalt}$Ht#]{/noalt} {alt}beep{/alt}"
                                "You tell Spamton that if he really doesn't want to come with,{w=0.2} he doesn't have to."
                                pause 1.0
                                show spamton slouch down frown at droop
                                pause 1.0
                                spamton "NO.{p=0.5}{noalt}*{/noalt} I'LL [[comes with it for free!]."
                                stop music fadeout 2.0
                                scene black with Dissolve(1.0)
                                play sfx waterwalk
                                pause 1.0
                                "You lead Spamton over to the other side of the Dark World where you met Tenna."
                                jump ending_spamtenna

                            "No":
                                jump spam_act

                    "Bring \"Mike\" here" if mke_success and not end_spamtat == "started":
                        "If you choose this option,{w=0.2} you may get the ending with Spamton and \"Mike\" or pivot to the ending with only \"Mike.\""
                        menu:
                            rq "(If you choose this option, you may get the ending with Spamton and \"Mike\" or pivot to the ending with only \"Mike.\")"
                            "Yes":
                                $ end_spamtenna = None
                                $ end_spamtat = "started"

                                "You told Spamton there was someone other than Tenna you wanted to introduce to him."
                                show spamton standing up stare at jump
                                spamton "[[Who] NOW??"
                                show spamton panic up screame at jump
                                spamton "YOU'RE TELLING ME THERE'S OTHER [[reanimated corpses] IN THIS [[scrap pile] ?!"
                                show spamton crazy angry
                                spamton "YIKES!!{p=0.5}{noalt}*{/noalt} THAT'S [[disgustang]!!"
                                show spamton standing up smile at jump
                                spamton "BUT I'M [[board] ENOUGH SO, SURE,{w=0.2} [[Knock yourself out]."
                                if persistent.glitches:
                                    show spamton standing up stare
                                else:
                                    show spamton standing up stare at shakingcg
                                spamton "I'M NOT [[Moving Out] OF THIS [[stand in position] THOUGH!!"
                                spamton "YOU'LL HAVE TO [[drag and drop] THEIR {noalt}@$${/noalt}{alt}beep{/alt} OVER HERE YOURSELF!!"
                                scene black with Dissolve(1.0)
                                play sfx waterwalk
                                pause 1.0
                                "You trudged back over to where you last left \"Mike.\""
                                pause 1.0
                                scene junkyard5 with Dissolve(1.0)
                                pause 1.0
                                jump mike_interact
                            
                            "No":
                                jump spam_act

                    "Say you didn't find anyone":
                        "If you choose this option, you will lock into the ending with Spamton."
                        "Do you wish to continue?"
                        menu:
                            rq "Do you wish to continue?"
                            "Yes":
                                $ end_triple = None
                                $ end_spamtenna = None
                                $ end_battenna = None
                                $ spam_cancel = True
                                
                                "You tell Spamton you couldn't find anyone else."
                                show spamton standing tilt laugh at jump
                                spamton "WELL THAT'S [[the way the cookie crumbles]!"
                                show spamton crazy laugh at jump
                                spamton "[[Don't worry] YET!{p=0.5}{noalt}*{/noalt} YOU CAN STILL BE STUCK IN [[hell] WITH [[that guy you hate] [[For NO extra costs!]"
                                play sfx spamlaugh
                                show spamton at xwiggle
                                spamton_shh "EAHAHEHAHAH!!"
                                stop music fadeout 1.0
                                pause 2.0
                                "About that..."
                                jump ending_spamton_only
                            
                            "No":
                                jump spam_act
                    
                    "Return":
                        jump spam_menu

            "Not yet":
                "You say you haven't found Tenna yet."
                show spamton crazy laugh at xwiggle
                spamton "OH WELL!!{nw=0.5}"
                show spamton standing up stare at jump
                extend "{p=0}{noalt}*{/noalt} IF YOU NEED [[literallly anything else] I'LL BE WAITING [[You are Here]!"
                hide spamton with Dissolve(0.2)
                jump ex_spamshop


    ### AFTER TRIPLE ENDING
    else:
        $ end_triple_spam = True
        show spamton standing up smile at spampos_center with Dissolve(0.2)
        show spamton at jump
        spamton "HEY HEY,{w=0.2} [persistent.mc!u]!"
        show spamton standing up frowne
        spamton "THAT WAS A [[disaster],{w=0.2} WASN'T {noalt}IT{/noalt}{alt}it{/alt}?"
        show spamton crazy laugh at xwiggle
        spamton "[[I told you] {noalt}IT{/noalt}{alt}it{/alt} WOULD BE [[Terrible Ideas] TO [[Comeback Special] THINGS WITH ME AND [[TV head]!"
        if persistent.glitches:
            show spamton slouch down panic
        else:
            show spamton slouch down panic at shakingcg
        spamton "HE'S SO [[full of] HIMSELF.{p=0.5}{noalt}*{/noalt} WHAT A [[handsome {noalt}and/or{/noalt}{alt}and or{/alt} beautiful] {noalt}@$$HOLE{/noalt}{alt}asshole{/alt}!"
        show spamton slouch down frown at yreset
        spamton "THAT [[You're the faker, faker] MIKE,{w=0.2} THOUGH...{p=0.5}{noalt}*{/noalt} YIKES!!{w=0.2} WHAT A [[piece of work]."
        if persistent.glitches:
            show spamton standing up stare
        else:
            show spamton standing up stare at shakingcg
        spamton "[[lucky dice] RECOGNIZED ME [[on site].{p=0.5}{noalt}*{/noalt} I COULD TELL BY THE LOOK ON HIS [[lack thereof] FACE THE MOMENT HE [[walked in the room]!"
        show spamton crazy angry at xwiggle
        spamton "COMMITTING MIKE [[Identity Theft]?!{p=0.5}{noalt}*{/noalt} ONLY [[Loser] [[steal someone else's identity] !!!"
        show spamton standing up smile at jump
        spamton "ANYWAY [[What's up?]"
        menu:
            rq "ANYWAY [[What's up?]"
            "Are you still bothered?":
                "You ask Spamton if he's still bothered from before."
                show spamton standing up stare at jump
                spamton "[[bothered?] BY WHAT?{p=0.5}{noalt}*{/noalt} [[Cathode] and [[dice boy] [[googly-eye]ING EACH OTHER??"
                show spamton slouch down panic
                spamton "I [[Do not] CARE WHAT THEY DO.{p=0.5}{noalt}*{/noalt} [[I just] DON'T [[want to be included] !!!"
                if persistent.glitches:
                    show spamton slouch down frown
                else:
                    show spamton slouch down frown glitch
                spamton "I'M NOT [[interested].{p=0.5}{noalt}*{/noalt} I'M NOT [[interested]."
                show spamton standing up stare at jump
                spamton "BESIDES [persistent.mc!u],{w=0.2} WE CAN HAVE MORE FUN [[by ourselves] DOING [[anything other than that] RIGHT?!"

            "Did you want to talk?":
                "You ask Spamton if he wanted to talk with you."
                show spamton standing up frowne
                spamton "[[talk?] ABOUT WHAT?{p=0.5}{noalt}*{/noalt} HAVEN'T WE [[talk?] ENOUGH ALREADY?!"
                show spamton crazy laugh at xwiggle
                spamton "[[Business] {noalt}IS{/noalt}{alt}is{/alt} MORE THAN JUST [[talk?] YOU KNOW!!"
                show spamton standing down panic at yreset
                spamton "[[Then again,]{w=0.2} I GUESS OUR [[Deal] WAS [[Transaction Cancelled]."
                show spamton standing up stare at jump
                spamton "WE ARE [[buy one get one FREE] TO DO [[order whatever you want]!{p=0.5}{noalt}*{/noalt} ...{w=0.2} JUST DON'T INVITE [[the other two]!!"

        pause 1.0
        show spamton standing up frowne
        spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} [persistent.mc!u]?"
        show spamton standing up glaree
        spamton "DON'T TELL ME YOU [[cared.] ABOUT THOSE [[2] [[buffoons] ?!"
        show spamton crazy frantic at jump
        spamton "YOUR [[The Smooth Taste of] MEN {noalt}IS{/noalt}{alt}is{/alt} [[undesirable]"
        if persistent.glitches:
            show spamton standing up frowne
        else:
            show spamton standing up frowne at shakingcg
        spamton "IGNORE HOW I [[business partner] ONE OF THEM!!!{p=0.2}{noalt}*{/noalt} THAT WAS [[the old me] !!!"
        show spamton slouch down panic
        spamton "WHY WOULD YOU WANT TO [[associate] WITH THEM??"
        menu:
            rq "WHY WOULD YOU WANT TO [[associate] WITH THEM??"
            "I like them":
                "You say you just like them."
                show spamton standing up frown at jump
                spamton "SO IT'S NOT [[THAT serious]...{p=0.5}{noalt}*{/noalt} OK, [persistent.mc!u] [[I believe you.]"
                show spamton crazy laugh at xwiggle
                spamton "YOU STILL HAVE [[questionable] [[Interests] !!"

            "I think they're cute":
                "You say you find the two of them cute."
                show spamton standing up stare
                spamton "[[cute] ?!{p=0.5}{noalt}*{/noalt} [[Pee-Yew] !!"
                show spamton slouch down panic at yreset
                spamton "WELL.{w=0.5} [[I can see the argument for] [[fuzzface].{p=0.5}{noalt}*{/noalt} BUT [[snake eyes]?!"
                show spamton standing up frowne
                spamton "MY [[statement still stands] ABOUT YOUR [[Opinion on] MEN!!"
                show spamton standing down frown
                spamton "[[but...]"

            "I just want to see this ending":
                "You don't really care either way,{w=0.2} you're just here for the lore."
                show spamton panic up screame at jump
                spamton "WHAT??{w=0.2} [persistent.mc!u]!!"
                show spamton standing tilt laugh at jump
                spamton "THAT'S A [[meta] TAKE IF I'VE EVER HEARD ONE!!"
                show spamton crazy laugh at xwiggle
                spamton "EVER HEARD OF A [[fourth wall],{w=0.2} [persistent.mc!u]?!{p=0.5}{noalt}*{/noalt} NOT ALL OF {noalt}US{/noalt}{alt}us{/alt} KNOW ABOUT [[[[ The Higher Plane ]] !!"
        
        show spamton standing up glaree at jump
        spamton "IF YOU'RE SO [[I insist.] ABOUT THIS,{w=0.2} [[I guess I don't have a choice]."
        show spamton standing up stare
        spamton "BUT [[Never ask me for anything again] !!"
        show spamton slouch down panic at xwiggle
        spamton "SO...{w=0.2} [persistent.mc!u].{p=0.5}{noalt}*{/noalt} {noalt}IS{/noalt}{alt}is{/alt} THERE [[plan A]?"
        "You told Spamton that there was a mattress to the east.{p=0.2}{noalt}*{/noalt} He should go there and wait for you."
        show spamton standing up stare at yreset
        spamton "{w=0.2}.{w=0.2}.{w=0.2}."
        show spamton crazy laugh at jump
        spamton "EAHEHAHEHAH!!{nw=0.5}"
        show spamton standing up frowne
        extend "{p=0}{noalt}*{/noalt} [[You're bold],{w=0.2} [persistent.mc!u]."
        show spamton standing up smile
        spamton "BUT [[Just this once,]{w=0.2} I'LL DO {noalt}IT{/noalt}{alt}it{/alt}."
        show spamton slouch down panic
        spamton "I JUST HAVE TO [[something]{p=0.5}{noalt}*{/noalt} TO [[Sort Items] OUT FIRST!!{p=0.5}{noalt}*{/noalt} I WILL [[arrive] [[A little later...]"
        show spamton standing up smile
        hide spamton with easeoutleft
        pause 1.0
        "Spamton wandered off."

        ## AUTOSAVE
        $ renpy.save("mainfile")

        if end_triple_mke and end_triple_ten:
            "Better make your own way over to that mattress, now."

            ### UNIVERSAL ENDING TRANSITION
            stop music fadeout 2.0
            scene black with Dissolve(1.0)
            play sfx waterwalk
            pause 3.0
            jump ending_universal

        elif end_triple_mke or end_triple_ten:
            "Just one more left to talk to."
        else:
            "Just two more left to talk to."
        jump ex_spamshop



######################################################
##### SPAMTON TALKING
default spam_convo = 0 # random roll when you hit "talk"
default spam_random = False # refreshed for randomization

default spam_convo1 = False # brought up reality
default spam_convo2 = False # brought up memoryshards
default spam_convo3 = False # brought up passion
default spam_convo4 = False # brought up mike

label spam_talk:
    ## check what player hasn't seen yet
    if not spam_convo1:
        $ spam_convo = 1
    elif not spam_convo2:
        $ spam_convo = 2
    elif not spam_convo3:
        $ spam_convo = 3
    elif spam_random:
        $ spam_random = False # reset randomization
    else:
        $ spam_convo = 0 # reset number

    pause 0.5
    
    ## convo 1
    if spam_convo == 1:
        $ spam_convo1 = True
        show spamton slouch down frown
        spamton "THIS [[[[ {color=[c_kindness]}Light{/color} ]]..."
        show spamton crazy angry at xwiggle
        spamton "[[It's actually pretty] [[#!X&]ING AWFUL!!!"
        show spamton standing up frown at jump
        spamton "{noalt}IT{/noalt}{alt}it{/alt} EITHER [[Press Button to do] NOTHING,{w=0.2} OR IT [[knock yourself out] AND I [[Have you ever found yourself] PASSED OUT WITH MY [[face in the dirt] !!"
        if persistent.glitches:
            show spamton crazy frantic
        else:
            show spamton crazy frantic at shakingcg
        spamton "YOU [[deal with it] EVERY DAY???{p=0.2}{noalt}*{/noalt} YIKES!!"
        show spamton standing up smile
        spamton "I WANT TO THROW THIS THING [[face in the dirt] AND [[See how it feels?]"
        show spamton slouch down frown at yreset
        pause 1.0
        show spamton at droop
        spamton "I THOUGHT{p=0.5}{noalt}*{/noalt} I THOUGHT [[ {color=[c_passion]}YOU{/color} ] MIGHT BE DIFFERENT"
        show spamton at droop
        spamton "BUT [[As it turns out,]{w=0.2} I WAS LYING TO [[no one other than] MYSELF!!"
        spamton "I WAS [[Desperate.]{nw=0.5}"
        show spamton standing tilt laugh at jump
        extend "{p=0}{noalt}*{/noalt} BUT [[What's new?],{w=0.2} EAHEHAH!!"

    ## convo 2
    elif spam_convo == 2:
        $ spam_convo2 = True
        show spamton slouch down frown at droop
        pause 1.0
        spamton "[[[[ Freedom ]]...{w=0.5} [[What does it even mean?]"
        spamton "I KNOW WE ALREADY [[Discuss.] THIS."
        show spamton standing tilt stare at rise
        spamton "BUT I CAN'T{p=0.5}{noalt}*{/noalt} BUT I CAN'T [[stop thinking about it stop thinking about it stop thinking ab] ??"
        show spamton standing down panic
        spamton "DID I EVER WANT [[A brand-new] REALITY,{w=0.5} OR DID I JUST WANT [[banner ads] TO [[cared.] ABOUT ME...?"
        spamton "DID I EVER KNOW [[What do you want] ?"
        pause 1.0
        show spamton crazy laugh at jump
        spamton "WELL,{w=0.2} [[Who cares] !!"
        show spamton standing up frowne
        spamton "[[No one is coming back for] ME.{p=0.5}{noalt}*{/noalt} I'M SICK OF BEING [[throw away] IN THE [[Corrupted Files] !!!"
        show spamton crazy laugh at jump
        spamton "[persistent.mc!u],{w=0.2} [persistent.mc!u]!!"
        show spamton crazy frantic at xwiggle
        spamton "IF YOU'RE GONNA [[kill time] TALKING TO [[your local] SPAMTON G. SPAMTON,{w=0.2} COULD YOU INSTEAD FIND THE [[Emergency Exit] ???"
        show spamton standing tilt laugh at jump
        spamton "IT'S [[Bored?] STANDING AROUND THIS [[It's empty.] [[$#!$]HOLE!!"

    ## convo 3
    elif spam_convo == 3:
        $ spam_convo3 = True
        show spamton standing up frowne
        spamton "[[h3ll] {noalt}IS{/noalt}{alt}is{/alt} A LOT [[less bad] THAN I THOUGHT IT'D BE!!"
        show spamton standing down panic
        spamton "EVERYONE ALWAYS SAID [[You're gonna] HATE [[it.]"
        show spamton standing down frown
        spamton "BUT..."
        show spamton slouch down panic
        spamton "IT'S [[Dead silent.]"
        show spamton crazy laugh at jump
        spamton "NO ONE HERE TO [[buggy] ME!!{w=0.5} NO ONE HERE TO [[scream in my face] !!!"
        show spamton standing tilt stare
        spamton "I USED TO THINK [[a silencer] WOULD [[Endless train of thoughts]..."
        show spamton standing down panic
        spamton "JUST AN [[assault] ON MY [[mind palace] [[Front Door] AGAIN AND AGAIN AND AGAIN AND"
        show spamton standing up stare at jump
        spamton "BUT AFTER [[Living in the City] MY [[wholesale] [[Lifetime Guarantee],{w=0.2} IT'S ALMOST [[nice] ?!"
        show spamton standing tilt laugh at jump
        spamton "[[It's like they say,]{w=0.2} LIVING IN [[bumf$@! nowhere] CAN REALLY [[ Clear your mind... ] !!"
        show spamton crazy laugh at xwiggle
        spamton "[[Then again,]{w=0.2} MAYBE I'VE JUST [[Lost something important],{w=0.2} EAHEHEHAHA!!"

    ## if all seen, randomly generate
    elif spam_convo == 0:
        $ spam_random = True
        $ spam_convo = renpy.random.randint(1,3)
        jump spam_talk

    show spamton standing up smile at yreset
    jump spam_menu



############################################################################################################
################## MIKE INTERACTS
label mike_interact:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_gameroom
    
    ### BEFORE TRIPLE ENDING
    if not end_triple == "done":
        show mike standing wink at mikepos_center with Dissolve(0.2)
        mike_no "So.{w=0.5} Any sign of Tenna?"

        menu mike_menu:
            rq "So. Any sign of Tenna?"
            "Talk":
                jump mike_talk

            "Act":
                if persistent.spamroute_fin:
                    menu mike_act:
                        rq "Act"
                        "Bring Tenna here" if end_battenna == "started":
                            "If you choose this option,{w=0.2} you will lock into the ending with \"Mike\" and Tenna."
                            menu:
                                rq "(If you choose this option, you will lock into the ending with \"Mike\" and Tenna.)"
                                "Yes":
                                    "You tell \"Mike\" you were able to find Tenna."
                                    show mike standing smile at jump
                                    mike_no "Y-{w=0.2} you did?!{p=0.2}{noalt}*{/noalt} FINALLY!{w=0.5} Ugh,{w=0.2} I was starting to get really worried..."
                                    show mike tie anime at jump
                                    mike_no "Okay, so,{w=0.2} alright,{w=0.2} where is he?"
                                    if persistent.glitches:
                                        show mike arms avert at jump
                                    else:
                                        show mike arms avert at shock
                                    mike_no "WAIT HE'S NOT HERE RIGHT NOW {noalt}IS{/noalt}{alt}is{/alt} HE?{p=0.2}{noalt}*{/noalt} HOLD ON,{w=0.2} I'M NOT EVEN IN COSTUME YET!!!"
                                    "You assure \"Mike\" that Tenna is waiting a little ways away where he can't see them, if \"Mike\" wants you to bring him over here."
                                    show mike arms freakout at jump
                                    mike_no "OF COURSE, HELLO??{p=0.2}{noalt}*{/noalt} That's the whole reason I came out here!!"
                                    show mike standing conflicted
                                    mike_no "Just gimmie a sec to get the Mike suit on,{w=0.2} first."
                                    stop music fadeout 2.0
                                    scene black with Dissolve(1.0)
                                    pause 1.0
                                    "You wait for \"Mike\" to give you the signal before going to fetch Tenna."
                                    jump secret_ending_battenna
                                
                                "No":
                                    jump mike_act

                        "Lead to Spamton's shop" if end_spamtat == "started":
                            "If you choose this option,{w=0.2} you will lock into the ending with \"Mike\" and Spamton."
                            menu:
                                rq "(If you choose this option, you will lock into the ending with \"Mike\" and Spamton.)"
                                "Yes":
                                    "You tell \"Mike\" you didn't find Tenna,{w=0.2} but you found someone else who might be able to help."
                                    show mike standing angry
                                    mike_no "...{w=0.2} Uh??{p=0.5}{noalt}*{/noalt} Sure??{w=0.5} Okay??"
                                    show mike standing conflicted
                                    mike_no "I don't REALLY see how this is gonna be helpful."
                                    show mike standing sigh
                                    mike_no "I guess I'm not really in the position to say no, though,{w=0.2} am I?"
                                    show mike tie nervous 
                                    mike_no "Whatever."
                                    show mike standing angry at jump
                                    mike_no "Sure,{w=0.2} fine,{w=0.2} okay.{p=0.5}{noalt}*{/noalt} Take me to where-ever this random person is who I sure hope isn't half-dead."
                                    stop music fadeout 2.0
                                    scene black with Dissolve(1.0)
                                    play sfx waterwalk
                                    pause 1.0
                                    "You led \"Mike\" over to where Spamton was waiting at his shop."
                                    jump secret_ending_spamtat
                                
                                "No":
                                    jump mike_act

                        "Lead to Spamton and Tenna" if end_triple == "started":
                            "If you choose this option,{w=0.2} you will lock into the ending with \"Mike,\" Tenna, and Spamton."
                            menu:
                                rq "(If you choose this option, you will lock into the ending with \"Mike,\" Tenna, and Spamton.)"
                                "Yes":
                                    "You tell \"Mike\" you did find Tenna."
                                    show mike standing smile at jump
                                    mike_no "Y-{w=0.2} you did?!{p=0.2}{noalt}*{/noalt} FINALLY!{w=0.5} Ugh,{w=0.2} I was starting to get really worried..."
                                    show mike tie anime at jump
                                    mike_no "Okay, so,{w=0.2} alright,{w=0.2} where is he?"
                                    if persistent.glitches:
                                        show mike arms avert at jump
                                    else:
                                        show mike arms avert at shock
                                    mike_no "WAIT HE'S NOT HERE RIGHT NOW {noalt}IS{/noalt}{alt}is{/alt} HE?{p=0.2}{noalt}*{/noalt} HOLD ON,{w=0.2} I'M NOT EVEN IN COSTUME YET!!!"
                                    "You assure \"Mike\" that Tenna is nowhere nearby,{w=0.2} but you can lead him to Tenna if he wants to join."
                                    show mike arms freakout at jump
                                    mike_no "OF COURSE I'M COMING WITH, HELLO??{p=0.2}{noalt}*{/noalt} That's the whole reason I came out here!!"
                                    show mike standing conflicted
                                    mike_no "Just gimmie a sec to get the Mike suit on,{w=0.2} first."
                                    stop music fadeout 2.0
                                    scene black with Dissolve(1.0)
                                    play sfx waterwalk
                                    pause 1.0
                                    "You lead \"Mike\" over to the other side of the Dark World where both Spamton and Tenna are waiting."
                                    jump secret_ending_triple
                                
                                "No":
                                    jump mike_act

                        "Say you didn't find anyone":
                            "If you choose this option,{w=0.2} you will lock into the ending with \"Mike.\""
                            menu:
                                rq "(If you choose this option, you will lock into the ending with \"Mike.\")"
                                "Yes":
                                    $ end_triple = None
                                    $ end_spamtenna = None
                                    $ end_battenna = None
                                    jump secret_ending_mike

                                "No":
                                    jump mike_act
                        
                        "Return":
                            jump mike_menu

                else:
                    "You don't think you can do anything here yet."
                    "Maybe you should deal with that salesman first..."
                    jump mike_menu

            "Not yet":
                "You say you haven't found anyone yet."
                show mike standing pout
                mike_no "Okay,{w=0.2} alright.{p=0.5}{noalt}*{/noalt} But don't take all day,{w=0.2} {noalt}y'hear{/noalt}{alt}ya hear{/alt}?!"
                show mike standing nervous at droop
                mike_no "It's a long trip back...{w=0.5} Once I,{w=0.2} uh.{w=0.2} Remember the direction I came from."
                hide mike with Dissolve(0.2)
                jump ex_gameroom


    ### AFTER TRIPLE ENDING
    else:
        $ end_triple_mke = True
        show mike arms freakout at mikepos_center with Dissolve(0.2)
        mike "I BUTCHERED THAT SO BAD."
        if persistent.glitches:
            show mike arms avert at jump
        else:
            show mike arms avert at shock
        mike "Why?{w=0.2} WHY?{w=0.2} Great,{w=0.2} GREAT!{p=0.5}{noalt}*{/noalt} Now Tenna's gonna be PISSED as heck at ME and there's gonna be nothing I can do about it."
        if persistent.glitches:
            show mike standing sigh
        else:
            show mike standing sigh at shakingcg
        mike "Think,{w=0.2} ahhh,{w=0.2} what would Mike do here...?!"
        menu:
            rq "Think, ahhh, what would Mike do here...?!"
            "Aren't YOU Mike?":
                "You remind him that he {noalt}IS{/noalt}{alt}is{/alt} Mike."
                show mike arms freakout at rise
                mike "NO,{w=0.2} haven't we gone over this?!"
                show mike arms avert at jump
                mike "Just because I'm using the same name as that guy, it doesn't just...{w=0.2} MAKE me that guy!!"
                show mike tie nervous at droop
                mike "Even if it's just...{w=0.2} Even if I don't wanna..."
            
            "What's wrong?":
                "You ask Mike what's wrong."
                show mike arms avert at rise
                mike "EVERYTHING?!{w=0.2} Weren't you there?!"
                show mike standing sigh at wiggle
                mike "Ahhh,{w=0.2} this is the worst thing that could have happened."
                show mike tie avert
                mike "That other guy, too--{w=0.2} I swear.{p=0.5}{noalt}*{/noalt} HE knows who the REAL Mike is,{w=0.2} sooo now I just look like a HUGE jerk!"
        
        show mike standing sigh at jump
        mike "FORGET {noalt}IT{/noalt}{alt}it{/alt}!!{w=0.2} I don't have the time for this."
        show mike standing angry
        mike "Look.{w=0.2} You.{p=0.5}{noalt}*{/noalt} What did they call you,{w=0.2} [persistent.mc]?"

        ### NAME REACTIONS
        if persistent.mc in ["Battat", "Pluey", "Jongler"]:
            show mike tie nervous
            mike "...{w=0.2} hey, wait.{w=0.2} You don't happen to know about...?"
            show mike standing sigh
            mike "Ah, forget it, forget it!{p=0.2}{noalt}*{/noalt} It's probably just a coincidence."
            show mike standing indifferent at jump
            mike "Anyway."
        
        elif persistent.mc == "Michael":
            show mike standing conflicted at jump
            mike "Wait.{w=0.2} That's.{p=0.5}{noalt}*{/noalt} Hold on,{w=0.2} is that REALLY your name?"
            show mike standing nervous at droop
            mike "No way,{w=0.2} you're not..."
            show mike tie nervous at wiggle
            mike "No,{w=0.2} wait,{w=0.5} those two DEFINITELY woulda said something if you WERE..."
            if persistent.glitches:
                show mike arms freakout
            else:
                show mike arms freakout at shakingcg
            mike "FORGET {noalt}IT{/noalt}{alt}it{/alt}, forget {noalt}IT{/noalt}{alt}it{/alt}!!{p=0.2}{noalt}*{/noalt} There's more important things to worry about!!"
        
        elif persistent.mc in ["Ass","Anus","Anuses","Arse","Arses","Asses","Asshole","Assholes","Dumbass","Dumbasses","Jackass","Jackasses","Lmao","Lmfao",
                                "Assfuck","Bastard","Bastards","Shit",'Shits',"Shitty","Shitter","Shithead","Shitheads","Shithole","Shitholes","Sex",'Sexy',"Sexes",'Sexs',"Sexie",
                                'Sexys',"Sexting","Sext","Fuck",'Fucker',"Robotfucker",'Monsterfucker',"Motherfucker","Dumbfuck",'Buttfuck','Fucking','Fuckface','Kink','Kinky','Piss',
                                'Pisses','Pissing','Pisser','Pissed','Pissface','Pissboy',"Damn","Dammit","Goddamn","Goddamnit",'Bitch',"Bitches","No bitches",'Nobitches','Boner',
                                "Boners","Dildo","Dildos","Dick","Dicks",'Dickbag',"Jizz","Jizzy","Cock","Cocks","Ball","Balls",'Penis',"Penises","Peni","Bollocks","Slut","Sluts","Slutty",
                                "Douche","Douchebag","Boob","Boobs","Boobie","Boobies",'Booby','Boobys','Boober',"Boobers","Tit","Tits",'Titty',"Tittys",'Titties','Tiddy','Crackhead',
                                'Tiddys','Tiddies','Manboob','Manboobs','Mantit','Mantitty','Breast','Breasts','Bosom','Clit','Clitoris','Labia','Vagina','Vaginas','Fleshlight',
                                'Fleshlights','Cunt','Cunty','Pussy','Pussies','Pussys','Bepis','Toilet',"Poop","Poopie","Poopy","Pee",'Peepee','Toylet',"Pee pee", "Poo poo pee pee",
                                "Poopoo peepee", "Poopoopeepee","Poo poo peepee","Poopoo pee pee","Queer","Gay","Gayass"]:
            show mike standing conflicted at droop
            mike "...{w=0.2} Are you REALLY gonna make me call you that?"
            show mike tie avert at jump
            mike "Ah,{w=0.2} nevermind."
        
        elif persistent.mc in ["Yep", "Yes", "Yeppers", "Yesplease", "Yes please", "Yup", "Yessiree", "Whatsit", "Whatsittooya", "What zit tooya", "Whatzittooya"]:
            show mike standing conflicted
            mike "Or...{w=0.2} I guess that's not really a name."
            if persistent.glitches:
                show mike arms freakout
            else:
                show mike arms freakout at shakingcg
            mike "But you never told me it,{w=0.2} so I don't have anything to go off of!!"
            show mike standing sigh at yreset
            mike "Whatever."
        
        elif persistent.mc in ["Jevil", "Seam"]:
            show mike standing nervous
            mike "Didn't think there'd be two people with THAT name,{w=0.2} out of all names..."
            show mike tie nervous at jump
            mike "Ah,{w=0.2} forget it, forget it!{w=0.5} I'm just mumbling to myself."
        
        ### BACK TO STORY
        show mike standing wink at yreset
        mike "We need to find the exit.{w=0.2} Now."
        show mike standing pout
        mike "I don't know how else I can make things better from here..."
        menu:
            rq "I don't know how else I can make things better from here..."
            "Why do YOU have to make it better?":
                "You question why this is Mike's responsibility."
                if persistent.glitches:
                    show mike arms freakout
                else:
                    show mike arms freakout at shakingcg
                mike "BECAUSE I SCREWED UP??{p=0.5}{noalt}*{/noalt} I couldn't even...{w=0.5} APOLOGIZE properly!{w=0.2} Or even say why I just freaked out!?"
            
            "Why do I have to help you?":
                "You question why it's your responsibility to help."
                if persistent.glitches:
                    show mike arms freakout
                else:
                    show mike arms freakout at shakingcg
                mike "BECAUSE I DON'T HAVE ANYONE ELSE TO GO TO??{p=0.2}{noalt}*{/noalt} I just need ANY help I can get,{w=0.2} seriously!!"
        
        show mike standing sigh at droop
        mike "I know it's a lot to ask.{p=0.5}{noalt}*{/noalt} I don't ask people for help a lot.{w=0.2} Trust me."
        show mike tie nervous at wiggle
        mike "I'm...{w=0.5} I don't know what else to do,{w=0.2} {noalt}haaa{/noalt}{alt}hah{/alt}...!"
        if persistent.glitches:
            show mike standing sigh
        else:
            show mike standing sigh at shakingcg
        mike "If I can't bring Tenna home in time,{w=0.2} I..."
        show mike standing conflicted
        if persistent.glitches:
            mike "What's gonna happen to me if I don't get back\nin time...?"
        else:
            mike "{sc=2}What's gonna happen to me if I don't get back\nin time...?{/sc}"
        show mike standing sigh at droop
        pause 1.5
        menu:
            "I think I have an idea.":
                pass
        
        "You tell Mike you have an idea that could help him out."
        show mike standing indifferent at rise
        mike "Y-{w=0.1} you...{w=0.5} Wait,{w=0.2} you DO?"
        show mike tie anime at jump
        mike "Well??{w=0.2} What is it??{p=0.2}{noalt}*{/noalt} Spit it out, spit it out!!"
        "You tell Mike that there's a mattress not far from here.{p=0.2}{noalt}*{/noalt} He should go wait for you there."
        show mike standing indifferent
        mike_shh "................................."
        pause 1.0
        show mike standing conflicted
        mike "Sorry.{p=0.5}{noalt}*{/noalt} WHAT{w=0.2} are you suggesting I do,{w=0.2} here,{w=0.2} exactly?"
        "You tell Mike to just trust you."
        show mike tie awkward at droop
        mike "ALRIGHT,{w=0.2} ALRIGHT,{w=0.2} fine!{p=0.5}{noalt}*{/noalt} This better not be anything weird,{w=0.2} though,{w=0.2} or I'm NOT gonna be happy!"
        show mike standing nervous at yreset
        hide mike with easeoutright
        pause 1.0
        "Mike wandered off."

        ## AUTOSAVE
        $ renpy.save("mainfile")

        if end_triple_spam and end_triple_ten:
            "Better make your own way over to that mattress, now."
            
            ### UNIVERSAL ENDING TRANSITION
            stop music fadeout 2.0
            scene black with Dissolve(1.0)
            play sfx waterwalk
            pause 3.0
            jump ending_universal

        elif end_triple_spam or end_triple_ten:
            "Just one more left to talk to."
        else:
            "Just two more left to talk to."
        jump ex_gameroom


######################################################
##### MIKE TALKING
default mike_convo = 0 # random roll when you hit "talk"
default mike_random = False # refreshed for randomization

default mike_convo1 = False # brought up tenna
default mike_convo2 = False # brought up reality
default mike_convo3 = False # brought up castle town

label mike_talk:
    ## check what player hasn't seen yet
    if not mike_convo1:
        $ mike_convo = 1
    elif not mike_convo2:
        $ mike_convo = 2
    elif not mike_convo3:
        $ mike_convo = 3
    elif mike_random:
        $ mike_random = False # reset randomization
    else:
        $ mike_convo = 0 # reset number

    pause 0.5

    ## convo 1
    if mike_convo == 1:
        $ mike_convo1 = True
        show mike standing nervous
        mike_no "I haven't seen Tenna since...{p=0.5}{noalt}*{/noalt} Well,{w=0.2} long story short,{w=0.2} we both were in a different Dark World called TV World."
        show mike tie nervous at wiggle
        mike_no "After this whole fiasco there,{w=0.2} where me and,{w=0.2} well,{w=0.2} everybody else who was employed under Tenna just up and quit--"
        show mike standing wink at jump
        mike_no "This prince came through and invited us to HIS Dark World instead.{w=0.5} The Lightners with him ended up bringing us there."
        show mike standing pout
        mike_no "He had this huge castle,{w=0.2} with a room specifically made for Tenna {noalt}'nd{/noalt}{alt}and{/alt} everything,{w=0.5} but Tenna wasn't in it when I tried to say hi..."
        show mike standing sigh at droop
        mike_no "And,{w=0.2} um.{w=0.2} Apologize.{w=0.2} For some stuff."
        if persistent.glitches:
            show mike arms avert at jump
        else:
            show mike arms avert at shock
        mike_no "But I couldn't!!{p=0.2}{noalt}*{/noalt} Because he was just,{w=0.2} GONE!"
        if persistent.glitches:
            show mike arms freakout
        else:
            show mike arms freakout at shakingcg
        mike_no "When I asked one of the Lightners about it later,{w=0.2} all she had to say was he's \"not in this Dark World\"!"
        show mike arms avert
        mike_no "Which was not only REALLY UPSETTING TO HEAR,{w=0.2} but also EXTREMELY UNHELPFUL!"
        show mike at yreset
        pause 1.0
        show mike standing nervous
        mike_no "...{w=0.2} So,{w=0.2} uh."
        show mike at droop
        mike_no "I haven't seen Tenna since before all of that happened."

    ## convo 2
    elif mike_convo == 2:
        $ mike_convo2 = True
        pause 0.5
        show mike standing nervous at droop
        mike_no "I still can't tell if you're real or not,{w=0.2} by the way."
        show mike standing conflicted
        mike_no "Sorry, is that like,{w=0.2} a horrific thing to say?{p=0.5}{noalt}*{/noalt} I don't know anymore."
        show mike standing nervous at wiggle
        mike_no "I've been out here without any ability to tell time or socialize for,{w=0.2} uhhh...{w=0.5} oh,{w=0.2} right,{w=0.2} can't tell time,{w=0.2} don't know how long I've been out here!"
        show mike tie nervous
        mike_no "It FEELS like it's been days,{w=0.2} though.{p=0.2}{noalt}*{/noalt} So I THINK,{w=0.5} I'm going crazy."
        show mike standing indifferent at yreset
        mike_no "...{w=0.2} What?{nw=0.5}"
        show mike arms avert at jump
        extend " D-{w=0.1} don't offer to pinch me,{w=0.2} what?!{p=0.5}{noalt}*{/noalt} Besides,{w=0.2} that probably wouldn't work, anyway..."
        show mike standing nervous
        mike_no "Dark Worlds for Lightners are just...{w=0.5} really convincing hallucinations,{w=0.2} right?{p=0.5}{noalt}*{/noalt} We're barely real to you guys to begin with."
        show mike standing pout
        mike_no "Just...{w=0.5} like a dream you can feel and smell and hear and stuff."
        show mike standing nervous
        mike_no "...{w=0.2} So even if you DID pinch me,{w=0.2} there's no guarantee I'm not just...{w=0.5} I don't know,{w=0.2} in something deeper than a Dark World?"
        show mike tie avert at wiggle
        mike_no "Like,{w=0.2} if you got even Darker,{w=0.2} that it became ANOTHER dream-layer or...{w=0.5} something like that??"
        show mike standing sigh at droop
        mike_no "Ah.{w=0.2} Forget it.{p=0.5}{noalt}*{/noalt} I don't have the energy to think about this right now..."

    ## convo 3
    elif mike_convo == 3:
        $ mike_convo3 = True
        pause 0.5
        show mike standing conflicted
        mike_no "I really hope things are okay back in Castle Town..."
        show mike standing indifferent
        mike_no "Oh,{w=0.2} right,{w=0.2} uh.{w=0.5} That's the name of the Dark World I came from."
        show mike tie avert
        mike_no "I,{w=0.2} ah,{w=0.2} wasn't the only guy posing as Mike, either,{w=0.5} there were two other guys I hired at some point.{w=0.2} Years ago."
        show mike standing sigh
        mike_no "I left them in charge and told them I was going to look for Tenna.{p=0.2}{noalt}*{/noalt} They tried to tell me not to,{w=0.2} but..."
        show mike standing conflicted
        mike_no "I didn't really feel good sitting around all day just hoping he might,{w=0.2} I don't know,{w=0.5} waltz in out of nowhere?"
        show mike tie nervous
        mike_no "Well...{w=0.5} That's when that one person showed up outta nowhere,{w=0.2} instead.{p=0.5}{noalt}*{/noalt} You know,{w=0.2} with the crystal thingy."
        show mike standing nervous
        mike_no "They said they'd give me what I wanted and connect me to where I wanted to go.{p=0.5}{noalt}*{/noalt} It'd just...{w=0.5} be at a price."
        show mike tie nervous at wiggle
        mike_no "The price being the whole time limit thing...{w=0.5} which,{w=0.2} I'm gonna be honest?"
        show mike standing nervous at droop
        mike_no "I don't really know what's going to happen when time's up."
        pause 1.0
        show mike tie nervous at wiggle
        mike_no "Nope,{w=0.2} nope.{w=0.5} Can't think about that right now.{p=0.2}{noalt}*{/noalt} It's fine.{w=0.2} It'll BE fine.{w=0.5} Just{w=0.2} FINE."

    ## if all seen, randomly generate
    elif mike_convo == 0:
        $ mike_random = True
        $ mike_convo = renpy.random.randint(1,3)
        jump mike_talk

    show mike standing wink at yreset
    jump mike_menu