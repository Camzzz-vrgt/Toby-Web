label credits:
    $ quick_menu = False
    $ persistent.cont = False
    show screen nomenu
    scene black

    ### first song
    play music dontforget noloop
    $ renpy.pause(1.0,hard=True)
    show logo iltv:
        xalign 0.5
        yalign 0.48
    $ renpy.pause(3.0,hard=True)
    show logo dr
    show text _("by Toby Fox"):
        xalign 0.5
        yalign 0.58
    $ renpy.pause(3.0,hard=True)
    hide logo
    show text _("-- PROGRAMMING --\n\n- Main Programmer -\nzirkkun\n\n- Ren'Py RGB Split Shader -\nAgentAlpha81") at truecenter
    $ renpy.pause(6.0,hard=True)
    show text _("-- PROGRAMMING --\n\n- Glitch Effects -\nGouvernathor\n\n- Ren'Py Kinetic Text Tags -\nWattson")
    $ renpy.pause(6.2,hard=True)
    show text _("-- PROGRAMMING SPECIAL THANKS --\n\nUndertale Ren'Py UI by DerpyChoCho\nfor inspiring the UI layout for I Love TV!\n\nThe Ren'Py SubReddit & Ren'Ai Forums\nfor having so many helpful resources and users")
    $ renpy.pause(6.0,hard=True)
    hide text
    $ renpy.pause(3.2,hard=True)

    ### TENNA
    if end_triple_ten or end_spamtenna == "done" or end_battenna == "done" or end_tenna:
        scene susie tenna
        show text _("-- ART & DESIGN --\n\n- Main Artist & Writer -\nzirkkun\n\n- \"Vess\" Character Design -\nzirkkun\n\n- Willo Character Design -\nzirkkun\n\n"):
            xalign 0.98
            yalign 0.85
    else:
        show text _("-- ART & DESIGN --\n\n- Main Artist & Writer -\nzirkkun\n\n- \"Vess\" Character Design -\nzirkkun\n\n- Willo Character Design -\nzirkkun")
    $ renpy.pause(6.0,hard=True)
    if end_triple_ten or end_spamtenna == "done" or end_battenna == "done" or end_tenna:
        scene dw tenna
        show text _("-- ART & DESIGN --\n\n- Tenna Character Design -\nToby Fox\nGigi D.G.\npixelatedcrown"):
            xalign 0.95
            yalign 0.2
    else:
        show text _("-- ART & DESIGN --\n\n- Tenna Character Design -\nToby Fox\nGigi D.G.\npixelatedcrown")
    $ renpy.pause(6.0,hard=True)
    scene black with Dissolve(0.5)
    $ renpy.pause(2.0,hard=True)
    
    ### SPAMTON
    if end_triple_spam or end_spamtenna == "done" or end_spamtat == "done" or end_spamton:
        scene susie spamton
        show text _("-- ART & DESIGN --\n\n- Susie Character Design -\nToby Fox\n\n- Mystery Man\nCharacter Design -\nToby Fox"):
            xalign 0.05
            yalign 0.2
    else:
        show text _("-- ART & DESIGN --\n\n- Susie Character Design -\nToby Fox\n\n- Mystery Man Character Design -\nToby Fox")
    $ renpy.pause(6.0,hard=True)
    if end_triple_spam or end_spamtenna == "done" or end_spamtat == "done" or end_spamton:
        scene dw spamton        
        show text _("-- ART & DESIGN --\n\n- Spamton Character Design -\nToby Fox\nTemmie Chang"):
            xalign 0.05
            yalign 0.8
    else:
        show text _("-- ART & DESIGN --\n\n- Spamton Character Design -\nToby Fox\nTemmie Chang")
    $ renpy.pause(5.0,hard=True)
    scene black with Dissolve(0.5)
    $ renpy.pause(1.0,hard=True)

    ### MIKE
    if end_triple_mke or end_battenna == "done" or end_spamtat == "done" or end_mike:
        scene susie mike
        show text _("-- ART & DESIGN --\n\n- Small Mike\nCharacter Design -\nAndy Brophy\n\n- Pippins Character Design -\nToby Fox"):
            xalign 0.95
            yalign 0.75
    else:
        show text _("-- ART & DESIGN --\n\n- Small Mike Character Design -\nAndy Brophy\n\n- Pippins Character Design -\nToby Fox")
    $ renpy.pause(5.5,hard=True)
    scene black with Dissolve(0.5)
    $ renpy.pause(0.8,hard=True)
    if end_triple_mke or end_battenna == "done" or end_spamtat == "done" or end_mike:
        scene dw mike
        show text _("-- ART & DESIGN --\n\n- Various Spritework -\nfrom UNDERTALE and\n DELTARUNE"):
            xalign 0.9
            yalign 0.15
    else:
        show text _("-- ART & DESIGN --\n\n- Various Spritework -\nfrom UNDERTALE and\n DELTARUNE")
    $ renpy.pause(6.0,hard=True)
    scene black with Dissolve(1.0)
    $ renpy.pause(3.3,hard=True)

    ### second song
    play music untilnexttime noloop
    show text _("-- SOUND EFFECTS --\n\nHigh traffic road sounds\nby IgnasD\n\nOld Rotary Phone Ringing ☎️ Free Sound Effect SFX\nby mycompasstv\n\ntelephone hang up sound effect$\nby SOUND EFFECT EN & FR")
    $ renpy.pause(3.0,hard=True)
    show text _("-- SOUND EFFECTS --\n\nGlass Shatter Sound Effect\nby BluePrismatic\n\nRipping Paper - Sound Effect (SFX)\nby Riven Dune")
    $ renpy.pause(3.5,hard=True)
    show text _("-- SOUND EFFECTS --\n\nShovel Digging Dirt - Sound Effect for editing\nby Sound Library\n\nBirthday Party Horn Sound Effect\nby SoundEffectsFactory")
    $ renpy.pause(3.2,hard=True)
    show text _("-- SOUND EFFECTS --\n\nPark ambiences\nby Thimras\n\n- All sound effects not listed here are either from\nDeltarune or Undertale,\ncredit belonging to Toby Fox and his team;\nor are other free assets. -")
    $ renpy.pause(3.5,hard=True)
    show text _("-- MUSIC --\n\n- Original Pieces -\nToby Fox\nLaura Shigihara\n\n- A CYBER'S WORLD? (Spamton Sweepstakes) -\narrangement by ShinkoNetCavy\n\n- Gaster's Waltz -\nToriOKAY\n\n- I Love TV! Unique Arrangements -\nzirkkun")
    $ renpy.pause(7.0,hard=True)
    show text _("-- ILTV Arrangements --\n\nQuiz! (Lo-Fi Mix)\nMIDI by ironinfidel47\n\nFaint Courage (Lo-Fi Mix) + Daycore ver.\nMIDI by Dubs\n\nSpamton (Lo-Fi Mix)\nMIDI by dollar channel")
    $ renpy.pause(6.5,hard=True)
    show text _("-- ILTV Arrangements --\n\nGreen Room (Music Box Mix)\nMIDI by Venn\n\nBIG SHOT (Remix)\nMIDI by Morakiv_\n\nAir Waves (Remix)\nMIDI by MintyFresh512")
    $ renpy.pause(6.5,hard=True)
    show text _("-- ILTV Arrangements --\n\nLost Girl (Cover) + Daycore ver.\nMIDI by Anonymous\n\nDon't Forget (Cover)\nMIDI by Newo")
    $ renpy.pause(7.0,hard=True)
    show text _("I Love TV!\nis entirely free-to-play with no intention\nof making a profit from, misusing,\nor demoralizing Toby Fox's content.\n\nThe project is made entirely out of fun\nand appreciation for Deltarune.\n\nPlease, if you have not already,\nsupport Toby Fox and the official release of\nUNDERTALE and DELTARUNE!")
    $ renpy.pause(10.0,hard=True)
    show text _("-- SPECIAL THANKS --\n\nTo my good friend, Topher Jackson-Sherriff,\nwho's always an incredibly supportive inspiration.\n\nAnd to {color=[c_passion]}YOU{/color},\nfor playing I Love TV!")
    $ renpy.pause(7.5,hard=True)
    hide text with Dissolve(1.0)
    $ renpy.pause(7.0,hard=True)

    ### WILLO
    play ambiance lightamb fadein 3.0
    pause 9.0

    ### CG DIFFERENT BASED ON ENDING
    if end_triple_mke and end_triple_spam and end_triple_ten:
        show uniend_willo triple
    elif end_spamtenna == "done":
        show uniend_willo spamtenna
    elif end_battenna == "done":
        show uniend_willo battenna
    elif end_spamtat == "done":
        show uniend_willo spamtat
    elif end_tenna:
        show uniend_willo tenna
    elif end_spamton:
        show uniend_willo spamton
    elif end_mike:
        show uniend_willo mike
    with Dissolve(4.0)
    pause 4.0
    play sfx cymbal
    pause 5.0
    stop sfx
    stop ambiance
    scene black
    $ renpy.pause(3.0,hard=True)

    ### IMAGE IF TRIPLE END OTHERWISE JUST TEXT
    if end_triple_mke and end_triple_spam and end_triple_ten:
        show tripleend at truecenter with dissolve
    else:
        show text _("{size=+10}THE END") at truecenter with dissolve
    pause
    hide text
    hide tripleend
    with dissolve

    $ renpy.pause(1.0, hard=True)

    ## FIRST TIME REACHING CREDITS
    if not persistent.playthru:
        show gaster neutral at gastpos_center with Dissolve(1.0)
        gaster "It seems you've reached {p=0.5}an end."
        show gaster side
        gaster "But this world {p=0.5}has more than meets the eye."
        show gaster smile
        gaster "If you wanted to find {p=0.5}another end..."
        show gaster smilee with Dissolve(0.5)
        gaster "I implore you {p=0.5}to Continue."
        show gaster side with Dissolve(0.5)
        gaster "Otherwise..."
        show gaster smile
        gaster "You can always {p=0.5}Reset."
        pause 1.0
        show gaster smilee with Dissolve(0.5)
        gaster "I shall await {p=0.5}your decision."
        scene black
        play sfx disappear
        $ renpy.pause(2.0, hard=True)
        $ persistent.playthru = True # CHANGE FOR DEBUG
        $ persistent.mainscreen = "Tenna"
        $ config.window_title = _("I Love TV!")
        $ change_icon(icon1)

    ## AUTOSAVE
    $ renpy.save("mainfile")

    ## GO BACK TO MAIN MENU
    if not persistent.cont:
        $ persistent.cont = True
        return

    ## LOADING FROM "continue"
    else:
        stop sfx
        jump cont_postend