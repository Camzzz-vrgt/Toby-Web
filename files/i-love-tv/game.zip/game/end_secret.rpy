############################################################################################################
################## MIKE ONLY ENDING
label secret_ending_mike:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    "You tell \"Mike\" you weren't able to find anyone."
    show mike standing conflicted at droop
    stop music fadeout 1.0
    mike_no "You really couldn't find him...?"
    mike_no "Ah,{w=0.2} crap, crap...{w=0.5} What am I supposed to do now?"
    show mike arms freakout at jump
    mike_no "I don't have any more leads!{p=0.2}{noalt}*{/noalt} I've got nothing!{w=0.2} Nothing!!"
    show mike tie avert at wiggle
    mike_no "Where else am I supposed to go?!{p=0.2}{noalt}*{/noalt} I've been running around in circles at this point!!"
    if m_info < 2:
        show mike standing sigh at droop
        mike_no "I didn't even find anything that you told me about before!!{w=0.2} Not a single thing!!"
    if persistent.glitches:
        show mike arms avert at jump
    else:
        show mike arms avert at shock
    mike_no "Gah!!{w=0.2} What am I supposed to do?!{p=0.5}{noalt}*{/noalt} What,{w=0.2} WHAT??"
    show mike standing nervous
    mike_no "I'm..."
    pause 1.0
    show mike standing sigh at droop
    mike_no "...{w=0.5} oh,{w=0.2} forget it."
    show mike standing conflicted
    mike_no "I'm just...{w=0.2} really tired.{p=0.5}{noalt}*{/noalt} Like,{w=0.2} REALLY tired."
    mike_no "So...{nw=0.5}"
    show mike standing sigh
    extend "{p=0}{noalt}*{/noalt} Ah, actually,{w=0.2} nevermind,{w=0.2} NEVERMIND."
    show mike tie nervous
    mike_no "You're basically a stranger.{p=0.5}{noalt}*{/noalt} You don't need to hear me rambling on about all this crap that doesn't matter to you."
    show mike tie avert
    pause 1.0
    menu:
        "{size=-10}{color=#aaaaaa}(This may affect your ending.){/color}{/size}\nComfort him":
            $ mke_comfort = True
            play sfx plop
            stop music
            scene black
            if persistent.glitches:
                pass
            else:
                with vpunch
            mike_no "Wh--{w=0.2} HEY!!"
            play music faintcourageSo
            show mikeend 1 shocked with Dissolve(2.0)
            pause 2.0
            show mikeend 1 angry with Dissolve(0.5)
            mike_no "G-{w=0.1} geez!!{w=0.2} Where's this coming from?!"
            mike_no "At least warn a guy next time you wanna do this kinda thing!!"
            pause 1.0
            show mikeend 1 confused with Dissolve(0.5)
            mike_no "Hey,{w=0.2} hey,{w=0.2} wait...{w=0.5} What're you even hugging me for...?"

        "Do not":
            $ mke_noexplain = True
            mike_noshh ".{w=0.2}.{w=0.2}."
            pause 1.0
            play music faintcourageSo
            show mike standing conflicted
            jump secret_ending_mike_you

    menu:
        rq "Hey, hey, wait... What're you even hugging me for...?"
        "I'm your hallucination, here to listen to your woes!":
            $ mke_hallu = True
            show mikeend 1 angry with Dissolve(0.5)
            mike_no "Wh--{w=0.2} hey,{w=0.2} HEY!!{w=0.5} Don't mess with me!!"
            mike_no "What's wrong with you?!{p=0.5}{noalt}*{/noalt} I'm genuinely stressed out about that,{w=0.2} don't mess with me right now!!"
            pause 1.0
            show mikeend 1 frown with Dissolve(0.5)
            mike_no "Ugh,{w=0.2} sorry,{w=0.2} sorry.{w=0.5} That didn't come out right."
            show mikeend 1 nervous with Dissolve(0.5)
            mike_no "You were just trying to lighten the mood with a joke,{w=0.2} right?"
            mike_no "I appreciate it, but...{w=0.5} I'm not really in the mood to hear you say THAT right now."
            show mikeend 1 sigh with Dissolve(0.5)
            mike_no "If you really wanna know what I was gonna say,{w=0.2} though...{p=0.5}{noalt}*{/noalt} Guess I can just keep running my mouth."
            mike_no "Just,{w=0.2} tell me when you want me to shut up.{p=0.5}{noalt}*{/noalt} I don't know how to stop half the time."

        "Say whatever you need to.":
            mike_no "Huh?"
            pause 1.0
            show mikeend 1 angry with Dissolve(0.5)
            mike_no "Oh,{w=0.2} whatever.{w=0.5} You're just saying that."
            mike_no "Don't force yourself,{w=0.2} there's no way you actually care about anything I'm going through."
            show mikeend 1 nervous with Dissolve(0.5)
            mike_no "You can't just...{w=0.5} care that much right after meeting someone..."
            pause 1.0
            show mikeend 1 angry with Dissolve(0.2)
            mike_no "...{w=0.2} Augh,{w=0.2} shut up!{p=0.5}{noalt}*{/noalt} I know you didn't say anything but shut up anyway!!"
            pause 1.0
            show mikeend 1 sigh with Dissolve(0.5)
            mike_no "Forget it,{w=0.2} forget it..."
            show mikeend 1 frown with Dissolve(0.5)
            mike_no "Sorry,{w=0.2} sorry.{p=0.5}{noalt}*{/noalt} My head's runnin' all over hell and back right now,{w=0.2} I just..."
            mike_no "I'm not really used to anyone really givin' a crap about,{w=0.5} really ANYTHING I've got to say."

        "I thought this would help.":
            show mikeend 1 frown with Dissolve(0.5)
            mike_no "..."
            mike_no "Well,{w=0.2} I guess..."
            show mikeend 1 angry with Dissolve(0.5)
            mike_no "But you coulda been a little more direct in telling me that,{w=0.2} y'know?!"
            show mikeend 1 sigh with Dissolve(0.5)
            mike_no "Ah,{w=0.2} who am I kidding...?{w=0.5} I'm the least direct guy in all the Worlds combined."
            show mikeend 1 nervous with Dissolve(0.5)
            mike_no "So...{w=0.2} what?{p=0.5}{noalt}*{/noalt} Did you actually wanna hear me ramble on about crap that doesn't matter to you,{w=0.2} or...?"
            menu:
                rq "So... what?\n{noalt}*{/noalt} Did you actually wanna hear me ramble on about crap that doesn't matter to you, or...?"
                "You can speak your mind.":
                    show mikeend 1 confused with Dissolve(0.5)
                    mike_no "What?"
                    show mikeend 1 nervous with Dissolve(0.5)
                    mike_no "I mean...{w=0.5} Okay.{w=0.5} Okay?{p=0.5}{noalt}*{/noalt} If ya really want me to."
                    mike_no "Just,{w=0.2} tell me to shut up when you're sick of hearing me yap."

                "Not really.":
                    $ mke_noexplain = True
                    show mikeend 1 sigh with Dissolve(0.5)
                    mike_no "Yeah,{w=0.2} that's fair."
                    mike_no "I won't drag you down a rabbit hole of \"woe is me\" or anything like that,{w=0.2} don't worry about any'a that."
                    mike_no "You've got your own crap to deal with, anyway,{w=0.2} I'm sure...{p=0.5}{noalt}*{/noalt} You don't need to carry all my garbage,{w=0.2} too."
                    show mikeend 1 nervous with Dissolve(0.5)
                    mike_no "But...{w=0.5} Thanks for trying to help,{w=0.2} at least."

    if not mke_noexplain:
        pause 1.0
        show mikeend 2 avert with Dissolve(0.5)
        mike_no "So,{w=0.2} uh."
        pause 1.0
        show mikeend 2 sigh with Dissolve(0.5)
        mike_no "I'm...{w=0.5} still tired.{w=0.2} Real tired."
        mike_no "You know,{w=0.2} the kind of tired when the weight of the world feels like it's resting on your shoulders..."
        mike_no "... and you can't do anything to move it,{w=0.2} despite how hard ya try?"
        show mikeend 2 frown with Dissolve(0.5)
        mike_no "That kinda tired."
        pause 1.0
        show mikeend 2 pained with Dissolve(0.5)
        mike_no "I just wanted to make sure Tenna was happy,{w=0.2} y'know?"
        mike_no "He always lashes out at everyone when he's not,{w=0.2} for one thing.{p=0.5}{noalt}*{/noalt} But..."
        pause 1.0
        show mikeend 2 sigh with Dissolve(0.5)
        mike_no "I left him when he needed me most...{w=0.5} all of us did."
        show mikeend 2 panic with Dissolve(0.5)
        mike_no "But, 'cause--{w=0.2} I'm MIKE,{w=0.2} right?!{p=0.5}{noalt}*{/noalt} MIKE'S supposed to be there for Tenna,{w=0.2} even if no one else is!"
        mike_no "\"Always there for Tenna,{w=0.2} never not there!\"{p=0.5}{noalt}*{/noalt} Hahahahaha!"
        show mikeend 2 pained with Dissolve(0.5)
        mike_no "...{w=0.2} except,{w=0.2} apparently,{w=0.5} when I just..."
        pause 1.0
        show mikeend 2 panic with Dissolve(0.5)
        mike_no "I saw him with my own two eyes--{w=0.2} he'd completely lost it!{p=0.5}{noalt}*{/noalt} The guy wasn't himself!"
        mike_no "I shoulda known that better than anybody...!!"
        mike_no "But I still was just whiny enough to not be able to do anything that mattered."
        show mikeend 2 sigh with Dissolve(0.5)
        mike_no "Why did I do that...?"
        pause 1.0
        menu:
            "You can't take on everything by yourself.":
                show mikeend 2 avert with Dissolve(0.5)
                mike_no "I mean,{w=0.2} I did hire two other guys."
                mike_no "...{w=0.2} to, uh,{w=0.2} pretend to be me when I...{w=0.5} couldn't.{w=0.2}.{w=0.2}."
                show mikeend 2 panic with Dissolve(0.2)
                mike_no "OKAY, okay,{w=0.2} I'm seeing your point,{w=0.2} but I'm NOT happy about it!!"
                show mikeend 2 angry with Dissolve(0.2)
                mike_no "Look,{w=0.2} look,{w=0.2} LOOK,{w=0.2} this is DIFFERENT!{p=0.2}{noalt}*{/noalt} Completely DIFFERENT!!"
                show mikeend 2 frown with Dissolve(0.5)
                mike_no "Tenna trusted me to be there for him,{w=0.2} and I wasn't."
                mike_no "I didn't even get to tell him I was sorry..."
                show mikeend 2 panic with Dissolve(0.5)
                mike_no "And now he's--{w=0.2} he's out here,{w=0.2} rotting in a heap of trash,{w=0.2} all by himself,{w=0.2} like he NEVER wanted,{w=0.2} and it's all my fault!"
                show mikeend 2 sigh with Dissolve(0.5)
                mike_no "All my fault,{w=0.2} all because I couldn't...{w=0.5} just deal with it for another TWO seconds longer..."
                pause 1.0
                menu:
                    "It's not your fault.":
                        show mikeend 2 panic with Dissolve(0.2)
                        mike_no "HOW?{w=0.2} How could it possibly NOT be my fault?!"
                        mike_no "Mike is Tenna's best friend.{p=0.5}{noalt}*{/noalt} He trusts Mike more than ANYONE ELSE.{w=0.2} PERIOD."
                        show mikeend 2 pained with Dissolve(0.5)
                        mike_no "Ahh,{w=0.2} it gets even worse,{w=0.2} because I'm not really Mike!{w=0.2} Hahaha!{p=0.2}{noalt}*{/noalt} Right,{w=0.2} RIGHT?!"
                        mike_no "No matter how much I--"
                        pause 1.0
                        show mikeend 2 panic with Dissolve(0.2)
                        mike_no "OKAY SHUTTING UP NOW."
                        show mikeend 2 sigh with Dissolve(0.5)
                        mike_no "Ugh.{w=0.5} Forget I just said anything..."
                        mike_no "I just...{p=0.5}{noalt}*{/noalt} I never wanted this to happen.{p=0.5}{noalt}*{/noalt} I never wanted to see Tenna hurt like that..."
                        show mikeend 2 pained with Dissolve(0.5)
                        mike_no "But I didn't know what to do...!{p=0.2}{noalt}*{/noalt} I just panicked and ran,{w=0.2} like a complete coward!"
                        mike_no "If I'd just rolled with it,{w=0.2} instead{w=0.2}.{w=0.2}.{w=0.2}.{p=0.5}{cps=25}{noalt}*{/noalt} Would things have turned out better...?{/cps}"
                        pause 1.0

                    "It'll be okay.":
                        show mikeend 2 angry with Dissolve(0.2)
                        if persistent.glitches:
                            mike_no "HOW.{w=0.2} Genuinely HOW."
                        else:
                            mike_no "HOW.{w=0.2} Genuinely {sc=2}HOW.{/sc}"
                        show mikeend 2 panic with Dissolve(0.5)
                        mike_no "My boss is lost,{w=0.2} I'M lost,{w=0.5} I made a deal with some sketchy person because I was desperate,{w=0.2} and now I'm gambling my LIFE away--"
                        if persistent.glitches:
                            mike_no "Tell me,{w=0.2} O Wise and Holy Lighter,{w=0.5} how the HELL is\nthis supposed to get ANY BETTER?!"
                        else:
                            mike_no "Tell me,{w=0.2} O Wise and Holy Lighter,{w=0.5} {sc=2}how the HELL is\nthis supposed to get ANY BETTER?!{/sc}" # SELF VOICING FIX
                        show mikeend 2 avert with Dissolve(0.5)
                        mike_no "...{w=0.5} Well, actually,{w=0.5} death WOULD be easier to manage.{p=0.5}{noalt}*{/noalt} Can't care if I can't feel anything."
                        pause 1.0
                        show mikeend 2 angry with Dissolve(0.2)
                        if mke_hallu:
                            mike_no "...{w=0.2} Oh, what,{w=0.2} you can make morbid jokes but I can't?!{p=0.5}{noalt}*{/noalt} Don't gimmie that look!!"
                        else:
                            mike_no "...{w=0.2} Hey,{w=0.2} hey,{w=0.2} I'm kidding,{w=0.2} it's a joke,{w=0.2} a JOKE,{w=0.5} don't look at me so pitifully!!"
                        show mikeend 2 sigh with Dissolve(0.5)
                        mike_no "My point is..."
                        show mikeend 2 smile with Dissolve(0.5)
                        mike_no "I...{w=0.5} appreciate you tryin' to help,{w=0.2} at least."
                        pause 1.0

            "It's okay to set boundaries.":
                show mikeend 2 angry with Dissolve(0.5)
                mike_no "What the heck does that have to do with anything?!"
                mike_no "This has nothing to do with boundaries!!{w=0.2} Tenna needed me,{w=0.2} and I failed him!!"
                show mikeend 2 frown with Dissolve(0.5)
                mike_no "I'm not really the most comforting guy out there or anything, but...{w=0.2} I've been TRYING."
                show mikeend 2 pained with Dissolve(0.5)
                mike_no "I just...{w=0.5} Somebody's gotta do something,{w=0.2} or ALL of us get to deal with it!"
                mike_no "I'm not tryin' to be a hero!{w=0.2} Or...{w=0.5} I'm not TRYING to, anyway..."
                show mikeend 2 sigh with Dissolve(0.5)
                mike_no "He just...{w=0.2} I wish he ONCE would have just..."
                pause 1.0
                show mikeend 2 avert with Dissolve(0.5)
                mike_no "Look,{w=0.2} look,{w=0.2} my point is,{w=0.2} this isn't about boundaries!!{p=0.5}{noalt}*{/noalt} This is about helping somebody in need,{w=0.2} alright?!"
                mike_no "I can't just brush him aside..."
                pause 1.0
                menu:
                    "You've been doing more than enough.":
                        pause 0.5
                        show mikeend 2 confused with Dissolve(0.5)
                        mike_no "...{w=0.2} huh?"
                        pause 1.0
                        show mikeend 2 angry with Dissolve(0.5)
                        mike_no "H-{w=0.1} hey,{w=0.2} don't go spouting stuff you don't know is true!{p=0.5}{noalt}*{/noalt} You don't know a thing I've done..."
                        mike_no "I..."
                        show mikeend 2 avert with Dissolve(0.5)
                        pause 1.0
                        mike_noshh ".{w=0.2}.{w=0.2}."
                        show mikeend 2 smile with Dissolve(0.5)
                        mike_no "Hahaha."
                        mike_no "Why did hearing you say that...{w=0.5} make me feel both relieved and exhausted at the same time?"
                        mike_no "Like,{w=0.2} \"I wanna take a nap\" exhausted.{p=0.5}{noalt}*{/noalt} Not like the thing I said before."
                        show mikeend 2 sigh with Dissolve(0.5)
                        mike_no "I don't have time for that,{w=0.2} though..."
                        pause 1.0
                        show mikeend 2 avert with Dissolve(0.5)
                        mike_no "...{w=0.2} oh,{w=0.2} who am I kidding?{p=0.5}{noalt}*{/noalt} This entire thing is a joke.{w=0.5} This entire escapade was a joke the moment I started."
                        mike_no "I just...{w=0.5} kinda want a break,{w=0.2} actually..."
                        show mikeend 2 sigh with Dissolve(0.5)
                        mike_no "Is that bad...?{p=0.5}{noalt}*{/noalt} Tenna's out there all alone,{w=0.2} and I just want a break?!"
                        mike_no "I feel like...{w=0.5} such a jerk."
                        pause 0.5

                    "You can say \"no\" sometimes.":
                        show mikeend 2 angry with Dissolve(0.2)
                        mike_no "HA!{w=0.2} YEAH, RIGHT!!"
                        mike_no "You know what happened the LAST time I did that,{w=0.2} huh?{w=0.2} HUH??"
                        show mikeend 2 panic with Dissolve(0.5)
                        if persistent.glitches:
                            mike_no "Yeah, that's right--{w=0.2} THAT'S HOW TENNA GOT STUCK HERE\nTO BEGIN WITH!!"
                            mike_no "I backed out,{w=0.2} I tried to quit,{w=0.2} I abandoned him when he needed me more than ever--{w=0.2} AND HE GOT THROWN OUT!"
                            mike_no "Now he's just,{w=0.2} GONE,{w=0.2} and I can't even tell him..."
                        else:
                            mike_no "Yeah, that's right--{w=0.2} {sc=2}THAT'S HOW TENNA GOT STUCK HERE\nTO BEGIN WITH!!{/sc}" # SELF VOICING FIX
                            mike_no "I backed out,{w=0.2} I tried to quit,{w=0.2} I abandoned him when he needed me more than ever--{w=0.2} {sc=2}AND HE GOT THROWN OUT!{/sc}" # SELF VOICING FIX
                            mike_no "Now he's just,{w=0.2} {sc=2}GONE,{/sc}{w=0.2} and I can't even tell him..."
                        show mikeend 2 pained with Dissolve(0.5)
                        mike_no "...{w=0.5} {cps=25}I can't even tell him I'm sorry...{/cps}"
                        show mikeend 2 frown with Dissolve(0.5)
                        mike_no "What's wrong with me?{w=0.2} Am I just selfish?!"
                        show mikeend 2 panic with Dissolve(0.2)
                        mike_no "Stupid,{w=0.2} hahaha,{w=0.2} I'm just a stupid JERK,{w=0.2} is what I am!"

            "This is more than I can help with.":
                $ mke_sorry = True
                show mikeend 2 avert with Dissolve(0.5)
                mike_no "That's fine...{w=0.2} I'm not really asking for help."
                mike_no "I wouldn't expect you to just jump in and fix everything.{p=0.5}{noalt}*{/noalt} Though,{w=0.2} I guess I..."
                show mikeend 2 sigh with Dissolve(0.5)
                mike_no "Augh.{w=0.2} Forget it.{p=0.5}{noalt}*{/noalt} I'll just shut my trap now."

        if not mke_sorry:
            show mikeend 2 sigh with Dissolve(0.5)
            mike_no "...{w=0.2} Ah,{w=0.2} just forget it.{w=0.5} Forget it,{w=0.2} this isn't worth talking about."
            mike_no "I've got so many issues that could each take a millennia to solve.{w=0.5} No way I'm expecting you to deal with all that."
            mike_no "So don't...{w=0.5} Well,{w=0.2} just don't."
            show mikeend 2 avert with Dissolve(0.5)
            mike_no "Especially since...{w=0.5} it might not even matter,{w=0.2} when time's up."
            pause 1.0
            menu:
                "Why do you keep cutting yourself off?":
                    $ mke_hesitation = True
                    show mikeend 2 confused with Dissolve(0.5)
                    mike_no "...{w=0.2} huh?{p=0.5}{noalt}*{/noalt} What'd'ya mean?"
                    mike_no "What,{w=0.2} that I keep saying it's not worth talking about all this crap?"
                    show mikeend 2 avert with Dissolve(0.5)
                    mike_no "I don't see why that should matter to you.{p=0.2}{noalt}*{/noalt} You're not a therapist or anything.{w=0.5} That I know of,{w=0.2} I guess."
                    mike_no "Though,{w=0.5} not like I ever was either,{w=0.2} I guess..."
                    pause 1.0
                    show mikeend 2 sigh with Dissolve(0.5)
                    mike_no "Ah...{p=0.5}{noalt}*{/noalt} No, no,{w=0.2} you're right,{w=0.2} you've got a point."
                    show mikeend 2 nervous with Dissolve(0.5)
                    mike_no "Actually...{w=0.5} you're not the first one to tell me somethin' like that."
                    mike_no "The...{w=0.2} The other two,{w=0.2} the guys who I hired to also be Mike.{p=0.2}{noalt}*{/noalt} They were real concerned about me headin' out here."
                    mike_no "Mostly 'cause...{w=0.5} I didn't tell them pretty much anything.{w=0.2} At all."
                    show mikeend 2 avert with Dissolve(0.5)
                    mike_no "They probably weren't gonna believe me,{w=0.2} for one thing,{w=0.2} but secondly?{p=0.5}{noalt}*{/noalt} Even if they did...{w=0.5} I didn't really want 'em to know."
                    mike_no "About everything out here, sure,{w=0.2} but also...{w=0.5} all the prophecy crap,{w=0.2} too."
                    show mikeend 2 sigh with Dissolve(0.5)
                    mike_no "I didn't find out the whole thing,{w=0.2} but,{w=0.2} even what I did,{w=0.2} it wasn't..."
                    pause 1.0
                    show mikeend 2 nervous with Dissolve(0.5)
                    mike_no "I'm getting off track.{p=0.5}{noalt}*{/noalt} Anyway,{w=0.2} those two get real mad at me for not telling them everything,{w=0.2} too."
                    mike_no "They're not wrong for that,{w=0.2} either.{p=0.5}{noalt}*{/noalt} But I never know what to do about it."
                    show mikeend 2 sigh with Dissolve(0.5)
                    mike_no "There's way too much going on in my head all the time.{p=0.2}{noalt}*{/noalt} I never know where to start.{w=0.2} Or when to stop."
                    mike_no "I'm all over the place,{w=0.2} all the time!{p=0.5}{noalt}*{/noalt} I talk about a lotta stuff but it's a lotta nothing!"
                    mike_no "I never get to anything that matters 'cause I...{p=0.5}{noalt}*{/noalt} I never know how to say it."
                    show mikeend 2 frown with Dissolve(0.5)
                    mike_no "People get mad when you bring up the important stuff,{w=0.2} ya know?"
                    mike_no "I don't actually wanna upset people, but...{w=0.5} I don't know how NOT to.{p=0.5}{noalt}*{/noalt} I'm really not good at this kinda stuff."
                    mike_no "Doesn't help,{w=0.2} probably,{w=0.2} that I wait until I can't hold it in anymore,{w=0.2} so it all just boils over..."
                    show mikeend 2 pained with Dissolve(0.5)
                    mike_no "Ahh,{w=0.2} y'know what?{p=0.2}{noalt}*{/noalt} It doesn't matter!"
                    show mikeend 2 sigh with Dissolve(0.5)
                    mike_no "It doesn't matter,{w=0.2} 'cause, at the end of the day,{w=0.5} I'm just a real shitty jerk."
                    pause 1.0
                    menu:
                        "You're not a jerk.":
                            show mikeend 2 frown with Dissolve(0.5)
                            mike_no "Yeah?{w=0.2} Ya think?"
                            show mikeend 2 avert with Dissolve(0.5)
                            mike_no "Well,{w=0.2} ya haven't really known me for very long,{w=0.2} so that's...{p=0.5}{noalt}*{/noalt} Actually,{w=0.2} wait, no,{w=0.2} that's still kind of surprising."
                            show mikeend 2 confused with Dissolve(0.5)
                            mike_no "Wait,{w=0.2} yeah,{w=0.2} no,{w=0.2} haven't I just been yelling and yapping at you this whole time??"
                            show mikeend 2 avert with Dissolve(0.5)
                            mike_no "...{w=0.2} Though.{w=0.2} Maybe it's, not weird.{p=0.5}{noalt}*{/noalt} You are still...{w=0.2} uh, hugging me.{w=0.2} For some reason."
                            pause 1.0
                            show mikeend 2 sigh with Dissolve(0.5)
                            mike_no "Y'know.{w=0.2} The other two say that a lot, too.{p=0.5}{noalt}*{/noalt} That I'm not a jerk."
                            mike_no "I kinda think they've lost their marbles sometimes."
                            mike_no "Or have a really bad frame of reference for what a \"good person\" is."
                            show mikeend 2 avert with Dissolve(0.5)
                            mike_no "But...{w=0.2} I dunno.{p=0.5}{noalt}*{/noalt} It's somehow different hearing you, some random person I just met,{w=0.2} say the same thing?"
                            mike_no "Sometimes I wonder if they just feel obligated to put up with me.{p=0.5}{noalt}*{/noalt} But you've got no reason to be here."
                            show mikeend 2 nervous with Dissolve(0.5)
                            mike_no "Yet...{w=0.5} you are,{w=0.2} anyway."
                            mike_no "Even though...{w=0.5} even though I'm not even the guy you were looking for."

                        "You don't have to hold back.":
                            show mikeend 2 frown with Dissolve(0.5)
                            mike_no "If I didn't,{w=0.2} we'd be stuck here until my dying breath."
                            mike_no "Only reason it wouldn't be yours, too,{w=0.2} is 'cause I'm pretty sure I'm..."
                            pause 1.0
                            show mikeend 2 sigh with Dissolve(0.5)
                            mike_no "Forget it."
                            mike_no "Or,{w=0.2} ah...{w=0.5} I guess, you just asked me to stop sayin' that."
                            show mikeend 2 avert with Dissolve(0.5)
                            mike_no "...{w=0.5} I'm real bad at listening, too,{w=0.2} apparently."
                            pause 1.0
                            show mikeend 2 nervous with Dissolve(0.5)
                            mike_no "Y'know,{w=0.2} I told myself years ago I wanted to stop bein' such a jerk,{w=0.2} and I feel like I've been trying real hard to do that..."
                            mike_no "... but I also feel like I haven't changed at all."
                            mike_no "The other two insist that I have,{w=0.2} but I just don't see it."
                            show mikeend 2 pained with Dissolve(0.5)
                            mike_no "Especially since,{w=0.2} they're often taking the brunt of my freak-outs,{w=0.5} since I end up going quiet if I accidentally slip up in front of Tenna..."
                            show mikeend 2 sigh with Dissolve(0.5)
                            mike_no "They say it doesn't bother 'em,{w=0.2} but...{w=0.5} I know it can't feel good."
                            show mikeend 2 confused with Dissolve(0.5)
                            mike_no "... and,{w=0.2} then there's you,{w=0.2} somehow."

                        "...":
                            pass

                "...":
                    pass

    scene black with Dissolve(2.0)
    pause 2.0
    scene junkyard5 with Dissolve(2.0)
    pause 1.0
    show mike standing conflicted at mikepos_center with Dissolve(1.0)

label secret_ending_mike_you:
    mike_no "Honestly,{w=0.2} I really don't get you."
    show mike tie nervous
    if mke_comfort:
        mike_no "Haven't ya just met me?{p=0.5}{noalt}*{/noalt} You tried helpin' me out and even...{w=0.5} Y'know,{w=0.2} all that.{w=0.5} That,{w=0.2} that just happened."
    else:
        mike_no "Haven't ya just met me?{p=0.5}{noalt}*{/noalt} Yet you still wanted to help me find Tenna...?"
    show mike standing sigh at droop
    mike_no "Not that I'm...{w=0.5} really in a position to criticize that--"
    show mike arms freakout at jump
    mike_no "But--{w=0.2} why bother??{p=0.5}{noalt}*{/noalt} What,{w=0.2} did I rack up enough pity points that you felt you HAD to??"
    show mike arms avert
    mike_no "Or are you just completely bored?!{p=0.5}{noalt}*{/noalt} Got nothing better to do with your time that you'd rather waltz around a dump for hours?"
    menu:
        rq "Or are you just completely bored?!\n{noalt}*{/noalt} Got nothing better to do with your time that you'd rather waltz around a dump for hours?"
        "I was also looking for Tenna":
            show mike standing indifferent at jump
            mike_no "Oh,{w=0.2} right."
            show mike standing nervous
            mike_no "Yeah,{w=0.2} right,{w=0.2} you said something about that already,{w=0.2} didn't ya?"
            if mke_silence:
                show mike standing conflicted
                mike_no "Or...{w=0.2} did you?{p=0.5}{noalt}*{/noalt} Ah,{w=0.2} nevermind,{w=0.2} that's not important."
            show mike standing sigh
            mike_no "But,{w=0.2} even still,{w=0.2} now that we can't find him,{w=0.5} you're still sticking around...?"
            show mike standing angry
            mike_no "You coulda left at any point,{w=0.2} y'know.{p=0.5}{noalt}*{/noalt} Not like I really woulda cared."
            show mike tie avert at jump
            mike_no "I was hopeful,{w=0.2} but...{p=0.5}{noalt}*{/noalt} I had a feeling things were gonna go poorly for me out here,{w=0.2} anyway."
            pause 1.0
            menu:
                "I didn't want to leave you alone.":
                    show mike standing sigh
                    mike_no "You REALLY don't need to conern yourself with that.{p=0.5}{noalt}*{/noalt} I'm pretty used to being alone."
                    show mike tie nervous
                    mike_no "The fact that I've talked to more than ONE person in the past ten years?{p=0.5}{noalt}*{/noalt} THAT'S surprising in itself."
                    show mike tie avert
                    pause 1.0
                    show mike standing nervous
                    mike_no "Well...{w=0.5} If anything,{w=0.2} I guess it's worth SOMETHING that I got to do the stuff that I did."
                    mike_no "Never really expected to have friends or...{w=0.5} somebody who I would be willing to throw away my life for."
                    pause 1.0
                    show mike tie nervous at wiggle
                    mike_no "Hahaha,{w=0.2} actually...{p=0.5}{noalt}*{/noalt} Knowing my luck,{w=0.2} I was certain that if everything went wrong,{w=0.2} I was just gonna die out here by myself."
                    show mike standing conflicted at yreset
                    mike_no "But if you're here,{w=0.2} before that happened...{p=0.5}{noalt}*{/noalt} Did I actually get lucky,{w=0.2} for once?"

                "I didn't have anywhere else to go.":
                    show mike standing pout
                    mike_no "Ah,{w=0.2} so...{w=0.5} you're just stuck here by chance?"
                    show mike tie nervous at wiggle
                    mike_no "Hahaha.{p=0.5}{noalt}*{/noalt} That's a little...{w=0.5} eerily familiar,{w=0.2} to be entirely honest with you."
                    show mike standing nervous at yreset
                    mike_no "It's nothing you did,{w=0.2} I promise ya that.{w=0.2} Just..."
                    show mike standing sigh
                    mike_no "It's not the first time I've been a last resort for somebody."
                    if persistent.glitches:
                        show mike arms freakout
                    else:
                        show mike arms freakout at shakingcg
                    mike_no "The whole MIKE schtick to begin with is BASICALLY just that!!"
                    show mike standing angry at jump
                    mike_no "Honestly,{w=0.2} I'd probably be MORE confused if you'd told me that...{w=0.5} I dunno,{w=0.2} you somehow KNEW I was here,{w=0.2} so you came here JUST to see me??"
                    show mike standing conflicted
                    mike_no "There's no way that's the case.{p=0.5}{noalt}*{/noalt} It'd have to be some kind of miracle for that to happen."
                    show mike standing angry
                    mike_no "And I'm not a guy who ever has miracles happen to him."

        "Why can't I want to help you?":
            show mike standing indifferent at jump
            pause 0.5
            show mike standing conflicted
            mike_no "I..."
            pause 1.0
            show mike standing nervous
            mike_no "I mean,{w=0.2} I guess there's not really anything that says you CAN'T,{w=0.2} it's just..."
            show mike standing sigh
            mike_no "Isn't it a bit much for you to stick your neck out like that for someone you{w=0.2}.{w=0.2}.{w=0.2}.{nw=0.5}"
            show mike standing indifferent at droop
            extend "{cps=35} barely even know.{/cps}"
            pause 1.0
            menu:
                "What's with the hesitation?":
                    if mke_hesitation:
                        show mike tie nervous at jump
                        mike_no "It's not--{w=0.2} uh..."
                        show mike tie avert
                        pause 1.0
                        show mike standing sigh
                        mike_no "You're gonna be upset if I don't explain it,{w=0.2} aren't ya?"
                        pause 1.0
                        show mike standing nervous
                        mike_no "Okay,{w=0.2} well..."
                    else:
                        mike_no "What hesitation?{w=0.2} I'm not hesitating on saying anything.{p=0.2}{noalt}*{/noalt} Where'd ya get that idea from?!"
                        mike_no "I said everything I was going to say!!{w=0.2} I don't have anything more to say!!"
                        mike_no "Ah,{w=0.2} forget it.{p=0.5}{noalt}*{/noalt} Really, it's really nothing major,{w=0.2} anyway,{w=0.2} so don't sweat it."
                        pause 1.0
                        show mike standing angry at jump
                        mike_no "HEY,{w=0.2} don't look at me like that!!"
                        show mike standing conflicted
                        mike_no "Alright,{w=0.2} ALRIGHT,{w=0.2} fine.{p=0.5}{noalt}*{/noalt} I've never been all that good of a liar,{w=0.2} anyway."
                        show mike arms freakout at jump
                        mike_no "I know.{w=0.2} IRONIC!"
                        show mike standing sigh
                        mike_no "Whatever,{w=0.2} just..."
                    show mike tie nervous 
                    if m_memshard:
                        mike_no "You remember that blue shard thing you showed me before...?{p=0.5}{noalt}*{/noalt} And that whole situation you told me about that you saw in it."
                        show mike standing sigh
                        mike_no "Well,{w=0.2} that's...{w=0.5} A real thing that happened.{p=0.5}{noalt}*{/noalt} Pretty much exactly how you explained it to me."
                        show mike standing nervous
                        mike_no "It was about ten or so years ago by now."
                        mike_no "He looked about ready to throw me into the nearest brick wall that day, but..."
                    else:
                        mike_no "So,{w=0.2} I met Tenna just over ten years ago."
                        mike_no "I didn't really care much about him at first,{w=0.2} when I started working for him."
                        show mike standing sigh
                        mike_no "But...{w=0.5} One day,{w=0.2} I just saw him in so much pain and I..."
                    show mike standing conflicted at droop
                    mike_no "I knew I needed to help."
                    show mike tie avert at wiggle
                    mike_no "He ended up scaring half the crew every other day,{w=0.2} and wasn't usually all that kind, either,{w=0.5} but I still had to help him."
                    show mike tie nervous at jump
                    mike_no "I mean,{w=0.2} I guess I didn't HAVE to,{w=0.5} but I FELT like I had to."
                    show mike standing conflicted
                    mike_no "Everyone else was just scared or talked crap behind his back, so...{w=0.5} Who else was gonna do it?"

                "You're not real":
                    mike_no "...{w=0.2} huh?"
                    show mike standing nervous
                    mike_no "Oh."
                    pause 1.0
                    show mike standing sigh
                    mike_no "Well,{w=0.2} I mean,{w=0.2} I guess you saying that makes sense...{p=0.5}{noalt}*{/noalt} You're a Lightner,{w=0.2} right?"
                    show mike standing pout
                    mike_no "In the Light World,{w=0.2} we're just...{p=0.5}{noalt}*{/noalt} We're just \"objects\" from your perspective,{w=0.2} yeah?"
                    show mike standing nervous
                    mike_no "So this probably seems surreal.{p=0.5}{noalt}*{/noalt} Talking to \"objects.\"{w=0.2} Finding out we've got lives where you can't see."
                    show mike tie avert
                    mike_no "I'll be honest,{w=0.2} it's...{w=0.5} still really weird to SEE Lightners,{w=0.2} in the flesh, too."
                    show mike tie nervous
                    mike_no "Sometimes,{w=0.2} I wondered if Lightners weren't real,{w=0.2} either..."
                    show mike arms avert at jump
                    mike_no "I mean,{w=0.2} the idea of beings made of Light that just--{w=0.2} treat us like toys??"
                    show mike arms freakout
                    mike_no "We're only supposed to be able to have connection to the Light World when a Dark Fountain is open,{w=0.2} but??{p=0.5}{noalt}*{/noalt} We still just have LIVES,{w=0.2} y'know!"
                    mike_no "It's not just,{w=0.2} GONE because there's no Fountain..."
                    show mike arms avert at jump
                    mike_no "It sounds like crazy talk!{w=0.2} At best a MYTH!{p=0.5}{noalt}*{/noalt} But,{w=0.2} now..."
                    show mike standing sigh at droop
                    mike_no "Maybe it's a little more real than I thought..."

        "I needed an escape":
            show mike standing indifferent at jump
            pause 0.5
            show mike standing conflicted
            mike_no "You needed an ESCAPE?{w=0.2} From, WHAT exactly?"
            show mike standing sigh
            mike_no "Is it related to your whole deal with why you've got a crystal-thingy,{w=0.2} too?{p=0.5}{noalt}*{/noalt} Or,{w=0.2} is it something else entirely?"
            pause 1.0
            show mike tie nervous at jump
            mike_no "Hey,{w=0.2} hey,{w=0.2} wait.{p=0.5}{noalt}*{/noalt} You're a Lightner,{w=0.2} right?"
            show mike tie avert
            mike_no "Or, even if you're not--{w=0.5} you're definitely something \"Lighter\" than this Dark World."
            show mike standing conflicted
            mike_no "Are you trying to escape just...{w=0.5} a hopeless reality?"
            show mike tie awkward at jump
            mike_no "Ah,{w=0.2} no,{w=0.2} forget it,{w=0.5} I'm probably reading too deep into it as usual."
            pause 1.0
            menu:
                "I feel hopeless":
                    show mike standing indifferent at jump
                    pause 1.0
                    show mike standing nervous at droop
                    mike_no "...{w=0.5} Yeah?{p=0.5}{noalt}*{/noalt} I get that feeling."
                    show mike standing sigh
                    mike_no "Everything's felt kinda hopeless for me for...{w=0.5} ages now,{w=0.2} too."
                    show mike tie nervous at jump
                    mike_no "It's just that,{w=0.2} NOW-now,{w=0.2} when there's actually an end in sight..."
                    show mike standing conflicted
                    mike_no "I've been begging for one for as long as I can remember...{w=0.5} but,{w=0.2} suddenly,{w=0.2} when there's a real chance I won't make it out alive...?"
                    show mike standing nervous
                    mike_no "I'm actually terrified.{p=0.5}{noalt}*{/noalt} Is that weird?"
                    pause 1.0
                    show mike standing angry
                    mike_no "Wow,{w=0.2} you look SO convinced.{p=0.2}{noalt}*{/noalt} My panic is just melting away."
                    show mike standing indifferent
                    mike_no "...{nw=0.2}"
                    show mike arms freakout at jump
                    extend "Oh, c'mon,{w=0.2} what,{w=0.2} you can't take a little sarcasm?!{w=0.2} Sheesh."
                    if mke_hallu:
                        show mike arms avert at jump
                        mike_no "Hey,{w=0.2} the joke you made earlier was WAY different,{w=0.2} don't gimmie that look!!"
                    show mike standing sigh
                    mike_no "Ah, forget it.{w=0.2} Forget I said anything about that.{p=0.2}{noalt}*{/noalt} Point is..."
                    show mike standing nervous
                    mike_no "It's,{w=0.2} okay.{w=0.5} If you feel that way.{p=0.2}{noalt}*{/noalt} Y'know?"
                    show mike tie nervous at wiggle
                    mike_no "Like,{w=0.2} it's not FUN to be absolutely miserable.{p=0.5}{noalt}*{/noalt} But it doesn't make you,{w=0.2} a terrible person or anything."
                    show mike standing pout at yreset
                    mike_no "There's...{w=0.2} things that make it less hopeless sometimes.{p=0.5}{noalt}*{/noalt} So ya gotta keep doing it for the stuff that makes things less bad."
                    mike_no "No matter what it is."
                    show mike tie awkward at jump
                    mike_no "I don't know if that's actually helpful or anything,{w=0.2} but it's all I've got,{w=0.2} okay?!"

                "You're not real":
                    show mike standing indifferent
                    pause 1.0
                    mike_no "... Uh???"
                    show mike standing angry
                    mike_no "What,{w=0.2} is that your way of blowing off my fear?{p=0.5}{noalt}*{/noalt} Well,{w=0.2} gee,{w=0.2} thanks."
                    pause 1.0
                    show mike standing nervous
                    mike_no "Or...{w=0.2} did you mean somethin' else?"
                    mike_no "It's,{w=0.2} kinda hard to tell.{p=0.5}{noalt}*{/noalt} Ya said it with such a strained expression..."
                    pause 1.0
                    show mike tie nervous at jump
                    mike_no "Well, whatever you meant..."
                    show mike tie avert
                    mike_no "...{w=0.2} No, nevermind.{p=0.5}{noalt}*{/noalt} Just,{w=0.2} know I'm not mad at ya."
                    show mike standing conflicted
                    mike_no "Sometimes you just say off stuff when you're upset or whatever,{w=0.2} right...?"
                    mike_no "Can't really be mad at you for something like that."

        "I wanted to be with someone":
            show mike standing indifferent
            mike_no "Just...{w=0.2} someone?"
            show mike standing pout at droop
            mike_no "So, you'd take anything,{w=0.2} huh..."
            show mike tie nervous
            mike_no "... Well.{w=0.2} That's a bit,{w=0.2} uncomfortably familiar."
            pause 1.0
            menu:
                "I'm glad I found you.":
                    if persistent.glitches:
                        show mike arms freakout at jump
                    else:
                        show mike arms freakout at shock
                    mike_no "Pffpftpftt!?"
                    show mike standing angry at jump
                    mike_no "What the heck are you going on about?!{p=0.2}{noalt}*{/noalt} I'm some freak you found in the trash!!" 
                    mike_no "Don't just say crap like that just because I'M feeling bad,{w=0.2} you--{w=0.2} {noalt}yatzy{/noalt}{alt}yahtzee{/alt}!!"
                    show mike standing conflicted
                    mike_no "There's nothing I've done here in the slightest that should make you care about me as an individual even SLIGHTLY."
                    show mike arms avert at jump
                    mike_no "So, just... don't!!"
                    pause 1.0
                    show mike standing angry
                    mike_no "Don't look at me like that."
                    show mike standing sigh at droop
                    mike_no "Ahh,{w=0.2} I went too far again,{w=0.2} didn't I...?"
                    show mike tie avert at wiggle
                    mike_no "Look,{w=0.2} look,{w=0.2} I--{w=0.2} I'm--{w=0.2} not good at this thing,{w=0.2} alright?!"
                    show mike standing nervous at yreset
                    mike_no "I dunno why somebody would wanna care about me at all,{w=0.2} if I'm bein' honest."
                    show mike standing sigh
                    mike_no "So,{w=0.2} uh...{w=0.5} Sorry."

                "You're not real":
                    show mike standing indifferent
                    mike_no "Uh...?"
                    mike_no "How am I supposed to interpret that,{w=0.2} exactly?"
                    show mike standing angry
                    mike_no "You wanted to be with someone,{w=0.2} but,{w=0.2} I'm not real...{p=0.5}{noalt}*{/noalt} How are these two points connected AT ALL??"
                    show mike arms freakout at jump
                    mike_no "Is it just that I'm not enough for you?{p=0.2}{noalt}*{/noalt} You can LEAVE,{w=0.2} ya know!"
                    show mike standing sigh at droop
                    mike_no "Ahh,{w=0.2} no,{w=0.2} no,{w=0.5} I'm jumpin' to conclusions again."
                    pause 1.0
                    show mike standing nervous at rise
                    mike_no "...{w=0.5} To be honest,{w=0.2} I can't really say I'm that bothered by your sentiment."
                    if mke_hallu:
                        show mike standing conflicted
                        mike_no "I know,{w=0.2} probably weird-sounding. I mean,{w=0.2} especially since I hated that joke you said earlier."
                    show mike standing sigh
                    mike_no "A lotta people tend to believe {noalt}Darkners{/noalt}{alt}dark nurs{/alt} are just things made to serve Lightners...{w=0.5} \"Objects,\"{w=0.2} yeah...?"
                    mike_no "Part of me never really believed that."
                    show mike standing pout
                    mike_no "It's not like I've ever done anything to prove that idea wrong, though."
                    show mike standing sigh at droop
                    mike_no "I keep getting so caught up doing stuff for other people that I don't even know who I AM anymore."
                    pause 1.0
                    show mike tie nervous at jump
                    mike_no "I guess,{w=0.2} my point is..."
                    mike_no "Even if I'm just an \"object\" to you...{p=0.5}{noalt}*{/noalt} I hope you're at least h{nw=0.5}"
                    show mike standing awkward at droop
                    extend "-- that you at least don't hate being stuck with me."

        "I don't wanna talk about it":
            show mike standing indifferent at jump
            mike_no "Oh."
            show mike standing nervous at droop
            mike_no "Uh.{p=0.5}{noalt}*{/noalt} That's okay,{w=0.2} too..."
            show mike standing pout
            mike_no "Sorry.{p=0.5}{noalt}*{/noalt} I asked that pretty aggressively,{w=0.2} didn't I...?"
            show mike tie nervous at wiggle
            mike_no "I'm...{w=0.2} real bad at holding my tongue.{p=0.5}{noalt}*{/noalt} Always.{w=0.5} And always have been."
            mike_no "I've been tryin' to work on that,{w=0.2} but..."
            show mike standing sigh at droop
            mike_no "Forget it.{w=0.2} Nevermind.{p=0.2}{noalt}*{/noalt} Let's just move on to something else.{p=0.5}{noalt}*{/noalt} Literally anything else."

    pause 1.0
    show mike standing conflicted at droop
    mike_no "Ahh,{w=0.2} I don't know how to talk to people."
    show mike tie avert
    if m_flirt:
        mike_no "You regretting flirting with me yet?"
    else:
        mike_no "You regretting ever talking to me yet?"
    mike_no "No?{w=0.2} Ah, well...{nw=0.5}"
    show mike standing indifferent at jump
    extend " W-{w=0.1} wait,{w=0.2} NO??"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "Whaddya mean,{w=0.2} \"NO\"??"
    show mike arms avert
    mike_no "Y-{w=0.21} you're--{nw=0.2}"
    show mike tie awkward at jump
    extend " WAIT, wait, wait,{w=0.2} hold on,{w=0.2} lemmie.{w=0.2}\nHold on.{w=0.2} HOLD."
    show mike standing awkward
    mike_no "Let me get this outta the way, first.{w=0.5} Before you start getting crazy eights on me."
    show mike tie awkward at wiggle
    mike_no "We're not--{p=0.2}{noalt}*{/noalt} This is not--{nw=0.5}"
    show mike standing sigh at droop
    extend "{p=0}{noalt}*{/noalt} It's not happening.{w=0.5} S-{w=0.1} sorry."
    show mike tie blush at rise
    mike_no "I just met you, for one thing, but I...{w=0.5} I dunno,{w=0.2} I dunno how to put it!"
    show mike standing awkward
    mike_no "I don't DISLIKE you!{w=0.2} But, I--{w=0.2} this is--{w=0.2} way too fast,{w=0.2} for me."
    show mike tie awkward
    mike_no "And it might not even matter,{w=0.2} so don't get too attached if I'm...{w=0.5} not gonna make it."
    show mike tie blush at wiggle
    mike_no "I mean, and--{w=0.2} my head gets all shaken up when people are nice to me.{p=0.5}{noalt}*{/noalt} Not in the fun way."
    show mike standing sigh at yreset
    mike_no "So, I...{w=0.5} At most, just,{w=0.2} if this doesn't all end in hellfire and death--"
    show mike standing conflicted
    mike_no "Could you gimmie a bit to get used to it,{w=0.2} so I don't have the desire to punch you in the face for saying you actually care about me?"
    show mike tie nervous at jump
    mike_no "Sorry,{w=0.2} I'm sorry,{w=0.2} I really don't wanna upset you,{w=0.2} but I also...{w=0.5} don't wanna outright hurt you,{w=0.2} either."
    menu:
        rq "Sorry, I'm sorry, I really don't wanna upset you, but I also... don't wanna outright hurt you, either."
        "It's okay.":
            "You tell \"Mike\" that you support his decision."
            show mike standing awkward at droop
            mike_no "Th...{w=0.2} thanks.{w=0.5} I think."
            show mike tie nervous at rise
            mike_no "I mean,{w=0.2} sometimes I feel awful about it.{w=0.5} Like I'm supposed to be different or something."
            show mike standing nervous at droop
            mike_no "But it...{w=0.5} means a lot that you think it's okay.{p=0.5}{noalt}*{/noalt} That's what I meant."
            show mike tie awkward at wiggle
            mike_no "You,{w=0.2} ah...{w=0.5} really make me feel..."
            if persistent.glitches:
                show mike arms avert at jump
            else:
                show mike arms avert at shock
            mike_no "N-{w=0.1} nevermind,{w=0.2} NEVERMIND!{p=0.5}{noalt}*{/noalt} Forget it,{w=0.2} forget it,{w=0.2} moving on!!"

        "You won't hurt me.":
            "You tell \"Mike\" you're not afraid of getting hurt."
            show mike standing conflicted at droop
            mike_no "Y'know,{w=0.2} I was trying to be more nice about it...{w=0.5}\nbut I really kinda meant.{p=0.2}{noalt}*{/noalt} No?{w=0.5} Just,{w=0.2} I'm not interested?"
            show mike standing sigh
            mike_no "Maybe I should have been more direct upfront.{p=0.2}{noalt}*{/noalt} Sorry,{w=0.2} that's on me."
            show mike tie avert at rise
            mike_no "Look,{w=0.2} I'm not worth your time anyway.{p=0.2}{noalt}*{/noalt} You should find somebody that's not gonna go poof in a few days..."

        "I wasn't interested in you that way.":
            "You explain that you didn't really want to date \"Mike\" anyway."
            show mike standing indifferent at jump
            mike_no "Oh.{p=0.5}{noalt}*{/noalt}  O-{w=0.1} oh."
            pause 2.0
            show mike tie awkward at wiggle
            mike_no "This isn't awkward at all,{w=0.2} hahahaha,{w=0.2} sorry,{w=0.2} SORRY,{w=0.2} I shouldn't've made that kinda assumption outta no where!!"
            show mike tie blush
            mike_no "My bad,{w=0.2} all me,{w=0.2} all the fault is on me,{w=0.2} nothing wrong with what you said,{w=0.2} just forget about it!"
            mike_no "Ahahahaha...{w=0.5} ha."
            show mike standing awkward at droop
            mike_no "B-{w=0.1} but...{w=0.5} That does relieve a lotta pressure,{w=0.2} if I'm gonna be honest."
            mike_no "So at least,{w=0.2} we cleared that up.{p=0.5}{noalt}*{/noalt} Yeah."
            show mike standing sigh at jump
            mike_no "Ahem."

    show mike standing sigh
    pause 1.0
    show mike standing conflicted
    mike_no "... Okay,{w=0.2} uh.{p=0.5}{noalt}*{/noalt} Now what?"
    show mike tie avert at wiggle
    mike_no "Tenna's still not here.{p=0.5}{noalt}*{/noalt} No idea where to look for the guy anymore,{w=0.2} and I kinda just..."
    mike_no "... wanna stop..."
    show mike standing sigh at droop
    mike_no "But I can't.{w=0.5} This is important.{p=0.5}{noalt}*{/noalt} Way more important than anything else."
    mike_no "I can't just leave Tenna out here all alone,{w=0.2} by himself."
    "You tell \"Mike\" you know a way you could help him out of here,{w=0.2} if he really wants to leave."
    show mike standing indifferent at jump
    mike_no "I..."
    pause 1.0
    show mike standing nervous at droop
    mike_no "...{w=0.2} really?"
    pause 1.0
    show mike tie nervous at jump
    mike_no "...{w=0.2} hey,{w=0.2} um...{p=0.5}{noalt}*{/noalt} Actually,{w=0.2} I still never got your name,{w=0.2} did I...?"
    show mike standing sigh
    mike_no "Forget it.{p=0.2}{noalt}*{/noalt} We can talk about that later."
    show mike tie avert at wiggle
    mike_no "What I meant to ask was,{w=0.2} do you...{w=0.5} think I kinda wasted my time out here?"
    mike_no "Is Tenna actually..."
    pause 2.0
    show mike tie nervous
    mike_no "...{w=0.2} the fact that you don't wanna say anything is, ah...{w=0.5} hahaha.{p=0.5}{noalt}*{/noalt} Telling."
    show mike standing nervous at droop
    mike_no "I...{w=0.5} I'm..."
    pause 2.0
    show mike standing sigh
    mike_no "Shit."
    mike_no "Shit,{w=0.2} I really wanna go back...{p=0.5}{noalt}*{/noalt} I'm so tired.{w=0.5} I'm so damn tired..."
    show mike standing conflicted
    mike_no "I miss the other two so much,{w=0.2} ahaha,{w=0.2} I didn't think I really...{p=0.5}{noalt}*{/noalt} Gah,{w=0.2} I just..."
    show mike arms freakout at jump
    mike_no "I just wanna breathe,{w=0.2} and have,{w=0.2} like,{w=0.2} TWO seconds to myself for once,{w=0.2} just once..."
    show mike standing conflicted
    mike_no "I{w=0.2}.{w=0.2}.{w=0.2}."
    pause 1.0
    show mike standing pout
    mike_no "Hey.{p=0.5}{noalt}*{/noalt} Wh-{w=0.1} when you say you can help me leave..."
    show mike standing nervous
    mike_no "Can you...{w=0.5} take me back to Castle Town?{w=0.2} Please?"
    show mike standing sigh
    mike_no "I don't wanna be here anymore.{p=0.2}{noalt}*{/noalt} I can't do this anymore."
    mike_no "I just...{w=0.5} wanna go.{p=0.5}{noalt}*{/noalt} I really,{w=0.2} really wanna go.{p=0.5}{noalt}*{/noalt} Before anything gets worse."
    "You tell \"Mike\" that you'll figure something out, he just has to follow you first."
    pause 1.0
    show mike standing nervous at rise
    mike_no "Th...{w=0.5} thanks."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    "You led \"Mike\" across the Dark World to the mattress where you'd seen that mystery man."

    ### TRANSITION TO UNIVERSAL ENDING 
    $ end_mike = True
    jump ending_universal