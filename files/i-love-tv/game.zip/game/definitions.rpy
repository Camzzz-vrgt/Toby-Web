############################################################################################################
################## GEN DEFINITIONS
default warnsee = False # does the player want to see the content warning
default multichar = False # are there multiple characters in the cutscene

default prevname = "" # previous player name, when giving a new name

default seenstats_fp = False # if player knows fp
default seenstats_lp = False # if player knows lp

default ex_memory = False # if started search for memoryshards
default memsh_cutscene = False # currently watching a cutscene
default memsh_location = None # applies for what scene to bring back up ; ex_starroom, ex_gameroom, ex_lumproom, ex_mattroom

### rightclick menu mini icons
default rightclick_icon = False # what icons are being used ; "False" is Spamton, "True" is Tenna

### tenna
default ten_name = False # if player entered in tenna's name as their own
default ten_moveboard = False # if player moved board after tenna date
default ten_symp = False # if player relates to tenna'a situation or not
default ten_outlet = False # if player heard him out or not
default ten_care = True # if player says they care about tenna or not
default ten_noexplain = False # if player skipped tenna's explanation of the past ; True if skipped
default ten_rightclick = False # change the mini Tenna in the rightclick menu; True is sad Tenna
default ten_rightclick_op = False # change the mini Tenna in the rightclick menu for opening sequence only
default ten_seen = False # seen his endings or not
default ten_swap = 0 # how many times swapped endings
default ten_cancel = False # if canceled other endings
default ten_tripleswap = False # don't ask about mike
default ten_triplespam = False # ask about dating / spamton dating
default ten_triplesilence = False # silence during his triple end convo

default ten_success = False # got good route ending or not
default ten_failed = False # got the bad end or not

### spamton
default spam_dealchoice = 0 # refusing spamton's deal
default spam_date1 = False # gone on spamton's first date
default spam_info = False # if spamton "hacked" you for "personal information"
default spam_datecheck = False # pass/fail check for going on first date
default spam_handover = False # turned true when selected then turn false again ; for offering your soul
default spam_want = None # questions in spamton's ending
default spam_noexplain = False # if listened to spamton's explanation
default spam_cancel = False # if canceled other endings

default spam_success = False # got good route ending or not
default spam_failed = False # got bad route ending or not

### gaster
default wdg_meet = False # met gaster or not (in-game, not intro)
default wdg_bedmeet = False # talked to via the mattress or not
default wdg_talkingto = False # talking to gaster presently (for reset)

### mike
default mke_menu = False # menu changes for mike date only
default mke_unlock = False # unlocked secret mike date or not
default mke_game = False # finished mike game
default mke_date = False # completed secret mike date or not
default mke_success = False # got good date ending or not
default mke_failed = False # got bad end or not
default mke_special = False # special section dedicated to just if you failed tenna and spamton w/o finding mike
default mke_noexplain = False # want to hear the explanation or not ; True is it was skipped
default mke_hallu = False # if joked abt being a hallucination, True
default mke_sorry = False # if you can't help
default mke_comfort = False # if you comforted him
default mke_silence = False # if said nothing during date (only unlocked during failed everyone but mike ending)
default mke_hesitation = False # asked why mike cuts himself off so much

### endings
default currentend = None # checking for failed heartbreak ; None, "tenna", "spamton", "mike" ; also changes icons in rightclick during spamtenna/triple end
default foundendguide = False # found the ending guide or not
default sptn_stuck = False # if said we might be stuck here for a while
default cont_reload = False # if loaded from continue

# for credits / checking
default end_tenna = False
default end_spamton = False
default end_mike = False
default end_wdg = False # no one else ending

default end_spamtenna = None # None, "started", "done"
default end_battenna = None # None, "started", "done"
default end_spamtat = None # None, "started", "done"
default end_triple = None # None, "started", "done"

# triple end
default end_triple_ten = False # sent tenna to the universal end
default end_triple_spam = False # sent spamton to the universal end 
default end_triple_mke = False # sent mike to the universal end


######################################################
##### COLORS
default c_passion = "#FF54A6"
default c_kindness = "#00C000"
default c_goner = "#aaaaaa"
default c_power = "#FF0000"
default c_star = "#FFF200"
default c_vessel = "#828282"


######################################################
##### PERSISTENT
default persistent.warning = False # content warning at the beginning
default persistent.gastmet = False # if the player has "met" gaster (made upon starting the game)
default persistent.mainskip = False # if player has seen the intro and will "skip" the main menu

default persistent.glitches = False # if player wants to turn off glitches ; if True, they are skipped

default persistent.itemheard = False # items mentioned before or not (affects quick menu + rightclick menu)

default persistent.route = "Tenna" # either "Tenna" or "Spamton" ; affects main menu
default persistent.mainscreen = "Tenna" # either "Tenna" or "Spamton" ; affects main menu ; ONLY WHEN PLAYED THE GAME BEFORE

default persistent.tenroute_fin = False # if tenna's route has been completed ; reset on finished run
default persistent.spamroute_fin = False # if spamton's route has been completed ; reset on finished run

default persistent.mc = "" # player name
default persistent.playthru = False # if player has played before (affects dialogue)
default persistent.reset = False # if player is resetting or not (affects main menu select only)
default persistent.gameover = 0 # how many times the player has hit the game over screen
default persistent.firstend = True # if the player has seen the "end" after spamton date 2
default persistent.cont = False # if selected "contine" after finishing the game
default persistent.prevreset = False # if previously reset
default persistent.loveletter = False # obtained love letter before (for resets)

### human i remember youre
default persistent.here = None # yes, no, maybe, where
default persistent.firstimpress = None # handsome, charming, nose, tall
default persistent.favefood = None # sweets, baked goods, or candy; salty foods, fries or pretzels; bitter foods, coffee, or chocolate; anything.
default persistent.favecolor = None # red, white, black, yellow
default persistent.programs = None # cooking shows, music videos, anime, romance shows
default persistent.blood = None # A, B, AB, O
default persistent.selflove = None # kindness, passion, determination, hope
default persistent.lovetv = False # i love tv.... or not

default persistent.deals = False # took spamton's deal willingly or not


######################################################
##### SOUND CHANNELS
init python:
    renpy.music.register_channel("sfx", "sfx", False) # second sound channel
    renpy.music.register_channel("sfx2", "sfx", False) # third sound channel
    renpy.music.register_channel("loop", "sfx", True) # loop
    renpy.music.register_channel("ambiance", "sfx", True) # ambiance


######################################################
##### WINDOW ICON CHANGE
### https://lemmasoft.renai.us/forums/viewtopic.php?t=67528
define icon1_file = "gui/window_icon.png"
define icon2_file = "gui/window_icon2.png"

init python:
    import pygame
    try:
        with renpy.loader.load(icon1_file) as f:
            icon1 = renpy.display.scale.image_load_unscaled(f, icon1_file)

        with renpy.loader.load(icon2_file) as f:
            icon2 = renpy.display.scale.image_load_unscaled(f, icon2_file)

    except renpy.webloader.DownloadNeeded:
        pass

    def change_icon(a):
        try:
            pygame.display.set_icon(a)
        except:
            pass


######################################################
##### ERASE SAVES
init -1 python:
    def erase_saves():
            for savegame in renpy.list_saved_games(fast=True):
                renpy.unlink_save(savegame)