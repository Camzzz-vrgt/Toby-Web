############################################################################################################
################## ROUTE INTRO
label spamtonstart:
    play ambiance wind fadein 1.0
    scene black
    pause 900
    stop ambiance fadeout 5.0
    play music dialtoneS fadein 6.0
    spamton "NOT THE [[The End.] YOU WANTED?"
    spamton "CAN'T TAKE [[No!] FOR AN ANSWER??"
    spamton "NEED SOMEONE WHO [[The More You Know!] WHAT A {p=0}{noalt}[[$#!$]ING E_MAIL IS{/noalt}{alt}beeping e-mail is{/alt}?!?!?"
    spamton "LOOK NO FURTHER YOU [[desperate little ]"
    $ renpy.pause (1.0, hard=True)
    play sfx bwaa
    scene white with Dissolve(0.2)
    pause 0.5
    scene black
    show soul_sketchy at soulbop
    with Dissolve (1.0)
    $ renpy.pause (3.0, hard=True)
    spamton "HOW ABOUT WE [[Make A Deal!] ?"
    spamton "IF YOU WERE TO [[Give That To Me]"
    pause 0.5
    show spamhand at spamhand_wiggle with Dissolve(2.0)
    pause 2.0
    spamton "[[For the low, low price of] YOUR \n[[{color=[c_passion]}Heart-shapedObject{/color}]{p=0.2}{noalt}*{/noalt} I CAN OFFER YOU [[1] [[HonestMan]"
    spamton "[[But wait, there's more!]{p=0.5}{noalt}*{/noalt} [[Act Now!] AND YOU CAN ALSO GET [[commemorative ring] [[[[For absolutely NO extra cost!]]"
    show spameyes_1:
        xpos 0.583
        ypos 0.39
    with Dissolve(2.0)
    pause 2.0
    spamton "WELL????{p=0.2}{noalt}*{/noalt} ARE YOU [[Offer Accepted] OR NOT????"
    spamton "I WOn'T FORCE [[your hand]"

    menu deal:
        "Accept":
            $ renpy.notify("+♡")
            if spam.lp > 0:
                $ spam.lp -= 5
            if spam.fp > 0:
                $ spam.fp -= 5
            spamton "THEN A DEAL'S A DEAL!"
            spamton "PLEASURE DOInG BUSINESS WITH [[{color=[c_passion]}YOU{/color}.]"
            stop music
            scene black
            $ persistent.deals = True
            $ renpy.pause(1.0, hard=True)

        "Do not":
            $ spam_dealchoice += 1
            show spameyes_1 static
            spamton "WRONG"
            show spameyes_1
            jump deal

        "I miss Tenna" if spam_dealchoice >= 3:
            show spameyes_2 at spameyes_shaking
            spamton "WHAT THE {noalt}[[$#!$]{/noalt}{alt}beep{/alt}"
            spamton "I OFFER YOU MY [[commemorative ring]{p=0.5}{noalt}*{/noalt} MY [[LOVE-LETTER-FOR-YOU.TXT.vbs]"
            spamton "AND THIS {noalt}IS{/noalt}{alt}is{/alt} THE THANKS I GET?!?!?"
            spamton "I'M AN [[HonestMan] !{p=0.5}{noalt}*{/noalt} THAT {noalt}[[$!#$]ER IS{/noalt}{alt}beeper is{/alt} A [[Trash Heap] CRIMINAL!!"
            spamton "BUT YOU'RE STILL THINKING ABOUT{p=0.2}{noalt}*{/noalt} HIM????????????"
            spamton "WELL {noalt}[[$#!$]{/noalt}{alt}beep{/alt} YOU, TOO!"
            spamton "UNFORTUNATELY FOR YOU, MY [[Friend Request Rejected],"
            spamton "I HAVE [[[[ Unholy ]] PERMISSION TO DO [[whatever I want.]"
            hide spameyes_2
            if persistent.glitches:
                show spameyes_1
            else:
                show spameyes_1 at shaking
            stop music
            play sfx spamlaugh
            $ renpy.pause(2.0, hard=True)
            scene black
            $ persistent.deals = False
            $ renpy.pause(1.0, hard=True)

    spamton "I'LL SEE YOU AGAIN WHEN YOU [[Sweet Dreams!]."
    $ renpy.pause(3.0, hard=True)
    $ persistent.route = "Spamton"
    $ renpy.quit() 



############################################################################################################
################## ACTUAL START
label spamroutestart:
    $ quick_menu = False
    scene black
    play ambiance wind
    pause
    $ quick_menu = True
    "All was dark."
    "When you closed your eyes again,{w=0.2} all was dark."
    "There was nothing for as far as you could see."
    pause 2.0
    menu:
        "Call out to Tenna":
            if ten.lp > 0 or ten.fp > 0:
                $ renpy.notify("+♡")
                if ten.lp > 0:
                    $ ten.lp -= 5
                if ten.fp > 0:
                    $ ten.fp -= 5
            play sfx hypnosis
            "You called out Tenna's name."
        
        "Call out to the stranger you made a deal with":
            $ spam.fp -= 5
            $ spam.lp -= 5
            $ renpy.notify("+♡")
            play sfx hypnosis
            "You called out,{w=0.2} hoping the suspicious stranger might still be here."
        
        "Open your eyes":
            "You decided to open your eyes,{w=0.2} and..."
            $ renpy.pause(1.0, hard=True)
            $ renpy.quit()

    pause 1.0
    "...{w=0.2} but nobody came."
    stop ambiance fadeout 4.0
    "You had no choice other than to fall deeper into the darkness."
    "In seemingly no time,{w=0.2} all and nothing began to consume your senses.{p=0.5}{noalt}*{/noalt} As if you were being sucked into a dream."
    pause 2.0

    ## WAKING UP IN SECOND HALF OF DARK WORLD
    $ quick_menu = True
    scene black
    show junkspam with Dissolve(2.0)
    pause 2.0
    "You don't recognize where you are."
    "As you move your hands to try and sit upright,{w=0.2} it feels like there's something muddy underneath you."
    "It's like you're laying on a mound of soggy trash..."
    play sfx waterwalk fadein 2.0
    pause 4.0
    stop sfx
    pause 1.0
    "Something approached you."
    "You glanced to where the sound came from..."
    if persistent.deals:
        show spamton standing up smile at spampos_center with Dissolve(1.0)
        play music spamtonO
        spamton "HEY ! HEY !{p=0.5}{noalt}*{/noalt} LOOK AT YOU!!!!!!"
        show spamton crazy laugh at xwiggle
        spamton "KEEPING OUR [[Specil Deal] AND NOT [[Abandoned] ME [[for the slime] !!!!!"
    
    else:
        show spamton slouch down frown at spampos_center with Dissolve(1.0)
        play music spamtonO
        spamton "SO YOU SHOWED UP ANYWAY."
        show spamton slouch down smile
        spamton "ARE YOU STILL INTERESTED IN MY [[Specil Deal] ?"
        show spamton standing up stare at xwiggle
        spamton "OR ARE YOU JUST HERE TO {noalt}[[$#!$]{/noalt}{alt}beep{/alt} ME OVER??!?!?!"

    show spamton panic up scream at jump
    spamton "WAIT!{nw=0.2}"
    show spamton standing up smile
    extend "{p=0}{noalt}*{/noalt} [[You've got mail!]"
    if persistent.glitches:
        show spamton standing tilt laugh
    else:
        show spamton standing tilt laugh at shaking
    spamton "CONGRULATIONS!{p=0.2}{noalt}*{/noalt} [[You have been selected to get an exclusive reward !]"
    if persistent.glitches:
        show spamton standing tilt stare
    else:
        show spamton standing tilt stare glitch at shaking
    spamton "[[Your Name Came Up For]{p=0.5}{noalt}*{/noalt} HURRY UP !{w=0.2} [[Your Reward is Ready]"
    show spamton at spampos_right
    show screen s_clickhere
    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### CLICKED SCREEN
label rewardrecieved:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True

    $ spam_info = True
    hide screen s_clickhere
    show spamton standing up smile at spampos_center
    spamton "[[Thank you for] [[persistent.mc]\n[[[[Personal Information]]."

    ### NAME REACTIONS
    if persistent.mc in ["Ass","Anus","Anuses","Arse","Arses","Asses","Asshole","Assholes","Dumbass","Dumbasses","Jackass","Jackasses","Lmao","Lmfao",
                        "Assfuck","Bastard","Bastards","Shit",'Shits',"Shitty","Shitter","Shithead","Shitheads","Shithole","Shitholes","Sex",'Sexy',"Sexes",'Sexs',"Sexie",
                        'Sexys',"Sexting","Sext","Fuck",'Fucker',"Robotfucker",'Monsterfucker',"Motherfucker","Dumbfuck",'Buttfuck','Fucking','Fuckface','Kink','Kinky','Piss',
                        'Pisses','Pissing','Pisser','Pissed','Pissface','Pissboy',"Damn","Dammit","Goddamn","Goddamnit",'Bitch',"Bitches","No bitches",'Nobitches','Boner',
                        "Boners","Dildo","Dildos","Dick","Dicks",'Dickbag',"Jizz","Jizzy","Cock","Cocks","Ball","Balls",'Penis',"Penises","Peni","Bollocks","Slut","Sluts","Slutty",
                        "Douche","Douchebag","Boob","Boobs","Boobie","Boobies",'Booby','Boobys','Boober',"Boobers","Tit","Tits",'Titty',"Tittys",'Titties','Tiddy','Crackhead',
                        'Tiddys','Tiddies','Manboob','Manboobs','Mantit','Mantitty','Breast','Breasts','Bosom','Clit','Clitoris','Labia','Vagina','Vaginas','Fleshlight',
                        'Fleshlights','Cunt','Cunty','Pussy','Pussies','Pussys','Bepis','Toilet',"Poop","Poopie","Poopy","Pee",'Peepee','Toylet',"Pee pee", "Poo poo pee pee",
                        "Poopoo peepee", "Poopoopeepee","Poo poo peepee","Poopoo pee pee","Queer","Gay","Gayass"]:
        show spamton standing up stare at jump
        spamton "WOW!{w=0.2} A NAME LIKE THAT CAN GET YOU [[banned in 37 countries and counting] !"
        show spamton crazy angry at xwiggle
        spamton "YOU'VE GOT [[no] CLASS!"
        show spamton standing up smile at yreset
        spamton "ANYWAY!!!"
    
    elif persistent.mc in ["Topher", "Tofu"]:
        show spamton standing up stare at jump
        spamton "WOW!{w=0.2} THE [[SPAMTON APOLOGIST 1997{noalt}(c){/noalt}{alt}copyright{/alt}] IN THE [[digitized] FLESH!!"
        show spamton crazy smirk at xwiggle
        spamton "WHAT ARE YOU,{w=0.2} SOME KIND OF [[puppy-dog-eyed] [[simpleton] ?!"
        show spamton standing up smile at jump
        spamton "IF THAT'S [[variable = True] THEN YOU'LL REALLY LIKE [[And for my next trick!]!"
    
    elif persistent.mc in ["Yep", "Yes", "Yeppers", "Yesplease", "Yes please", "Yup", "Yessiree", "Whatsit", "Whatsittooya", "What zit tooya", "Whatzittooya"]:
        show spamton standing up stare at jump
        spamton "BY THE WAY.{p=0.5}{noalt}*{/noalt} WHAT IN THE [[Identity Theft Protection] {noalt}IS{/noalt}{alt}is{/alt} THIS?!"
        show spamton standing tilt laugh at xwiggle
        spamton "[persistent.mc!u]?!{p=0.2}{noalt}*{/noalt} THAT'S NOT A NAME!!"
        show spamton standing up smile at jump
        spamton "WHATEVER!!!"
    
    elif persistent.mc == "Jevil":
        show spamton standing up stare
        spamton "ARE YOU COMMITTING [[Identity Fraud] ?!{p=0.2}{noalt}*{/noalt} YOU'RE NOT [[Murder Clown{space=30}Halloween Costume] !!"
        show spamton standing tilt laugh at jump
        spamton "ACTUALLY IT'S BETTER THIS WAY I HATE THAT GUY!!!"
        show spamton standing up smile
        spamton "MOVING ON!!"

    ### BACK TO STORY
    if persistent.glitches:
        show spamton standing tilt laugh flipped
    else:
        show spamton standing tilt laugh flipped at shaking
    spamton "[[kindly check the attached] REWARD [[from]{p=0.2}{noalt}*{/noalt} SPAMTON G. SPAMTON!"
    play sfx weirdeffect
    if not persistent.playthru:
        $ inventory.append(itm_loveletter)
        $ persistent.loveletter = True
        "You received some kind of digital data.{p=0.2}{noalt}*{/noalt} It was somehow added to your ITEMS...?"
    else:
        "You received some kind of digital data.{p=0.2}{noalt}*{/noalt} But it was already in your ITEMS..."
    show spamton standing up stare at jump
    spamton "[persistent.mc!u] !!!!{p=0.5}{noalt}*{/noalt} WELCOME TO THE [[Trash Zone]"
    if persistent.glitches:
        show spamton crazy avert
    else:
        show spamton crazy avert at shaking
    spamton "I BET THAT [[scrap heap] {noalt}DIDN''T{/noalt}{alt}didn't{/alt} TELL YOU THAT!"
    show spamton standing up stare at jump
    spamton "YES THIS {noalt}IS{/noalt}{alt}is{/alt} THE [[luxurious, spacious] DUMP!"
    show spamton standing up stare at xwiggle
    spamton "DON'T ASK ME WHY I'M HERE."
    menu:
        rq "DON'T ASK ME WHY I'M HERE."
        "Why are you here?":
            if persistent.glitches:
                show spamton crazy frantic
            else:
                show spamton crazy frantic at shaking
            spamton "{noalt}IS{/noalt}{alt}is{/alt} THERE [[gloop] IN YOUR EARS???"
            show spamton panic up screame at jump
            spamton "I SAID [[[[DON'T]] !!!!"
        
        "...":
            $ renpy.notify("+♡")
            if spam.lp > 0:
                $ spam.lp -= 5
            if spam.fp > 0:
                $ spam.fp -= 5
            show spamton standing tilt laugh
            spamton "{noalt}THA T'S{/noalt}{alt}that's{/alt} THE [[spirits] !"

    show spamton standing up smile at yreset
    spamton "ANYWAY"
    if persistent.deals:
        spamton "NOW THAT I HAVE YOUR [[[[Personal Information]] WE ARE NEARLY DONE!"
        if persistent.glitches:
            show spamton standing tilt laugh
        else:
            show spamton standing tilt laugh at shaking
    else:
        show spamton standing up stare at xwiggle
        spamton "MY [[Make A Deal!] {noalt}IS{/noalt}{alt}is{/alt} STILL ON THE [[Tables On Sale for $79.99 Each]"
        spamton "YOU ARE [[Interested?] RIGHT"
        if persistent.glitches:
            show spamton standing tilt laugh
        else:
            show spamton standing tilt laugh at shaking
        play sfx spamlaugh
        $ _history = False
        spamton_shh "[[[[Unintelligible laughter]]{nw=0.5}"
        $ _history = True
        spamton "[[[[Unintelligible laughter]]{fast}{p=0}{noalt}*{/noalt} WHY ELSE WOULD YOU [[Press Return] ?"
        show spamton standing up stare at xwiggle
    spamton "JUST HAND OVER YOUR {noalt}[[HeartShapedObject]{/noalt}{alt}heart-shaped object{/alt} AND [[Scram!]"
    menu:
        rq "JUST HAND OVER YOUR {noalt}[[HeartShapedObject]{/noalt}{alt}heart-shaped object{/alt} AND [[Scram!]"
        "Hand it over":
            pause 1.0
            nar_quiet "{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}"
            "Your arm resisted."
        
        "Do not":
            pass
    
    if persistent.glitches:
        show spamton crazy angry 
    else:
        show spamton crazy angry at shaking
    spamton "WHAT'S THE [[Hold up!] ?!"
    "You remind Spamton that he said something about a ring, too."
    show spamton standing up smile at jump
    spamton "MY [[commemorative ring]?"
    if persistent.glitches:
        show spamton crazy laugh at jump
    else:
        show spamton crazy laugh glitch at jump
    spamton "EAEHAHAH!{p=0.5}{noalt}*{/noalt} [persistent.mc!u]!"
    show spamton crazy avert
    spamton "I WOULDN'T JUST [[don't forget.]"
    show spamton standing up stare at jump
    spamton "GET THE RING FIRST AND IT'LL [[cost ya]{p=0.2}{noalt}*{/noalt} [[cost ya] 1997 KROMER."
    "...{w=0.2} you don't have any kromer."
    show spamton standing tilt laugh at jump
    spamton "[[Oh no] {noalt}IT{/noalt}{alt}it{/alt} SEEMS YOU [[money no] ENOUGH"
    show spamton standing tilt stare at xwiggle
    spamton "FORTUNATELY A {noalt}[[Heart-shapedObject]{/noalt}{alt}heart-shaped object{/alt} WILL COVER THE [[4 payments of $4.99]"
    "You tell him you'll come up with the money."
    show spamton standing up stare at jump
    spamton "WHAT"
    spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} [persistent.mc!u]???"
    if persistent.glitches:
        show spamton crazy angry
    else:
        show spamton crazy angry at shaking
    spamton "THIS {noalt}IS{/noalt}{alt}is{/alt} THE {noalt}[[[[$#!$]{/noalt}{alt}beep{/alt}hole].{p=0.5}{noalt}*{/noalt} THERE {noalt}IS{/noalt}{alt}is{/alt} NO KROMER HERE"
    "You say you'll find it anyway."
    show spamton standing up stare at yreset
    pause 1.0
    show spamton crazy laugh flipped at xwiggle
    spamton "EAEHAHa!{p=0.5}{noalt}*{/noalt} YOU ARE [[{color=[c_star]}Determination.{/color}] AREN'T YOu?!?!"
    show spamton standing up stare at jump
    spamton "{noalt}[[#!$#]{/noalt}{alt}beep{/alt} YOU."
    if persistent.glitches:
        show spamton crazy frantic flipped
    else:
        show spamton crazy frantic flipped at shaking
    spamton "I'LL BE IN MY [[[[New and Improved!]] [[Home-made Storefront Site] WHEN YOU [[Changed your mind?]"
    show spamton standing up stare
    if persistent.deals:
        spamton "I DON'T MAKE [[Free] DEALS!!"
    else:
        spamton "I DON'T GIVE [[free handouts] TO [[Losers] [[like you.]"

    ## TRANSITION TO EXPLORE
    stop music
    show spamton standing up smile at yreset
    play sfx slideaway
    show spamton:
        xpos -0.1
    with MoveTransition(1.0)
    hide spamton
    pause 2.0
    play music dump

    ## AUTOSAVE
    $ renpy.save("mainfile")

    jump ex_spamshop


######################################################
##### SHOP DATE PREAMBLE
label spamdate_check1:
    if money >= 1000:
        if not vex_spamdate1:
            $ vex_spamdate1 = True
        menu:
            rq "Spend 1000 kromer to go on a date with Spamton?{p=0}{noalt}*{/noalt} You currently have [money] kromer."
            "Yes":
                if itm_greenshard1 not in inventory:
                    "You feel like you haven't bought all that you can yet."
                else:
                    $ spam_datecheck = True

            "No":
                if persistent.glitches:
                    show spamshop_spamton e_eyes
                else:
                    show spamshop_spamton e_eyes at shakingcg
                spamton "AM I NOT GOOD ENOUGH FOR [[your money] ???????????"
    
    else:
        if not vex_spamdate1:
            $ vex_spamdate1 = True
            "You can't afford a date with that kind of a price tag..."
        else:
            "You still don't have enough kromer for Spamton."
    
    return

label spamdate_shop_preamble:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    play sfx item
    $ money -= 1000
    "You handed over all of the money you had."
    show spamshop_spamton e_laugh
    spamton "WOA H !{p=0.5}{noalt}*{/noalt} AREN'T YOU A RICH LITTLE [[[[Hochi Mama]] ?!"
    if persistent.glitches:
        show spamshop_spamton e_laugh
    else:
        show spamshop_spamton e_laughf
    spamton "I CAN FEEL MY [[Attraction Levels Rising] WITH A [[phat] WALLET LIKE THAT!"
    show spamshop_spamton e_eyes
    spamton "ANYWAY YOU CAN [[Leave.] THaAT'S ENOUGH."
    show spamshop_spamton e_laugh
    spamton "BY THE WAY THIS [[does not count towards] [[commemorative ring {noalt}(c){/noalt}{alt}copyright{/alt}1997]"
    show spamshop_spamton e_neutral
    pause 2.0
    show spamshop_spamton e_eyes at jump
    spamton "WHY ARE YOU STILL [[staring into my]"
    spamton "WHAT??{w=0.2} WHAT???"
    show spamshop_spamton e_laugh at jump
    spamton "YOU WANT [[More Than You Can Imagine] THAN THAT??"
    if persistent.glitches:
        show spamshop_spamton e_laugh
    else:
        show spamshop_spamton e_laughf
    spamton "{noalt}WO W OW!!{/noalt}{alt}wowow!{/alt}{p=0.5}{noalt}*{/noalt} YOU REALLY ARE A [[desperate little]"
    show spamshop_spamton e_neutral at jump
    spamton "[[Y'know what?] SURE.{p=0.5}{noalt}*{/noalt} WHY THE {noalt}[[X$!#]{/noalt}{alt}beep{/alt} NOT?"
    stop music
    scene black
    play sfx dooropen
    pause 1.0
    play sfx doorclose
    pause 2.0
    show junkspam with Dissolve(1.0)
    pause 1.0
    show spamton standing up smile at spampos_center with Dissolve(0.2)
    spamton "SO WHAT [[Fancyful] [[Big Ideas] DID YOU HAVE FOR THIS [[Last-Minute Date Night Plans] ?"
    show spamton standing tilt laugh at jump
    spamton "[[Your options are:]{p=0.5}{noalt}*{/noalt} THE [[Dump],{w=0.5} THE [[Dump,]{w=0.5} THE [[Trash Zone],.{w=0.5} ThE [[dump.],"
    show spamton crazy smirk at xwiggle
    spamton "EHAHA!{p=0.5}{noalt}*{/noalt} SOUNDS PRETTY [[bad]"

    ### TRANSITION TO DATE 1
    call date_intro from _call_date_intro_3

    # REMEMBER IN CASE DATE FAILED
    $ spamem_fp = spam.fp
    $ spamem_lp = spam.lp

    # SPAMTON DATE VARIABLES
    $ date_fp = spam.fp
    $ date_maxfp = spam.maxfp
    $ date_lp = spam.lp
    $ date_hb = 3
    if spam.hb != 3:
        $ spam.hb == 3
    $ date_maxlp = spam.maxlp
    $ date_name = spam.char

    # RESET VARIABLES
    $ currentdate = "shop"
    $ turn = 0
    $ flirt = 0
    $ check = 0
    $ niceday = 0
    $ vess_hp = 3

    show screen datestats
    play music spamtonL
    show spamton standing up smile at yreset
    jump spamdate_shop


######################################################
##### POST SHOP DATE
label spamdate_shop_fail:
    # REVERT TO PREVIOUS FP/LP STATE
    $ spam.fp = spamem_fp
    $ spam.lp = spamem_lp

    # RESET VARIABLES TO DEFAULT ; FOR RETRYING
    $ spam_handover = False # turned true when selected then turn false again
    $ s_check = False # seen the check text
    $ s_niceday = 0 # if told spamton "nice day" (goes up with how many times)
    $ s_flirt = False # if flirted with on the shop date
    $ s_misstenna = False # said "i miss tenna"
    $ s_regret = False # said you don't regret going on a date
    $ s_great = False # said this date is great!
    $ s_hso = False # talked about heart shaped object
    $ s_ring = False # asked about ring
    $ s_soul = False # asked about the soul finding
    $ s_memshardask = False # asked about memoryshard
    $ s_sillystrings = False # if answered "well... i mean..." about if vess is being controlled
    $ s_help = False # seen the help text before
    $ s_help_used = 0 # how many times used help
    $ s_help_dance = False # done the dance before
    $ s_help_kiss = False # blown a kiss before
    $ s_help_done = False # spamton won't help anymore
    $ s_t1 = False # seen the turn 1 text or not
    $ s_t3 = False # seen the turn 4 text or not
    $ s_t6 = False # seen the turn 6 text or not
    $ s_bribesee = False # if seen the tuto text for bribing/restoring
    $ s_bribeitm = 2 # how many items are available
    $ s_bribe_menu_text1 = "" # correct grammar for bribeitm
    $ s_bribe_menu_text2 = "" # correct grammar for bribeitm
    $ s_shadow = False # offered the shadow crystal
    $ s_memshard = False # offered the memoryshard (spamton, 1)
    $ s_figure = False # shown spamton the fighate
    $ s_food = False # if given food before or no
    $ s_loveletter = False # if asked abt love letter for u already
    $ s_flower = False # gave him the flower already

    stop music fadeout 1.0
    hide screen datestats
    show spamton standing up stare at yreset
    spamton "WOW!{w=0.2} THAT DATE WAS [[0/10, Would Not Reccommend]"
    show spamton standing tilt laugh at xwiggle
    spamton "I DON'T KNOW THAT I'VE EVER HAD ONE [[worse] !!"
    show spamton standing up frowne at jump
    spamton "BUT WE STILL HAVE [[Our Deals]...{p=0.2}{noalt}*{/noalt} EAHAHAEH! DON'T JUST [[fuhgeddaboudit] SO EASILY, [persistent.mc!u]!!"
    show spamton standing up stare
    spamton "LOOK.{w=0.2} LOOK.{p=0.2}{noalt}*{/noalt} [persistent.mc!u]?"
    spamton "I'M GIVING YOU A [[full refund]."
    play sfx item
    $ money += 1000
    "You suddenly feel 1000 [[kromer] richer..."
    show spamton crazy laugh at jump
    spamton "IF YOU CAN [[git gud] AND [[Come Back Soon!],{w=0.2} THEN I'LL JUST [[Forget this ever happened.]"
    show spamton standing up smile
    spamton "IN THE MEANWHILE...{w=0.5} I'LL BE WAITING IN MY [[not] [[Trailer] !!"
    play sfx slideaway
    show spamton:
        xpos -0.1
    with MoveTransition(1.0)
    pause 2.0
    play music dump

    ## AUTOSAVE
    $ renpy.save("mainfile")

    jump ex_spamshop

label spamdate_shop_success:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ spam_date1 = True

    stop music fadeout 1.0
    hide screen datestats
    show spamton crazy laugh at jump
    spamton "WELL THIS HAS BEEN [[terrible] [persistent.mc!u],{w=0.2} NO [[Thanks for inviting me!]"
    show spamton standing up stare at jump
    spamton "NOW.{w=0.2} YOUR [[New Employment]."
    show spamton standing tilt laugh at xwiggle
    spamton "WHEN YOU [[Collect all ] MemoryShards,{w=0.2} COME FIND ME IN MY [[Home Sweet] JUNK SHOP!"
    if persistent.glitches:
        show spamton standing up stare
    else:
        show spamton standing up stare at shakingcg
    spamton "[[Do Not] FORGET.{p=0.2}{noalt}*{/noalt} [[Do Not] FORGET.{p=0.2}{noalt}*{/noalt} [[Do Not] FORGET."
    show spamton standing up smile at yreset
    spamton "ANYWAY."
    play sfx slideaway
    show spamton:
        xpos -0.1
    with MoveTransition(1.0)
    pause 2.0
    play music dump
    jump ex_spamshop


######################################################
##### STARTING SECOND DATE
label spamdate_eye_preamble:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    if persistent.glitches:
        show spamshop_spamton e_laugh at yreset
    else:
        show spamshop_spamton e_laughg at yreset
    spamton "WELL, WHAT ARE YOU WAITING FOR??{p=0.5}{noalt}*{/noalt} HAND THEM OVER!!"
    "You tell Spamton you're not handing over anything until he upholds his end of the bargain."
    show spamshop_spamton e_eyes
    spamton "YOU'RE [[No Fun Allowed].{p=0.5}{noalt}*{/noalt} HOW'S A GUY SUPPOSED TO [[rip you off] IF YOU'RE TOO [[outsmart those scam deals]?!"
    show spamshop_spamton e_neutral
    spamton "OK [[twist my arm] YOU WIN.{p=0.5}{noalt}*{/noalt} I AM A [[Business Loving Businessman] AFTER ALL."
    stop music
    scene black
    play sfx dooropen
    pause 1.0
    play sfx doorclose
    pause 2.0
    show junkyard6 with Dissolve(1.0)
    pause 1.0
    show spamton standing up smile at spampos_center with Dissolve(0.2)
    spamton "WOW!{p=0.2}{noalt}*{/noalt} A [[New and] WORSE [[Location] !"
    show spamton slouch down panic
    spamton "THIS PLACE {noalt}IS{/noalt}{alt}is{/alt} REALLY"
    pause 2.0
    show spamton slouch down frown
    spamton ".{w=0.5} SOMETHING."

    ### TRANSITION TO DATE 2
    call date_intro from _call_date_intro_4

    # SPAMTON DATE VARIABLES
    $ date_fp = spam.fp
    $ date_maxfp = spam.maxfp
    $ date_lp = spam.lp
    $ date_hb = spam.hb
    $ date_maxlp = spam.maxlp
    $ date_name = spam.char

    # RESET VARIABLES
    $ currentdate = "eye"
    $ turn = 0
    $ flirt = 0
    $ check = 0
    $ niceday = 0
    $ vess_hp = 3

    show screen datestats
    play music bigshotL
    show spamton standing up smile at yreset
    jump spamdate_eye


######################################################
##### POST SECOND DATE
label spamdate_eye_end:
    $ persistent.spamroute_fin = True

    ## AUTOSAVE
    $ renpy.save("mainfile")

    stop music fadeout 1.0
    hide screen datestats
    scene junkyard6
    show spamton standing up frowne at spampos_center zorder 1
    spamton "[persistent.mc!u]!{p=0.2}{noalt}*{/noalt} I'M [[calling it off]."
    if persistent.glitches:
        show spamton standing up stare
    else:
        show spamton standing up stare at shakingcg
    spamton "I'M DONE PLAYING [[carrot on a stick] WITH YOU!!"
    spamton "EITHER [[Gimmie, Gimmie!] OR [[We can do this the hard way.]"
    menu:
        rq "EITHER [[Gimmie, Gimmie!] OR [[We can do this the hard way.]"
        "Hand it over":
            "Your arm resisted."

        "Do not":
            pass

    spamton "[persistent.mc!u].{p=0.2}{noalt}*{/noalt} [persistent.mc!u].{p=0.2}{noalt}*{/noalt} [persistent.mc!u]."
    spamton "I'M DONE PLAYING [[Mr. NiceGuy]"
    spamton "I WANT [[what I want] AND I WANT {noalt}IT{/noalt}{alt}it{/alt} [[Now!!]"
    spamton "AND I--{nw=0.2}"
    show strings zorder 0:
        xalign 0.515
    if persistent.glitches:
        show spamton slouch down static at jump
        show soulgrn_whole zorder 2:
            xpos 0.47
            ypos 0.54
    else:
        show spamton slouch down static glitch at shock
        show strings at shakingcg
        show soulgrn_whole at shaking zorder 2:
            xpos 0.47
            ypos 0.54
    spamton "[[KLGKGH]--"
    show blackpng zorder 3
    hide soulgrn_whole
    hide strings
    play sfx click
    if persistent.glitches:
        pass
    else:
        with vpunch
    pause 1.0
    hide blackpng
    play music digitalroots
    if persistent.glitches:
        show spamton cg zoom soul
    else:
        show spamton cg zoom soul at shakingcg
    spamton "[[Help.]"
    spamton "YOUR {noalt}[[[[Heart-ShapedObject]]{/noalt}{alt}heart-shaped object{/alt}"
    $ _history = False
    spamton "GIVE {noalt}IT{/noalt}{alt}it{/alt} TO ME{nw}"
    $ _history = True
    spamton "GIVE {noalt}IT{/noalt}{alt}it{/alt} TO ME [[NOW]"
    spamton "[[Don't Wait!] ANY LONGER{p=0.2}{noalt}*{/noalt} [[I can't wait!] ANY LONGER!!"

    if not persistent.playthru:
        "You wholeheartedly resisted."

        ### FAKEOUT GAME OVER
        $ quick_menu = False
        $ skipyes = False
        $ _skipping = False
        $ renpy.choice_for_skipping()
        show screen nomenu

        stop music
        scene black
        pause 0.5
        play sfx bump
        if persistent.glitches:
            pass
        else:
            with vpunch
        pause 1.0
        "Your body gave out from a lack of energy."

        ## AUTOSAVE
        $ renpy.save("mainfile")

        ### GASTER VISIT
        play music drone
        $ renpy.pause (3.0, hard=True)

        if persistent.firstend:
            $ persistent.firstend = False
            show text _("And, so...") at truecenter with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("You've reached the end of the dream.") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (2.0, hard=True)
            show text _("I apologize if you wished for something more.") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("I am merely connecting you to this world,") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("I am not controlling it.") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("In fact, I have absolutely no influence over it at all.") with dissolve

        else:
            show text _("Welcome back, player.") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("I presume you desire something of me.") with dissolve
            pause
            hide text with dissolve
            $ renpy.pause (1.0, hard=True)
            show text _("Why else would you return to this empty place?") with dissolve
        
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        menu:
            "Reestablish the connection":
                pass

            "Accept your fate":
                show text _("I appreciate all that you have done for me.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Your actions, your choices, your affection...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("It has all provided such fascinating results.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Of course, whenever you desire...") with dissolve
                pause
                stop music
                show text _("I shall await for the next time you fall asleep.")
                pause
                scene black
                $ renpy.pause(1.0, hard=True)
                $ renpy.quit()

        $ renpy.pause(1.0, hard=True)
        show text _("Ha, ha... I do not understand the source of your {color=[c_passion]}PASSION{/color}.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("How can you possess such infatuation for something...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("... when it doesn't even exist in your reality?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(2.0, hard=True)
        show text _("Although, I suppose that, too, makes me a hypocrite.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(2.0, hard=True)
        show text _("{color=[c_passion]}PASSION{/color}, {color=[c_star]}DETERMINATION{/color}--") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("They both are rather similar, are they not?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(2.0, hard=True)
        show text _("Well... I have always wanted to research that parallel reality.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("The second vessel was far too rebellious, but, mayhaps...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(2.0, hard=True)
        show text _("Player, I will restore the connection once more.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("I hope you will attain your more satisfactory ending.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("But do know, it still must come to an end,") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("Just as everything else.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("However, please allow me to provide you with a piece of advice:") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("When you are able, with those who are willing,") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("Lead them to this place where you can begin to wake up...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("... but not yet completely open your eyes to your reality.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("Perhaps you could rest\nupon that same object where you first saw me.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(2.0, hard=True)
        show text _("I will make some adjustments on my end.\nTake as much time as you need.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("When the time is right, however...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("You may awake as someone else entirely.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("I trust you will know what to do when that occurs.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause(1.0, hard=True)
        show text _("For now...") with dissolve
        pause
        stop music
        show text _("I will return you to your dream.")
        pause
        hide text
        pause 2.0
        $ quick_menu = True
        $ skipyes = True
        $ _skipping = True
        hide screen nomenu
    
    jump ending_spamton


######################################################
##### PICKUP ENDINGS GUIDE
label pickup_endings:
    play sfx plop
    pause 1.0
    show itemframe i_notes at truecenter with easeinbottom
    "There was a note that hit your foot as you tried to walk away."
    "You reached down to grab it,{w=0.2} opening it as you went to stand back up straight."
    hide itemframe with easeoutbottom
    $ foundendguide = True
    play sfx sparkleglock
    show endingguide at truecenter with easeinbottom
    alt "There's a house containing a red star."
    alt "There's a building containing a green heart."
    alt "There's a TV containing a blue cube. The game console is yellow."
    alt "Red Star to Green Heart = Red and Green"
    alt "Red Star to Blue Cube = Red and Blue"
    alt "Green Heart to Blue Cube = Green and Blue"
    alt "Red Star to Green Heart to Red and Green to Blue Cube = Red and Green and Blue"
    pause
    play sfx item
    hide endingguide
    $ inventory.append(itm_notes)
    "You put the [itm_notes.name] into your pocket.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."

    ### CONTINUE
    if end_spamtat == "started":
        scene black with Dissolve(1.0)
        play sfx waterwalk
        pause 1.0
        "You trudged back over to where you last left \"Mike.\""
        pause 1.0
        scene junkyard5 with Dissolve(1.0)
        pause 1.0
        jump mike_interact

    else:
        play music dump
        jump ex_starroom