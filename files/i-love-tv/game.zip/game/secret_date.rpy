############################################################################################################
################## PREAMBLE TO MIKE DATE
label mikedate_preamble:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ mke_menu = True
    
    show costume smile at cospos_center with Dissolve(0.5)
    pause 2.0
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    mike "Huh?!{p=0.2}{noalt}*{/noalt} Who's there??"
    show costume angry
    mike "Another person?{w=0.2} NOW??"
    mike "Ugh,{w=0.2} have you been here this whole time?{p=0.5}{noalt}*{/noalt} Didn't you even hear the guy hootin' and hollerin' over here??"
    show costume smile
    mike "Whatever.{p=0.5}{noalt}*{/noalt} Guess it's better now rather than later."
    mike "I was getting sick and tired of moping around in this SLOPPY DUMP!"
    mike "Hey,{w=0.2} tell me stranger--"
    stop ambiance fadeout 1.0
    show dfountainF:
        xalign 0.5
    show costume pointing smile
    with Dissolve(1.0)
    pause 0.5
    show costume pointing frown
    mike "...{w=0.2} you seen a TV around here?"

    ## TRANSITION TO DATE
    call date_intro from _call_date_intro

    # MIKE DATE VARIABLES
    $ date_fp = mke.fp
    $ date_maxfp = mke.maxfp
    $ date_lp = mke.lp
    $ date_maxlp = mke.maxlp
    $ date_hb = mke.hb
    $ date_name = mke.char

    # RESET VARIABLES
    $ currentdate = "secret"
    $ turn = 0
    $ flirt = 0
    $ check = 0
    $ niceday = 0
    $ vess_hp = 3

    play music airwavesL
    show screen datestats



############################################################################################################
################## ACTUAL DATE
label mikedate_secret:
    ### SAVING INFO FOR FP/LP SCREEN
    if turn > 0:
        $ mke.fp = date_fp
        $ mke.lp = date_lp
        $ mke.hb = date_hb

    ### WIN CONDITION
    if vess_hp == 0:
        jump gameover
    elif date_hb == 0:
        jump mikedate_fail
    elif date_fp <= 0 and date_lp <= 0:
        jump mikedate_success

    ### MENU TEXT
    if turn == 0:
        $ menu_text = "It's \"Mike\"...?"
    elif check == 1 and not m_check:
        $ m_check = True
        $ menu_text = "He doesn't have any eyes...?"
    elif m_convo == 6 and m_shadowconvo == 0 and not m_shadow:
        $ menu_text = "Maybe you have an ITEM you could show Mike..."
    elif m_shadow and m_shadowconvo == 0:
        if s_shadow:
            $ menu_text = "You wonder why you and Mike both have a Shadow Crystal."
        else:
            $ menu_text = "You wonder why you and Mike both have one of those invisible items."
    elif turn == 1:
        $ menu_text = "Who is \"Mike\"...?"
    else:
        $ menu_text = renpy.random.choice(["Mike is DEFINITELY a microphone!", "Sounds like feedback.", "Smells like gambling.", "Mike LOVES yapping.", "Mike talks very quickly, as he always does.", "Clock's ticking.", "Your time grows more limited."])

    ### AFTER CONFIRMED PLAYER KNOWS TENNA
    if m_convo >= 3:
        if turn == (m_turn + 3):
            show costume down annoyed at jump
            mike "Hey, HEY,{w=0.2} what are we doing just standing around here like this?!"
            show costume pointing angry
            mike "Hello?{w=0.2} HELLO??{w=0.5} Have you forgotten that the first thing I asked you about is WHERE'S TENNA??"
            show costume tie nervous
            mike "Why are you tryin' to chat me up like this is some kinda funfest-nonsense-thing?!"
            menu:
                rq "Why are you tryin' to chat me up like this is some kinda funfest-nonsense-thing?!"
                "Because I want to talk to you":
                    show costume pointing angry at jump
                    mike "You--!!{nw=0.2}"
                    show costume down annoyed at droop
                    extend " h.{w=0.5} Huh."
                    show costume tie nervous
                    mike "Wait you.{w=0.5} You what,{w=0.2} now?"
                    show costume pointing angry at jump
                    mike "W-{w=0.1} WAIT,{w=0.2} NO.{w=0.5} WE DON'T HAVE TIME FOR THIS!!"
                    show costume pointing nervous at wiggle
                    mike "MAYBE LATER,{w=0.2} MAYBE??"
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at jump
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Mike still seemed flattered.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Mike still seemed flattered.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

                "Why are you in such a rush?":
                    "You asked Mike why he was rushing so much to begin with."
                    show costume down angry
                    mike "I TOLD YOU!!{p=0.2}{noalt}*{/noalt} I'm on a super-special, super-important mission to find Tenna!!"
                    show costume pointing angry flipped at cospos_center_fl
                    show costume at jump
                    mike "I've already been wandering to-and-fro enough to make my way back to the Fountain where I started!"
                    show costume tie frown flipped
                    mike "There's only so much TIME IN A DAY, y'know!!{p=0.5}{noalt}*{/noalt} Not everybody likes waltzing around in a dump!!"

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani
                    show screen datestats
                    if date_hb == 0:
                        jump mikedate_fail

                    show costume pointing frown at cospos_center
                    mike "If you're not gonna help then just GET OUT OF THE WAY.{p=0.2}{noalt}*{/noalt} OKAY?{w=0.2} YOU GOT THAT??"

        ### "GIVE ME SOMETHING" "FUCK NO"
        elif turn == (m_turn + 6):
            show costume down frown at yreset
            mike "This is taking a ridiculous amount of time..."
            show costume pointing nervous
            mike "I don't even get why you're keeping me here??{p=0.5}{noalt}*{/noalt} This is kind of a nothing conversation,{w=0.2} of all the conversations I've had??"
            show costume at wiggle
            mike "I can't tell if you're trying to help me or dissuade me??{p=0.2}{noalt}*{/noalt} What??{w=0.2} Do you know somethin' I don't,{w=0.2} huh?"
            menu:
                rq "I can't tell if you're trying to help me or dissuade me??\n{noalt}*{/noalt} What?? Do you know somethin' I don't, huh?"
                "I don't know more than I've said.":
                    "You tell Mike that you've already explained everything you could to him."
                    show costume pointing frown at yreset
                    mike "You're not yankin' my chain on this one,{w=0.2} yeah?{nw=0.5}"
                    show costume down annoyed flipped at cospos_center_fl
                    show costume at jump
                    extend "{p=0}{noalt}*{/noalt} Ugh,{w=0.2} just great..."
                    show costume tie frown flipped
                    mike "I can't force more out of ya if you don't know,{w=0.2} but this is such a pain in my ass!!"
                    show costume tie nervous flipped at wiggle
                    mike "C'mon,{w=0.2} Tenna...{w=0.5} where did you go...?"
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at cospos_center
                        show costume at jump
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Mike seems downtrodden, but trusts your word.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Mike seems downtrodden, but trusts your word.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

                "I'll tell you for a price.":
                    "You suggest offering more information if Mike gives you something first."
                    if persistent.glitches:
                        show costume pointing angry at jump
                    else:
                        show costume pointing angry at shock
                    mike "Oh COME ON!!{p=0.2}{noalt}*{/noalt} I don't have time for this kinda crap,{w=0.2} y'know!!"
                    show costume down annoyed
                    mike "Just tell me already!"

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_1
                    show screen datestats
                    if date_hb == 0:
                        jump mikedate_fail

                    show costume pointing angry
                    mike "You're really testing my patience.{p=0.5}{noalt}*{/noalt} SERIOUSLY,{w=0.2} I'm at my wit's end."

        ### TENNA JEALOUSY POTENTIAL
        elif turn == (m_turn + 9):
            show costume pointing frown at jump
            mike "Y'know,{w=0.2} how is it that ya even met Tenna to begin with?"
            show costume down frown
            mike "You asked me about it,{w=0.2} but now I'm realizin' I don't even know your relation to the guy at all..."
            show costume pointing frown
            mike "You from around here?{nw=0.5}"
            show costume tie nervous flipped at cospos_center_fl
            show costume at jump
            extend "{p=0}{noalt}*{/noalt} No,{w=0.2} wait,{w=0.2} that wouldn't make sense,{w=0.2} you're clearly a Lightner."
            show costume tie frown flipped
            mike "... or,{w=0.2} something like that."
            show costume pointing frown at cospos_center
            show costume at jump
            mike "So,{w=0.2} what?{p=0.5}{noalt}*{/noalt} So, you fancy dumpster diving,{w=0.2} and you wanted to take it a step further by playing around in a dump??"
            show costume pointing nervous
            mike "... or,{w=0.2} two steps further.{p=0.2}{noalt}*{/noalt} Since you're in a Dark World dump."
            show costume down nervous at jump
            mike "Ah,{w=0.2} nevermind,{w=0.2} I'm gettin' off track!{p=0.2}{noalt}*{/noalt} Point is--{w=0.2} what's your relation to Tenna,{w=0.2} huh??"
            menu:
                rq "Ah, nevermind, I'm gettin' off track!\n{noalt}*{/noalt} Point is-- what's your relation to Tenna, huh??"
                "He asked me on a date":
                    "You said that Tenna had asked you out on a date."
                    show costume tie awkward at jump
                    mike "JUST LIKE THAT??"
                    show costume down nervous at droop
                    mike "I mean,{w=0.2} well.{p=0.2}{noalt}*{/noalt} Has he known you for a while already...?"
                    show costume tie frown
                    mike "Or has he really reached a point where he'd..."
                    pause 1.0
                    show costume pointing nervous at jump
                    mike "NEVERMIND,{w=0.2} hahaha,{w=0.2} anyway!{p=0.5}{noalt}*{/noalt} Glad we got that out of the way!!"
                    menu:
                        rq "NEVERMIND, hahaha, anyway!\n{noalt}*{/noalt} Glad we got that out of the way!!"
                        "Do you also want to date him?":
                            "You ask Mike if he's also interested in dating Tenna."
                            show costume down nervous at jump
                            mike "Huh?"
                            show costume tie awkward at jump
                            mike "WAIT, WHAT DO YOU MEAN, \"ALSO\"?{p=0.2}{noalt}*{/noalt} WHY DID YOU SAY {noalt}IT{/noalt}{alt}it{/alt} SO... {noalt}INVITATIONALLY{/noalt}{alt}invitationally{/alt}???"
                            show costume pointing nervous at wiggle
                            mike "Look, look, LOOK,{w=0.5} I didn't SAY anything ABOUT THAT,{w=0.2} so...{w=0.5} so...{w=0.5} SO JUST..."
                            show costume tie awkward flipped at cospos_center_fl
                            mike "AH,{w=0.2} NEVERMIND,{w=0.2} FORGET {noalt}IT{/noalt}{alt}it{/alt}!{w=0.5} MOVING ON!!"
                            if date_lp > 0:
                                play sfx ding
                                show costume tie awkward at cospos_center
                                show costume at jump
                                $ date_lp -= 10
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Mike seems a bit interested in you, too.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Mike seems a bit interested in you, too.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

                        "I wasn't really into it":
                            "You tell Mike you weren't really into Tenna anyway."
                            show costume pointing angry at rise
                            mike "YOU WEREN'T??"
                            show costume tie awkward at jump
                            mike "I MEAN.{p=0.5}{noalt}*{/noalt} THAT'S FINE...!"
                            show costume tie nervous
                            mike "I.{w=0.5} Just."

                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_2
                            show screen datestats
                            if date_hb == 0:
                                jump mikedate_fail
                           
                            show costume pointing nervous at wiggle
                            mike "How's about you forget anything I just said right now,{w=0.2} okay?{w=0.2} Capeesh?{w=0.2} You cool with that?{w=0.2} Great?{w=0.2} Great."

                "He kept me trapped for a little bit":
                    "You said that Tenna kept you trapped for a while,{w=0.2} until he disappeared."
                    show costume pointing nervous at jump
                    mike "AGAIN?"
                    show costume tie frown
                    mike "I mean,{w=0.2} hold on.{nw=0.2}"
                    show costume pointing nervous
                    extend "{p=0}{noalt}*{/noalt} Hey,{w=0.2} hey,{w=0.2} just so ya know,{w=0.2} Tenna's not...{w=0.5} NORMALLY the type of guy to do that kinda stuff."
                    show costume down frown
                    mike "He's been all outta sorts for,{w=0.2} you know,{w=0.2} a WHILE now,{w=0.2} you know how it is."
                    show costume pointing frown
                    mike "Could ya be a pal and just forget about that part?"
                    menu:
                        rq "Could ya be a pal and just forget about that part?"
                        "I was kind of into it" if not persistent.deals:
                            "You told Mike you thought Tenna was kind of hot while doing that anyway."
                            show costume down nervous at jump
                            mike "You--"
                            pause 1.0
                            show costume pointing nervous at jump
                            mike "You-- HUH?"
                            show costume pointing angry
                            mike "{noalt}UM{/noalt}{alt}um{/alt}??{w=0.5} HEY.{w=0.2} HEY?{p=0.5}{noalt}*{/noalt} THAT'S A LITTLE TOO MUCH INFORMATION,{w=0.2} DON'T YOU THINK??"

                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_3
                            show screen datestats
                            if date_hb == 0:
                                jump mikedate_fail

                            show costume tie awkward at jump
                            mike "I mean--{w=0.2} I don't wanna yuck your yum or anything, but,{w=0.2} hey,{w=0.2} could ya consider that I maybe didn't wanna hear that?!"
                            show costume down annoyed
                            mike "Sheesh..."

                        "I don't have to listen to you" if persistent.deals:
                            "You told Mike you weren't just going to forget it like that."
                            show costume pointing nervous
                            mike "What?{w=0.5} Wait,{w=0.2} but,{w=0.2} I'm not kiddin' ya,{w=0.2} y'know!{p=0.5}{noalt}*{/noalt} No joshes,{w=0.2} no japes,{w=0.2} nuh-uh!{w=0.5} None'a that!"
                            show costume pointing frown
                            mike "Tenna's really not a bad guy,{w=0.2} he's just..."
                            show costume down frown
                            pause 1.0
                            mike "Just..."

                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_4
                            show screen datestats
                            if date_hb == 0:
                                jump mikedate_fail
                            
                            show costume tie frown
                            mike "Oh,{w=0.2} forget it.{p=0.5}{noalt}*{/noalt} There's no convincing somebody who already doesn't care."

                        "Consider it forgiven":
                            "You told Mike you'd just forget about it."
                            show costume tie nervous
                            mike "Yeah,{w=0.2} yeah,{w=0.2} that's good.{p=0.2}{noalt}*{/noalt} Real good idea."
                            show costume pointing frown at jump
                            mike "And maybe don't bring it up to him,{w=0.2} either.{p=0.2}{noalt}*{/noalt} Ever.{w=0.2} Never-ever do that."
                            show costume tie nervous at wiggle
                            mike "He gets,{w=0.2} well,{w=0.2} kind of...{w=0.5} sensitive sometimes,{w=0.2} y'know?{p=0.2}{noalt}*{/noalt} Ya get what I mean?"
                            if date_lp > 0:
                                play sfx ding
                                show costume tie awkward at jump
                                $ date_lp -= 10
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Mike seems a bit distracted.{p=0.2}{noalt}*{/noalt} But he gained 10 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Mike seems a bit distracted.{p=0.2}{noalt}*{/noalt} But he gained 10 {color=[c_passion]}LP{/color}."

        ### IMPATIENCE GROWING
        elif turn == (m_turn + 12):
            show costume down annoyed at yreset
            mike "Look...{nw=0.5}"
            show costume tie nervous at jump
            if m_memshard:
                extend " hey,{w=0.2} wait,{w=0.2} I still never got your name,{w=0.2} did I?"
            else:
                extend " hey,{w=0.2} wait,{w=0.2} I never got your name,{w=0.2} did I?"
            show costume tie frown
            mike "Ugh.{w=0.2} Whatever.{w=0.5} I'm not really concerned about that right now."
            show costume pointing frown
            mike "I'm all for yappin' and chattin' as much as the next guy,{w=0.2} but I'm REALLY busy."
            show costume pointing nervous
            mike "I can't stay all that long.{p=0.5}{noalt}*{/noalt} Look,{w=0.2} maybe if you head out and find Castle Town or somethin' later--?"
            show costume down nervous flipped at cospos_center_fl
            show costume at wiggle
            mike "Ah, who am I kidding!{w=0.5} Why am I trying to invite you some place right now?!"
            menu:
                rq "Ah, who am I kidding!{w=0.5} Why am I trying to invite you some place right now?!"
                "You like me, right?":
                    "You flatly suggest that Mike might be into you."
                    show costume tie nervous at cospos_center
                    show costume at jump
                    mike "w-{w=0.1} WHAT??"
                    show costume pointing nervous
                    mike "I'm sorry.{w=0.5} WHAT are you trying to say about me?!{p=0.2}{noalt}*{/noalt} I JUST MET YOU and I JUST said I still don't know your name!!"
                    show costume pointing angry at jump
                    if flirt > 0 or m_flower:
                        mike "Also--{w=0.2} what part of I AM A BUSY GUY isn't clickin'?!{p=0.2}{noalt}*{/noalt} Your skull too full of fantasies to piece that together?!"
                    else:
                        mike "Besides,{w=0.2} I'll have you know I am VERY BUSY working for TENNA EXCLUSIVELY."
                        mike "I don't have the time for any kind of\nrelationship-ANYTHING!"                    
                    show costume down frown
                    mike "Ah...{w=0.5} nevermind."

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_5
                    show screen datestats
                    if date_hb == 0:
                        jump mikedate_fail

                    show costume down annoyed
                    mike "Point is,{w=0.2} lay off, pal."

                "We can hang out later, too, if you want.":
                    "You say that you wouldn't mind hanging out later, too."
                    show costume tie nervous at cospos_center
                    show costume at jump
                    mike "Y-{w=0.1} you're serious?"
                    mike "I mean,{w=0.2} uh,{w=0.2} HAHAHA, ahem.{nw=0.2}"
                    show costume pointing smile at jump
                    extend " SURE, sure!!{w=0.5} Yeah,{w=0.2} I'm the one who suggested it,{w=0.2} after all!!"
                    show costume tie smile
                    mike "Once we find Tenna,{w=0.2} I,{w=0.2} uh..."
                    show costume pointing nervous
                    mike "Wait,{w=0.2} aren't you a Lightner?{p=0.5}{noalt}*{/noalt} You'd probably have an easier time bringing us to Castle Town than me leading you there..."
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at jump
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Mike seems a bit more excited.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Mike seems a bit more excited.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

        ### RUNNING OUT OF TIME
        elif turn == (m_turn + 15):
            show costume down annoyed at jump
            mike "Listen, hey,{w=0.2} I know you're havin' fun standing there listening to me ramble,{w=0.2} but..."
            show costume pointing frown
            mike "I'm real serious.{p=0.2}{noalt}*{/noalt} I can't stick around doin' absolutely nothing all day!!"
            show costume tie nervous at wiggle
            mike "Tenna's in trouble,{w=0.2} {noalt}y'see{/noalt}{alt}ya see{/alt},{w=0.2} and if I don't find him..."
            show costume at yreset
            pause 1.0
            show costume down angry at jump
            mike "Well,{w=0.2} the point is,{w=0.2} I can't stick around,{w=0.2} {noalt}y'hear{/noalt}{alt}ya hear{/alt} me?!"
            menu:
                rq "Well, the point is, I can't stick around, {noalt}y'hear{/noalt}{alt}ya hear{/alt} me?!"
                "I could join you in looking for him":
                    "You said you'd help Mike look for Tenna,{w=0.2} if he'd let you."
                    show costume pointing angry at jump
                    mike "Hey,{w=0.2} HEY,{w=0.2} I already said, {w=0.2}I'M doing this!{p=0.5}{noalt}*{/noalt} This is Mike's job,{w=0.2} just MIKE'S--{w=0.2} nobody else's!!"
                    mike "I can handle it myself...{nw=0.5}"
                    show costume tie nervous at droop
                    extend "{p=0}{noalt}*{/noalt} Though,{w=0.2} I guess a break couldn't hurt..."
                    show costume pointing angry at jump
                    mike "AUGH,{w=0.2} no, NO,{w=0.2} I can't do that right now.{p=0.5}{noalt}*{/noalt} When this is all over,{w=0.2} then,{w=0.2} THEN..."
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at jump
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Mike started thinking about something else.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Mike started thinking about something else.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

                "Can't you spare a minute for me?":
                    "You ask why Mike can't spare even a minute of his time to talk to you."
                    show costume pointing angry at jump
                    mike "You hear a single word I've said?!{p=0.2}{noalt}*{/noalt} I need to find TENNA and I DON'T HAVE THAT MUCH TIME."
                    show costume down angry
                    mike "Geez,{w=0.2} GEEZ,{w=0.5} are you actually \"enjoying\" listening to me,{w=0.2} or are you just staring at me for your own amusement?!"

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_6
                    show screen datestats
                    if date_hb == 0:
                        jump mikedate_fail

                    show costume down frown
                    mike "I can't wrap my head around how you haven't put two and two together yet.{p=0.2}{noalt}*{/noalt} What's not clicking?!"

        ### TIME'S UP
        elif turn == (m_turn + 20):
            jump mikedate_fail


    ### BEFORE CONFIRMED PLAYER KNOWS TENNA
    else:
        if turn == 5:
            show costume down frown at yreset
            mike "Hey,{w=0.2} how long are you plannin' to just bum around and spout random crap at me,{w=0.2} now?"
            show costume pointing frown
            mike "Not all of us have all the time in the world to mosey about forever!{w=0.5} Some of us only have,{w=0.2} uhhh..."
            show costume pointing angry at jump
            mike "Well,{w=0.2} IT'S NOT YOUR BUSINESS,{w=0.2} but I'm BUSY!"
            "You might want to push the conversation along a bit faster..."
            play sfx awkwardS
            $ vess_hp -= 1
            "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

        elif turn == 8:
            show costume down annoyed at yreset
            mike "{noalt}Pal.{/noalt}{alt}pal .{/alt}{w=0.2} Buddy.{w=0.2} Person I just met."
            show costume pointing angry at wiggle
            mike "I need you to either get a move on with what you wanted to talk to me about here or let me go."
            show costume pointing frown
            mike "I'm not kidding around.{p=0.2}{noalt}*{/noalt} This is serious,{w=0.2} I tell ya.{w=0.2} SERIOUS."
            "You might want to push the conversation along a bit faster..."
            play sfx awkwardS
            $ vess_hp -= 1
            "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

        elif turn == 11:
            jump mikedate_fail
    
    ### SAVING INFO FOR FP/LP SCREEN
    if turn > 0:
        $ mke.fp = date_fp
        $ mke.lp = date_lp
        $ mke.hb = date_hb

    ### WIN CONDITION (after mike turn)
    if vess_hp == 0:
        jump gameover
    elif date_hb == 0:
        jump mikedate_fail
    elif date_fp <= 0 and date_lp <= 0:
        jump mikedate_success

    $ turn += 1

label mikedate_secret_menu:
    show costume pointing smile at cospos_center
    show costume at yreset
    show screen mikedate_select
    $ quick_menu = True
    $ skipyes = False
    $ _skipping = False

    date "[menu_text]"

    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## INTERACTS

######################################################
##### TALK
label mikedate_talk:
    $ skipyes = True
    $ _skipping = True
    hide screen mikedate_select
    
    menu:
        date "Talk"
        "Nice day!":
            $ niceday += 1
            if niceday < 3:
                if niceday == 1:
                    "You told Mike you thought today was a nice day."
                    show costume pointing frown
                    mike "Where's this comin' from?{p=0.2}{noalt}*{/noalt} Are you just yapping for the sake of yapping?"
                    show costume tie smile at jump
                    mike "Joke's on you,{w=0.2} {noalt}HA{/noalt}{alt}hah{/alt}!{w=0.2} I'M the professional yapper here!!{p=0.2}{noalt}*{/noalt} Thats why they call me MOTORMOUTH!"
                    mike "Small talk means nothing to me!!{w=0.2} NOTHING!!"
                    if date_fp > 0:
                        play sfx ding
                        show costume tie smile at jump
                        $ date_fp -= 4
                        if not seenstats_fp:
                            $ seenstats_fp = True
                            "He's still happy to talk, anyway?{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}Friendship Points{/color}."
                        else:
                            "He's still happy to talk, anyway?{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."
                
                elif niceday == 2:
                    "You again told Mike you thought today was a nice day."
                    show costume pointing frown at jump
                    mike "I heard ya the first time,{w=0.2} ya room noise!"
                    show costume tie nervous
                    mike "What,{w=0.2} someone hit the rewind button on you or something?!"
                    
                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_7
                    show screen datestats

                    show costume pointing angry at jump
                    mike "Ya better have got more material than that!{p=0.2}{noalt}*{/noalt} I don't have time for this kinda crap!!{w=0.2} This is TIME-SENSITIVE,{w=0.2} ya know!!!"
            
            else:
                "Mike doesn't seem interested in talking about this anymore."
                jump mikedate_secret_menu

        "Who are you?" if m_convo == 0:
            $ m_convo += 1
            "You ask who this person is,{w=0.2} despite the fact you can see his name on the stat screen above his head."
            show costume tie smile at jump
            mike "ME?!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} I'm SO glad you asked!"
            show costume pointing smile at jump
            mike "Motormouth Mike's the name!{p=0.5}{noalt}*{/noalt} I'm the Micro Phone who croons and groans!{p=0.2}{noalt}*{/noalt} Nice to meetcha!"
            show costume pointing frown
            mike "I'm on a special mission,{w=0.2} see?{p=0.5}{noalt}*{/noalt} Super special!{w=0.2} Not quite secret,{w=0.2} but VERY IMPORTANT!!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                if not seenstats_fp:
                    $ seenstats_fp = True
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}Friendship Points{/color}."
                else:
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."

        "Special mission?" if m_convo == 1:
            $ m_convo += 1
            "You asked Mike to explain more about the \"special mission\" he's on."
            show costume pointing nervous
            mike "Oh-ho-ho?{w=0.2} Are ya lookin' to help me out?"
            show costume pointing angry at jump
            mike "Well FAT CHANCE!{w=0.2} I don't need an OUNCE of YOUR help!"
            mike "...{nw=0.2}"
            show costume down frown flipped at cospos_center_fl
            show costume at jump
            extend " that being said,{w=0.5} have you by chance seen a TV recently?{p=0.5}{noalt}*{/noalt} Somewhere between an inch to twenty feet tall?"
            show costume pointing smile at cospos_center
            show costume at jump
            mike "Oh?{w=0.2} You know, do ya??{p=0.5}{noalt}*{/noalt} You're nodding like a guy who knows!"
            show costume pointing frown
            mike "Then I can't let you leave...{w=0.5} not until you tell me WHERE THE HECK HE WENT??"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike looks a little antsy.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Tenna?" if m_convo == 2:
            $ m_convo += 1
            "You ask how Mike knows Tenna."
            show costume down angry
            mike "How I KNOW him??{p=0.5}{noalt}*{/noalt} Hahahaha,{w=0.2} oh,{w=0.2} you're KIDDING right?!?!"
            show costume tie blush at jump
            mike "I'm his favorite person!!{p=0.5}{noalt}*{/noalt} Without a doubt--{w=0.2} Mike's number one!"
            show costume pointing smile
            mike "Anything Tenna wants,{w=0.2} whenever he wants it--{w=0.2} I'm there!"
            show costume at wiggle
            mike "The stage, the lights!{w=0.2} The do-zits, the what-zits!{p=0.5}{noalt}*{/noalt} All of it is me!!{w=0.2} ME!!{w=0.2} MEE-yike,{w=0.2} that's right!"
            show costume pointing frown at jump
            mike "Not only that-- not only THAT!{p=0.5}{noalt}*{/noalt}  I do his therapy, his analogies!{w=0.2} His first aid, his last aid!!"
            show costume tie smile at jump
            mike "I {noalt}read{/noalt}{alt}reed{/alt} him bedtime stories!{w=0.2} I sort his nose drawers!{p=0.5}{noalt}*{/noalt} I babysit his kids!{w=0.2} I sing his theme song!"
            show costume pointing smile at jump
            mike "Mike!{w=0.2} Always there for Tenna,{w=0.2} never not!!!"
            mike "...{nw=0.2}"
            show costume down frown flipped at cospos_center_fl
            show costume at jump
            extend " except right now.{w=0.5} Because I lost him."
            show costume tie nervous at cospos_center
            show costume at jump
            mike "Wait, no--{w=0.2} it wasn't ME who lost him!!{p=0.2}{noalt}*{/noalt} The Lightners did that!!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike seems worried about something.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

            $ m_turn = turn
            show costume tie frown
            mike "Hold on, HOLD ON just a minute.{p=0.2}{noalt}*{/noalt} You know Tenna by name?{w=0.2} Ya just said it!"
            show costume down annoyed
            mike "You've not only SEEN the guy,{w=0.2} but you KNOW the guy, too?!"
            show costume tie smile at jump
            mike "HA-HA!{w=0.2} I've really hit the jackpot by findin' you,{w=0.2} then!"
            show costume pointing smile
            mike "Tell me.{w=0.2} Where'd he go?{w=0.2} Where is he?"
            menu:
                rq "Tell me. Where'd he go? Where is he?"
                "He ran away from me.":
                    "You say that the last time you saw Tenna,{w=0.2} he didn't want anything to do with you."
                    show costume pointing angry at jump
                    mike "What, WHAT?{p=0.5}{noalt}*{/noalt} Wait,{w=0.2} wait just a second here--{w=0.5} you're spouting a buncha crap,{w=0.2} aren't you?!"
                    show costume tie frown
                    mike "I mean, c'mon,{w=0.2} everyone -- I mean EVERYONE --{w=0.2} knows Tenna's not really the type of guy to turn most people away, unless...{w=0.2} uh..."
                    show costume pointing angry
                    mike "NEVERMIND!{w=0.5} Nevermind,{w=0.2} I don't actually care what it is you're up to,{w=0.2} actually."
                    mike "You're just.{nw=0.5}"
                    show costume tie nervous at droop
                    extend " The only lead I've got."
                
                "I'm looking for him too." if not ten_failed:
                    "You clarify that you lost sight of him and are trying to find him, too."
                    show costume pointing angry at jump
                    mike "WHAT?{p=0.5}{noalt}*{/noalt} Ugh,{w=0.2} you've gotta be kiddin' me!{w=0.2} Right?!{w=0.5} C'mon,{w=0.2} tell me you're yankin' my chain!"
                    show costume down annoyed
                    mike "Ah, whatever.{w=0.2} Whatever!{w=0.5} You're a better direction than I had before."
                    show costume tie nervous at droop
                    mike "Which was nothing."
                    show costume pointing smile at jump
                    mike "'sides,{w=0.2} two's better than one in this kinda situation, right?!{p=0.5}{noalt}*{/noalt} Cover more ground!{w=0.2} Get more stuff done!"

                "..." if ten_failed:
                    $ mke_silence = True
                    show costume pointing frown at jump
                    mike "Hey,{w=0.2} HEY,{w=0.2} I asked you a question,{w=0.2} didn't I?!{p=0.2}{noalt}*{/noalt} What're you gettin' all quiet on me for?!"
                    show costume tie nervous at jump
                    mike "H-{w=0.1} hold on,{w=0.2} wait,{w=0.2} don't look at me like that-- GEEZ!{p=0.5}{noalt}*{/noalt} Why do ya look so guilty all of a sudden...?"
                    pause 1.0
                    show costume down nervous
                    mike "Well, uh,{w=0.5} forget about it!{w=0.2} Just,{w=0.2} forget I said anything!"
                    show costume pointing frown
                    mike "If you know something, you can tell me later,{w=0.2} I guess..." 
        
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike is willing to tolerate you?{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."

        "Lightners?" if m_convo == 3:
            $ m_convo += 1
            "You asked about the Lightners Mike mentioned before."
            show costume down frown
            mike "You don't know?{w=0.2} You don't KNOW??{p=0.5}{noalt}*{/noalt} What kind of craziness is that??"
            show costume pointing angry at jump
            mike "You're a Lightner too,{w=0.2} ain'tcha?{p=0.5}{noalt}*{/noalt} You sure as hell aren't a {noalt}Darkner{/noalt}{alt}dark nur{/alt},{w=0.2} I can tell that much."
            show costume tie frown flipped at cospos_center_fl
            show costume at jump
            mike "Or.{w=0.5} Or,{w=0.2} maybe.{p=0.5}{noalt}*{/noalt} You just haven't met the ones I'm talking about?"
            show costume pointing angry at cospos_center
            show costume at jump
            mike "Ah,{w=0.2} who cares!{w=0.2} Who CARES,{w=0.2} am I right?"
            show costume down annoyed
            mike "You don't know the Lightners?{w=0.2} Fine!{w=0.2} Doesn't matter!{p=0.5}{noalt}*{/noalt} What you DO have is the deets on Tenna--{w=0.2} which {noalt}IS{/noalt}{alt}is{/alt} what I need."
            show costume pointing nervous at jump
            mike "I'm trying to fix the damage THOSE idiots did by LOSING HIM!!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike is a little distracted.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Lost?" if m_convo == 4:
            $ m_convo += 1
            "You questioned what Mike meant by Tenna being \"lost.\""
            show costume down annoyed
            mike "Uhh.{w=0.2} You know.{p=0.5}{noalt}*{/noalt} The same as anybody else would use the definition for?"
            show costume pointing frown
            mike "Gone missing?{w=0.2} Left without a trace?{w=0.2} Disappeared and nobody knows where the guy went??"
            show costume down frown
            mike "The Lightners brought the rest of us --{w=0.2} those of us who knew Tenna,{w=0.2} that is --{w=0.2} to a different Dark World."
            mike "Then they said they'd bring Tenna over later."
            show costume pointing angry at jump
            mike "But you know what?{w=0.2} They DIDN'T!{p=0.5}{noalt}*{/noalt} They didn't do that at ALL!"
            show costume tie frown at wiggle
            mike "They kept it real vague,{w=0.2} on the down-low,{w=0.2} and didn't tell me what happened,{w=0.2} even when I asked."
            show costume pointing angry
            mike "The one of 'em had this sketchy look on her face,{w=0.2} and when I saw that-- I knew,{w=0.2} oh,{w=0.2} I KNEW something was up."
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike seems retroactively upset.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Something was up?" if m_convo == 5:
            $ m_convo += 1
            "You ask Mike what he means when he says, \"something was up.\""
            show costume down annoyed at jump
            mike "Isn't it OBVIOUS?{w=0.2} Sheesh."
            show costume pointing angry
            mike "The Lightners were hiding something from me--{w=0.2} something from ALL OF {noalt}US{/noalt}{alt}us{/alt}."
            show costume down annoyed
            mike "Tenna never visited the Mike Room ONCE.{p=0.5}{noalt}*{/noalt} Not ONCE!!"
            mike "That's insane for a guy who makes us do\neverything--"
            show costume tie nervous at jump
            mike "I mean, uh,{nw=0.2}"
            show costume pointing nervous at jump
            extend " a friend who trusts me,{w=0.2} the one and only MIKE,{w=0.2} with everything!"
            show costume down annoyed
            mike "So...{p=0.5}{noalt}*{/noalt} I HAD to go find him!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike seems stuck on something.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Shadow Crystal?" if s_shadow and m_shadow and m_shadowconvo == 0:
            $ m_shadowconvo += 1
            "You asked Mike where he got that Shadow Crystal from."
            show costume tie frown
            mike "You,{w=0.2} huh?{p=0.5}{noalt}*{/noalt} You know it by NAME?"
            show costume tie nervous
            mike "Wait,{w=0.2} how come you were told that but I wasn't?!{p=0.2}{noalt}*{/noalt} Who gave that thing to you, who?!"
            "You tell Mike that you have no idea."
            show costume down frown
            mike "Ugh,{w=0.2} figures.{p=0.2}{noalt}*{/noalt} Whatever,{w=0.2} WHATEVER!{w=0.5} This isn't why I'm here ANYWAY!"
            show costume pointing frown
            mike "I've got the thing,{w=0.2} I'm right where I'm supposed to be..."
            show costume pointing nervous at jump
            mike "But the TV'S NOWHERE IN SIGHT?!"
            show costume at wiggle
            mike "Just HOW BIG is this Dark World,{w=0.2} BY THE WAY??"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                if not seenstats_fp:
                    $ seenstats_fp = True
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}Friendship Points{/color}."
                else:
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."

        "The invisible item?" if not s_shadow and m_shadow and m_shadowconvo == 0:
            $ m_shadowconvo += 1
            "You asked Mike where he got the same kind of invisible item that you have."
            show costume tie frown
            mike "I'd imagine the same place as you,{w=0.2} huh?{w=0.2} Right?{w=0.5} Why wouldn't it be??"
            show costume tie nervous
            mike "Wait,{w=0.2} where'd YOU get YOURS from,{w=0.2} then?!"
            "You tell Mike that you have no idea."
            show costume down frown
            mike "Ugh,{w=0.2} figures.{p=0.2}{noalt}*{/noalt} Whatever,{w=0.2} WHATEVER!{w=0.5} This isn't why I'm here ANYWAY!"
            show costume pointing frown
            mike "I've got the thing,{w=0.2} I'm right where I'm supposed to be..."
            show costume pointing nervous at jump
            mike "But the TV'S NOWHERE IN SIGHT?!"
            show costume at wiggle
            mike "Just HOW BIG is this Dark World,{w=0.2} BY THE WAY??"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                if not seenstats_fp:
                    $ seenstats_fp = True
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}Friendship Points{/color}."
                else:
                    "Mike looks like he has more to say.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."

        "This Dark World..." if m_shadowconvo == 1:
            $ m_shadowconvo += 1
            "You tell Mike that when you first woke up here,{w=0.2} you were in a completely different part than where you two are now."
            show costume down annoyed
            mike "Of course.{w=0.2} OF COURSE!"
            show costume pointing angry at jump
            mike "This place is HUGE,{w=0.2} then!{w=0.5} Does it even end?!"
            show costume tie nervous at wiggle
            mike "Nothing around here can be easy, can it.{p=0.5}{noalt}*{/noalt} Why did I agree to something with a time limit when I didn't know how long it'd take me...?!"
            show costume pointing nervous
            mike "Gah,{w=0.2} I don't even know what direction I came from anymore..."
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike is feeling a bit lost.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "How did you get here?" if m_shadowconvo == 2:
            $ m_shadowconvo += 1
            "You ask Mike how he managed to get here."
            show costume tie frown
            mike "Oh, c'mon,{w=0.2} you say that like it's bizarre that a microphone waltzed in through a Dark Fountain!"
            show costume pointing frown at jump
            mike "Wouldn't you have come in here the same way?!"
            "You tell Mike that you don't know how you first arrived."
            show costume pointing nervous
            mike "What?{nw=0.5}"
            show costume tie frown flipped at cospos_center_fl
            show costume at jump
            extend "{p=0}{noalt}*{/noalt} Now hold on here, hold on.{w=0.2} That doesn't make a lick of sense!"
            show costume pointing frown at cospos_center
            show costume at jump
            mike "You're a LIGHTNER!{p=0.5}{noalt}*{/noalt} Going in and out of Dark Fountains should be easy-peezy for a Lightner!!"
            show costume tie frown
            mike "Unless somebody made the Fountain while you were still in the area...?"
            show costume pointing frown
            mike "Say,{w=0.2} you haven't seen any other Lightners in this Dark World, have you?"
            mike "Maybe that could... {nw=0.2}"
            show costume tie awkward at jump
            extend "WAIT A SECOND,{w=0.2} I don't have the time here to deal with YOUR problems!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike stops himself from going down a rabbit hole.{p=0.2}{noalt}*{/noalt} He gained 4 {color=[c_kindness]}FP{/color}."

        "Time limit?" if m_shadowconvo == 3:
            $ m_shadowconvo += 1
            "You ask Mike about the \"time limit\" he keeps bringing up."
            show costume pointing angry
            mike "That's none of your business, ya punk!{p=0.2}{noalt}*{/noalt} What Mike does is MIKE'S business,{w=0.2} nobody else's!!"
            show costume down frown
            mike "Except Tenna's but that's not the point.{w=0.2} ANYWAY."
            show costume pointing angry at jump
            mike "If you're not gonna help me find Tenna,{w=0.2} then just quit askin' me useless questions like this."
            show costume down angry
            mike "You KNOW there's a time limit,{w=0.2} so STOP WASTIN' MY TIME."
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike is growing very impatient.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Seen anybody else?" if m_shadowconvo == 4:
            $ m_shadowconvo += 1
            "You ask Mike if he's seen anyone aside from you while looking for Tenna."
            show costume down frown at jump
            mike "No, why?{w=0.2} Was I supposed to?"
            show costume pointing nervous at jump
            mike "Wait,{w=0.2} there's other people here who are ALIVE??{p=0.2}{noalt}*{/noalt} Oh, that's..."
            show costume tie nervous flipped at cospos_center_fl
            show costume at wiggle
            mike "That's not unsettling or creepy at all,{w=0.2} hahaha,{w=0.2} I'm sure that's fine and not an indicator for my future or anything!!!"
            show costume pointing nervous at cospos_center
            show costume at jump
            mike "Wait,{w=0.2} have you MET other people here?!"
            "You nod somewhat uncertainly."
            show costume tie frown
            mike "AUGH,{w=0.2} and you didn't think to tell me SOONER?!{p=0.2}{noalt}*{/noalt} I need as much help as I can get here,{w=0.2} y'know!!!"
            if date_fp > 0:
                play sfx ding
                show costume tie smile at jump
                $ date_fp -= 4
                "Mike is becoming a bit frantic.{p=0.2}{noalt}*{/noalt} But he gained 4 {color=[c_kindness]}FP{/color}."

        "Return":
            jump mikedate_secret_menu

    jump mikedate_secret


######################################################
##### ACT
label mikedate_act:
    $ skipyes = True
    $ _skipping = True
    hide screen mikedate_select

    menu:
        date "Act"
        "Check":
            $ check += 1
            if check == 1:
                "\"Mike\" - 50 FP  50 LP{p=0.2}{noalt}*{/noalt} Definitely the ONE and ONLY REAL Mike!"
                show costume pointing angry at jump
                mike "Mike CHECK!{p=0.2}{noalt}*{/noalt} Is this thing on?{w=0.2} Are ya hearing me over there?"
                mike "You are?{p=0.5}{noalt}*{/noalt} Then QUIT STARIN' at me!!"
                show costume tie awkward
                mike "These eyes aren't for YOU to look at,{w=0.2} punk!"
            else:
                "\"Mike\" - 50 FP  50 LP{p=0.2}{noalt}*{/noalt} Clock's ticking."
                jump mikedate_secret_menu

        "Flirt":
            $ m_flirt = True
            if date_fp > 0:
                "You flirted with Mike."
                show costume tie awkward at jump
                mike "WHOA,{w=0.2} hey,{w=0.2} WHOA!!{p=0.5}{noalt}*{/noalt} Back off,{w=0.2} pal!"
                show costume pointing nervous at wiggle
                mike "I get that I'm a good-lookin' fella and everything,{w=0.2} but I JUST met ya!"
                show costume tie smile at jump
                mike "At least buy me a TV Dinner or something first.{p=0.2}{noalt}*{/noalt} Sheesh."
                "Maybe Mike would be more receptive if you were better friends..."
            
            else:
                $ flirt += 1
                if flirt == 1:
                    "You complimented Mike's microphone-like hairdo."
                    if date_lp > 0:
                        play sfx ding
                        show costume down frown at jump
                        $ date_lp -= 5
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "He...{w=0.2} bristled?{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}Love Points{/color}."
                        else:
                            "He...{w=0.2} bristled?{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}LP{/color}."
                    show costume down nervous
                    mike "Haha,{w=0.5} what?{w=0.2} WHAT?"
                    show costume tie smile at jump
                    mike "I mean.{w=0.2} Of COURSE you'd like it!{p=0.5}{noalt}*{/noalt} Everybody does!{w=0.2} Nobody doesn't!"
                    show costume pointing smile at jump
                    mike "But I see right through you.{p=0.5}{noalt}*{/noalt} I'm a smart guy and I know EXACTLY what you're trying to pull!!"
                    show costume pointing angry
                    mike "Don't think your fancy-schmancy words are gonna woo me over for a second!{w=0.2} Not a SINGLE SECOND!!"
                    show costume tie awkward at droop
                    mike "I'm,{w=0.2} ah..."
                    show costume pointing nervous at jump
                    if m_flower:
                        mike "I'm still too busy for any kinda relationship nonsense!"
                        show costume pointing angry
                        mike "Takes all kinds of work to keep Tenna's business in order!"
                    else:
                        mike "A BUSY GUY!{w=0.5} Yeah,{w=0.2} a REAL BUSY GUY!!"
                        show costume pointing angry
                        mike "I don't have time for you and your funny business!!"

                elif flirt == 2:
                    "You told Mike that his outfit was top-notch,{w=0.2} and asked him where he got it."
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at jump
                        $ date_lp -= 5
                        "He jolted and his smile quirked.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}LP{/color}."
                    show costume tie smile at jump
                    mike "Where I GOT it??{w=0.5} WHERE I got it???"
                    show costume pointing frown at jump
                    mike "Heh...{w=0.2} You wouldn't know talented craftsmanship if it bit you in the nose!!{p=0.5}{noalt}*{/noalt} I MADE this outfit!"
                    show costume pointing smile
                    mike "Made it,{w=0.2} all by myself!{p=0.5}{noalt}*{/noalt} Hand-made, hand-sewn,{w=0.2} no ifs {noalt}and/or{/noalt}{alt}and or{/alt} buts about it!!"
                    show costume down smile
                    mike "Of COURSE it's top-notch!{w=0.2} Of COURSE it suits me perfectly!!"
                    show costume tie blush at wiggle
                    mike "It's the perfect Mike fit,{w=0.2} fitting and fitted for the number-one-and-only MIKE!"

                elif flirt == 3:
                    "You said that Mike looked like a very huggable person."
                    if date_lp > 0:
                        play sfx ding
                        show costume tie awkward at jump
                        $ date_lp -= 3
                        "He nearly jumped out of his skin.{p=0.2}{noalt}*{/noalt} But he still gained 3 {color=[c_passion]}LP{/color}."
                    show costume at wiggle
                    mike "Wh-{w=0.1} what're you getting at with that,{w=0.2} huh?!"
                    show costume pointing angry at jump
                    mike "Look, hey, see,{w=0.2} I didn't come here for this kind of treatment!!"
                    show costume down annoyed
                    mike "Quit tryin' to butter me up, or whatever you're doin'!"
                
                elif flirt == 4:
                    "You flirted with Mike again,{w=0.2} but...{nw=0.2}"
                    show costume down annoyed
                    mike "Could you STOP that?{w=0.2} Seriously!!{w=0.2} I asked you MULTIPLE times already, didn't I, huh?!"

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_8
                    show screen datestats

                    show costume pointing angry at rise
                    mike "I'm not here TO be all flattered by some random STRANGER!"
                    mike "I'm not joking or joshing around here,{w=0.2} this is REALLY frustrating!!"

                else:
                    "You worry this might upset Mike more if you tried it again."
                    jump mikedate_secret_menu

        "Pet":
            if m_pet_no:
                "You worry this might upset Mike more if you tried it again."
                jump mikedate_secret_menu
            else: 
                $ m_pet += 1
                show costume tie awkward at jump
                play sfx plop
                "You gave Mike a pat on the head."
                if m_pet_lp > 1:
                    show costume pointing nervous
                    if m_pet == 1:
                        mike "Where's this comin' from?!{p=0.2}{noalt}*{/noalt} Geez.{w=0.5} If I had a nickel for everybody who tried to pet me outta nowhere..."
                    else:
                        mike "Sheesh,{w=0.2} what is it with you?{p=0.5}{noalt}*{/noalt} You just give headpats to every guy you meet?"
                    if m_pet > 1:
                        $ m_pet_lp -= 1 # starts at 5, drops 1 every time
                    if date_lp > 0:
                        play sfx ding
                        show costume tie blush at jump
                        $ date_lp -= m_pet_lp
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Mike seemed to appreciate it, regardless.{p=0.2}{noalt}*{/noalt} He gained [m_pet_lp] {color=[c_passion]}Love Points{/color}."
                        else:
                            "Mike seemed to appreciate it, regardless.{p=0.2}{noalt}*{/noalt} He gained [m_pet_lp] {color=[c_passion]}LP{/color}."
                
                else:
                    $ m_pet_no = True
                    show costume at wiggle
                    mike "A-{w=0.1} alright, ALRIGHT already!!{p=0.5}{noalt}*{/noalt} Enough with the headpats already!!"
                    show costume pointing nervous at jump
                    mike "Do you think I'm a cat or something?"
                    show costume pointing angry
                    mike "Mike is NOT a cat!!{p=0.5}{noalt}*{/noalt} Mike is a MICROPHONE!{w=0.2} It's in the name-- MIKE!!"
                    show costume tie nervous at wiggle
                    mike "Hahaha...{w=0.2} hahaha...{w=0.5} ahem."

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_9
                    show screen datestats

                    show costume pointing smile at jump
                    mike "ANYWAY!!!!!"

        "Infodump\n{size=-10}{color=#aaaaaa}(Restore){/color}{/size}" if date_hb < 3:
            if not m_infosee:
                $ m_infosee = True
                "Mike really seems like he needs to know where Tenna is."
                "You don't know much,{w=0.2} but maybe if you told him what you DO know,{w=0.2} he would hate you less...?"
                "But it might {color=[c_passion]}start to wake you up{/color} if you try."
            if m_info == 1:
                $ m_info_menu_text = "piece"
            else:
                $ m_info_menu_text = "pieces"
            menu:
                rq "You have {color=[c_passion]}[m_info]{/color} [m_info_menu_text] of info left to share with Mike."
                "Share" if m_info > 0:
                    play sfx item
                    $ m_info -= 1
                    if m_info == 1:
                        "You tell Mike that when you last talked with Tenna,{w=0.2} he'd made a colorfully-painted \"board\" that collapsed onto the ground."
                        show costume tie smile at jump
                        mike "Really?!{p=0.5}{noalt}*{/noalt} Oh, that's SUPER good info, pal!{w=0.2} Can't get better than this, honestly!!"
                        show costume pointing smile
                        mike "This place is as dreary as can be--{w=0.2} something painted with COLOR and LIFE??{p=0.5}{noalt}*{/noalt} That'll stick out like a green thumb!"
                        show costume tie nervous at jump
                        mike "... I mean.{w=0.2} A SORE thumb."
                        show costume pointing nervous at wiggle
                        mike "...{w=0.2} ANYWAY!!"

                    elif m_info == 0:
                        "You tell Mike that you distinctly remember a broken robot arm near where you first met Tenna."
                        show costume pointing nervous at jump
                        mike "AN ARM???{w=0.5} JUST.{w=0.2} A WHOLE ARM????"
                        show costume tie nervous flipped at cospos_center_fl
                        show costume at jump
                        mike "Oh no.{w=0.2} That can't be good.{w=0.2} Ahhh."
                        show costume pointing angry at cospos_center
                        show costume at jump
                        mike "Ahh, forget it!{w=0.2} Nope,{w=0.2} not thinking about that right now!!{p=0.5}{noalt}*{/noalt} I'll just...{w=0.5} keep an eye out for it!"
                        show costume pointing nervous at wiggle
                        mike "It being.{w=0.2} An arm.{w=0.2} Just an ENTIRE severed arm.{p=0.5}{noalt}*{/noalt} Yup.{w=0.2} Yup.{w=0.2} This is fine."
                        show costume tie nervous
                        mike "That's the kind of good, specific info I need,{w=0.2} hahaha!{p=0.2}{noalt}*{/noalt} Thanks.{w=0.2} I think."

                    ### RESTORE
                    hide screen datestats
                    call restore_ani from _call_restore_ani
                    show screen datestats

                    "... though,{w=0.2} Mike's response leaves you feeling a little awkward."
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

                "Do not":
                    jump mikedate_secret_menu

        "Return":
            jump mikedate_secret_menu

    jump mikedate_secret


######################################################
##### ITEM
label mikedate_item:
    $ date_item = True
    $ quick_menu = False
    hide screen mikedate_select
    call screen inv_view
    jump mikedate_secret_menu

label mikedate_item_react:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True

    ## SHADOW CRYSTAL
    if which_item == itm_shadow:
        if not m_shadow:
            $ m_shadow = True
            if s_shadow:
                "You showed off the Shadow Crystal you've been carrying this whole time."
            else:
                "You showed off the strange invisible item you've been carrying this whole time."
            show costume down frown at jump
            mike "Huh?{w=0.2} Whassat you've got there?"
            show costume tie frown
            mike "Hold on.{w=0.2} Hang on.{p=0.5}{noalt}*{/noalt} I think I actually KNOW what that is you've got there."
            show costume tie frown flipped at cospos_center_fl
            show costume at jump
            mike "It's...{w=0.2} somewhere...{nw=0.5}"
            show costume pointing smile at cospos_center
            show costume at jump
            extend " Here it is!{w=0.2} Yup!"
            play sfx sparkleglock
            show itemframe i_shadow at truecenter with easeinbottom
            "Mike showed off what looked to be almost nothing,{w=0.2} if it weren't for the rippling shadow it produced."
            "When you peered into it closely,{w=0.2} it looked like a giant garbage dump was inside."
            hide itemframe with easeoutbottom
            show costume at jump
            mike "I've got basically the same thing right here, yup!"
            show costume tie frown
            mike "Yours is kinda different, though...{w=0.5} I can't really see into the other side all that clearly."
            "You weren't even aware there was \"another side\" to see from it."
        
        else:
            if s_shadow:
                "You pulled back out the Shadow Crystal again."
            else:
                "You pulled back out the strange invisible item again."
            show costume tie frown
            mike "You did show me that, yeah.{p=0.5}{noalt}*{/noalt} Can't explain much more, though."
            show costume pointing nervous
            mike "W-{w=0.1} wait,{w=0.2} you're distracting me from why I'm here in the first place!!"

    ## MEMORYSHARD (mike, 9)
    elif which_item == itm_blueshard:
        if not m_memshard:
            $ m_memshard = True
            if ex_memory:
                "You present the blue MemoryShard you found earlier to Mike."
            else:
                "You present the blue shard you found earlier to Mike."
            show costume down frown
            "You explain the vision that it gave you,{w=0.2} describing how distraught Tenna was and that he told someone he was going to talk to Mike."
            show costume tie nervous
            mike "Th--{w=0.1} that..."
            show costume at droop
            mike "You're a real weird person,{w=0.2} you know that,{w=0.2} you,{w=0.5} uh..."
            show costume tie frown at rise
            mike "Wait,{w=0.2} did you ever tell me what your name was?"
            show costume pointing angry at jump
            mike "NEVERMIND!!{w=0.5} Point is,{w=0.2} your hyper-specific stories about nothing pertaining to me are a weird thing to say and I want nothing to do with it!"
            show costume pointing nervous at wiggle
            mike "{noalt}Y'hear{/noalt}{alt}ya hear{/alt} that?{w=0.2} Huh??{p=0.5}{noalt}*{/noalt} NOTHING, I said,{w=0.2} NOTHING!!"
        
        else:
            "You try to show Mike the shard again, but...{nw=0.2}"
            show costume tie nervous at jump
            mike "Get that thing outta here!!{p=0.2}{noalt}*{/noalt} I don't wanna think about THAT m-- uh,{w=0.5} STORY."
            mike "THE STORY.{w=0.2} THE WEIRD STORY.{p=0.5}{noalt}*{/noalt} THE REALLY WEIRD STORY YOU TOLD."
            show costume tie awkward at wiggle
            mike "YEAH THAT.{w=0.2} I'M NOT THINKING ABOUT {noalt}IT{/noalt}{alt}it{/alt} SO STOP PRETENDING I AM!!"

    ## FIGLOVE / FIGHATE
    elif which_item == itm_figlove or which_item == itm_fighate:
        "You show off the Tenna figure you have to Mike."
        show costume tie frown
        mike "Now how'd you get a hold of THIS?{p=0.5}{noalt}*{/noalt} THIS??{w=0.2} WHICH WASN'T EVEN RELEASED??"
        if which_item == itm_fighate:
            show costume pointing angry at jump
            mike "The arms are even knocked off the damn thing!"
        show costume tie frown flipped at cospos_center_fl
        show costume at jump
        mike "Did those kids throw out half of TV World or something...?{p=0.5}{noalt}*{/noalt} But why would they do that?!"
        show costume tie nervous at cospos_center
        show costume at jump
        mike "What?{nw=0.5}"
        show costume pointing nervous at jump
        extend " No,{w=0.2} NO,{w=0.2} I'm not mumbling to myself,{w=0.2} hahaha!{w=0.2} Nope!{w=0.5} Just chattering about nothing to no one!"
        show costume down frown
        mike "Oh,{w=0.2} forget it.{w=0.5} Forget you heard anything!!"
        show costume down angry at jump
        mike "... and GIMMIE that thing!!{p=0.5}{noalt}*{/noalt} I don't know where ya got it but YOU'RE not supposed to have it!!"
        play sfx plop
        if which_item == itm_figlove:
            $ inventory.remove(itm_figlove)
        elif which_item == itm_fighate:
            $ inventory.remove(itm_fighate)
        show costume pointing angry at jump
        "Mike yoinked the figure out of your hands before you could even argue."
        show costume down annoyed
        mike "This is TV Time merch that never got to hit the shelves!{w=0.2} Never!!"
        show costume tie frown
        mike "... {w=0.2}on account of the fact that nobody really ever wanted to buy anything with Tenna's face on it."
        show costume down smile at jump
        mike "BUT, BUT!{w=0.2} As Tenna's beloved employee and number one favorite of all time,{w=0.5} it's MY responsibility to make sure those top-secret things DON'T get out!"
        show costume pointing smile at jump
        mike "You hearing that?{w=0.2} You really absorbing it?!{p=0.5}{noalt}*{/noalt} Well GOOD!{w=0.2} 'Cuz it means you're NOT getting this back!!"
        if date_lp > 0:
            play sfx ding
            show costume tie awkward at jump
            $ date_lp -= 10
            if not seenstats_lp:
                $ seenstats_lp = True
                "Mike seems too excited about this figure.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
            else:
                "Mike seems too excited about this figure.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

    ## FLOWER
    elif which_item == itm_flower:
        $ m_flower = True
        play sfx item
        $ inventory.remove(itm_flower)
        "You offered the flower in your pockets to Mike."
        show costume tie awkward at jump
        mike "H-{w=0.1} huh?{p=0.5}{noalt}*{/noalt} Where'd you...?!"
        show costume pointing nervous at jump
        mike "Did you get this just to give it to me??{p=0.5}{noalt}*{/noalt} Wait, wait, no, that doesn't make any sense!!"
        show costume tie awkward at wiggle
        mike "Hahaha,{w=0.2} well,{w=0.2} I mean,{w=0.1} it'd be rude to turn down a gift from somebody..."
        show costume pointing angry at jump
        mike "But don't get any funny ideas from this, {noalt}y'hear{/noalt}{alt}ya hear{/alt}?!{p=0.5}{noalt}*{/noalt} I'm..."
        show costume pointing nervous at jump
        if flirt > 0:
            mike "I'm still too busy for any kinda relationship nonsense!"
            show costume pointing angry
            mike "All kinds of work to keep Tenna's business in order!"
        else:
            mike "A BUSY GUY!{w=0.5} Yeah,{w=0.2} a REAL BUSY GUY!!"
            show costume pointing angry
            mike "I don't have time for you and your funny business!!"
        if date_lp > 0:
            play sfx ding
            show costume tie awkward at jump
            $ date_lp -= 10
            if not seenstats_lp:
                $ seenstats_lp = True
                "Mike seems conflicted about something.{p=0.2}{noalt}*{/noalt} But he still gained 10 {color=[c_passion]}Love Points{/color}."
            else:
                "Mike seems conflicted about something.{p=0.2}{noalt}*{/noalt} But he still gained 10 {color=[c_passion]}LP{/color}."

    ## FOOD
    elif which_item in [itm_pie, itm_candy, itm_fries, itm_pretzel, itm_coffee, itm_cocoa]:
        if m_food:
            "You tried to offer more of the food you had with you,{w=0.2} but...{nw=0.2}"
            show costume tie nervous at jump
            mike "Uhhhhh HEY!{w=0.5} I appreciate all the giftin' you're doin', hahahaha,{w=0.2} why wouldn't I?!{p=0.2}{noalt}*{/noalt} Mike loves all sorts of attention!"
            show costume pointing smile at jump
            mike "But.{w=0.2} Maybe.{w=0.2} MAYBE.{w=0.5} You can keep that one for yourself?"
            show costume tie nervous at jump
            mike "NOT THAT I DIDN'T LIKE {noalt}IT{/noalt}{alt}it{/alt} BEFORE!{w=0.2} I'm just...{w=0.5} STUFFED TO THE GILLS OVER HERE!!"
            show costume at wiggle
            mike "Yeah,{w=0.2} couldn't eat another bite if I tried!!"        
        
        else:
            $ m_food = True
            if which_item == itm_pie:
                $ inventory.remove(itm_pie)
            elif which_item == itm_candy:
                $ inventory.remove(itm_candy)
            elif which_item == itm_fries:
                $ inventory.remove(itm_fries)
            elif which_item == itm_pretzel:
                $ inventory.remove(itm_pretzel)
            elif which_item == itm_coffee:
                $ inventory.remove(itm_coffee)
            elif which_item == itm_cocoa:
                $ inventory.remove(itm_cocoa)
            play sfx item
            "You offered Mike some of the food you had in your inventory."
            show costume down frown
            mike "Hey, now,{w=0.2} what?{w=0.5} Why are you offering me somethin' to eat??"
            show costume pointing nervous at jump
            mike "Actually, scratch that--{w=0.2} where did you GET that?{p=0.5}{noalt}*{/noalt} Isn't this the dump??"
            show costume tie smile
            mike "...{w=0.2} b-{w=0.1} but, hey,{w=0.2} it'd be pretty rude of me to turn down something you're offerin',{w=0.2} right?!"
            show costume tie nervous at jump
            play sfx gulp
            "Mike very unenthusiastically{w=0.5} TRIES it.{w=0.2}.{w=0.2}.{w=0.2}?"
            "Somehow,{w=0.2} despite the food going into his mouth,{w=0.2} his nonchalant expression really doesn't scream he actually consumed it."
            show costume tie frown flipped at cospos_center_fl
            show costume at droop
            mike "Pee-yew,{w=0.2} this stuff smells terrible...{nw=0.5}"
            show costume pointing nervous at cospos_center
            show costume at jump
            extend " BUT, it tastes okay,{w=0.2} I guess?!"
            show costume pointing smile
            mike "Look! Look here now,{w=0.2} don't think too highly of my opinion on it!!{p=0.5}{noalt}*{/noalt} I'm a guy with a sophisticated palate!"
            show costume tie smile
            mike "And I'm a little stressed from...{w=0.2} gettin' all the way over here from another Dark World!!{p=0.5}{noalt}*{/noalt} You understand, right?!{w=0.2} 'Course you do!!!"
            if date_lp > 0:
                play sfx ding
                show costume tie awkward at jump
                $ date_lp -= 5
                if not seenstats_lp:
                    $ seenstats_lp = True
                    "Mike appreciated the gesture, at least.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                else:
                    "Mike appreciated the gesture, at least.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

    ## PIPIS
    elif which_item == itm_pipis:
        "You pulled out the weird item you found a while ago."
        show costume pointing nervous at rise
        mike "GAH!!!{p=0.5}{noalt}*{/noalt} WHERE DID YOU GET THAT?!?!{w=0.2} HOW'S SHE ALL THE WAY OUT HERE?!?!"
        play sfx pipisS
        $ inventory.remove(itm_pipis)
        show costume at jump
        "Mike ripped the weird item out of your hands."
        if persistent.glitches:
            show costume pointing angry at jump
        else:
            show costume pointing angry at shock
        mike "YOU TRYIN' TO GIVE A GUY A HEART ATTACK??{w=0.2} ME BEING THE GUY??{p=0.5}{noalt}*{/noalt} B-{w=0.1} be careful carrying her around!!"
        show costume tie nervous flipped at cospos_center_fl
        show costume at wiggle
        mike "Geez, GEEZ,{w=0.2} if Tenna found out she'd been thrown out,{w=0.2} he'd have ALL of our heads!!"
        mike "Oh. Right, wait, huh.{nw=0.5}"
        show costume tie nervous at cospos_center
        show costume at jump
        extend "{p=0}{noalt}*{/noalt} Thanks for finding this!{w=0.2} I guess??"
        show costume at wiggle
        mike "I'm gonna...{w=0.2} hold onto her.{p=0.5}{noalt}*{/noalt} It's MIKE'S duty, after all,{w=0.2} hahaha!"
        if date_lp > 0:
            play sfx ding
            show costume tie awkward at jump
            $ date_lp -= 5
            if not seenstats_lp:
                $ seenstats_lp = True
                "Mike seems sensitive about something.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}Love Points{/color}."
            else:
                "Mike seems sensitive about something.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}LP{/color}."
    
    ## ALL OTHERS
    else:
        "You don't think Mike would have anything to say about that."
        jump mikedate_secret_menu

    jump mikedate_secret



############################################################################################################
################## DATE ENDINGS

######################################################
##### SUCCESS
label mikedate_success:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    hide screen datestats
    $ mke.fp = date_fp
    $ mke.lp = date_lp
    $ mke.hb = date_hb
    $ mke_date = True
    $ mke_success = True
    
    stop music
    show costume pointing frown at cospos_center
    show costume at jump
    mike "Hold on, hold it,{w=0.2} stop, STOP."
    play ambiance wind
    pause 1.0
    show costume down frown
    mike "You...{w=0.5} you had one of those,{w=0.2} too,{w=0.2} right?{nw=0.5}"
    show costume down nervous at droop
    if s_shadow:
        extend "{p=0}{noalt}*{/noalt} The \"Shadow Crystal\" or whatever."
    else:
        extend "{p=0}{noalt}*{/noalt} That clear crystal thing."
    show costume pointing nervous
    mike "Does that mean,{w=0.2} you already know...?"
    show costume at wiggle
    mike "Or,{w=0.2} uh,{w=0.2} how much DO you know?"
    show costume tie nervous flipped at cospos_center_fl
    mike "You weren't just kinda,{w=0.2} waltzing around and plucked that off the ground somehow,{w=0.2} right?"
    show costume pointing nervous at cospos_center
    mike "How...{w=0.2} much do you know about...{w=0.5} y'know...?"
    menu:
        rq "How... much do you know about... y'know...?"
        "{color=#FF54A6}I{/color} know you're not Mike.":
            "{color=[c_passion]}You{/color} tell \"Mike\" you already know he's not actually Mike."
            show costume pointing angry at jump
            mike_no "Oh, come on!{w=0.2} That isn't what I meant..."
            show costume tie nervous
            mike_no "But,{w=0.2} if you know that,{w=0.2} then..."
            show costume pointing nervous
            mike_no "You probably know about.{w=0.2} The OTHER thing.{w=0.2} Right?"
            show costume tie nervous at droop
            mike_no "Yeah,{w=0.2} you're nodding, so..."
            show costume tie frown
            mike_no "...{w=0.5} {cps=35}\"{color=[c_power]}The Lord of the Screens,{w=0.2} cleaved Red by the Blade.{/color}\"{/cps}{p=0.5}{noalt}*{/noalt} That."

        "{color=#FF54A6}I{/color} know about the prophecy.":
            "{color=[c_passion]}You{/color} tell \"Mike\" you already know about the prophecy."
            show costume tie nervous at droop
            mike "Ha{w=0.2} ha{w=0.2} ha.{w=0.5} Yeah.{w=0.2} I had a feeling."
            show costume tie frown
            mike "If you know that,{w=0.2} then..."
            show costume tie nervous at wiggle
            mike "You...{w=0.5} probably already know,{w=0.2} that I'm,{w=0.2} uh...{w=0.2} not the guy I said I was,{w=0.2} huh...?"
            show costume down frown at droop
            mike_no "I'm...{w=0.5} not really Mike."
            show costume pointing nervous at jump
            mike_no "I don't even know WHO Mike is!"

    show costume tie nervous flipped at cospos_center_fl
    show costume at jump
    mike_no "Ah,{w=0.2} crap.{p=0.2}{noalt}*{/noalt} It's getting so stuffy in this costume."
    show costume pointing frown at cospos_center
    show costume at jump
    mike_no "Uh.{w=0.2} You're sure Tenna's nowhere nearby, right?"
    "You nod,{w=0.2} saying you're absolutely certain."
    show costume tie smile
    mike_no "Okay.{w=0.2} You better not be lying to me."
    show costume tie frown
    mike_no "I mean,{w=0.2} I know I was just lying to you about...{w=0.5} my whole identity and everything{nw}"
    show costume pointing nervous at jump
    extend " BUT WE'RE IGNORING THAT."
    show costume down frown
    mike_no "That's,{w=0.2} uh...{w=0.2} a different subject.{p=0.2}{noalt}*{/noalt} Complicated."
    show costume pointing nervous
    mike_no "ANYWAY.{w=0.2} MOVING ON."
    show costume pointing smile at jump
    mike_no "Let's get away from the Fountain.{w=0.2} I can barely see over here."

    ## TRANSITION
    stop ambiance fadeout 1.0
    play sfx waterwalk
    scene black with Dissolve(2.0)
    "You and \"Mike\" walked back towards the Dark World,{w=0.2} in the same direction you came from earlier."
    pause 1.0
    scene junkyard5 with Dissolve(1.0)
    pause 1.0
    "For a second,{w=0.2} you thought you lost \"Mike\" somewhere in the darkness,{w=0.2} but..."
    show mikeend_date down with Dissolve(1.0)
    pause 0.5
    mike_no "So..."
    pause 1.0
    show mikeend_date angry with Dissolve(0.2)
    mike_no "HEY why are you looking at me like that?!{w=0.2} I told you the costume was getting stuffy!!"
    mike_no "Don't tell me now you think I look like a creep or something??"
    show mikeend_date down
    mike_no "Ugh,{w=0.2} nevermind!{p=0.5}{noalt}*{/noalt} Look,{w=0.2} so long as nobody else sees me like this,{w=0.2} it's...{w=0.5} probably fine."
    mike_no "You already knew from the beginning,{w=0.2} apparently,{w=0.2} so this really doesn't matter...{w=0.5} probably."
    show mikeend_date angry
    mike_no "JUST DON'T GO SPOUTING ABOUT {noalt}IT{/noalt}{alt}it{/alt} TO RANDOM PEOPLE OKAY??{w=0.5} I CANNOT have it get out that I'm not Mike!"
    show mikeend_date down with Dissolve(0.5)
    mike_no "...{w=0.2} Sigh.{w=0.2} Okay.{w=0.2} Fine."
    mike_no "Just let me get back into my regular clothes real quick."
    hide mikeend_date with Dissolve(1.0)
    pause 2.0
    show mike standing pout at mikepos_center with easeinleft
    mike_no "Anyway..."
    pause 1.0
    play music lostgirl
    show mike standing sigh
    mike_no "I don't know how long I have left at this point.{w=0.2} If I'm gonna be honest."
    show mike standing conflicted at droop
    mike_no "I came out here looking for Tenna, like I said,{w=0.2} but I've been wandering around for...{w=0.2} I don't know,{w=0.2} a WHILE now."
    show mike standing nervous
    mike_no "He just disappeared,{w=0.2} and the Lightners didn't say where to,{w=0.2} but...{w=0.5} It just didn't make sense that he'd be GONE."
    show mike standing sigh at rise
    mike_no "I don't really know WHO gave me that stupid crystal thing,{w=0.2} but they gave me an answer that I..."
    show mike tie nervous at wiggle
    mike_no "I didn't really like {noalt}IT{/noalt}{alt}it{/alt}, either,{w=0.2} to be honest with you!!"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "\"{color=[c_power]}The Lord of the Screens, cleaved Red by the Blade{/color}\"?{p=0.5}{noalt}*{/noalt} I didn't want to hear THAT!!"
    show mike tie anime at jump
    mike_no "But then I thought,{w=0.2} wait.{w=0.2} Hold on a second."
    show mike tie nervous
    mike_no "On its surface,{w=0.2} sounds like he died,{w=0.2} RIGHT?"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "Hahaha,{w=0.2} but,{w=0.2} BUT!{w=0.5} It's not,{w=0.2} DIRECT!!{p=0.2}{noalt}*{/noalt} People can live after having their arms chopped off,{w=0.2} for example!!"
    show mike arms avert
    mike_no "It doesn't say ANYWHERE that Tenna was supposed to DIE,{w=0.2} just that he was supposed to be \"CLEAVED\"!!"
    show mike tie nervous at droop
    mike_no "...{w=0.2} not that being \"cleaved\" is a good thing{nw}"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    extend " BUT {noalt}IT{/noalt}{alt}it{/alt} MEANS HE'S NOT DEAD!!{p=0.5}{noalt}*{/noalt} I REFUSE TO BELIEVE THAT HE COULD HAVE DIED!!"
    show mike standing nervous at yreset
    mike_no "Maybe I just didn't want it to be true,{w=0.2} or something..."
    pause 1.0
    show mike tie nervous
    mike_no "So they helped bring me here.{p=0.2}{noalt}*{/noalt} Same person who gave me that crystal."
    show mike standing conflicted
    mike_no "They told me I had a week and showed me the way to get here."
    mike_no "If I found Tenna,{w=0.2} I'd only have the remaining time to make it back home with him,{w=0.2} but..."
    show mike arms avert at wiggle
    mike_no "I...{w=0.5} don't remember which way I came from anymore,{w=0.2} hahaha...!!!"
    show mike arms freakout
    mike_no "Even if I FOUND him,{w=0.2} I don't know that we'd actually be able to make it home in time,{w=0.2} hahahaha...{w=0.2} ha..."
    show mike standing sigh at droop
    pause 1.0
    show mike standing conflicted
    mike_no "And now you're caught up.{p=0.5}{noalt}*{/noalt} Congrats.{w=0.2} Or something."
    show mike standing sigh at rise
    mike_no "Ugh,{w=0.2} I'm sick of being out here...{w=0.5} It's so.{w=0.2} gross."
    show mike standing nervous
    mike_no "If I'm bein' honest,{w=0.2} it was getting harder and harder to believe Tenna's alive somewhere out here."
    show mike tie avert at wiggle
    mike_no "I was starting to wonder if I'd actually just had some weird dream and had already...{w=0.5} uh.{w=0.2} Y'know."
    show mike standing sigh at yreset
    mike_no "Nevermind I'm not going to get into that-- but,{w=0.2} well."
    show mike standing conflicted
    mike_no "Dumps aren't...{w=0.5} great places.{p=0.5}{noalt}*{/noalt} To {noalt}Darkners{/noalt}{alt}dark nurs{/alt},{w=0.2} that is."
    show mike standing pout
    mike_no "Lightners just kinda find them inconvenient or whatever,{w=0.2} right?"
    mike_no "Just a buncha smelly trash in a pile that takes up too much space...?"
    show mike arms avert
    mike_no "Well,{w=0.2} uh,{w=0.2} can't speak for everybody--{w=0.2} but I can tell ya I've never met someone who doesn't think places like this are cursed or something."
    show mike tie nervous
    mike_no "Hahaha,{w=0.5} it reeks,{w=0.2} but mostly of...{w=0.2} y'know.{nw=0.5}"
    show mike at droop
    extend " Death."
    show mike standing sigh at rise
    mike_no "So...{w=0.5} I thought maybe I just couldn't take the reality of Tenna being dead and.{w=0.2}.{w=0.2}."
    mike_no "*Ahem*{p=0.5}{noalt}*{/noalt} ...{nw=0.2}"
    show mike standing conflicted
    extend " Died."
    show mike tie anime at jump
    mike_no "BUT-- you've seen him,{w=0.2} right?{w=0.2} You said you did earlier!!"
    show mike arms freakout at jump
    mike_no "So unless I've COMPLETELY lost my marbles at this point,{w=0.2} that means my theory was correct!!"
    show mike tie nervous at wiggle
    mike_no "Please don't be some kind of hallucination or something I don't think I could emotionally handle that at this point hahaha."
    menu:
        rq "Please don't be some kind of hallucination or something I don't think I could emotionally handle that at this point hahaha."
        "I'm definitely and totally real.":
            show mike arms freakout at jump
            mike_no "Say that any more convincing,{w=0.2} will ya?!"
            show mike tie nervous
            mike_no "But,{w=0.2} FINE,{w=0.5} I'll trust you on that."
            show mike standing nervous at droop
            mike_no "Not like I have much choice in the matter..."

        "I'm a figment of your imagination.":
            if persistent.glitches:
                show mike arms freakout
            else:
                show mike arms freakout at shakingcg
            mike_no "DON'T MESS WITH ME ON THIS!!{w=0.2} HEY!!"
            show mike arms avert
            mike_no "DON'T SMIRK AT ME,{w=0.2} YOU JERK!!"
            show mike standing sigh at droop
            mike_no "Ugh!!{w=0.5} Of all the people for me to be stuck with right now..."

        "I don't know what I am.":
            show mike standing indifferent at droop
            mike_no "O-{w=0.1} oh."
            pause 1.0
            show mike standing nervous at rise
            mike_no "Well...{w=0.2} uh.{w=0.5} I guess I sorta know what you mean."
            show mike standing pout at droop
            mike_no "Sometimes your head gets all muddled and you just kinda...{w=0.5} don't know who you are anymore.{w=0.5} Right?"
    
    show mike standing conflicted at rise
    mike_no "Ah,{w=0.2} forget it!"
    show mike standing sigh
    mike_no "I just wasted so much time..."
    show mike tie anime at jump
    mike_no "Look,{w=0.2} if you know where Tenna is,{w=0.2} I need you to bring him here."
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "BUT WARN ME FIRST SO I CAN PUT THE COSTUME BACK ON."
    show mike standing wink at yreset
    mike_no "I'll be waiting right here,{w=0.2} alright?{p=0.5}{noalt}*{/noalt} I'm really trusting you on this."
    show mike standing nervous at droop
    mike_no "If this doesn't work,{w=0.2} then.{w=0.2}.{w=0.2}."
    show mike tie nervous at jump
    mike_no "Nope, nope!{w=0.2} Nope!!{w=0.2} Not thinking about that right now!!"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "You!!{w=0.2} Go get Tenna!!{w=0.2} And bring him here!!{p=0.2}{noalt}*{/noalt} Got it?!"
    show mike arms avert
    mike_no "No dilly-dallying on this, either!!{p=0.5}{noalt}*{/noalt} I still have to find the way home,{w=0.2} remember?!"
    stop music fadeout 1.0
    show mike standing wink at yreset

    $ mke_menu = False    
    hide mike with Dissolve(0.5)
    pause 1.0
    play music dump
    jump ex_gameroom


######################################################
##### FAIL
label mikedate_fail:
    $ mke.fp = date_fp
    $ mke.lp = date_lp
    if mke.hb != 0:
        $ mke.hb = date_hb
    $ mke_date = True
    $ mke_failed = True

    $ currentend = "mike"
    hide screen datestats

    stop music
    show costume down frown at cospos_center
    mike "Y'know what?{w=0.2} Nevermind."
    show costume tie frown
    mike "This is a waste of my time,{w=0.2} and I REALLY don't have a lot of that anymore."
    show costume tie nervous at wiggle
    mike "Ahh, how long as it even been now?{p=0.2}{noalt}*{/noalt} I started losing track sometime yesterday,{w=0.2} I think,{w=0.2} augh,{w=0.2} crap..."

    ### TRIPLE HEARTBREAK
    if mke.hb != 0:
        call heartbreak_triple_ani from _call_heartbreak_triple_ani_3

    show costume down frown at yreset
    mike "Anyway.{w=0.5} If you find Tenna..."
    pause 1.0
    show costume down frown flipped at cospos_center_fl
    show costume at jump
    pause 2.0
    show costume pointing smile at cospos_center
    show costume at jump
    mike "Tell him Mike's lookin' for him,{w=0.2} will ya?"
    show costume down smile
    mike "Thanks."
    hide costume with easeoutleft
    pause 1.0
    $ mke_menu = False

    if mke_special:
        jump ending_none
    else:
        play sfx waterwalk
        scene black with Dissolve(2.0)
        pause 1.0
        "You trudged back to the Dark World,{w=0.2} and away from the Fountain..."
        pause 1.0
        scene junkyard5 with Dissolve(1.0)
        play music dump
        jump ex_gameroom