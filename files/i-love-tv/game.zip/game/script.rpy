﻿############################################################################################################
################## CHANGE BEFORE RELEASING

##############################################################
### REMEMBER: fix all "PLACEHOLDER" and "CHANGE FOR DEBUG" ###
###           and "DEBUG ONLY"                             ###
##############################################################

# CHANGE FOR DEBUG
default debugtesting = False # activates debug menu / testroom
define config.hard_rollback_limit = 0 # rollback to 0 for release (breaks persistent data if on) 





############################################################################################################
################## GASTER INTRO / SPLASH SCREEN
label splashscreen:
    ### DEBUG ONLY
    if debugtesting:
        $ persistent.gastmet = True
        $ persistent.mainskip = True
        $ persistent.warning = True
        #$ persistent.tenroute_fin = False
        #$ persistent.route = "Tenna"
        $ persistent.itemheard = True

    ## GAME TITLE (as seen by player)
    if persistent.playthru:
        if persistent.mainscreen == "Tenna":
            $ config.window_title = _("I Love TV!")
            $ change_icon(icon1)
        elif persistent.mainscreen == "Spamton":
            $ config.window_title = _("ILOVEYOU")
            $ change_icon(icon2)
    elif persistent.route == "Tenna":
        $ config.window_title = _("I Love TV!")
        $ change_icon(icon1)
    elif persistent.route == "Spamton":
        $ config.window_title = _("ILOVEYOU")
        $ change_icon(icon2)

    ## CONTENT WARNING
    if not persistent.warning:
        scene black
        call screen confirm("This game may not be suited for all audiences.\nSimilar to DELTARUNE, its content is rated for teens and up (13+).\n\nWould you like to read the content warning?\n{color=[c_goner]}(Note: reading the warning is not required.\nIt may contain mild spoilers.){/color}", yes_action=[SetVariable("warnsee", True), Return()], no_action=Return())
        if warnsee == True:
            call screen confirm("This game contains:\noccasional swearing,\nmild jumpscares,\nmild flashing imagery,\nmild sexual humor,\nmentions of death and suicide,\nvague references to alcohol,\npast and present relationships potentially not involving the player,\nand both obsessive and otherwise unhealthy\nrelationship dynamics.", yes_action=Return(), no_action=Return(), ok_ver=True)

        call screen confirm("Would you like to play in fullscreen mode?\n{color=[c_goner]}(This can be changed in SETTINGS\nor by pressing [[F] at any point.){/color}", yes_action=[Preference("display", "fullscreen"), Return()], no_action=Return())
        call screen confirm("Would you like to turn off\nglitches and shaking imagery/text?\n{color=[c_goner]}(It is recommended to turn this off if you use self-voicing,\nbut is not required. This can be changed in SETTINGS at any point.){/color}", yes_action=[SetVariable("persistent.glitches", True), Return()], no_action=Return())
        call screen confirm("Would you also like to turn off\nscene transitions to reduce motion?\n{color=[c_goner]}(This can be changed in SETTINGS at any point.){/color}", yes_action=[InvertSelected(Preference("transitions", "toggle")), Return()], no_action=Return())
        call screen confirm("This game can be played by navigating\nthe screen with a keyboard and/or mouse.\n\nWould you like to view the controls?\n{color=[c_goner]}(These can be viewed in HELP at any point.){/color}", yes_action=[ShowMenu("help"), Return()], no_action=Return())
        call screen confirm("This game only has one save slot,\nbut features autosaves at varying points.", yes_action=Return(), no_action=Return(), ok_ver=True)
        
        $ persistent.warning = True
        pause 1.0

    ## MEET GASTER
    if not persistent.gastmet:
        scene black
        play music anotherhim fadein 4.0
        $ renpy.pause (5.0, hard=True)
        show text _("Interesting...") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("So you've returned.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("Oh, am I mistaken?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("Well, then... You remind me of someone I've met prior.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Your SOULs emanate a very similar strength...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("A very similar {color=[c_passion]}PASSION{/color}.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("You should know...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("There is only so much this world can offer you at such a great distance.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("Ha, ha. Perhaps that is hypocritical, yes...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("After all, I have done nothing but observe for many years.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("How many years?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("It could be very many, it could be very few.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("It's a matter of perspective, is it not?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("I digress. What is it that you desire?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("Well... I suppose I cannot truly deny you what you wish.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("I do possess the means to establish such a connection.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("Though, perhaps your desires could aid me in my study...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        play sfx bwaa
        scene white with Dissolve(0.2)
        pause 0.5
        scene black
        show soul_sketchy at soulbop
        with Dissolve (1.0)
        $ renpy.pause (3.0, hard=True)
        show text _("I concede.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Shall we make a deal, then?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("I will allow you to enter this world in some capacity.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("And in exchange...") with dissolve
        pause
        scene black
        stop music
        $ persistent.gastmet = True

    ## STARTING SPAMTON ROUTE
    elif persistent.tenroute_fin and persistent.route != "Spamton":
        jump spamtonstart

    return


############################################################################################################
################## START
label start:
    stop music
    $ inventory.append(itm_shadow)
    if persistent.playthru:
        $ inventory.append(itm_loveletter)

    if persistent.playthru:
        $ seenstats_fp = True
        $ seenstats_lp = True

    ### DEBUG ONLY
    if debugtesting:
        jump debug

    ### RESET / NEW GAME
    elif persistent.reset:
        $ persistent.reset = False
        jump gaster_reset

    ### STARTING TENNA ROUTE
    else:
        jump tennastart