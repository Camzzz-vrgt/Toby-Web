############################################################################################################
################## DEBUG CHAPTER SELECT
### this is messy because it's just to navigate in game more easily

label debug:
    scene black
    if not persistent.mc:
        $ persistent.mc = "Vess"

    ######################################################
    ##### MAIN DEBUG MENU
    menu debug_menu:
        rq "debug menu"
        "test room":
            jump testroom
        "change things":
            jump debug_change
        "inventory":
            jump debug_inventory
        "tenna route":
            jump debug_tennaroute
        "spamton route":
            jump debug_spamtonroute
        "memoryshards":
            jump debug_memoryshards
        "next page":
            jump debug_menu2
        "return":
            return

    menu debug_menu2:
        rq "debug menu"
        "endings":
            jump debug_endings
        "legend of tenna":
            jump debug_lot
        "gaster shit":
            jump debug_gaster
        "mike date":
            scene black
            pause 2.0
            jump mikedate_preamble
            play ambiance wind
        "ex_interact":
            jump debug_interact
        "game over":
            jump gameover
        "prev page":
            jump debug_menu
        "return":
            return
    

    ######################################################
    ##### TENNA ROUTE
    menu debug_tennaroute:
        rq "tenna route"
        "tennastart":
            $ debugtesting_check = False
            jump tennastart
        "namecheck":
            menu:
                rq "yes name or no name"
                "no name":
                    $ persistent.mc = ""
                "yes name":
                    pass
            play music sponsors
            scene black
            show junkyard
            show quizboard at Position(xalign=0.5)
            show tenna upright chest neutral at tenpos_center
            pause 0.0
            jump namecheck
        "quizstart":
            play music sponsors
            scene black
            show junkyard
            show quizboard at Position(xalign=0.5)
            show tenna upright chest neutral at tenpos_center
            pause 0.0
            jump quizstart
        "postquiz":
            scene black
            show junkyard
            show quizboard at Position(xalign=0.5)
            show quizboard2 at dropin2
            show tenna upright card smile at tenpos_right
            pause 0.0
            jump postquiz
        "shop_nmt":
            scene black
            show junkyard
            show tenshop e_smile at center
            play music greenroom
            jump shop_nmt
        "next page":
            jump debug_tennaroute2
        "back":
            jump debug_menu

    menu debug_tennaroute2:
        rq "tenna route"
        "tennaend":
            scene black
            show junkyard
            show parkboard at dropin
            show tenna slouch claw angry at tenpos_center
            pause 0.0
            jump tennaend
        "parkstart":
            $ date_fp = ten.fp
            $ date_maxfp = ten.maxfp
            $ date_lp = ten.lp
            $ date_hb = ten.hb
            $ date_maxlp = ten.maxlp
            $ date_name = ten.char
            jump parkstart
        "prev page":
            jump debug_tennaroute
        "back":
            jump debug_menu


    ######################################################
    ##### LEGEND OF TENNA
    menu debug_lot:
        rq "legend of tenna"
        "park date":
            scene black
            show junkyard
            show parkboard at center
            show tenna upright chest neutral at tenpos_center
            pause 0.0
            jump lot_intro
        "mike":
            jump lot_mike
        "tv time 2":
            jump lot_tvtime2
        "back":
            jump debug_menu


    ######################################################
    ##### SPAMTON / WEIRD ROUTE
    menu debug_spamtonroute:
        rq "spamton route"
        "spamtonstart":
            jump spamtonstart
        "spamroutestart":
            jump spamroutestart
        "shop_spam":
            scene black
            show spamshop_bg2 zorder 0
            show spamshop_bg zorder 2
            show spamshop_glitch at Position(xpos=1650) zorder 1
            show spamshop_spamton e_neutral at left zorder 3
            play music dialtone
            jump shop_spam
        "spamdate_shop_preamble":
            scene black
            show spamshop_bg2 zorder 0
            show spamshop_bg zorder 2
            show spamshop_glitch at Position(xpos=1650) zorder 1
            show spamshop_spamton e_neutral at left zorder 3
            play music dialtone
            $ money = 1000
            jump spamdate_shop_preamble
        "spamdate_eye_preamble":
            scene black
            show spamshop_bg2 zorder 0
            show spamshop_bg zorder 2
            show spamshop_glitch at Position(xpos=1650) zorder 1
            show spamshop_spamton e_neutral at left zorder 3
            play music dialtone
            jump spamdate_eye_preamble
        "back":
            jump debug_menu


    ######################################################
    ##### CHANGE THINGS
    menu debug_change:
        rq "change things"
        "test for date lp/fp":
            "date_fp is [date_fp] and date_lp is [date_lp]{p=0}{noalt}*{/noalt} ten.fp is [ten.fp] and ten.lp is [ten.lp]"
            $ ten.fp = date_fp
            $ ten.lp = date_lp
            "AFTER CHANGE:{p=0}date_fp is [date_fp] and date_lp is [date_lp]{p=0}{noalt}*{/noalt} ten.fp is [ten.fp] and ten.lp is [ten.lp]"
            jump debug_change
        "check fp/lp":
            "date_fp: [date_fp] date_lp: [date_lp] // ten.fp: [ten.fp] ten.lp: [ten.lp] ten.hb: [ten.hb] // spam.fp: [spam.fp] spam.lp: [spam.lp] spam.hb: [spam.hb]\nmke.fp: [mke.fp] mke.lp: [mke.lp] mke.hb: [mke.hb]"
            jump debug_change
        "persistent delete":
            $ persistent._clear()
            $ persistent.mc = "Vess"
            "Persistent data cleared."
            jump debug_change
        "route":
            if persistent.route == "Tenna":
                $ persistent.route = "Spamton"
            else:
                $ persistent.route = "Tenna"
            "Route is now [persistent.route]"
            jump debug_change
        "quiz answers":
            menu:
                "persistent.here"
                "yes":
                    $ persistent.here = "yes"
                "no":
                    $ persistent.here = "no"
                "maybe":
                    $ persistent.here = "maybe"
                "where":
                    $ persistent.here = "where"
                "none":
                    $ persistent.here = None
            menu:
                "persistent.firstimpress"
                "handsome":
                    $ persistent.firstimpress = "handsome"
                "charming":
                    $ persistent.firstimpress = "charming"
                "nose":
                    $ persistent.firstimpress = "nose"
                "tall":
                    $ persistent.firstimpress = "tall"
                "none":
                    $ persistent.firstimpress = None
            menu:
                "persistent.favefood"
                "sweet":
                    menu:
                        "sweet"
                        "baked goods":
                            $ persistent.favefood = "baked goods"
                        "candy":
                            $ persistent.favefood = "candy"
                        "sweets":
                            $ persistent.favefood = "sweets"
                "salty":
                    menu:
                        "salty"
                        "fries":
                            $ persistent.favefood = "fries"
                        "pretzels":
                            $ persistent.favefood = "pretzels"
                        "salty foods":
                            $ persistent.favefood = "salty foods"
                "bitter":
                    menu:
                        "bitter"
                        "coffee":
                            $ persistent.favefood = "coffee"
                        "chocolate":
                            $ persistent.favefood = "chocolate"
                        "bitter foods":
                            $ persistent.favefood = "bitter foods"
                "anything":
                    $ persistent.favefood = "anything"
                "none":
                    $ persistent.favefood = None
            menu:
                "persistent.favecolor"
                "red":
                    $ persistent.favecolor = "red"
                "white":
                    $ persistent.favecolor = "white"
                "black":
                    $ persistent.favecolor = "black"
                "yellow":
                    $ persistent.favecolor = "yellow"
                "none":
                    $ persistent.favecolor = None
            menu:
                "persistent.programs"
                "cooking shows":
                    $ persistent.programs = "cooking shows"
                "music videos":
                    $ persistent.programs = "music videos"
                "anime":
                    $ persistent.programs = "anime"
                "romance shows":
                    $ persistent.programs = "romance shows"
                "none":
                    $ persistent.programs = None
            menu:
                "persistent.blood"
                "A":
                    $ persistent.blood = "A"
                "AB":
                    $ persistent.blood = "AB"
                "B":
                    $ persistent.blood = "B"
                "O":
                    $ persistent.blood = "O"
                "none":
                    $ persistent.blood = None
            menu:
                "persistent.selflove"
                "kindness":
                    $ persistent.selflove = "kindness"
                "passion":
                    $ persistent.selflove = "passion"
                "determination":
                    $ persistent.selflove = "determination"
                "hope":
                    $ persistent.selflove = "hope"
                "none":
                    $ persistent.selflove = None
            menu:
                "persistent.lovetv"
                "yes":
                    $ persistent.lovetv = True
                "no":
                    $ persistent.lovetv = False
            "data is changed."
            jump debug_change
        "back":
            jump debug_menu


    ######################################################
    ##### INVENTORY
    menu debug_inventory:
        rq "inventory"
        "add items":
            $ inventory.extend([itm_dvd, itm_flower, itm_pipis, itm_figlove, itm_redshard2, itm_greenshard2, itm_redshard1, itm_redshard3])
            "stuff has now been added"
            jump debug_inventory
        "add money":
            $ money += 100
            "D$100 added"
            jump debug_inventory
        "back":
            jump debug_menu


    ######################################################
    ##### MEMORYSHARDS
    menu debug_memoryshards:
        rq "memoryshards"
        "memoryshard tenna 1":
            jump memoryshard1
        "memoryshard tenna 2":
            jump memoryshard2
        "memoryshard tenna 3":
            jump memoryshard3
        "memoryshard spamton 1":
            jump memoryshard4
        "memoryshard spamton 2":
            jump memoryshard5
        "next page":
            jump debug_memoryshards2
        "return":
            jump debug_menu

    menu debug_memoryshards2:
        rq "memoryshards"
        "memoryshard spamton 3":
            jump memoryshard6
        "memoryshard tenna 4":
            jump memoryshard7
        "memoryshard spamton 4":
            jump memoryshard8
        "memoryshard gp/mike":
            jump memoryshard9
        "prev page":
            jump debug_memoryshards
        "return":
            jump debug_menu


    ######################################################
    ##### ENDINGS
    menu debug_endings:
        rq "endings"
        "tenna ending":
            play music dump
            scene tennahouse
            jump ending_tenna
        "spamton ending":
            jump ending_spamton
        "triple ending":
            jump secret_ending_triple
        "spamtenna ending":
            jump ending_spamtenna
        "battenna ending":
            jump secret_ending_battenna
        "mike ending":
            play music dump
            scene junkyard5
            show mike standing conflicted at mikepos_center
            jump secret_ending_mike
        "spamtat ending":
            jump secret_ending_spamtat
        "credits":
            menu:
                rq "which ending"
                "tenna":
                    $ end_tenna = True
                "spamton":
                    $ end_spamton = True
                "mike":
                    $ end_mike = True
                "spamtenna":
                    $ end_spamtenna = "done"
                "battenna":
                    $ end_battenna = "done"
                "spamtat":
                    $ end_spamtat = "done"
                "triple":
                    $ end_triple_mke = True
                    $ end_triple_spam = True
                    $ end_triple_ten = True
                "return":
                    jump debug_endings
            jump credits
        "return":
            jump debug_menu


    ######################################################
    ##### GASTER / EX_TESTING
    menu debug_gaster:
        rq "gaster shit"
        "neveruse":
            jump neveruse
        "return":
            jump debug_menu

    
    ######################################################
    ##### INTERACT
    menu debug_interact:
        rq "ex_interact"
        "mikeinteract":
            play music dump
            scene junkyard5
            jump mike_interact
        "return":
            jump debug_menu



############################################################################################################
################## TEST ROOM

label testroom:
    pause
    jump testroom