############################################################################################################
################## TRANSITIONS

######################################################
##### SPAMTON SHOP TRANSITION INSIDE/OUTSIDE
label trns_shop_spam:
    stop music
    hide screen ex_spamshop
    scene black
    play sfx dooropen
    pause 1.0
    play sfx doorclose
    pause 2.0
    show spamshop_bg2 zorder 0
    if persistent.glitches:
        show spamshop_glitchNo zorder 1:
            xpos 1460
    else:
        show spamshop_glitch zorder 1:
            xpos 1460
    show spamshop_bg zorder 2
    show spamshop_spamton e_neutral at left zorder 3
    play music dialtone
    $ quick_menu = True
    jump shop_spam

label trns_ex_spamshop:
    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    stop music
    scene black
    play sfx dooropen
    pause 1.0
    play sfx doorclose
    pause 2.0
    play music dump
    show junkspam
    jump ex_spamshop


######################################################
##### SPAMTON SHOP <> DIRT LUMP TRANSITION
label trns_spam_lump:
    hide screen ex_spamshop
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard3 with dissolve
    jump ex_lumproom

label trns_lump_spam:
    hide screen ex_lumproom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkspam with dissolve
    jump ex_spamshop


######################################################
##### SPAMTON SHOP <> NORTH SPAM SHOP
label trns_spam_north:
    hide screen ex_spamshop
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard2
    show dfountain at dfountain_pos
    with dissolve
    jump ex_north

label trns_north_spam:
    hide screen ex_north
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkspam with dissolve
    jump ex_spamshop


######################################################
##### GAME ROOM <> NORTH SPAM SHOP
label trns_game_north:
    hide screen ex_gameroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard2
    show dfountain at dfountain_pos
    with dissolve
    jump ex_north

label trns_north_game:
    hide screen ex_north
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard5 with dissolve
    jump ex_gameroom


######################################################
##### GAME ROOM <> MIKE ROOM
label trns_mike_game:
    hide screen ex_mikeroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard5 with dissolve
    jump ex_gameroom

label trns_game_mike:
    hide screen ex_gameroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    pause 2.0
    stop music fadeout 2.0
    pause 4.0
    jump mikedate_preamble


######################################################
##### DARKNESS HALLWAY <> NORTH SPAM SHOP
label trns_north_dark:
    hide screen ex_north
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    $ vex_darklocation = "north"
    jump ex_darkness 

label trns_dark_north:
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard2
    show dfountain at dfountain_pos
    with dissolve
    jump ex_north


######################################################
##### OG ROOM <> DARKNESS HALLWAY
label trns_dark_og:
    hide screen ex_ogroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard with dissolve
    jump ex_ogroom

label trns_og_dark:
    hide screen ex_ogroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    $ vex_darklocation = "og"
    jump ex_darkness


######################################################
##### TENNA'S HOUSE <> OG ROOM
label trns_ten_og:
    hide screen ex_tenhouse
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard with dissolve
    jump ex_ogroom

label trns_og_ten:
    hide screen ex_ogroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show tennahouse with dissolve
    jump ex_tenhouse


######################################################
##### MATTRESS ROOM <> NORTH SPAM SHOP
label trns_matt_north:
    hide screen ex_mattroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard2
    show dfountain at dfountain_pos
    with dissolve
    jump ex_north

label trns_north_matt:
    hide screen ex_north
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard4 with dissolve
    jump ex_mattroom


######################################################
##### MATTRESS ROOM <> DIRT LUMP
label trns_lump_matt:
    hide screen ex_lumproom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard4 with dissolve
    jump ex_mattroom

label trns_matt_lump:
    hide screen ex_mattroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard3 with dissolve
    jump ex_lumproom


######################################################
##### MATTRESS ROOM <> STARWALKER ROOM
label trns_star_matt:
    hide screen ex_starroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard4 with dissolve
    jump ex_mattroom

label trns_matt_star:
    hide screen ex_mattroom
    play sfx waterwalk
    scene black with dissolve
    pause 2.0
    stop sfx fadeout 1.0
    show junkyard6 with dissolve
    jump ex_starroom