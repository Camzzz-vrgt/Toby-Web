############################################################################################################
################## TENNA AND SPAMTON
label ending_spamtenna:
    $ currentend = "spamtenna"

    ## AUTOSAVE
    $ renpy.save("mainfile")

    scene junkyard with Dissolve(2.0)
    pause 1.0
    show spamton standing up frown at spampos_right zorder 1 with easeinright
    spamton "WHERE {noalt}IS{/noalt}{alt}is{/alt} [[Boob Tube] SUPPOSED TO BE AGAIN?"
    "You remind Spamton that you asked Tenna to wait for you around here."
    show spamton standing up glaree at jump
    pause 1.0
    show spamton at spampos_inleft with ease
    pause 0.5
    show spamton standing up glare flipped at jump
    pause 1.0
    show spamton standing up frown flipped
    pause 1.0
    spamton "HUH,.{p=0.5}{noalt}*{/noalt} I'LL BE [[sentenced to forty thousand years in {noalt}h31L],{/noalt}{alt}beep{/alt}"
    play music heyevery
    show spamton standing tilt laugh flipped at jump
    spamton "WOAH HEY, [persistent.mc!u] ?{p=0.5}{noalt}*{/noalt} YOU ACTUALLY FOUND HIS HAPPY [[plasstic {noalt}@$$]{/noalt}{alt}beep{/alt} OVER HERE???"
    show spamton standing up smile flipped
    show tenna upright chest blank at tenpos_inright with easeinright
    pause 0.5
    show tenna panic panic at jump
    $ multichar = True
    $ _history = False
    tenna "What the--{nw=0.2}"
    $ _history = True
    stop music
    play sfx beepSh
    if persistent.glitches:
        show tenna panic smpte at jump
    else:
        show tenna panic smpte at shock 
    tenna_shh "What the--{fast}{p=0}{noalt}*{/noalt} EEEEEEICK--!!"
    show tenna panic panic flipped at wiggle
    tenna "Wh-{w=0.1} what the in WORLD are you showing me,{w=0.2} [persistent.mc]?!"
    show tenna upright chest angry
    tenna "Why would you think I'd want to see {noalt}hi--{/noalt}{alt}him{/alt} THIS{w=0.5} ugly--{w=0.2} creature--{w=0.5} THING?"
    show spamton standing up frown flipped
    spamton_shh ".{w=0.2}.{w=0.2}."
    show spamton standing up frowne flipped at jump
    spamton "[[Trash Heap],{w=0.2} DON'T YOU RECOGNIZE\n[[the {noalt}E_MAIL{/noalt}{alt}e-mail{/alt} guy]?"
    show tenna panic panic at jump
    tenna "{cps=60}Oh goodness gracious why does he TALK like THAT?!{/cps}"
    $ multichar = False
    "You interrupt to tell Tenna that this is Spamton."
    $ multichar = True
    show tenna upright back nose at jump
    pause 3.0
    show tenna upright back nosed at droop
    tenna "There's no way."
    tenna "You're not...{nw=0.5}"
    show tenna stretch shrug smile flipped at jump
    extend "{p=0}{noalt}*{/noalt} There's JUST no way,{w=0.2} haha!!"
    if persistent.glitches:
        show tenna stretch shrug weak flipped
    else:
        show tenna stretch shrug weak flipped at shaking
    tenna "I KNOW that spammy mailman,{w=0.2} and--{nw=0.1}"
    show tenna at yreset
    if persistent.glitches:
        show spamton slouch down panic flipped
    else:
        show spamton slouch down panic flipped at shakingcg
    spamton "DON'T [[call me] THAt."
    show tenna slouch panic static at droop
    tenna "Augh--{w=0.2} what happened with your VOICE?{p=0.5}{noalt}*{/noalt} My poor antennae are going to need a massage after this..."
    show spamton crazy frantic flipped
    spamton "OH {noalt}[[$#!$]{/noalt}{alt}beep{/alt} YOU!!{p=0.5}{noalt}*{/noalt} WHY {noalt}DONn'T YOoU{/noalt}{alt}don't you{/alt} JUST [[[[In desperate need of a repair?]]{noalt},,{/noalt} YOU [[broken, unwanted appliances] !!!!"
    show tenna slouch claw panic at jump
    tenna "Th-{w=0.1} the f--?!{nw=0.1}"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    extend " HEY!{p=0.5}{noalt}*{/noalt} Who are YOU to berate me to my face like that?!"
    show tenna upright chest angry at rise
    tenna "[persistent.mc].{w=0.5} There must be some kind of mistake.{p=0.5}{noalt}*{/noalt} This just CAN'T be him."
    if persistent.glitches:
        show spamton standing tilt laugh flipped at yreset
    else:
        show spamton standing tilt laugh flipped glitch at yreset
    spamton "NOPE.{w=0.5} {noalt}IT'S{/noalt}{alt}it's{/alt} [[Right on the money]."
    if persistent.glitches:
        show spamton standing tilt stare flipped
    else:
        show spamton standing tilt stare flipped glitch
    $ _history = False
    spamton "[[[[Number One Rated Salesman 1997]] IN THE [[lack thereof] FLESh,{p=0.5}{noalt}*{/noalt} {noalt}SPAMTONnnnnnnnn{/noalt}{alt}spamtonnnnnnnn{/alt}{nw=0.1}"
    $ _history = True
    spamton "[[[[Number One Rated Salesman 1997]] IN THE [[lack thereof] FLESh,{p=0}{noalt}*{/noalt} {fast}SPAMTON G. SPAMTON!"
    show tenna upright chest panic at jump
    tenna "Are you two trying to make fun of me or something?{p=0.5}{noalt}*{/noalt} I'm not THAT dense,{w=0.2} you know!!"
    show spamton crazy smirk
    spamton "APPARENTLY YOU ARE{p=0.5}{noalt}*{/noalt} NOT THAT THAT'S [[New Deals Incoming] OR ANYTHING."
    show tenna at rise
    $ _history = False
    tenna "Wha--{nw=0.5}"
    show tenna upright back angry flipped at jump
    extend "{p=0}{noalt}*{/noalt} Okay.{w=0.2} Okay.{nw=0.8}"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    extend " What the {nw}"
    play sfx beepSh
    tenna_shh "Wha--\n{noalt}*{/noalt} Okay. Okay. What the{fast} {noalt}$#!${/noalt}{nw=0.1}"
    $ _history = True
    tenna "Wha--\n{noalt}*{/noalt} Okay. Okay. What the {noalt}$#!${/noalt}{fast} is going on?"
    show spamton standing up glaree flipped at jump
    spamton "[[desperate little] OVER HERE THOUGHT {noalt}IT{/noalt}{alt}it{/alt} WOULD BE A [[Grand ol' times] TO {noalt}[[Reunion_Episode] US.{/noalt}{alt}reunion episode us{/alt}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    tenna "It's not a \"REUNION EPISODE\" if I DON'T KNOW WHO YOU ARE!?"
    if persistent.glitches:
        show spamton crazy frantic flipped
    else:
        show spamton crazy frantic flipped at shakingcg
    spamton "YOU NEED PROOF ?"
    show spamton standing up stare flipped
    spamton "[persistent.mc!u].{w=0.2} GIMMIE."
    play sfx plop
    show spamton at jump
    $ inventory.remove(itm_ring)
    $ multichar = False
    "You didn't know what Spamton meant,{w=0.2} but before you could ask,{w=0.2} he was already ripping the ring off of your finger and handing it to Tenna."
    $ multichar = True
    show tenna upright chest angry
    show spamton crazy frantic at jump
    spamton "CHECK THE [[InsideInformation]."
    show tenna upright chest frown at jump
    $ multichar = False
    "Tenna did as asked,{w=0.2} peering at the inside of the ring's band..."
    show tenna upright chest blank
    pause 2.0
    show tenna upright back nose
    pause 2.0
    play sfx click
    show tenna upright back nose flipped at jump
    pause 1.0
    "Tenna threw the ring into the dirt."
    $ multichar = True
    pause 1.0
    play music nowsyourchance
    show tenna at droop
    tenna "So,{w=0.2} what?{p=0.5}{noalt}*{/noalt} You want me to believe because you have THAT,{w=0.2} now you're suddenly him?"
    show spamton crazy angry flipped at jump
    spamton "I ONLY GOT [[it's one-of-a-kind].{p=0.5}{noalt}*{/noalt} YOU SHOULD KNOW [[this much, please!]."
    show spamton crazy frantic at jump
    spamton "I TOLD YOU WHEN YOu RUINEED THE [[ten_surprise.wav]"
    show tenna upright back nosed
    tenna "Th...{w=0.2} that's..."
    show tenna at wiggle
    tenna "Th-{w=0.1} that's--!"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "Okay,{w=0.2} FINE!{w=0.5} So WHAT if you ARE him?!{p=0.5}{noalt}*{/noalt} What do you care,{w=0.2} huh?!"
    show tenna upright chest angry at rise
    tenna "Why would I EVER want to see YOUR face again after everything you did to me!"
    if persistent.glitches:
        show spamton standing tilt laugh flipped
    else:
        show spamton standing tilt laugh flipped glitch
    spamton "EHAHEH!!{w=0.2} ME??{p=0.5}{noalt}*{/noalt} [[You did this] TO YOU!!"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "I did NOT!{p=0.5}{noalt}*{/noalt} I tried SO HARD to keep things in order after SOMEBODY up and disappeared!!"
    show tenna upright chest panic at rise
    tenna "It's actually a miracle I'm in the good-enough condition that I am--{w=0.2} unlike YOU!"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "You look so goddamn awful that you're UNRECOGNIZABLE!"
    show spamton slouch down panic flipped at shakingcg
    spamton "YOU HAD [[luxurious, spacious homes] TO LIVE IN,{p=0.5}{noalt}*{/noalt} I HAD THE [[luxurious, spacious] GARBAGE!!"
    show spamton standing tilt laugh at jump
    spamton "BUT HEY !{nw=0.5}"
    if persistent.glitches:
        show spamton standing up stare flipped
    else:
        show spamton standing up stare flipped at shakingcg
    extend "{p=0}{noalt}*{/noalt} AT LEAST I'M STILL [[The classics you know and love] HEIGHT."
    show tenna panic panic
    tenna "A-{nw=0.1}"
    show tenna at jump
    extend " are you calling me SHORT?"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "How DARE you!{w=0.2} It's not MY FAULT!"
    show tenna upright chest angry at rise
    tenna "I nearly DIED,{w=0.2} you SMARMY LITTLE RAT!"
    show tenna at wiggle
    tenna "Maybe you'd ALREADY KNOW if you didn't RUN AWAY like the little freak you are!"
    show spamton crazy laugh at jump
    spamton "{noalt}EHAHHahHAH!!{/noalt}{alt}eahaehahehhaha{/alt}{p=0.5}{noalt}*{/noalt} ARE YOU [[for real?] RIGHT NOW?!?!"
    if persistent.glitches:
        show spamton standing up stare flipped
    else:
        show spamton standing up stare flipped at shakingcg
    spamton "[[Trash Heap].{p=0.5}{noalt}*{/noalt} YOU SHOULD HAVE BEEN [[Killed] AGES AGO!!"
    show spamton crazy smirk
    spamton "IT'S A [[Tragic] THAT YOU {noalt}AREN''t{/noalt}{alt}aren't{/alt}"
    show tenna stretch shrug smile at jump
    tenna "Oh!{w=0.2} Well aren't you the{nw}"
    play sfx ten_aww
    extend " {image=txt_charmer}{alt}charmer{/alt} {w=0.5}for this{nw}"
    if persistent.glitches:
        show tenna slouch claw angry at jump
        play sfx ten_rock
        extend "{p=0}{image=txt_heartwarmingG}{alt}HEARTWARMING REUNION?!{/alt}"
        show tenna upright chest angry
    else:
        show tenna slouch claw angry at shock
        play sfx ten_rock
        extend "{p=0}{image=txt_heartwarming}{alt}HEARTWARMING REUNION?!{/alt}"
        show tenna upright chest angry at shaking
    tenna "What do you even care what I'm doing?!{w=0.2} YOU'RE the one who left ME BEHIND!"
    if persistent.glitches:
        show spamton standing tilt laugh flipped at jump
    else:
        show spamton standing tilt laugh flipped glitch at jump
    spamton "[[Coming straight from] THE [[[[CRIMINAL]] WHO GOT ME [[[[It Burns! Ow! Stop!]]"
    show tenna slouch claw panic at droop
    tenna "What are you TALKING about?{p=0.5}{noalt}*{/noalt} Are you trying to say {color=#FDFF38}I{/color} made you this way?!"
    show spamton crazy laugh at jump
    spamton "YOU SAID BE [[Honest]"
    show tenna upright chest angry at rise
    tenna "Oh--{w=0.2} OH!!{p=0.5}{noalt}*{/noalt} Why you little--"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "THAT'S {noalt}IT!{/noalt}{alt}it!{/alt}{w=0.2} I'm done here.{p=0.2}{noalt}*{/noalt} I'm moving on."
    show tenna upright chest angry flipped
    if persistent.glitches:
        show spamton standing tilt laugh flipped at jump
    else:
        show spamton standing tilt laugh flipped glitch at shock
    play sfx spamlaugh
    $ _history = False
    spamton_shh "[[[[Unintelligible Laughter]]{nw=0.2}"
    $ _history = True
    show spamton crazy frantic at xwiggle
    spamton "[[[[Unintelligible Laughter]]{fast}{p=0}{noalt}*{/noalt} YOU??????????????{p=0.2}{noalt}*{/noalt} MOVE ON???????????"
    if persistent.glitches:
        show spamton crazy laugh
    else:
        show spamton crazy laugh glitch
    spamton "YOU'RE SO STUCK IN [[The past] THAT YOU DON'T EVEN KNOW WHAT [[The now] {noalt}IS{/noalt}{alt}is{/alt}!!!!!!!"
    show tenna upright chest angry at jump
    tenna "You trying to imply that you want ANYTHING to do with me?!"
    show spamton standing up frown flipped at yreset
    spamton "..."
    pause 1.0
    show spamton standing up frown at jump
    spamton "DO YOU CARE [[or not]?"
    show tenna upright chest panic at jump
    tenna "What?"
    show spamton standing up glare
    spamton "I'M NOT REPEATING MYSELF."
    show tenna upright chest blank
    tenna "..."
    pause 1.0
    show tenna upright chest confused at rise
    tenna "I{w=0.2}.{w=0.2}.{w=0.2}."
    pause 2.0
    show tenna upright back frown at droop
    tenna "No."
    tenna "I don't."
    show spamton standing up frown
    spamton "[[Honest] ?"
    show tenna upright chest angry at rise
    tenna "YES,{w=0.2} I'm being HONEST!"
    show tenna slouch claw angry at wiggle
    tenna "How about YOU try that for once,{w=0.2} since you're so ALLERGIC to it that you couldn't trust me with ANYTHING!"
    show spamton crazy laugh at xwiggle
    spamton "HEAHAHA!!!{p=0.5}{noalt}*{/noalt} [[Cathode]."
    if persistent.glitches:
        show spamton standing up frowne flipped
    else:
        show spamton standing up frowne flipped at shakingcg
    spamton "YOU DON'T KNOW THE [[Half-off sale] OF {noalt}IT{/noalt}{alt}it{/alt}."
    show tenna upright chest angry at rise
    tenna "What?! Auugh--{w=0.2} I COULD HAVE!"
    if persistent.glitches:
        show tenna slouch claw angry
        tenna "IF YOU HAD JUST SAID.{w=0.1} ANYTHING!" 
        show spamton slouch down panic flipped
    else:
        show tenna slouch claw angry at shaking
        tenna "IF YOU HAD JUST {sc=3}SAID.{w=0.1} ANYTHING!{/sc}" # SELF VOICING FIX
        show spamton slouch down panic flipped glitch
    spamton "YOU [[Act] LIKE [[It's just that easy!]"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    tenna "{noalt}IT{/noalt}{alt}it{/alt} {noalt}IS{/noalt}{alt}is{/alt}, YOU--{w=0.5} UGHHHHHHHHHHHHHH{nw}"
    show tenna at leanleftQ
    tenna "GET OVER HERE!!{p=0.2}{noalt}*{/noalt} I'LL TEAR YOU APART WITH MY BARE HANDS!!!"
    show spamton standing tilt laugh flipped at jump
    spamton "I'D LIKE TO SEE YOU [[Try me.]"
    show tenna upright chest panic at jump
    show spamton standing up frowne flipped at jump
    play sfx plop
    stop music
    $ multichar = False
    "You hastily step between them before they rip each other's throats out."
    $ multichar = True
    show tenna panic panic at jump
    tenna "Wh--{w=0.2} [persistent.mc]!{nw=0.2}"
    show tenna at leanrightL
    extend "{p=0}{noalt}*{/noalt} I-{w=0.1} I...{w=0.2} nearly forgot you were here,{w=0.2} haha...!"
    show spamton crazy smirk at xwiggle
    spamton "TOO [[[[blinded by the]] YOUR OBSESSIVE [[Hatred] FOr ME??"
    show tenna upright chest awkward at jump
    tenna "Is that some freakshow kind of flirting?!"
    show spamton panic up scream at jump
    spamton "WHY {noalt}IS{/noalt}{alt}is{/alt} [[*that*] YOUR FIRST THOUGHT???"
    show tenna slouch claw panic at droop
    tenna "I--{nw=0.5}"
    show tenna panic flustered at jump
    extend " D-{w=0.1} don't think that deep into it!!"
    show spamton standing up frown flipped
    spamton "WHATEVER."
    show spamton standing up frown
    show tenna upright chest panic
    spamton "I'M {noalt}[[Leave.]ING{/noalt}{alt}leaving{/alt}"
    show spamton:
        xoffset -50
    with MoveTransition(0.5, time_warp=_warper.ease)
    show tenna upright back confused at leanleftL
    tenna "Wait.{w=0.2} Can I--{nw=0.2}"
    show spamton slouch down frown flipped at jump
    spamton "WHY ARE YOU STILL TALKING"
    pause 1.0
    show tenna upright chest frown 
    tenna "I just...{w=0.5} want some closure.{w=0.5} Now that you're here."
    show tenna at droop
    tenna "Don't you?"
    show spamton standing down frown
    spamton "..."
    pause 1.0
    play music glowingsnow
    show tenna upright back frown at jump
    tenna "Can {color=#FDFF38}I{/color} be honest for a second?"
    pause 1.0
    show spamton standing down frown flipped at jump
    pause 1.0
    show tenna upright back nose
    tenna "I didn't care much about you.{p=0.5}{noalt}*{/noalt} For a very long time."
    show tenna at droop
    tenna "There was a point where I...{w=0.5} STARTED to care.{p=0.5}{noalt}*{/noalt} But by then it was too late."
    show tenna upright back nosed
    tenna "I fought myself on that constantly.{w=0.5} I still do..."
    show tenna slouch panic panic
    tenna "I was using you for my own benefit, after all.{p=0.5}{noalt}*{/noalt} I didn't deserve the love you wanted to offer me."
    show tenna upright back panic at rise
    tenna "That's why I came up with that deal,{w=0.2} y'know?{p=0.5}{noalt}*{/noalt} Haha..."
    show spamton slouch down frown flipped
    show tenna stretch shrug smile flipped at jump
    tenna "I thought it might even the playing field a bit...{p=0.5}{noalt}*{/noalt} But it...{w=0.5} really wasn't going to ACTUALLY make up for anything."
    show tenna stretch shrug weak flipped
    tenna "It was selfish.{p=0.5}{noalt}*{/noalt} I didn't think it through at all..."
    show tenna at droop
    tenna "It wasn't the--{nw=0.2}"
    show spamton standing down static flipped
    spamton "[[fuzzface] SHUT UP FOR A SECOND."
    show tenna upright back panic at jump
    tenna "{noalt}--?!{/noalt}{alt}huh?{/alt}"
    show spamton standing down panic flipped at jump
    spamton "YOU'RE A PIECE OF {noalt}[[$#!X]{/noalt}{alt}beep{/alt}.{p=0.5}{noalt}*{/noalt} THAaT'S NO LIE."
    show spamton slouch down static flipped
    spamton "BUT I [[used] YOU [[2]."
    show tenna slouch claw panic at droop
    tenna "What?{w=0.2} HOW?"
    show spamton slouch down smile flipped
    spamton "YOU WERE [[Desperate] TO PUT ME ON\n[[[[Mr. \"Ant\" Tenna's TV Time!]],{p=0.2}{noalt}*{/noalt} SO I TOOK THAT [[new job openings]"
    show spamton standing down panic flipped at rise
    spamton "THAT WAY I COULD BE A [[proper manners] [[[[ Big Shot ]] [[No Strings Attached!]"
    show tenna at rise
    tenna "Th...{w=0.2} huh?"
    show tenna upright chest confused at jump
    tenna "We only met after you were ALREADY famous!{p=0.5}{noalt}*{/noalt} You were an overnight success story!!"
    show tenna upright chest angry flipped at jump
    tenna "And it pissed me off SO much that when you had the GALL to INTRODUCE YOURSELF to ME,{w=0.5} I--{nw=0.2}"
    show spamton standing up frown flipped at xwiggle
    spamton "EARTH TO [[Static Picture] ???"
    show spamton at yreset
    show tenna upright chest panic at jump
    pause 2.0
    show tenna upright back nose at droop
    tenna "...{w=0.5} Go on."
    pause 1.0
    show spamton standing up glaree flipped
    spamton "YIKES."
    show spamton standing tilt laugh flipped
    spamton "MAYBE [[your too too] HONEST NOW."
    show tenna stretch shrug weak at wiggle
    tenna "Yeah, well,{w=0.2} over a DECADE of repeated abandonment can really get to someone,{w=0.2} {noalt}HA HA{/noalt}{alt}haha{/alt}!"
    show spamton standing up glaree flipped
    spamton "THE [[dramatic irony]."
    show tenna upright back frown at jump
    tenna "Oh, forget it.{p=0.2}{noalt}*{/noalt} What were you saying?"
    show spamton crazy angry at xwiggle
    spamton "{noalt}IT{/noalt}{alt}it{/alt} DOESN'T MATTER ANYWAy."
    show spamton slouch down static at yreset
    spamton "I CAn'T {noalt}exxPLAIN{/noalt}{alt}explain{/alt} [[Too Much Work Weighing You Down?]."
    show tenna upright back nose at jump
    pause 2.0
    show tenna upright back angry flipped at jump
    tenna "Of course not.{p=0.5}{noalt}*{/noalt} You never can."
    show tenna stretch shrug smile flipped
    tenna "I don't know why I expected to get \"closure\" from someone as closed-OFF as YOU!"
    show spamton at droop
    spamton "YOU {noalt}DONn''T [[comprehende?] [[Cathode],,{/noalt}{alt}don't compre henday? cathode"
    show tenna slouch claw panic at jump
    tenna "Of course I don't {noalt}\"comprende\"{/noalt}{alt}com prenday{/alt}!{w=0.2} Why would I?!"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    tenna "You've never explained a DAMN thing ONCE!"
    show tenna upright pointing weak
    tenna "Please.{p=0.5}{noalt}*{/noalt} Please just tell me SOMETHING so I can MOVE ON!"
    if persistent.glitches:
        show spamton slouch down panic flipped
        spamton "I {noalt}C4NnN''T SAy [[$#!T$]!!1!{/noalt}{alt}can't say beep!{/alt}"
    else:
        show spamton slouch down panic flipped glitch at shakingcg
        spamton "{sc=3}I C4NnN''T SAy {/sc}[[{sc=3}$#!T${/sc}]{sc=3}!!1!{/sc}" # SELF VOICING FIX
    show tenna slouch claw panic at droop
    if persistent.glitches:
        show spamton standing tilt stare flipped
    else:
        show spamton standing tilt stare flipped glitch at yreset
    spamton "{noalt}I ALl<RAedY HAD[[] A [[[[bad deals]] WIT H{space=40}S OME[[1] ELs3!{/noalt}{alt}I already had a [[bad deals] with someone else!{/alt}"
    show spamton slouch down static flipped at xwiggle
    spamton "{noalt}THATt{/noalt}{alt}that{/alt} [[last time offer] PHoNE {noalt}C4All [[Call]ED IT{/noalt}{alt}call called it{/alt} [[[[ Connection Lost ]]"
    if persistent.glitches:
        show spamton crazy angry flipped
        spamton "{noalt}BEC A USEe OF TH3 StuP1Dd!!{/noalt}{alt}because of the stupid{/alt}{w=0.1} BULL[[feces] !!!{w=0.2} THAT [[[[ you ]] MADE ME [[JohnHandcock]!!!"
        show spamton slouch down static at yreset
        spamton "I {noalt}WAAantED{/noalt}{alt}wanted{/alt} TO [[Trust] YOU."
        show spamton slouch down smile
        spamton "[[Wich] WAS MY OWN {noalt}[[$&!#In]G{/noalt}{alt}beeping{/alt} FAULT !!!"
        show spamton slouch down static
    else:
        show spamton crazy angry flipped glitch
        spamton "{noalt}BEC A USEe OF TH3 StuP1Dd!!{/noalt}{alt}because of the stupid{/alt}{w=0.1} BULL[[feces] !!!{w=0.2} THAT [[[[ you ]] MADE ME [[JohnHandcock]!!!"
        show spamton slouch down static glitch at yreset
        spamton "I {noalt}WAAantED{/noalt}{alt}wanted{/alt} TO [[Trust] YOU."
        show spamton slouch down smile glitch
        spamton "[[Wich] WAS MY OWN {noalt}[[$&!#In]G{/noalt}{alt}beeping{/alt} FAULT !!!"
        show spamton slouch down static glitch
    show tenna upright back nose
    pause 2.0
    show tenna upright back nosed
    tenna "So..."
    tenna "What?"
    show tenna upright back nosed flipped at jump
    tenna "I'm just supposed to feel bad that you left without saying anything because you \"couldn't\"?"
    show tenna upright chest confused at wiggle
    tenna "I would have HELPED,{w=0.2} you know!{w=0.5} If you had said LITERALLY ANYTHING AT ALL!"
    show spamton slouch down frown flipped at jump
    spamton "I TrIED [[Someone Is Calling] YOU."
    if persistent.glitches:
        show tenna upright pointing weak
        tenna "WHEN?" # SELF VOICING FIX
    else:
        show tenna upright pointing weak at shaking
        tenna "{sc=3}WHEN?{/sc}" # SELF VOICING FIX
    show spamton slouch down panic flipped
    $ _history = False
    spamton "A{nw=0.1}"
    spamton "AFT{nw=0.1}"
    $ _history = True
    spamton "AFTER.{p=0.5}{noalt}*{/noalt} [[1-Day Shipping] AFTER."
    show tenna upright back nose at droop
    tenna "Oh, please.{w=0.5} Now you're just lying."
    show spamton standing down panic flipped
    spamton "YOu CHANGED YOUR [[credit card numbers] !!"
    show tenna slouch panic panic at rise
    tenna "What does my credit card have to do with this?{p=0.5}{noalt}*{/noalt} Did you try to ROB me, too?"
    show spamton standing down frown flipped at xwiggle
    spamton "{noalt}N,nNO!{/noalt}{alt}nnno!{/alt}{p=0.5}{noalt}*{/noalt} YOUR [[Ring... Ring...] [[Fun with Numbers]!!"
    show tenna upright chest angry at jump
    tenna "My PHONE number?"
    show spamton crazy angry
    if persistent.glitches:
        spamton "I [[tried and tried and tried and tried and]\n {noalt}N0THiNG{/noalt}{alt}nothing{/alt}!!"
    else:
        spamton "I [[tried and tried and tried and tried and]\n{sc=3}N0THiNG!!{/sc}" # SELF VOICING FIX
    show tenna upright chest blank
    show spamton standing down frown flipped at jump
    spamton "JUST [[[[We're sorry. The number you have dialed is not available at this time.]] ON [[loop-de-loop] LIKE A [[New Record!]"
    spamton "YOU REALLY [[don't care],{w=0.5} DO YOU?"
    if persistent.glitches:
        show spamton crazy frantic flipped
    else:
        show spamton crazy frantic flipped at shakingcg
    spamton "YOU [[wahh! wahh!] LIKE I [[fled the scene] YOU FOoR {noalt}DE4AD dd{/noalt}{alt}dead{/alt} BUT!!{w=0.2} YOU [[cut it off already!] WITHOUT EVEN [[tryeing]!!!"
    show tenna upright chest panic at rise
    tenna "You think that I'M the one who--{nw=0.2}"
    if persistent.glitches:
        show spamton slouch down panic flipped at jump
    else:
        show spamton slouch down panic flipped glitch at shock
    spamton "YOU {noalt}DIDNNn''T{/noalt}{alt}didn't{/alt} EVEN [[Follow Me]!!"
    show tenna upright back confused at shrink
    tenna "..."
    show spamton standing up frown at jump
    spamton "YOU SAID {noalt}IT{/noalt}{alt}it{/alt} YOURSELF.{p=0.5}{noalt}*{/noalt} YOU NEVER [[[[REALLY cared.]]"
    show tenna upright back frown at shrinks
    tenna "..."
    pause 2.0
    show tenna upright back nosed flipped at jump
    tenna "Are you happy now?"
    tenna "Happy you got all that shit off your chest and threw it right in my face?"
    show spamton standing up glare flipped at jump
    spamton "YOU [[lit-errally] ASKED FOR {noalt}IT{/noalt}{alt}it{/alt}."
    show tenna at wiggle
    tenna "I didn't ask you to INSULT me."
    if persistent.glitches:
        show spamton crazy frantic
    else:
        show spamton crazy frantic glitch at shakingcg
    spamton "HOW [[Do you ever think about] {noalt}IT{/noalt}{alt}it{/alt} FEELS BEING TOLD YOU WERE A [[used] [[puppet on a string],{w=0.2} YOU RADIOACTIVE [[[[ Light ]]BULB ?!?!"
    show tenna slouch claw angry at zreset
    tenna "You JUST said you used me, too,{w=0.2} don't even START with this!!"
    $ multichar = False
    "You tried to step into the situation..."
    menu:
        rq "(You tried to step into the situation...)"
        "This isn't solving anything.":
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You tell them this back-and-forth is pointless."
            $ multichar = True
            show tenna panic panic at shrink
            tenna "I...!"
            show spamton standing up glaree flipped at jump
            spamton "I DON'T REaLLY CARE."
            show spamton crazy laugh at xwiggle
            spamton "WHAT {noalt}IS{/noalt}{alt}is{/alt} [[The Point] ANYWAY?{p=0.5}{noalt}*{/noalt} [[The End] {noalt}IS{/noalt}{alt}is{/alt} ALWAYS THE SAME."
            spamton "THIS {noalt}IS [[h3ll].{/noalt}{alt}is hell.{/alt}{p=0.5}{noalt}*{/noalt} MIGHT AS WELL DO [[whatever]"
            show tenna upright chest angry at zreset
            tenna "So you choose to insult me?!"
            show spamton standing up glare flipped at jump
            spamton "AS IF YOU WEREN'T [[insult me]?????"
            show tenna upright chest panic at jump
            tenna "Th...{nw=0.2}"
            show tenna at shrink
            extend " th-{w=0.1} that's..."
            show tenna upright pointing oh at jump
            tenna "Y-{w=0.1} you started it!"
            show spamton standing tilt laugh flipped at xwiggle
            spamton "OH SO WE'RE PLAYING THAT [[Game, Game!] NOW?"
            show spamton crazy laugh at jump
            spamton "YIKES [[Boob Tube] YOU'RE WORSE THAN I THOUGHT"
            show tenna upright pointing weak at wiggle
            tenna "H-{w=0.1} hey,{w=0.2} c'mon!"

        "Can't you try to say something nice?":
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You suggest one of them try to say something nice about the other for once."
            $ multichar = True
            show tenna upright chest panic at shrink
            show spamton standing up stare flipped at yreset
            spamton_shh "..."
            if persistent.glitches:
                show spamton crazy laugh at jump
            else:
                show spamton crazy laugh at shock
            spamton "EAHAEHAHEH!!{w=0.5} LIKE WHAT???"
            show spamton standing tilt laugh flipped
            spamton "NOT REALLY MUCH [[golden star sticker] TO SAY ABOUT A [[Hunk of Junk] !"
            show tenna upright chest angry at wiggle
            tenna "R-{w=0.1} rude!{w=0.5} I could find something nice to say about you!"
            show spamton standing up smile flipped at jump
            spamton "THEN [[do it, you {noalt}wont]{/noalt}{alt}won't{/alt} ??"
            show tenna upright back frown at jump
            tenna "I..."
            pause 1.0
            show tenna upright pointing oh
            tenna "I...{w=0.5} think you have a nice smile."
            show spamton standing up frown flipped
            pause 2.0
            show tenna upright back panic at shrinks
            tenna "...{w=0.2} um.{nw=0.5}"
            show tenna at wiggle
            extend "{p=0}{noalt}*{/noalt} Haha,{w=0.2} well..."
            show spamton standing tilt laugh flipped at jump
            spamton "[[Cathode] ARE YOU EVEN LOOKING [[@] MY {noalt}[[X#@*]ING{/noalt}{alt}beeping{/alt} FACE RIGHT NOW??"
            show tenna upright back awkward at jump
            tenna "Y-{w=0.1} yes?!"
            show spamton standing up frowne flipped
            spamton "OH [[Heavens Above] YOU REALLY ARE."
            show spamton crazy frantic flipped at jump
            spamton "YOU HAVE [[Top 10 Worst ] TASTE THAN I THOUGHT."
            if persistent.glitches:
                show tenna panic flustered at jump
            else:
                show tenna panic flustered at shock
            tenna "What's that supposed to mean?!"
    
    $ multichar = False
    "You try to think of something else to calm them down..."
    menu:
        rq "(You try to think of something else to calm them down...)"
        "We might be stuck here for a while.":
            $ sptn_stuck = True
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You remind them that you guys might be stuck here,{w=0.2} so maybe they could try to get along."
            $ multichar = True
            show tenna upright pointing smile at jump
            tenna "Pfft, haha,{w=0.2} [persistent.mc]!{w=0.5} Don't be such a Debbie Downer.{p=0.5}{noalt}*{/noalt} We won't be stuck here FOREVER..."
            show tenna stretch shrug smile at jump
            tenna "Someone will come looking for us eventually!{p=0.5}{noalt}*{/noalt} I mean,{w=0.2} YOU showed up, after all."
            tenna "Anything could happen!"
            if persistent.glitches:
                show spamton standing tilt laugh flipped
            else:              
                show spamton standing tilt laugh flipped glitch
            spamton "IN YOUR [[dreams] [[Trash Heap]"
            show spamton standing up frown flipped at jump
            spamton "ONLY PLACE WE GO FROM HERE {noalt}IS{/noalt}{alt}is{/alt} THE [[[[ endless void ]]"
            show tenna panic panic at jump
            tenna "Yikes!{p=0.5}{noalt}*{/noalt} Ahah...{w=0.2} Maybe YOU'RE more of the Debbie Downer."
            show spamton slouch down static flipped at droop
            spamton "IT'S JUST [[[[ the Truth ]]."
            if persistent.glitches:
                show spamton slouch down static flipped
            else:
                show spamton slouch down static flipped glitch
            spamton "[persistent.mc!u] {noalt}IS{/noalt}{alt}is{/alt} RIGHT.{p=0.5}{noalt}*{/noalt} WE'RE [[stuck in the] HERE"

        "We don't have to make this more miserable.":
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You tell them that arguing is just going to make the situation more miserable."
            $ multichar = True
            show tenna stretch shrug smile at jump
            tenna "What situation?{w=0.5} We don't have to just STAY here,{w=0.2} you know!"
            show tenna upright pointing oh at jump
            tenna "Even if we're still...{w=0.2} stuck in the dump for some reason,{w=0.5} I've got a whole other HALF of the Dark World I can stay on!"
            show spamton standing up glare flipped at jump
            spamton "BY [[yorself]?"
            show tenna upright back frown at shrinks
            tenna "I..."
            show tenna upright pointing oh at zreset
            tenna "[persistent.mc] would be there!{p=0.5}{noalt}*{/noalt} Right?"
            show spamton standing tilt laugh flipped at xwiggle
            spamton "EAHEHAHAH!{p=0.5}{noalt}*{/noalt} YOU KEEP [[steeling] EVERYTHING FOR YOURSELF [[don'cha]!?"
            show tenna upright chest angry at jump
            show spamton standing up smile flipped at yreset
            tenna "I find it hard to believe [persistent.mc] would rather spend more time with YOU than ME!"
            $ multichar = False
            "..."
            $ multichar = True
            pause 1.0
            show tenna upright chest panic at shrink
            tenna "...{w=0.2} Haha,{w=0.2} [persistent.mc]?{p=0.5}{noalt}*{/noalt} What's that look for...?"
            show spamton standing up stare flipped at jump
            spamton "LOOKS LIKE [[Can't decide?] TO ME."
            $ multichar = False
            "You nod along with what Spamton said."

    $ multichar = False
    "You try to think of one last thing to say..."
    menu:
        rq "(You try to think of one last thing to say...)"
        "You don't have to like each other.":
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You say neither of them have to go back to liking each other to make the situation tolerable."
            $ multichar = True
            pause 1.0
            show tenna upright back frown at wiggle
            tenna "..."
            show spamton standing up glare flipped at jump
            spamton "WHAT [[Now!]?"
            show tenna upright chest awkward at jump
            tenna "N-{w=0.2} Nothing!{w=0.5} I didn't say anything?!"
            show spamton standing up glaree flipped at jump
            spamton "YOU'VE GOT THAT [[mushy-gushy] LOOK IN YOUR [[screens]."
            show tenna stretch shrug smile flipped at jump
            tenna "What?{p=0.5}{noalt}*{/noalt} Haha!{w=0.2} Ha.{w=0.5} WHAT?"
            show tenna stretch shrug weak flipped at wiggle
            tenna "{cps=60}N-{w=0.1} no I do NOT!{p=0.5}{noalt}*{/noalt} I JUST said,{w=0.2} I don't care about you anymore!!{/cps}"
            show spamton standing tilt laugh flipped at xwiggle
            play sfx spamlaugh
            $ _history = False
            spamton_shh "EHAHAEHAH!!{nw=1.0}"
            $ _history = True
            if persistent.glitches:
                show spamton slouch down panic flipped
            else:
                show spamton slouch down panic flipped at shakingcg
            spamton "EHAHAEHAH!!{fast}{p=0}{noalt}*{/noalt} AND YOU SAID I COULDN'T BE AN [[HonestMan] ?"
            show tenna slouch claw angry at zreset
            tenna "S-{w=0.1} shut UP!"
            show tenna upright back frown at droop
            tenna "Y-{w=0.1} you expect me to say something when [persistent.mc] is here...?"
            if persistent.glitches:
                show tenna slouch claw angry at jump
            else:
                show tenna slouch claw angry at shock
            tenna "I want to MOVE ON,{w=0.2} you know!"
            show spamton standing up glaree flipped at rise
            spamton "[[desperate little] DOESN'T CARE.{p=0.5}{noalt}*{/noalt} JUST [[take a good look at that] EXPRESSION"
            show tenna upright back panic at jump
            tenna "H-{w=0.1} huh?"

        "Can you both just apologize?":
            show spamton standing up frown flipped at jump
            show tenna upright back panic at jump
            "You tell the two of them to just apologize for the wrong they both did already."
            $ multichar = True
            show tenna upright chest angry at rise
            tenna "The wrong {color=#FDFF38}I{/color} did?!{p=0.5}{noalt}*{/noalt} [persistent.mc],{w=0.2} I {noalt}didn't--{/noalt}{alt}didn't{/alt}{nw=0.2}"
            $ multichar = False
            "You remind Tenna he directly admitted what he did wrong to you already."
            $ multichar = True
            show tenna upright back nose at jump
            pause 1.0
            show tenna upright back frown at shrinkss
            tenna "T-{w=0.1} that's..."
            show spamton standing up glaree flipped
            spamton "[[Trash Heap] YOU HAVEN'T CHANGED A BIT."
            show tenna slouch claw angry at zreset
            tenna "What is THAT supposed to mean?!"
            show tenna upright chest angry at jump
            tenna "I-{w=0.1} I have every right to be miserable because of what YOU did!{p=0.5}{noalt}*{/noalt} And I never ONCE missed you!"
            if persistent.glitches:
                show spamton standing tilt laugh flipped
            else:
                show spamton standing tilt laugh flipped glitch at jump
            spamton "THAT'S A [[lie] AND YOU KNOW {noalt}IT{/noalt}{alt}it{/alt}.{p=0.5}{noalt}*{/noalt} AND YOU SAID I'M THE [[lier] ??"
            show spamton crazy smirk at xwiggle
            spamton "I DIDN'T EVEN SAY ANYTHING ABOUT YOU [[missed] ME."
            show tenna upright back panic at droop
            tenna "Haha...!{p=0.5}{noalt}*{/noalt} I'm...{w=0.2} serious.{w=0.5} I want to move on...!"
            show tenna upright back frown
            tenna "That's part of why I...{p=0.5}{noalt}*{/noalt} [persistent.mc], I..."
            show spamton slouch down panic flipped at yreset
            spamton "[[Cathode] YOURE REALLY STARTING TO GET [[Tired of those boring, repetitive tasks?]"
    
    show tenna upright chest confused
    show spamton slouch down frown flipped
    spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} THE REASON YOU BROUGHT ME HERE."
    if persistent.glitches:
        show spamton slouch down static flipped
    else:
        show spamton slouch down static flipped glitch
    spamton "YOU WANT {noalt}US{/noalt}{alt}us{/alt} TO [[Get-Along Shirt] AGAIN SO YOU DON'T HAVE TO [[juggling act] ?"
    show spamton standing up stare flipped at jump
    spamton "WELL IT'S NOT HAPPENING!!!"
    if persistent.glitches:
        show spamton crazy angry flipped at jump
    else:
        show spamton crazy angry flipped at shock
    spamton "I THOUGHT SURVIVING [[ death metal ] WOULD HAVE MADE THIS [[hunk of junk] LESS OF A {noalt}[[4!&X]{/noalt}{alt}beep{/alt} BUT NO!!!"
    show tenna panic panic at jump
    if persistent.glitches:
        show spamton crazy frantic flipped
    else:
        show spamton crazy frantic flipped at shakingcg
    spamton "YOU'RE SOMEHOW WORSE??? THAN BEFORE???{p=0.5}{noalt}*{/noalt} HOW DID YOU [[manager] THAT???"
    spamton "YOU KEEP [[lyeing] AND [[cryeing] AND [[sigheing] LIKE WE'RE ALL SUPPOSED TO DO SOMETHING ABOUT {noalt}IT{/noalt}{alt}it{/alt}!!{p=0.5}{noalt}{noalt}*{/noalt} [[$#!X]{/noalt}{alt}beep{/alt} THAT!!"
    show tenna at droop
    tenna "I-{w=0.1} I..."
    show spamton standing down static at droop
    pause 2.0
    show tenna upright back nose at shrink
    tenna "S...{w=0.5} Sp...{p=0.5}{noalt}*{/noalt} I'm..."
    show tenna at shrinks
    tenna "[persistent.mc]?{p=0.5}{noalt}*{/noalt} You..."
    show tenna upright back black at shrinkss
    tenna "I'm...{p=0.8}{noalt}*{/noalt} I'm sorry."
    pause 1.0
    tenna "{cps=25}I'm so sorry...{/cps}"
    show spamton slouch down static
    spamton "YEAH [[right]."
    spamton "YOU SAY THAT EVERY TIME."
    show tenna slouch panic panic
    tenna "I mean it...!{p=0.5}{noalt}*{/noalt} What else do you want from me?!"
    show tenna at wiggle
    tenna "I'm trying my best,{w=0.2} really, I am...{p=0.5}{noalt}*{/noalt} I don't want to hurt you...{p=0.5}{noalt}*{/noalt} I don't WANT to hurt ANYONE...!"
    show tenna stretch shrug weak
    tenna "You don't have to like me.{p=0.5}{noalt}*{/noalt} You don't even have to forgive me!"
    show tenna slouch panic static
    tenna "But please...{w=0.5} Can't you at least{w=0.5} trust me...?"
    show spamton slouch down frown
    spamton "HOW AM I SUPPOSED TO IF YOU KEEP [[flip-flop]\n[[clip-clop]ING BACK AND FORTH ON EVERYTHING."
    show tenna upright pointing weak
    tenna "I-{w=0.1} I don't know...{w=0.5} I don't know!"
    show tenna slouch panic static flipped
    tenna "{cps=25}I...{w=0.5} I don't{w=0.5} know...{/cps}"
    pause 2.0
    show spamton standing down panic flipped at rise
    pause 2.0
    spamton "...{w=0.5} [[Cathode]."
    show tenna upright back black flipped at yreset
    tenna "...?"
    show spamton standing down frown flipped
    spamton "I'M ONLY GOING TO ASK THIS [[one more time]."
    show spamton slouch down frown flipped
    spamton "DO YOU CARE [[or not]?"
    pause 3.0
    show tenna slouch panic static flipped at droop
    tenna "...{w=1.0} Yes."
    tenna "So much.{p=0.5}{noalt}*{/noalt} So much that I hate it."
    show tenna slouch panic panic flipped
    tenna "I didn't want to see you again,{w=0.5} because I knew I wouldn't be able to handle it."
    tenna "But I also couldn't handle the thought of never being able to even so much as...{w=0.5} apologize for what all happened."
    show tenna upright back black flipped
    tenna "I thought I'd be able to move on...{w=0.5} but it all happened so fast...{w=0.5} and suddenly it felt like everyone was moving on without me."
    show tenna slouch panic static flipped
    tenna "Then,{w=0.2} all I wanted was to be happy again,{w=0.5} like I used to be.{p=0.5}{noalt}*{/noalt} Haha..."
    tenna "But all that's just...{p=0.5}{noalt}*{/noalt} Gone."
    show tenna upright back black flipped at wiggle
    tenna "Sometimes,{w=0.5} I wondered if I'd ever be happy again."
    tenna "But it's just...{nw=1.0}"
    show tenna at shrinksss
    extend "{p=0}{noalt}*{/noalt} Gone."
    show spamton at droop
    pause 2.0
    show spamton standing down static flipped
    spamton "[[fuzzface]."
    show spamton standing down frown flipped
    spamton "FOR THE RECORD{w=0.2} I DON'T {noalt}[[h8]{/noalt}{alt}hate{/alt} YOU."
    show spamton standing down panic flipped
    spamton "I [[wished] {noalt}IT{/noalt}{alt}it{/alt} COULD HAVE BEEN BETTER.{p=0.5}{noalt}*{/noalt} BUT THIS WAS GOING TO HAPPEN [[In any case,]"
    show spamton slouch down panic flipped
    spamton "YOU WERE SUPPOSED TO--{nw=0.5}"
    show strings_Fl zorder 0:
        xalign 0.25
    if persistent.glitches:
        show soulgrn_whole zorder 2:
            xpos 0.3
            ypos 0.55
        show spamton slouch down static flipped at jump
    else:
        show strings_Fl at shakingcg
        show soulgrn_whole at shaking zorder 2:
            xpos 0.3
            ypos 0.55
        show spamton slouch down static glitch flipped at shock
    spamton "--HRDKSFBJK--!{nw=0.2}"
    hide soulgrn_whole
    hide strings_Fl
    extend ""
    show tenna slouch claw panic at zreset
    tenna "S-{nw=0.1}"
    show tenna at jump
    extend " Spamton?!"
    show spamton standing down static flipped at jump
    spamton "{noalt}iiiI'M FINE!{p=0.5}{noalt}*{/noalt} f1NE! 1<!{/noalt}{alt}I'm fine! Fine!{/alt}"
    show spamton standing up glare flipped at xwiggle
    spamton "{noalt}EUGH,.{/noalt}{alt}eugh.{/alt}{p=0.5}{noalt}*{/noalt} WHY {noalt}IS{/noalt}{alt}is{/alt} [[that] WHAT MADE YOU REMEMBER MY [[Hoover Dam] NAME?"
    show tenna panic panic
    tenna "I...{nw=0.5}"
    show spamton at yreset
    show tenna upright back panic at jump
    extend "{p=0}{noalt}*{/noalt} I mean,{w=0.2} I never FORGOT it, haha."
    show tenna upright back frown
    tenna "But speaking it just...{w=0.5} brought up melancholic memories."
    pause 2.0
    show spamton standing down frown at droop
    spamton "...{w=0.5} YOU'VE REALLY BEEN THROUGH {noalt}IT{/noalt}{alt}it{/alt},{w=0.2} HUH."
    show tenna upright back confused at jump
    pause 2.0
    show tenna upright back neutral
    tenna "...{w=0.5} Not as much as you,{w=0.2} by the looks of it,{w=0.2} haha..."
    show spamton crazy laugh at jump
    spamton "GEE,{w=0.2} [[Thank you for your patronage.]"
    show tenna upright pointing weak at wiggle
    tenna "Now hold on,{w=0.2} I didn't mean it like that!!"
    show spamton standing tilt laugh flipped at jump
    spamton "EAHAHEHAH!{p=0.5}{noalt}*{/noalt} I KNOW,{w=0.2} [[Cathode].{w=0.5} IM MESSING WITH YOU."
    show tenna slouch claw panic at jump
    tenna "O-{w=0.1} oh.{p=0.5}{noalt}*{/noalt} O-{w=0.1} oh!!"
    show tenna stretch shrug smile at jump
    tenna "I knew that!!{p=0.5}{noalt}*{/noalt} Haha!!"
    show spamton standing up smile flipped
    show tenna upright back panic
    pause 1.0
    show tenna upright back nose at rise
    tenna "So, I...{w=0.2} um.{w=0.5} Ahem."
    show tenna upright back blank
    tenna "Not to jump to conclusions or anything,{nw=0.5}"
    show tenna upright chest panic at jump
    extend " but does this mean you...?"
    show spamton standing up glare flipped at jump
    spamton "I DON'T WANT [[2] DATE YOU EVER AGAIN.{p=0.2}{noalt}*{/noalt} DON'T EVEN [[Let's play pretend] THAT'S AN OPTION."
    show spamton standing up glaree flipped
    spamton "BUT I CAN [[tol]ERATE YOU."
    show tenna upright back frown at droop
    tenna "...{nw=1.0}"
    show tenna upright pressed smile at rise
    extend " Really?"
    show spamton slouch down panic flipped
    spamton "OH NO."
    show tenna at wiggle
    tenna "Haha,{w=0.2} you know,{w=0.5} this is ABOVE and BEYOND what I could have ever expected,{w=0.2} after everything that's happened!"
    show tenna upright pointing smile at jump
    tenna "I promise I won't let you down.{w=0.5} I'll keep doing--{nw=0.2}"
    show spamton crazy frantic flipped at jump
    spamton "OH [[to heck] WITH THAT."
    show tenna slouch claw panic at droop
    tenna "Excuse me?"
    show spamton standing up frown flipped
    spamton "YOU'RE GONNA [[Torx Screw Sale] UP.{p=0.5}{noalt}*{/noalt} EVERYBODY DOES."
    show spamton slouch down frown flipped
    spamton "I'VE DONE {noalt}IT{/noalt}{alt}it{/alt} TOO."
    show spamton crazy avert flipped at jump
    spamton "SO STOP TRYING TO BE [[Perfection] ALL THE TIME!!"
    show tenna upright chest panic at jump
    tenna "O-{w=0.1} oh...!"
    pause 1.0
    show tenna upright chest confused
    tenna "Okay.{p=0.5}{noalt}*{/noalt} I'll, uh.{w=0.2} Do my best at not doing my best?"
    show tenna upright chest neutral
    tenna "Haha,{w=0.2} it sounds so goofy when I say it like that."
    show spamton standing up smile flipped at jump
    spamton "YEAH WELL YOU'RE [[ (real) ] GOOFY SO {noalt}IT{/noalt}{alt}it{/alt} FITS."
    show tenna upright pointing smile at jump
    tenna "Pfft.{p=0.5}{noalt}*{/noalt} Hahaha!{w=0.2} You still are so..."

    ## AUTOSAVE
    $ renpy.save("mainfile")

    pause 1.0
    $ end_spamtenna = "done"
    $ multichar = False
    if mke_success:
        "You belatedly remembered that there was somebody else you found in the Dark World."
        "You wonder if you should tell Tenna and Spamton..."
        menu sptnend_choice:
            rq "(You wonder if you should tell Tenna and Spamton...)"
            "Tell them":
                "If you choose this option,{w=0.2} you may lock into the ending with Tenna, Spamton, and \"Mike\" or pivot to the ending with only \"Mike.\""
                menu:
                    rq "(If you choose this option, you may lock into the ending with Tenna, Spamton, and \"Mike\" or pivot to the ending with only \"Mike.\")"
                    "Yes":
                        $ end_triple = "started"
                        
                        show spamton standing up frown flipped at jump
                        show tenna upright back blank at jump
                        "You interject to tell the other two you remember there was someone else in this Dark World."
                        $ multichar = True
                        show spamton standing up stare flipped at jump
                        spamton "WHAT???"
                        show tenna upright pointing oh
                        tenna "WOW!{p=0.5}{noalt}*{/noalt} [persistent.mc],{w=0.2} you have a real knack for finding people,{w=0.2} huh?"
                        show spamton crazy frantic flipped
                        spamton "WHAT ANIMATED [[scrap parts] DID YOU FIND??"
                        show tenna upright pointing weak at droop
                        tenna "That's...{w=0.5} a bit morbid,{w=0.2} don't you think?"
                        show spamton standing up frown flipped at xwiggle
                        spamton "AS IF YOU'RE NOT EXXACTLY THAT??"
                        show tenna upright chest angry at jump
                        tenna "Ouch,{w=0.2} hey,{w=0.2} c'mon!!{p=0.5}{noalt}*{/noalt} I thought we were being nice now!!"
                        show spamton standing tilt laugh flipped at jump
                        spamton "I'LL BE NICE WHEN I SEE [[[[ The Light ]]"
                        $ multichar = False
                        "You...{w=0.2} figure you'll leave them to it while you go and fetch \"Mike.\""
                        stop music fadeout 1.0
                        play sfx waterwalk
                        scene black with Dissolve(2.0)
                        pause 3.0
                        scene junkyard5 with Dissolve(1.0)
                        stop sfx fadeout 1.0
                        play music dump
                        pause 1.0
                        jump mike_interact

                    "No":
                        jump sptnend_choice
            
            "Do not":
                "If you choose this option,{w=0.2} you will lock into the ending with only Tenna and Spamton."
                menu:
                    rq "(If you choose this option, you will lock into the ending with only Tenna and Spamton.)"
                    "Yes":
                        "You decided things are fine as they are."

                    "No":
                        jump sptnend_choice
    
    show tenna upright chest panic at jump
    show spamton standing up stare flipped at jump
    "You interject to bring up that you know a way to get the both of them out of here."
    $ multichar = True
    show tenna slouch claw panic at jump
    tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}?{nw=0.5}"
    show tenna upright pointing weak at wiggle
    if sptn_stuck:
        extend "{p=0}{noalt}*{/noalt} [persistent.mc],{w=0.2} I thought you said we were going to be stuck here...?"
    else:
        extend "{p=0}{noalt}*{/noalt} [persistent.mc],{w=0.2} how long have you known that...?"
    show spamton crazy laugh at xwiggle
    spamton "YEAH [[what gives] ??{p=0.2}{noalt}*{/noalt} DON'T HIDE [[the goods] FROM US!!"
    show tenna upright back awkward at jump
    tenna "\"Us\"?"
    show spamton crazy frantic
    spamton "IT'S A [[Collective] TERM,{w=0.2} [[dust magnet] !!"
    show tenna panic flustered at jump
    tenna "Right!{w=0.2} Haha...!"
    show tenna upright back frown at droop
    tenna "Anyway..."
    show tenna upright pointing oh at jump
    tenna "[persistent.mc]!{p=0.2}{noalt}*{/noalt} What's the plan, then?"
    show spamton standing up frown flipped at jump
    $ multichar = False
    "You explain how there's a mattress on the other side of this Dark World that you three will need to go to."
    $ multichar = True
    show tenna upright back awkward at jump
    show spamton standing up frowne flipped
    spamton "...{nw=0.5}"
    show spamton crazy laugh at jump
    extend " EAHEHAHEHAH!!"
    show spamton standing up stare flipped at jump
    spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} NO???"
    show tenna upright chest confused at jump
    tenna "Hey,{w=0.2} now!{w=0.5} Let's at least hear what [persistent.mc] has to say!"
    show tenna upright pointing oh at jump
    tenna "So?{p=0.5}{noalt}*{/noalt} Tell us your plan!"
    $ multichar = False
    "You say it'll be easier to explain once you get there."
    $ multichar = True
    show spamton standing up glaree flipped
    show tenna upright chest awkward at jump
    tenna "Oh!"
    show tenna at wiggle
    tenna "Well,{w=0.2} if you insist..."
    show spamton crazy angry at xwiggle
    spamton "{noalt}EUGH.{/noalt}{alt}ugh.{/alt}"
    show spamton standing up glaree flipped at jump
    spamton "YOU'RE LUCKY I [[ trust ] YOU,{w=0.2} [persistent.mc!u].{p=0.5}{noalt}*{/noalt} [[Lead the way!]"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    $ multichar = False
    "You lead Tenna and Spamton to the mattress on the other side of the Dark World."

    # TO UNIVERSAL ENDING
    jump ending_universal