############################################################################################################
################## BG's and CG's
image black = "#000"
image white = "#fff"
image grey = "#A2A2A2"
image darkgrey = "#8B8B8B"
image blackpng = "images/blackpng.png"
image sickoverlay = "#943a836f"
image fadeoverlay = "#00000090"

## logos
image logo iltv = "gui/logo sm.png"
image logo dr = "gui/logo dr.png"

######################################################
##### BG'S
image crtscroll:
    "gui/menu bg.png"
    yalign 0.0
    linear 10.0 yalign 1.0
    repeat

image dfountain:
    "images/bg/small dark fountain 1.png"
    pause 0.3
    "images/bg/small dark fountain 2.png"
    pause 0.3
    "images/bg/small dark fountain 3.png"
    pause 0.3
    "images/bg/small dark fountain 4.png"
    pause 0.3
    repeat

image dfountainF:
    "images/bg/full dark fountain 1.png"
    pause 0.4
    "images/bg/full dark fountain 2.png"
    pause 0.4
    "images/bg/full dark fountain 3.png"
    pause 0.4
    repeat

image junkyard = "images/bg/junkyard.png" # intro w tenna
image junkyard2 = "images/bg/junkyard2.png" # fountain room
image junkyard3 = "images/bg/junkyard3.png" # dirt lump
image junkyard4 = "images/bg/junkyard4.png" # mattress
image junkyard5 = "images/bg/junkyard5.png" # tv room
image junkyard6 = "images/bg/junkyard6.png" # eye room

image junkspam = "images/bg/junkspam.png" # outside of spamshop
image tennahouse = "images/bg/tennahouse.png"

image quizboard = "images/bg/quiz board.png"
image quizboard2 = "images/bg/quiz board2.png"
image parkboard = "images/bg/park board.png"
image parkboard2 = "images/bg/park board2.png"

image tvoverlay = "images/bg/tv overlay.png"


######################################################
##### GEN CG'S
image vess cg = "images/cg/vess cg.png"

image crtoverlay:
    "images/crt overlay.png"
    yalign 0.0
    linear 10.0 yalign 1.0
    repeat

image staticoverlay:
    "images/static overlay 1.png"
    pause 0.08
    "images/static overlay 3.png"
    pause 0.08
    "images/static overlay 4.png"
    pause 0.08
    repeat

image vignetteoverlay:
    "images/vignette 1.png" with Dissolve(2.0)
    pause 2.0
    "images/vignette 2.png" with Dissolve(2.0)
    pause 2.0
    repeat

image tv_turnon:
    "images/cg/tv turn off1.png"
    pause 0.15
    "images/cg/tv turn off2.png"
    pause 0.15
    "images/cg/tv turn off5.png"

image tv_shutdown:
    "images/cg/tv turn off2.png"
    pause 0.08
    "images/cg/tv turn off3.png"
    pause 0.08
    "images/cg/tv turn off4.png"
    pause 0.08
    "images/cg/tv turn off5.png"

### mini icons
transform mini_tenna1:
    "images/sprites/tenna/mini icon tenna1.png"
    xpos 0.25
    ypos 0.25
    ease 0.8 rotate -2
    ease 0.8 rotate 2
    repeat

transform mini_tenna2:
    "images/sprites/tenna/mini icon tenna2.png"
    xpos 0.25
    ypos 0.25
    ease 1.0 rotate -2
    ease 1.0 rotate 2
    repeat

transform mini_spamton:
    "images/sprites/spamton/mini icon spamton.png"
    xpos 0.575
    ypos 0.25
    linear 0.6 xoffset -5
    linear 0.6 xoffset 5
    repeat

transform mini_mike:
    "images/sprites/mike/mini icon mike.png"
    xpos 0.03


######################################################
##### MEMORYSHARDS

### memoryshard 1 (tenna and spamton meet)
image mscg1 001 = "images/memoryshard/memoryshard 1 001.png"
image mscg1 002 = "images/memoryshard/memoryshard 1 002.png"
image mscg1 003 = "images/memoryshard/memoryshard 1 003.png"
image mscg1 004 = "images/memoryshard/memoryshard 1 004.png"
image mscg1 005 = "images/memoryshard/memoryshard 1 005.png"
image mscg1 006 = "images/memoryshard/memoryshard 1 006.png"
image mscg1 007 = "images/memoryshard/memoryshard 1 007.png"
image mscg1 008 = "images/memoryshard/memoryshard 1 008.png"
image mscg1 009 = "images/memoryshard/memoryshard 1 009.png"
image mscg1 010 = "images/memoryshard/memoryshard 1 010.png"
image mscg1 011 = "images/memoryshard/memoryshard 1 011.png"
image mscg1 012 = "images/memoryshard/memoryshard 1 012.png"
image mscg1 013 = "images/memoryshard/memoryshard 1 013.png"
image mscg1 014 = "images/memoryshard/memoryshard 1 014.png"
image mscg1 015 = "images/memoryshard/memoryshard 1 015.png"
image mscg1 016 = "images/memoryshard/memoryshard 1 016.png"
image mscg1 017 = "images/memoryshard/memoryshard 1 017.png"
image mscg1 019 = "images/memoryshard/memoryshard 1 019.png"
image mscg1 018 = "images/memoryshard/memoryshard 1 018.png"
image mscg1 020 = "images/memoryshard/memoryshard 1 020.png"
image mscg1 021 = "images/memoryshard/memoryshard 1 021.png"
image mscg1 022 = "images/memoryshard/memoryshard 1 022.png"
image mscg1 023 = "images/memoryshard/memoryshard 1 023.png"
image mscg1 024 = "images/memoryshard/memoryshard 1 024.png"

### memoryshard 2 (tenna offers the deal)
image mscg2 001 = "images/memoryshard/memoryshard 2 001.png"
image mscg2 002 = "images/memoryshard/memoryshard 2 002.png"
image mscg2 003 = "images/memoryshard/memoryshard 2 003.png"
image mscg2 004 = "images/memoryshard/memoryshard 2 004.png"
image mscg2 005 = "images/memoryshard/memoryshard 2 005.png"
image mscg2 006 = "images/memoryshard/memoryshard 2 006.png"
image mscg2 007 = "images/memoryshard/memoryshard 2 007.png"
image mscg2 008 = "images/memoryshard/memoryshard 2 008.png"
image mscg2 009 = "images/memoryshard/memoryshard 2 009.png"
image mscg2 010 = "images/memoryshard/memoryshard 2 010.png"
image mscg2 011 = "images/memoryshard/memoryshard 2 011.png"
image mscg2 012 = "images/memoryshard/memoryshard 2 012.png"
image mscg2 013 = "images/memoryshard/memoryshard 2 013.png"
image mscg2 014 = "images/memoryshard/memoryshard 2 014.png"
image mscg2 015 = "images/memoryshard/memoryshard 2 015.png"

### memoryshard 3 (tenna is abandoned)
image mscg3 001 = "images/memoryshard/memoryshard 3 001.png"
image mscg3 002 = "images/memoryshard/memoryshard 3 002.png"
image mscg3 003 = "images/memoryshard/memoryshard 3 003.png"
image mscg3 004 = "images/memoryshard/memoryshard 3 004.png"
image mscg3 005 = "images/memoryshard/memoryshard 3 005.png"
image mscg3 006 = "images/memoryshard/memoryshard 3 006.png"
image mscg3 007 = "images/memoryshard/memoryshard 3 007.png"
image mscg3 008 = "images/memoryshard/memoryshard 3 008.png"
image mscg3 009 = "images/memoryshard/memoryshard 3 009.png"
image mscg3 010 = "images/memoryshard/memoryshard 3 010.png"
image mscg3 011 = "images/memoryshard/memoryshard 3 011.png"
image mscg3 012 = "images/memoryshard/memoryshard 3 012.png"
image mscg3 013 = "images/memoryshard/memoryshard 3 013.png"
image mscg3 014 = "images/memoryshard/memoryshard 3 014.png"
image mscg3 015 = "images/memoryshard/memoryshard 3 015.png"
image mscg3a 015a = "images/memoryshard/memoryshard 3 015a.png"
image mscg3 016 = "images/memoryshard/memoryshard 3 016.png"
image mscg3 017 = "images/memoryshard/memoryshard 3 017.png"
image mscg3 018 = "images/memoryshard/memoryshard 3 018.png"
image mscg3 019 = "images/memoryshard/memoryshard 3 019.png"
image mscg3 020 = "images/memoryshard/memoryshard 3 020.png"
image mscg3 021 = "images/memoryshard/memoryshard 3 021.png"
image mscg3 022 = "images/memoryshard/memoryshard 3 022.png"
image mscg3 023 = "images/memoryshard/memoryshard 3 023.png"

image mscg3 2-3:
    "mscg3 002"
    pause 0.1
    "mscg3 003"
    pause 0.1
    repeat

image mscg3 5-6:
    "mscg3 005"
    pause 0.1
    "mscg3 006"
    pause 0.1
    repeat

image mscg3 15-16:
    xalign 0.5
    "mscg3 015"
    pause 0.2
    ease 0.4 xpos 2.0
    pause 0.5
    xpos 2.0
    "mscg3 016"
    ease 0.4 xalign 0.5
    pause 0.5

image mscg3a 15a:
    xalign 0.5
    "mscg3a 015a"
    pause 1.0
    ease 0.4 xpos -2.0


### memoryshard 4 (spamton snaps)
image mscg4 001 = "images/memoryshard/memoryshard 4 001.png"
image mscg4 002 = "images/memoryshard/memoryshard 4 002.png"
image mscg4 003 = "images/memoryshard/memoryshard 4 003.png"
image mscg4 004 = "images/memoryshard/memoryshard 4 004.png"
image mscg4 005 = "images/memoryshard/memoryshard 4 005.png"
image mscg4 006 = "images/memoryshard/memoryshard 4 006.png"
image mscg4 007 = "images/memoryshard/memoryshard 4 007.png"
image mscg4 008 = "images/memoryshard/memoryshard 4 008.png"
image mscg4 009 = "images/memoryshard/memoryshard 4 009.png"
image mscg4 010 = "images/memoryshard/memoryshard 4 010.png"
image mscg4 011 = "images/memoryshard/memoryshard 4 011.png"
image mscg4 012 = "images/memoryshard/memoryshard 4 012.png"
image mscg4 013 = "images/memoryshard/memoryshard 4 013.png"
image mscg4 014 = "images/memoryshard/memoryshard 4 014.png"
image mscg4 015 = "images/memoryshard/memoryshard 4 015.png"
image mscg4 016 = "images/memoryshard/memoryshard 4 016.png"
image mscg4 017 = "images/memoryshard/memoryshard 4 017.png"
image mscg4 018 = "images/memoryshard/memoryshard 4 018.png"
image mscg4 019 = "images/memoryshard/memoryshard 4 019.png"
image mscg4 018 9a:
    "mscg4 018"
    pause 0.5
    "mscg4 019"
    pause 0.5
    repeat
image mscg4 020 = "images/memoryshard/memoryshard 4 020.png"
image mscg4 021 = "images/memoryshard/memoryshard 4 021.png"
image mscg4 022 = "images/memoryshard/memoryshard 4 022.png"
image mscg4 023 = "images/memoryshard/memoryshard 4 023.png"

### memoryshard 5 (tenna admits not liking spamton)
image mscg5 001 = "images/memoryshard/memoryshard 5 001.png"
image mscg5 002 = "images/memoryshard/memoryshard 5 002.png"
image mscg5 003 = "images/memoryshard/memoryshard 5 003.png"
image mscg5 004 = "images/memoryshard/memoryshard 5 004.png"
image mscg5 005 = "images/memoryshard/memoryshard 5 005.png"
image mscg5 006 = "images/memoryshard/memoryshard 5 006.png"
image mscg5 007 = "images/memoryshard/memoryshard 5 007.png"
image mscg5 008 = "images/memoryshard/memoryshard 5 008.png"
image mscg5 009 = "images/memoryshard/memoryshard 5 009.png"
image mscg5 010 = "images/memoryshard/memoryshard 5 010.png"
image mscg5 011 = "images/memoryshard/memoryshard 5 011.png"
image mscg5 012 = "images/memoryshard/memoryshard 5 012.png"
image mscg5 013 = "images/memoryshard/memoryshard 5 013.png"
image mscg5 014 = "images/memoryshard/memoryshard 5 014.png"
image mscg5 015 = "images/memoryshard/memoryshard 5 015.png"
image mscg5 016 = "images/memoryshard/memoryshard 5 016.png"
image mscg5 017 = "images/memoryshard/memoryshard 5 017.png"
image mscg5 018 = "images/memoryshard/memoryshard 5 018.png"

### memoryshard 6 (accept proposal)
image mscg6 001 = "images/memoryshard/memoryshard 6 001.png"
image mscg6 002 = "images/memoryshard/memoryshard 6 002.png"
image mscg6 003 = "images/memoryshard/memoryshard 6 003.png"
image mscg6 004 = "images/memoryshard/memoryshard 6 004.png"
image mscg6 005 = "images/memoryshard/memoryshard 6 005.png"
image mscg6 006 = "images/memoryshard/memoryshard 6 006.png"
image mscg6 007 = "images/memoryshard/memoryshard 6 007.png"
image mscg6 008 = "images/memoryshard/memoryshard 6 008.png"
image mscg6 009 = "images/memoryshard/memoryshard 6 009.png"
image mscg6 010 = "images/memoryshard/memoryshard 6 010.png"
image mscg6 011 = "images/memoryshard/memoryshard 6 011.png"
image mscg6 012 = "images/memoryshard/memoryshard 6 012.png"
image mscg6 013 = "images/memoryshard/memoryshard 6 013.png"
image mscg6 014 = "images/memoryshard/memoryshard 6 014.png"
image mscg6 015 = "images/memoryshard/memoryshard 6 015.png"
image mscg6 016 = "images/memoryshard/memoryshard 6 016.png"
image mscg6a 016a = "images/memoryshard/memoryshard 6 016a.png"
image mscg6 017 = "images/memoryshard/memoryshard 6 017.png"
image mscg6 018 = "images/memoryshard/memoryshard 6 018.png"
image mscg6 019 = "images/memoryshard/memoryshard 6 019.png"
image mscg6 020 = "images/memoryshard/memoryshard 6 020.png"

### memoryshard 7 (tenna apologizes)
image mscg7 001 = "images/memoryshard/memoryshard 7 001.png"
image mscg7 002 = "images/memoryshard/memoryshard 7 002.png"
image mscg7 003 = "images/memoryshard/memoryshard 7 003.png"
image mscg7 004 = "images/memoryshard/memoryshard 7 004.png"
image mscg7 005 = "images/memoryshard/memoryshard 7 005.png"
image mscg7 006 = "images/memoryshard/memoryshard 7 006.png"
image mscg7 007 = "images/memoryshard/memoryshard 7 007.png"
image mscg7 008 = "images/memoryshard/memoryshard 7 008.png"
image mscg7 009 = "images/memoryshard/memoryshard 7 009.png"
image mscg7 010 = "images/memoryshard/memoryshard 7 010.png"
image mscg7 011 = "images/memoryshard/memoryshard 7 011.png"
image mscg7 012 = "images/memoryshard/memoryshard 7 012.png"
image mscg7 013 = "images/memoryshard/memoryshard 7 013.png"
image mscg7 014 = "images/memoryshard/memoryshard 7 014.png"
image mscg7 015 = "images/memoryshard/memoryshard 7 015.png"
image mscg7 016 = "images/memoryshard/memoryshard 7 016.png"
image mscg7 017 = "images/memoryshard/memoryshard 7 017.png"
image mscg7 018 = "images/memoryshard/memoryshard 7 018.png"
image mscg7 019 = "images/memoryshard/memoryshard 7 019.png"
image mscg7 020 = "images/memoryshard/memoryshard 7 020.png"
image mscg7 021 = "images/memoryshard/memoryshard 7 021.png"
image mscg7 022 = "images/memoryshard/memoryshard 7 022.png"
image mscg7 023 = "images/memoryshard/memoryshard 7 023.png"
image mscg7 024 = "images/memoryshard/memoryshard 7 024.png"
image mscg7 025 = "images/memoryshard/memoryshard 7 025.png"
image mscg7 026 = "images/memoryshard/memoryshard 7 026.png"
image mscg7 027 = "images/memoryshard/memoryshard 7 027.png"
image mscg7 028 = "images/memoryshard/memoryshard 7 028.png"
image mscg7 029 = "images/memoryshard/memoryshard 7 029.png"
image mscg7 030 = "images/memoryshard/memoryshard 7 030.png"
image mscg7 031 = "images/memoryshard/memoryshard 7 031.png"
image mscg7 032 = "images/memoryshard/memoryshard 7 032.png"
image mscg7 033 = "images/memoryshard/memoryshard 7 033.png"
image mscg7 034 = "images/memoryshard/memoryshard 7 034.png"
image mscg7 035 = "images/memoryshard/memoryshard 7 035.png"
image mscg7 036 = "images/memoryshard/memoryshard 7 036.png"
image mscg7 037 = "images/memoryshard/memoryshard 7 037.png"

### memoryshard 8 (spilled coffee)
image mscg8 001 = "images/memoryshard/memoryshard 8 001.png"
image mscg8 002 = "images/memoryshard/memoryshard 8 002.png"
image mscg8 003 = "images/memoryshard/memoryshard 8 003.png"
image mscg8 004 = "images/memoryshard/memoryshard 8 004.png"
image mscg8 005 = "images/memoryshard/memoryshard 8 005.png"
image mscg8 006 = "images/memoryshard/memoryshard 8 006.png"
image mscg8 007 = "images/memoryshard/memoryshard 8 007.png"
image mscg8 008 = "images/memoryshard/memoryshard 8 008.png"
image mscg8 009 = "images/memoryshard/memoryshard 8 009.png"
image mscg8 010 = "images/memoryshard/memoryshard 8 010.png"
image mscg8 011 = "images/memoryshard/memoryshard 8 011.png"
image mscg8 012 = "images/memoryshard/memoryshard 8 012.png"
image mscg8 013 = "images/memoryshard/memoryshard 8 013.png"
image mscg8 014 = "images/memoryshard/memoryshard 8 014.png"
image mscg8 015 = "images/memoryshard/memoryshard 8 015.png"
image mscg8 016 = "images/memoryshard/memoryshard 8 016.png"
image mscg8 017 = "images/memoryshard/memoryshard 8 017.png"
image mscg8 018 = "images/memoryshard/memoryshard 8 018.png"
image mscg8 019 = "images/memoryshard/memoryshard 8 019.png"
image mscg8 020 = "images/memoryshard/memoryshard 8 020.png"
image mscg8 021 = "images/memoryshard/memoryshard 8 021.png"
image mscg8 022 = "images/memoryshard/memoryshard 8 022.png"
image mscg8 023 = "images/memoryshard/memoryshard 8 023.png"
image mscg8 024 = "images/memoryshard/memoryshard 8 024.png"
image mscg8 025 = "images/memoryshard/memoryshard 8 025.png"
image mscg8 026 = "images/memoryshard/memoryshard 8 026.png"
image mscg8 027 = "images/memoryshard/memoryshard 8 027.png"
image mscg8 028 = "images/memoryshard/memoryshard 8 028.png"
image mscg8 029 = "images/memoryshard/memoryshard 8 029.png"
image mscg8 030 = "images/memoryshard/memoryshard 8 030.png"
image mscg8 031 = "images/memoryshard/memoryshard 8 031.png"

### memoryshard 9 (mike's promise)
image mscg9 001 = "images/memoryshard/memoryshard 9 001.png"
image mscg9 002 = "images/memoryshard/memoryshard 9 002.png"
image mscg9 003 = "images/memoryshard/memoryshard 9 003.png"
image mscg9 004 = "images/memoryshard/memoryshard 9 004.png"
image mscg9 005 = "images/memoryshard/memoryshard 9 005.png"
image mscg9 006 = "images/memoryshard/memoryshard 9 006.png"
image mscg9 007 = "images/memoryshard/memoryshard 9 007.png"
image mscg9 008 = "images/memoryshard/memoryshard 9 008.png"
image mscg9 009 = "images/memoryshard/memoryshard 9 009.png"
image mscg9 010 = "images/memoryshard/memoryshard 9 010.png"
image mscg9 011 = "images/memoryshard/memoryshard 9 011.png"
image mscg9 012 = "images/memoryshard/memoryshard 9 012.png"
image mscg9 013 = "images/memoryshard/memoryshard 9 013.png"
image mscg9 014 = "images/memoryshard/memoryshard 9 014.png"
image mscg9 015 = "images/memoryshard/memoryshard 9 015.png"
image mscg9 016 = "images/memoryshard/memoryshard 9 016.png"
image mscg9 017 = "images/memoryshard/memoryshard 9 017.png"
image mscg9 018 = "images/memoryshard/memoryshard 9 018.png"
image mscg9 019 = "images/memoryshard/memoryshard 9 019.png"
image mscg9 019a:
    "mscg9 018"
    pause 0.03
    "mscg9 019"
    pause 0.03
    "mscg9 020"
image mscg9 020 = "images/memoryshard/memoryshard 9 020.png"
image mscg9 021 = "images/memoryshard/memoryshard 9 021.png"
image mscg9 022 = "images/memoryshard/memoryshard 9 022.png"
image mscg9 023 = "images/memoryshard/memoryshard 9 023.png"
image mscg9 024 = "images/memoryshard/memoryshard 9 024.png"
image mscg9 025 = "images/memoryshard/memoryshard 9 025.png"


######################################################
##### TENNA CG'S
image sadsit 1 = "images/cg/tenna sad sit.png"
image sadsit 2 = "images/cg/tenna sad turn.png"

image tenna cg zoom angry = "images/cg/tenna up close anger.png"
image tenna cg zoom panic = "images/cg/tenna up close panic.png"
image tenna cg zoom blush = "images/cg/tenna up close blush.png"

image technicalSt = "images/cg/technical 01.png"

### technical difficulties please stand by.
image technical:
    "images/cg/technical 01.png"
    pause 1.2
    "images/cg/technical 02.png"
    pause 0.05
    "images/cg/technical 03.png"
    pause 0.05
    "images/cg/technical 04.png"
    pause 0.05
    "images/cg/technical 05.png"
    pause 0.05
    "images/cg/technical 06.png"
    pause 0.05
    "images/cg/technical 01.png"

### not mr tenna's shop
layeredimage tenshop:
    always:
        "images/shops/tenshop.png"

    group emotion:
        attribute e_smile default:
            pos(299,286)
            "images/shops/tenshop smile.png"

        attribute e_awkward:
            pos(299,286)
            "images/shops/tenshop awkward.png"

        attribute e_frown:
            pos(299,286)
            "images/shops/tenshop frown.png"

        attribute e_blush:
            pos(299,286)
            "images/shops/tenshop blush.png"

### main menu
transform tenmenu:
    "gui/tenna menu 1.png"
    pause 10.0
    "gui/tenna menu 2.png" 
    xoffset 5
    pause 0.2
    "gui/tenna menu 3.png" 
    xoffset -10
    pause 0.2
    xoffset 0
    repeat

image tennaend 1 = "images/cg/tennaend 1.png" 
image tennaend 3 = "images/cg/tennaend 3.png"

image tennaend 2 down angry = "images/cg/tennaend 2 down angry.png"
image tennaend 2 down confused = "images/cg/tennaend 2 down confused.png"
image tennaend 2 down frown = "images/cg/tennaend 2 down frown.png"
image tennaend 2 down nose = "images/cg/tennaend 2 down nose.png"
image tennaend 2 down pained = "images/cg/tennaend 2 down pained.png"
image tennaend 2 down panic = "images/cg/tennaend 2 down panic.png"
image tennaend 2 down smile = "images/cg/tennaend 2 down smile.png"

image tennaend 2 side angry = "images/cg/tennaend 2 side angry.png"
image tennaend 2 side confused = "images/cg/tennaend 2 side confused.png"
image tennaend 2 side frown = "images/cg/tennaend 2 side frown.png"
image tennaend 2 side nose = "images/cg/tennaend 2 side nose.png"
image tennaend 2 side pained = "images/cg/tennaend 2 side pained.png"
image tennaend 2 side panic = "images/cg/tennaend 2 side panic.png"
image tennaend 2 side smile = "images/cg/tennaend 2 side smile.png"


######################################################
##### SPAMTON CG'S
image spamhand = "images/cg/spamton hand.png"
image spameyes_1 = "images/cg/spamton eyes1.png"
image spameyes_2 = "images/cg/spamton eyes2.png"

image spameyes_1 static:
    "images/cg/spamton eyes3.png"
    pause 0.2
    "images/cg/spamton eyes4.png"
    pause 0.2
    repeat

### spamton shop
image spamshop_glitch:
    animated_glitch("images/shops/spamshop glitch.png", chroma=False, offset=20, timeout_vanilla=0.2)
image spamshop_glitchNo = "images/shops/spamshop glitch.png"

image spamshop_laugh glitch:
    animated_glitch("images/shops/spamshop spamton laugh.png", chroma=False, offset=20, timeout_vanilla=1)

image spamshop_laugh flip:
    "images/shops/spamshop spamton laugh.png"
    pause 0.2
    Transform("images/shops/spamshop spamton laugh.png", xzoom=-1.0)
    pause 0.2
    repeat

image spamshop_static:
    "images/shops/spamshop spamton static1.png"
    pause 0.2
    "images/shops/spamshop spamton static2.png"
    pause 0.2
    repeat

image spamshop_static glitch:
    animated_glitch("spamshop_static", chroma=False)

image spamshop_bg = "images/shops/spamshop bg.png"
image spamshop_bg2 = "images/shops/spamshop bg2.png"

layeredimage spamshop_spamton:
    always:
        "images/shops/spamshop spamton.png"

    group emotion:
        attribute e_neutral default:
            pos(394,0)
            "images/shops/spamshop spamton neutral.png"

        attribute e_eyes:
            pos(394,0)
            "images/shops/spamshop spamton eyes.png"

        attribute e_static:
            pos(394,0)
            "spamshop_static"

        attribute e_laugh:
            pos(394,0)
            "images/shops/spamshop spamton laugh.png"

        attribute e_laughf:
            pos(394,0)
            "spamshop_laugh flip"

        attribute e_laughg:
            pos(394,0)
            "spamshop_laugh glitch"

        attribute e_staticg:
            pos(394,0)
            "spamshop_static glitch"

### main menu
transform spammenu:
    "gui/spam menu 1.png"
    pause 10.0
    "gui/spam menu 2.png"
    pause 0.1
    "gui/spam menu 3.png"
    pause 0.1
    "gui/spam menu 4.png"
    pause 0.1
    "gui/spam menu 2.png"
    pause 0.1
    "gui/spam menu 3.png"
    pause 0.1
    "gui/spam menu 4.png"
    pause 0.1
    repeat

image spamton cg zoom soul = "images/cg/spam up close 1.png"

image spamend fail 1 = "images/cg/spamend hug fail 1.png"
image spamend fail 2 = "images/cg/spamend hug fail 2.png"
image spamend fail 3 = "images/cg/spamend hug fail 3.png"

image spamend 1 angry = "images/cg/spamend 1 angry.png"
image spamend 1 angrye = "images/cg/spamend 1 angrye.png"
image spamend 1 deadpan = "images/cg/spamend 1 deadpan.png"
image spamend 1 frown = "images/cg/spamend 1 frown.png"
image spamend 1 glare = "images/cg/spamend 1 glare.png"
image spamend 1 glaree = "images/cg/spamend 1 glaree.png"
image spamend 1 pained = "images/cg/spamend 1 pained.png"
image spamend 1 smile = "images/cg/spamend 1 smile.png"
image spamend 1 smilee = "images/cg/spamend 1 smilee.png"
image spamend 1 struggle = "images/cg/spamend 1 struggle.png"
image spamend 1 strugglee = "images/cg/spamend 1 strugglee.png"
image spamend 1 static:
    "images/cg/spamend 1 static1.png"
    pause 0.2
    "images/cg/spamend 1 static2.png"
    pause 0.2
    repeat

image spamend 2 angry = "images/cg/spamend 2 angry.png"
image spamend 2 angrye = "images/cg/spamend 2 angrye.png"
image spamend 2 deadpan = "images/cg/spamend 2 deadpan.png"
image spamend 2 frown = "images/cg/spamend 2 frown.png"
image spamend 2 glare = "images/cg/spamend 2 glare.png"
image spamend 2 glaree = "images/cg/spamend 2 glaree.png"
image spamend 2 pained = "images/cg/spamend 2 pained.png"
image spamend 2 smile = "images/cg/spamend 2 smile.png"
image spamend 2 smilee = "images/cg/spamend 2 smilee.png"
image spamend 2 struggle = "images/cg/spamend 2 struggle.png"
image spamend 2 strugglee = "images/cg/spamend 2 strugglee.png"
image spamend 2 static:
    "images/cg/spamend 2 static1.png"
    pause 0.2
    "images/cg/spamend 2 static2.png"
    pause 0.2
    repeat


######################################################
##### MIKE CG'S
image mikeend_date down = "images/cg/mike date end down.png"
image mikeend_date angry = "images/cg/mike date end angry.png"

image mikeend 1 angry = "images/cg/mikeend 1 angry.png"
image mikeend 1 confused = "images/cg/mikeend 1 confused.png"
image mikeend 1 frown = "images/cg/mikeend 1 frown.png"
image mikeend 1 nervous = "images/cg/mikeend 1 nervous.png"
image mikeend 1 shocked = "images/cg/mikeend 1 shocked.png"
image mikeend 1 sigh = "images/cg/mikeend 1 sigh.png"

image mikeend 2 angry = "images/cg/mikeend 2 angry.png"
image mikeend 2 avert = "images/cg/mikeend 2 avert.png"
image mikeend 2 confused = "images/cg/mikeend 2 confused.png"
image mikeend 2 frown = "images/cg/mikeend 2 frown.png"
image mikeend 2 nervous = "images/cg/mikeend 2 nervous.png"
image mikeend 2 pained = "images/cg/mikeend 2 pained.png"
image mikeend 2 panic = "images/cg/mikeend 2 panic.png"
image mikeend 2 sigh = "images/cg/mikeend 2 sigh.png"
image mikeend 2 smile = "images/cg/mikeend 2 smile.png"


######################################################
##### ENDING CG'S
image uniend tenna = "images/cg/uniend tenna.png"
image uniend spamton = "images/cg/uniend spamton.png"
image uniend mike = "images/cg/uniend mike.png"

image uniend spamtenna = "images/cg/uniend spamtenna.png"
image uniend spamtat = "images/cg/uniend spamtat.png"
image uniend battenna = "images/cg/uniend battenna.png"
image uniend triple = "images/cg/uniend triple.png"

## willo
image uniend_willo tenna = "images/cg/uniend willo tenna.png"
image uniend_willo spamton = "images/cg/uniend willo spamton.png"
image uniend_willo mike = "images/cg/uniend willo mike.png"

image uniend_willo spamtenna = "images/cg/uniend willo spamtenna.png"
image uniend_willo spamtat = "images/cg/uniend willo spamtat.png"
image uniend_willo battenna = "images/cg/uniend willo battenna.png"
image uniend_willo triple = "images/cg/uniend willo triple.png"

## credits
image susie tenna = "images/cg/credits lw tenna.png"
image susie spamton = "images/cg/credits lw spamton.png"
image susie mike = "images/cg/credits lw mike.png"

image dw tenna = "images/cg/credits dw tenna.png"
image dw spamton = "images/cg/credits dw spamton.png"
image dw mike = "images/cg/credits dw mike.png"

image tripleend = "images/cg/tripleend.png"