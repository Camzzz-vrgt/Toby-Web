############################################################################################################
################## GASTER INTERACT/LOREDUMP
label neveruse:
    $ quick_menu = False
    $ renpy.pause(1.0,hard=True)
    play music gasterwaltz fadein 4.0
    $ renpy.pause(1.0,hard=True)

    if not wdg_bedmeet:
        $ renpy.pause(4.0, hard=True)
        show text _("Are you trying to wake up?") at truecenter with dissolve
        pause
        $ quick_menu = True
        menu:
            "Yes":
                hide text with dissolve
                show text _("Very well.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("You needn't worry... Once you go back to sleep?") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Everything will be") with dissolve
                pause
                stop music
                show text _("just as you remembered.")
                pause
                scene black
                $ renpy.pause(1.0, hard=True)
                $ renpy.quit()

            "No":
                if not wdg_bedmeet:
                    hide text with dissolve
                    show text _("How intriguing.") with dissolve
                    pause
                    hide text with dissolve
                    $ renpy.pause(1.0, hard=True)
                    show text _("I fail to see why you would return here otherwise.") with dissolve
                    pause
                else:
                    hide text with dissolve
                    show text _("I see.") with dissolve
                    pause
                    hide text with dissolve
                    $ renpy.pause(1.0, hard=True)
                    show text _("Have you come for me, then?") with dissolve
                    pause

        menu:
            "Who are you?":
                hide text with dissolve
                show text _("Ah, the player...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("I feel you may already know who I am.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Yet, I also know that you have no idea at all.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("I am both a man you seek...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("... nor am I remotely close to him at all.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Perhaps the one you seek is from another time, another place...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("Or mayhaps the other \"him\" never existed to begin with.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Who's to say? Ha ha...") with dissolve
                pause

            "Where am I?":
                hide text with dissolve
                show text _("Ah, the player...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("You are exactly where you wanted to be.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("Granted, I cannot control any of the individuals here...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("The television's decision to step away is his own.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("Of course, no choice made here will matter in the end.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Your connection with this world is minimal at best...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("... limited to the screen that binds you.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(2.0, hard=True)
                show text _("You, too, wish for a freedom that you cannot attain. Ha ha...") with dissolve
                pause

        hide text with dissolve
        pause 0.5
        menu:
            "Can I see you?":
                $ renpy.pause(1.0, hard=True)
                show text _("That is up to you, in actuality.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("How will you perceive me?") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Perhaps it is worth putting that question to the test.") with dissolve
                pause

            "Wake up":
                $ renpy.pause(1.0, hard=True)
                show text _("Very well.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("You needn't worry... Once you go back to sleep?") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("Everything will be") with dissolve
                pause
                stop music
                show text _("just as you remembered.")
                pause
                scene black
                $ renpy.pause(1.0, hard=True)
                $ renpy.quit()

    scene black with dissolve
    pause 2.0
    show gaster neutral at gastpos_center with Dissolve(1.0)

    if not wdg_bedmeet:
        $ wdg_bedmeet = True
        gaster_wd "WELL NOW."
        show gaster frown with Dissolve(0.5)
        gaster "Ah, {p=0.5}I hope you will {p=0.5}excuse me."
        gaster "I forget {p=0.5}that you are unable {p=0.5}to understand that language."
        show gaster side
        gaster "But perhaps, {p=0.5}You could remember {p=0.5}if you were to scroll up."
        gaster "Nevertheless..."
        show gaster smile with Dissolve(0.5)
        gaster "Are you {p=0.5}satisfied?"
        show gaster smilee
        gaster "Tell me. {p=0.5}What am I {p=0.5}to you?"
        menu:
            gaster_rq "Tell me.\nWhat am I\nto you?"
            "W.D. Gaster":
                show gaster side
                gaster_wd "THAT THEORY {p=0.5}PERSISTS AS ALWAYS."
            "A god":
                show gaster side
                gaster_wd "YOU GIVE ME {p=0.5}FAR TOO MUCH CREDIT."
            "A part of the survey program":
                show gaster side
                gaster_wd "I SUPPOSE I DO {p=0.5}SURVEY YOU PLENTY."
            "Mike":
                show gaster side
                gaster_wd "SURELY, {p=0.5}YOU MUST BE JOKING."
        show gaster neutral
        gaster "Your answer {p=0.5}differs from before."
        show gaster neutrale
        gaster "Or perhaps {p=0.5}you do not remember {p=0.5}the time before."
        show gaster neutral
        gaster "Regardless, {p=0.5}Your theories {p=0.5}will always entertain me."
    
        pause 1.0
        menu:
            "What happened with Spamton?":
                if spam.lp > 0 or spam.fp > 0:
                    $ renpy.notify("+♡")
                    if spam.lp > 0:
                        $ spam.lp -= 5
                    if spam.fp > 0:
                        $ spam.fp -= 5
                play sfx hypnosis
                show gaster frowns
                gaster "You ask me {p=0.5}about the e-mail?"
                gaster "Well."
                pause 1.0
                show gaster smile with Dissolve(0.5)
                gaster "We once met {p=0.5}in passing."
                gaster "He mistook me for {p=0.5}someone else."
                show gaster smilee
                gaster "Similar as you take me for {p=0.5}the very same."
                show gaster frowns
                gaster "However, {p=0.5}I heard out his plea {p=0.5}regardless."
                show gaster frownse
                gaster "I gifted him {p=0.5}exactly what he desired."
                show gaster frown
                gaster "But for him {p=0.5}it was not enough."
                show gaster frowns
                gaster "Unsurprisingly, {p=0.5}his life did not change."
                gaster "He still lacked {p=0.5}the \"freedom\" he desired."
                show gaster side
                gaster_wd "HILARIOUS."
                show gaster smile
                gaster "I await the day he realizes {p=0.5}his {color=[c_kindness]}freedom{/color} {p=0.5}is already his own."

            "Where did Tenna go?":
                if ten.lp > 0 or ten.fp > 0:
                    $ renpy.notify("+♡")
                    if ten.lp > 0:
                        $ ten.lp -= 5
                    if ten.fp > 0:
                        $ ten.fp -= 5
                play sfx hypnosis
                show gaster frowns
                gaster "You ask me {p=0.5}about the television?"
                gaster "Well."
                pause 1.0
                show gaster frown with Dissolve(0.5)
                gaster "I do not know {p=0.5}where he resides."
                show gaster frowne
                gaster "But he is surely {p=0.5}lost."
                pause 0.5
                show gaster frowns
                gaster "You should know {p=0.5}when he first arrived here..."
                gaster "He was in {p=0.5}dire disrepair."
                show gaster side
                gaster "By all means, {p=0.5}he should have perished."
                show gaster neutral
                gaster "He has lost sight {p=0.5}of who he is."
                gaster "He has lost {p=0.5}nearly all hope."
                show gaster smile
                gaster "But he woke up, {p=0.5}restored his form, {p=0.5}and continued to exist."
                gaster "Perhaps even he {p=0.5}does not know why."
                gaster "So, {p=0.5}he remains."
                show gaster smilee
                gaster_wd "HOW {p=0.5}INSPIRING."

            "Who is Mike?" if mke_date:
                if mke.fp > 0:
                    $ mke.fp -= 5
                    $ renpy.notify("+♡")
                elif mke.lp > 0:
                    $ mke.lp -= 5
                    $ renpy.notify("+♡")
                play sfx hypnosis
                show gaster frowns
                gaster "Are you asking on behalf {p=0.5}of the die?"
                gaster "Well."
                pause 1.0
                show gaster frown with Dissolve(0.5)
                gaster "I have no more information for you {p=0.5}than I gave to him."
                show gaster frowns
                gaster "I am not of this world. {p=0.5}I merely observe."
                show gaster frownse
                gaster "You and I are {p=0.5}alike {p=0.5}in this way."
                show gaster neutral
                gaster "But I can tell you {p=0.5}the shadow in your pocket {p=0.5}was a gift."
                show gaster smile
                gaster "I gifted him {p=0.5}a similar object {p=0.5}as the one I gave you."
                show gaster neutral
                gaster "But the answers it holds {p=0.5}are interpretive."
                show gaster side
                gaster "Where will it {p=0.5}guide you?"
                gaster "What will it {p=0.5}give you?"
                show gaster smile
                gaster "That is yours {p=0.5}to decide."
                gaster "For it always {p=0.5}provides the same answer."
                show gaster smilee
                gaster_wd "THE MEANING OF FATE {p=0.5}IS UP TO THE BEHOLDER."

        pause 1.0
        show gaster frowns with Dissolve(0.5)
        gaster "Show me, player."
        show gaster neutrale
        gaster "What do you {p=0.5}see here?"
        show gaster smile
        gaster "I do not mean {p=0.5}to judge."
        gaster "I am simply {p=0.5}curious."
        show gaster smilee
        gaster "What brings you {p=0.5}to a place such as this?"
        show gaster frowns
        gaster "Knowing your love {p=0.5}is wasted?"
        gaster "Knowing your choices {p=0.5}mean nothing?"
        show gaster frownse
        gaster "Knowing the end {p=0.5}will always be the same?"
        show gaster side
        gaster "This world {p=0.5}is a dream."
        gaster "This world {p=0.5}is an illusion."
        gaster "This world {p=0.5}was never supposed to exist."
        show gaster smilee
        gaster "You {p=0.5}were never supposed to exist."
        gaster "And yet {p=0.5}you do anyway."
        show gaster laugh
        gaster "Isn't that so {p=0.5}fascinating?"
        show gaster smile
        gaster "All of you {p=0.5}clinging {p=0.5}to what was never meant to be."
        show gaster frownse
        gaster "Clinging {p=0.5}to a sliver of hope."
        gaster "Clinging {p=0.5}to life."
        show gaster laugh
        gaster_wd "VERY {p=0.5}VERY {p=0.5}INTERESTING."
        show gaster smile
        gaster "Even {p=0.5}with nothing left"
        gaster "Even {p=0.5}at your lowest"
        gaster "Even {p=0.5}in the face of death"
        show gaster smilee
        gaster "You persist."
        gaster "You refuse."
        show gaster side
        gaster "Perhaps {p=0.5}this dream..."
        gaster "Provided you with more {p=0.5}than I expected."
        pause 1.0
        show gaster smile with Dissolve(0.5)
        gaster "I want you {p=0.5}to show me..."
        gaster "Prove to me {p=0.5}your purpose."
        gaster "Prove to me {p=0.5}your worth."
        show gaster smilee
        gaster "Prove to me {p=0.5}{color=[c_passion]}your Passion{/color}."
        show gaster neutral
        gaster "I can see {p=0.5}it exists."
        show gaster smilee
        gaster "Continue utilizing it."
        show gaster laugh
        gaster "Push it {p=0.5}to its very limits."
        $ quick_menu = False
        play sfx disappear
        scene black
        stop music
        $ renpy.pause(3.0,hard=True)
        scene junkyard4 with Dissolve(1.0)
        pause 1.0
        play sfx plop
        pause 0.5
        $ quick_menu = True
        "As you woke up,{w=0.2} you rolled over onto a dull rock."
        play sfx sparkleglock
        show itemframe i_redshard3 at truecenter with easeinbottom
        if vex_natennuh:
            "It looked like a crystal,{w=0.2} kind of like the one you got from \"Mr. Natennuh.\""
        else:
            "It looked like a crystal,{w=0.2} kind of like the one you got from \"Not Tenna.\""
        "You're certain it wasn't there before you took a nap."
        play sfx item
        hide itemframe
        $ inventory.append(itm_redshard3)
        "You picked up the red shard.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        "Although,{w=0.2} the moment you touched it..."
        stop music
        scene black
        "Something overcame your senses."
        jump memoryshard3


######################################################
##### AFTER THE INTRO
    else:
        $ quick_menu = True
        gaster "Welcome back."
        show gaster neutrale
        gaster "Your return was {p=0.5}inevitable."
        show gaster neutral

        menu wdg_menu:
            rq "What will you do?"
            "Talk":
                jump wdg_talk

            "Act":
                menu wdg_act:
                    rq "Act"
                    "Reset the dream":
                        $ wdg_talkingto = True
                        call gaster_reset from _call_gaster_reset
                        $ wdg_talkingto = False
                        jump wdg_menu

                    "Wake up":
                        pause 1.0
                        scene black with dissolve
                        gaster "Do as you wish."
                        gaster "Live well knowing {p=0.5}the moment you {p=0.5}shut your eyes again..."
                        gaster "Everything will be"
                        stop music
                        $ renpy.choice_for_skipping()
                        $ quick_menu = False
                        gaster "just as you remembered."
                        $ renpy.pause(1.0, hard=True)
                        $ renpy.quit()
                    
                    "Return":
                        jump wdg_menu
                
            "Go back to sleep":
                gaster "Sleep {p=0.5}as long as you need."
                gaster "But know {p=0.5}you cannot sleep {p=0.5}for eternity."
                play sfx disappear
                scene black
                stop music
                $ quick_menu = False
                $ renpy.pause(3.0, hard=True)
                show junkyard4
                play music dump
                jump ex_mattroom


######################################################
##### TALKING INTERACTION
default wdg_convo = 0 # random roll when you hit "talk"
default wdg_random = False # refreshed for randomization

default wdg_convo1 = False # brought up reality
default wdg_convo2 = False # brought up memoryshards
default wdg_convo3 = False # brought up passion
default wdg_convo4 = False # brought up mike

default wdg_mikecheck = False # if seen new mike text (when found mike)

label wdg_talk:
    ## check what player hasn't seen yet
    if not wdg_convo1:
        $ wdg_convo = 1
    elif not wdg_convo2:
        $ wdg_convo = 2
    elif not wdg_convo3:
        $ wdg_convo = 3
    elif mke_date and not wdg_mikecheck:
        $ wdg_convo = 4
    elif not wdg_convo4:
        $ wdg_convo = 4
    elif wdg_random:
        $ wdg_random = False # reset randomization
    else:
        $ wdg_convo = 0 # reset number

    ## your reality (haha)
    if wdg_convo == 1:
        $ wdg_convo1 = True
        pause 1.0
        show gaster frownse with Dissolve(1.0)
        gaster "You recognize {p=0.5}none of this is {p=0.5}real,"
        gaster "Don't you?"
        show gaster neutrale
        gaster "It never has been."
        gaster "It never will be."
        show gaster side
        gaster "Such is the state {p=0.5}of our separated Worlds."
        show gaster smile
        gaster "An illusion {p=0.5}parallel to your state of mind."
        show gaster smilee
        gaster "A dream {p=0.5}that cannot manifest in Light."
        gaster "Two sides of the same coin {p=0.5}that neither do nor don't co-exist."
        show gaster frowns
        gaster "Ha ha."
        show gaster laugh
        gaster_wd "YOU DON'T UNDERSTAND, {p=0.5}DO YOU?"

    ## memoryshards
    elif wdg_convo == 2:
        $ wdg_convo2 = True
        pause 1.0
        show gaster neutrale with Dissolve(1.0)
        gaster "Perhaps you have seen {p=0.5}the colored shards."
        show gaster smilee
        gaster "Yes, {p=0.5}there are three kinds."
        show gaster side
        gaster "The red star, {p=0.5}the green heart, {p=0.5}the blue cube."
        show gaster smile
        gaster "They are my creation, {p=0.5}you should know."
        gaster "When whole, {p=0.5}they represent {p=0.5}a beloved memory."
        show gaster frown
        gaster "But if those beloved memories {p=0.5}bring foul thoughts..."
        gaster "The shard will shatter {p=0.5}into several parts."
        show gaster frowns
        gaster "The broken shards {p=0.5}can only recall {p=0.5}the most painful of times."
        show gaster frownse
        gaster "The memory's joy {p=0.5}has been forever tainted."
        show gaster side
        gaster_wd "TRULY A FATE {p=0.5}WORSE THAN DEATH."

    ## passion
    elif wdg_convo == 3:
        $ wdg_convo3 = True
        pause 1.0
        show gaster neutrale with Dissolve(1.0)
        gaster "{color=[c_passion]}Passion{/color} {p=0.5}intrigues me so."
        show gaster smile
        gaster "What does {p=0.5}it mean?"
        gaster "What does {p=0.5}it represent?"
        show gaster smilee
        gaster "Perhaps it is {p=0.5}love."
        gaster "Perhaps it is {p=0.5}{color=[c_star]}Determination{/color}."
        show gaster frowns
        gaster "Perhaps it is {p=0.5}a mix of the two."
        show gaster frown
        gaster_wd "THE WHITE DUST {p=0.5}COMBINED WITH THE RED BLOOD..."
        show gaster frownse
        gaster "A life born {p=0.5}from unfortunate circumstance?"
        show gaster neutral
        gaster "Like a work of art {p=0.5}unlike anything else..."
        pause 1.0
        show gaster smilee with Dissolve(1.0)
        gaster "{color=[c_passion]}You{/color} are {p=0.5}invaluable beyond compare."

    ## mike
    elif wdg_convo == 4:
        $ wdg_convo4 = True
        if mke_date:
            $ wdg_mikecheck = True
            pause 1.0
            show gaster frownse with Dissolve(1.0)
            gaster "I see you have met {p=0.5}the other shadow."
            show gaster side
            gaster "Ha ha. {p=0.5}He doesn't keep his mouth shut, {p=0.5}does he?"
            show gaster laugh
            gaster_wd "HOW {p=0.5}INTERESTING."
            show gaster smile
            gaster "It does not {p=0.5}concern me."
            show gaster smilee
            gaster "It is rather {p=0.5}entertaining."
            show gaster frowns
            gaster "What he seeks {p=0.5}cannot be found."
            show gaster neutral
            gaster "As much as what you desire {p=0.5}cannot be."
            show gaster neutrale
            gaster "Perhaps if you were to {p=0.5}seek a compromise..."
            show gaster side
            gaster "Alas..."
            gaster_wd "WHAT AN {p=0.5}UNFORTUNATE PAIR."
        else:
            pause 1.0
            show gaster smile with Dissolve(1.0)
            gaster "There is another {p=0.5}you have yet to meet."
            show gaster smilee
            gaster "Were you {p=0.5}aware of this?"
            gaster "One for each {p=0.5}of the three colored shards..."
            show gaster neutrale
            gaster "I am certain {p=0.5}you can find this person {p=0.5}if you so desired."
            show gaster side
            gaster "Perhaps you should inspect {p=0.5}any boxes you find {p=0.5}hidden amongst the scenery."
            gaster "Perhaps you should inspect {p=0.5}a game within a game."
            gaster "Perhaps there is {p=0.5}a console that turns yellow {p=0.5}when you get near."
            show gaster laugh
            gaster_wd "OR PERHAPS NOT?"

    ## if all seen, randomly generate
    elif wdg_convo == 0:
        $ wdg_random = True
        $ wdg_convo = renpy.random.randint(1,4)
        jump wdg_talk

    show gaster neutral
    jump wdg_menu