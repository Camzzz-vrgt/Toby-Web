############################################################################################################
################## TENNA MEMORYSHARDS

######################################################
##### TENNA AND SPAMTON MEET
label memoryshard1:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind fadein 1.0
    $ renpy.pause(2.0, hard=True)
    tenna_sub "How did things turn out like this...?"
    tenna_sub "If only he hadn't left me..."
    tenna_sub "My old partner."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play ambiance cityQ fadein 1.0
    play music cyberworldM fadein 1.0
    scene grey
    show crtoverlay zorder 99
    show mscg1 001
    with Dissolve(2.0)
    alt "Tenna and a Pippins are standing side-by-side, having a conversation in Cyber City."
    tenna "Ever since they brought that laptop home,{w=0.2} it's been so congested around here."
    tenna "I feel like I barely have the space to breathe,{w=0.2} haha!"
    show mscg1 002
    gp "That's not exactly helped by the fact that you're workin' yourself half to death over there,{w=0.2} either."
    gp "Ya oughta start takin' breaks more often,{p=0.2} Mr. Tenna..."
    show mscg1 003
    tenna "Like I've got the time for that."
    show mscg1 002
    gp "Well,{w=0.2} you could...{w=0.2} Y'know.{w=0.5} Make the time."
    gp "Y'know,{w=0.5} like most people would do in your situation?"
    show mscg1 003
    tenna "Yeah,{w=0.2} and then what?{p=0.5}{noalt}*{/noalt} Be unavailable when the Dreemurrs and Holidays get together and wanna watch TV?"
    play sfx plop
    show mscg1 004
    if persistent.glitches:
        pass
    else:
        with vpunch
    tenna "I can't afford to do that!{w=0.2} I'd be ruined!{p=0.5}{noalt}*{/noalt} What if they think I'm broken?!"
    show mscg1 005
    gp "Oh, hey, c'mon, Mr. Tenna,{w=0.2} you know that's not what I..."
    show mscg1 006
    spamglass "Hey,{w=0.2} you."
    show mscg1 007
    alt "A third person has walked up to where Pippins and Tenna were talking."
    $ renpy.pause(2.0, hard=True)
    show mscg1 008
    tenna "... {w=0.5}Are you talking to me?"
    show mscg1 009
    spamglass "What do you think?"
    show mscg1 010
    spamglass "I saw your show the other night.{p=0.2}{noalt}*{/noalt} Pretty entertaining."
    show mscg1 011
    $ renpy.pause(2.0, hard=True)
    show mscg1 012
    alt "Pippins and Tenna exchange a dead silent glance."
    $ renpy.pause(2.0, hard=True)
    show mscg1 010
    $ renpy.pause(1.0, hard=True)
    show mscg1 013
    spamglass ".{w=0.2}.{w=0.2}."
    show mscg1 014
    spamglass "...{w=0.2} so,{w=0.2} anyway."
    spamglass "I've got places to be--{nw=0.2}"
    show mscg1 015
    tenna "W-{w=0.1} wait.{p=0.2}{noalt}*{/noalt} You, ah--"
    play sfx whip
    show mscg1 016 at jump
    tenna "Would you wanna be on it yourself?"
    show mscg1 017
    $ renpy.pause(2.0, hard=True)
    spamglass "..."
    $ renpy.pause(1.0, hard=True)
    tenna "..."
    $ renpy.pause(2.0, hard=True)
    show mscg1 018
    spamglass "...{w=0.2} Eh.{w=0.2} Sure.{p=0.5}{noalt}*{/noalt} Why the hell not?"
    show mscg1 019
    tenna "R-{nw=0.1}"
    show mscg1 at jump
    extend " really?!"
    hide mscg1
    spamglass "Here."
    show mscg1 020 with easeintop
    spamglass "Shoot me an e-mail later."
    hide mscg1
    show black
    with Dissolve(1.0)
    $ renpy.pause(1.0, hard=True)
    show mscg1 021 with Dissolve(1.0)
    alt "Tenna is now holding a business card. It has some information details and in the right corner is a cartoonish car."
    alt "The information reads, \"Spamton G. Spamton: #1 SALESMAN. spamtongspam@mail.com. 555-094-1059.\""
    $ renpy.pause(3.0, hard=True)
    show mscg1 022
    tenna "...{w=0.2} Hey,{w=0.2} Pippins?"
    show mscg1 023
    gp "Yep?"
    show mscg1 024
    tenna "What's an \"e-mail\"?"
    stop music fadeout 2.0
    stop ambiance fadeout 2.0
    hide mscg1 with Dissolve(2.0)
    $ renpy.pause(2.0, hard=True)

    ## may change this later for re-watching
    jump nmt_returnshard

### RETURN TO NOT MR TENNA'S SHOP
label nmt_returnshard:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene black
    show junkyard
    show tenshop e_frown at center
    show tenshop at jump
    tenna "Whoa, hey,{w=0.2} [persistent.mc]!{p=0.5}{noalt}*{/noalt} You alright over there?"
    show tenshop e_awkward
    tenna "Oh,{w=0.2} there you are!"
    tenna "You were staring at that thing for so long and didn't even hear me call your name..."
    pause 1.0
    "You shove the red shard into your pocket."
    play music greenroom
    jump shop_nmt


######################################################
##### TENNA OFFERS THE DEAL
label memoryshard2:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    tenna_sub "It took a little sweet talk..."
    tenna_sub "But just when I had finally...{w=0.5} finally?{w=0.2} Haha--"
    tenna_sub "Gotten him to sign the deal."
    tenna_sub "He suddenly had to take a phone call."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music flashback fadein 1.0
    scene darkgrey
    show crtoverlay zorder 99
    show mscg2 001
    with Dissolve(2.0)
    alt "Spamton and Tenna sit across from each other at a table."
    tenna "It'll be easy,{w=0.2} I promise!"
    tenna "When have I EVER led you astray?"
    show mscg2 002
    spamadd "Last week."
    show mscg2 003
    tenna "Wh--{p=0.5}{noalt}*{/noalt} Oh,{w=0.2} what,{w=0.2} because I gave you the wrong directions ONE time?"
    show mscg2 004
    tenna "Geez,{w=0.2} haha!{p=0.5}{noalt}*{/noalt} You really do hold a grudge,{w=0.2} Spammy!"
    show mscg2 005
    spamadd "It made me an hour late to the film set,{w=0.2} you fu{nw=0.2}"
    show mscg2 006
    tenna "Yeah, yeah, yeah--{w=0.2} but it's okay now,{w=0.2} right?{p=0.5}{noalt}*{/noalt} So what does it matter?"
    show mscg2 007
    spamadd "..."
    $ renpy.pause(1.0, hard=True)
    show mscg2 008
    tenna "Anyway,{w=0.2} as I was saying..."
    hide mscg2
    $ renpy.pause(0.5, hard=True)
    show mscg2 009 with easeintop
    $ renpy.pause(1.0, hard=True)
    tenna "All you have to do is sign your name."
    show mscg2 004
    tenna "Super simple!"
    show mscg2 010
    alt "Spamton looks away in distress."
    $ renpy.pause(2.0, hard=True)
    tenna "Hey,{w=0.2} now."
    show mscg2 011
    tenna "You know you can trust me,{w=0.2} don't you?"
    show mscg2 012
    tenna "We're partners!{p=0.5}{noalt}*{/noalt} We've been through thick and thin!"
    tenna "Besides,{w=0.2} what's the worst that could happen?"
    show mscg2 013
    $ renpy.pause(1.0, hard=True)
    tenna "It's not like a big shot like you would just drop off overnight over something as silly as this,{w=0.2} haha."
    show mscg2 004
    tenna "People love you!"
    $ renpy.pause(1.0, hard=True)
    show mscg2 012 with Dissolve(0.5)
    tenna "...{w=1} Myself included,{w=0.2} of course."
    tenna "I'd never do something that would hurt you."
    $ renpy.pause(1.0, hard=True)
    show mscg2 013
    $ renpy.pause(2.0, hard=True)
    show mscg2 014
    alt "Spamton reaches for a pen."
    $ renpy.pause(2.0, hard=True)
    show mscg2 015
    alt "Spamton starts to sign his name..."
    $ renpy.pause(2.0, hard=True)
    scene black
    stop music
    play sfx ringring
    $ quick_menu = False
    $ renpy.pause(8.0, hard=True)

    ## may change this later for re-watching
    $ quick_menu = True
    jump tvtime_returnshard

### RETURN TO GAME ROOM (TENNA)
label tvtime_returnshard:    
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene junkyard5 with Dissolve(1.0)
    pause 1.0
    "...{w=0.5} You shove the red shard into your pocket."
    if itm_redshard1 in inventory and itm_redshard2 in inventory and itm_redshard3 in inventory:
        call redtriple from _call_redtriple
    play music dump
    jump ex_gameroom


######################################################
##### TENNA IS ABANDONED
label memoryshard3:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    tenna_sub "I gave him EVERYTHING!{w=0.5} EVERYTHING I HAD!"
    tenna_sub "My LIFE ADVICE!"
    tenna_sub "All.{w=0.2} He had.{w=0.2} To do."
    tenna_sub "Was tell me what his little secret was."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    scene darkgrey
    show crtoverlay zorder 99
    alt "The phone is ringing. Spamton looks terrified."
    play loop ringring
    show mscg3 2-3
    $ renpy.pause(2,hard=True)
    show mscg3 001
    $ renpy.pause(3.95, hard=True)
    show mscg3 5-6
    $ renpy.pause(2,hard=True)
    show mscg3 004
    $ renpy.pause(3.9, hard=True)
    show mscg3 007
    tenna "...?"
    show mscg3 008
    tenna "You doin' alright over there,{w=0.2} big shot?"
    show mscg3 009
    spamadd "{cps=60}I have to take that.{/cps}"
    show black
    stop loop
    play sfx pickup
    $ renpy.pause(1.0, hard=True)
    hide black
    show mscg3 010
    alt "Spamton picks up the phone."
    $ renpy.pause(4.0, hard=True)
    show mscg3 011
    alt "Spamton jolts where he stands."
    $ renpy.pause(3.0, hard=True)
    show mscg3 012
    $ renpy.pause(2.0, hard=True)
    show mscg3 013
    alt "Tenna nervously looks down at the contract."
    $ renpy.pause(1.0, hard=True)
    show mscg3 014
    alt "The contract is half-signed, reading, \"Spamton G. S\""
    $ renpy.pause(2.0, hard=True)
    play sfx runaway
    show mscg3a 15a
    show mscg3 15-16
    tenna "Wh--{w=0.1} Hey!{p=0.5}{noalt}*{/noalt} Where are you going?!"
    hide mscg3a
    $ renpy.pause(0.5, hard=True)
    show mscg3 016:
        xpos 2.0
    with MoveTransition(0.2,leave_time_warp=_warper.easeout)
    hide mscg3
    play music flashback_slow fadein 2.0
    $ renpy.pause(0.5, hard=True)
    show mscg3 017 with easeinleft
    $ renpy.pause(3.0, hard=True)
    play sfx plop
    show mscg3 018 with dissolve
    $ renpy.pause(3.0, hard=True)
    show mscg3 019 with dissolve
    alt "Tenna stands up from his seat and reached towards the phone."
    $ renpy.pause(1.0, hard=True)
    tenna "{cps=25}(Was this what he was keeping from me?){/cps}"
    play sfx step1
    show mscg3 020 with dissolve
    $ renpy.pause(1.0, hard=True)
    tenna "{cps=25}(All those calls he keeps taking?){/cps}"
    show black
    play sfx step2
    $ renpy.pause(1.0, hard=True)
    hide black
    show mscg3 021
    tenna "{cps=20}(Who's on the other line...?){/cps}"
    show black
    play sfx plop
    $ renpy.pause(1.0, hard=True)
    hide black
    show mscg3 022
    tenna "{cps=15}(Does this mean I can finally...?){/cps}"
    stop music
    show mscg3 023
    alt "The other line was silent as Tenna picked up the phone."
    $ renpy.pause(5.0, hard=True)
    scene black
    $ renpy.pause(1.0, hard=True)
    play sfx hangup
    alt "Tenna hangs up the phone aggressively."
    $ renpy.pause(2.0, hard=True)
    tenna "That little freak ripped me off!!"
    $ renpy.pause(2.0, hard=True)

    ## may change this later for re-watching
    jump wdg_returnshard

### RETURN TO MATTRESS ROOM
label wdg_returnshard:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene junkyard4 with Dissolve(1.0)
    pause 1.0
    "...{w=0.5} You shove the red shard into your pocket."
    if itm_redshard1 in inventory and itm_redshard2 in inventory and itm_redshard3 in inventory:
        call redtriple from _call_redtriple_1
    play music dump
    jump ex_mattroom


######################################################
##### TENNA APOLOGIZES (seen after getting all tenna shards)
label memoryshard7:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    tenna_sub "I never wanted to hurt him."
    tenna_sub "But, even still..."
    tenna_sub "I can't believe,{w=0.2} after all this,{w=0.2} I'm..."
    tenna_sub "It feels like I'm actually starting to\nCARE about him."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music greenroomB fadein 1.0
    show crtoverlay zorder 99
    show mscg7 001
    with Dissolve(2.0)
    alt "Tenna is sitting by himself in the TV World green room."
    $ renpy.pause(3.0, hard=True)
    show mscg7 002
    play sfx step1
    $ renpy.pause(1.3,hard=True)
    show mscg7 003
    play sfx2 step2
    alt "Spamton walks on through, not looking at Tenna."
    $ renpy.pause(1.3, hard=True)
    show mscg7 004
    play sfx step1
    tenna "I'm sorry."
    $ renpy.pause(2.0, hard=True)
    show mscg7 005
    tenna "{cps=20}I'm so sorry...{/cps}"
    show mscg7 006
    spamadd "So you claim."
    show mscg7 007
    tenna "{cps=60}I mean it,{w=0.2} really!{/cps}"
    show mscg7 008
    tenna "I just--{w=0.5} {cps=25}got very overwhelmed...{/cps}"
    show mscg7 009
    alt "Spamton doesn't look at Tenna."
    $ renpy.pause(2.0, hard=True)
    show mscg7 010
    tenna "I really do care about you.{p=0.2}{noalt}*{/noalt} So much."
    show mscg7 008
    tenna "I'm the one who asked you out,{w=0.2} aren't I...?"
    show mscg7 011
    tenna "Haha...{w=0.5} I guess that doesn't mean much..."
    show mscg7 012
    alt "Both Tenna and Spamton look at each other."
    $ renpy.pause(3.0, hard=True)
    show mscg7 013
    alt "Tenna sulks."
    $ renpy.pause(2.0, hard=True)
    show mscg7 014
    tenna "I'm sorry,{w=0.2} I'll just go--{nw=0.5}"
    play sfx plop
    show mscg7 015 with vpunch
    spamadd "Wait."
    show mscg7 016
    alt "Tenna looks down at Spamton."
    $ renpy.pause(2.0, hard=True)
    show mscg7 017
    spamadd "I..."
    $ renpy.pause(2.0, hard=True)
    show mscg7 018
    spamadd "Sorry.{p=0.5}{noalt}*{/noalt} For snapping at you."
    spamadd "You...{w=0.5} didn't deserve that."
    show mscg7 019
    spamadd "I've just got...{w=0.5} a lot of shit on my plate,{w=0.2} is all."
    show mscg7 020
    spamadd "That whole thing just made it all boil over."
    $ renpy.pause(2.0, hard=True)
    show mscg7 021
    $ renpy.pause(1.0, hard=True)
    show mscg7 022
    tenna "I wish you would have said something,{w=0.2} haha."
    tenna "I could've helped,{w=0.2} y'know?"
    show mscg7 023
    spamadd "This isn't--"
    show mscg7 018
    $ renpy.pause(2.0, hard=True)
    show mscg7 019
    spamadd "It's not that simple."
    show mscg7 024
    $ renpy.pause(2.0, hard=True)
    show mscg7 022
    tenna "Well...{w=0.5} it could be.{w=0.2} If you just.{w=0.2} Y'know."
    show mscg7 025
    tenna "Told me."
    show mscg7 026
    spamadd "It's NOT that simple."
    show mscg7 022
    tenna "Aha..."
    show mscg7 024
    alt "Tenna struggles to keep it together."
    $ renpy.pause(2.0, hard=True)
    show mscg7 027
    $ renpy.pause(2.0, hard=True)
    play sfx plop
    show mscg7 028
    tenna "C'mon,{w=0.2} now.{p=0.5}{noalt}*{/noalt} We're partners!"
    show mscg7 029
    tenna "You can trust me."
    $ renpy.pause(1.0, hard=True)
    show mscg7 030
    alt "Spamton looks at their joined hands, blushing."
    $ renpy.pause(2.0, hard=True)
    show mscg7 031
    spamadd "I appreciate it,{w=0.2} big guy,{w=0.2} I really do.{p=0.5}{noalt}*{/noalt} But I'm dead serious."
    spamadd "I'll be fine.{w=0.2} I can handle it.{p=0.5}{noalt}*{/noalt} You just keep bein' your dumb, goofy self,{w=0.2} will ya?"
    show mscg7 032
    spamadd "Helps me keep my head on straight."
    show mscg7 033
    tenna "R-{w=0.1} really?{p=0.5}"
    tenna "Sure,{w=0.2} I can definitely do that,{w=0.2} whatever you want me to--!{nw=0.5}"
    play sfx plop
    show mscg7 034 with vpunch
    tenna "Eek--!"
    play sfx bump
    show blackpng
    $ renpy.pause(2.0, hard=True)
    show mscg7 035
    hide blackpng with Dissolve(1.0)
    spamadd "This'll do for now."
    $ renpy.pause(2.0, hard=True)
    show mscg7 036
    alt "Tenna debates for a moment..."
    $ renpy.pause(3.0, hard=True)
    show mscg7 037 with Dissolve(0.2)
    alt "... before he smiles."
    $ renpy.pause(2.0, hard=True)
    stop music fadeout 2.0
    scene black with Dissolve(1.0)
    $ renpy.pause(2.0, hard=True)

    ## may change this later for re-watching
    return

### COMING FROM OTHER SHARDS
label redtriple:
    pause 1.0
    "...{w=0.2} That's strange."
    "The shard drew two things closer to it like a magnet."
    play sfx sparklegem
    show itemframe i_redmem at truecenter with easeinbottom
    pause 1.0
    if ex_memory:
        "All three of the red MemoryShards have connected into one."
    else:
        "All three of the red shards have connected into one."
    "But before you could inspect them any further--"
    scene black
    stop music
    "{noalt}--{/noalt} something overcame your senses again."
    call memoryshard7 from _call_memoryshard7

    ## AUTOSAVE
    $ renpy.save("mainfile")
    
    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    if memsh_location == "ex_gameroom":
        scene junkyard5 with Dissolve(1.0)
    elif memsh_location == "ex_mattroom":
        scene junkyard4 with Dissolve(1.0)
    pause 1.0
    show itemframe i_redmem at truecenter with easeinbottom
    if ex_memory:
        "You glanced down at the MemoryShards."
    else:
        "You glanced down at the red shards."
    show itemframe i_redmemS
    play loop rumble
    "They started to tremble in your hand..."
    pause 2.0
    stop loop
    play sfx soulcrack 
    show itemframe i_redmemSh
    pause 1.0
    if ex_memory:
        "The MemoryShard shattered."
    else:
        "The large red shard shattered."
    pause 0.5
    hide itemframe with easeoutbottom
    pause 0.5
    play sfx plop
    pause 1.0
    "You try to put them back into your pocket,{w=0.2} but now they seem to be repelling each other..."
    "...{w=0.2} You suppose you can put each one in a different pocket."
    pause 0.5
    play music dump
    return



############################################################################################################
################## SPAMTON MEMORYSHARDS

######################################################
##### SPAMTON SNAPS
label memoryshard4:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    if persistent.glitches:
        spamton_sub "YOU'RE THE ONE THAT SHOULD BE HAVING A {noalt}[[Refr3shing n1ghts{/noalt}{alt}refreshing night's{/alt} sleep] IN THE [[Recycling Bin]!!!"
    else:
        spamton_sub "{sc=3}YOU'RE{/sc} THE ONE THAT SHOULD BE HAVING A {noalt}[[Refr3shing n1ghts{/noalt}{alt}refreshing night's{/alt} sleep] IN THE [[Recycling Bin]!!!"
    spamton_sub "EVERYTHING {noalt}IS{/noalt}{alt}is{/alt} HIS"
    spamton_sub "EVERYTHING {noalt}IS{/noalt}{alt}is{/alt} HIS FAULT."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music spamtonS fadein 1.0
    scene grey
    show staticoverlay zorder 99
    show mscg4 001
    with Dissolve(2.0)
    alt "Spamton is in some kind of distress, while Tenna reaches out to him with concern."
    tenna "Don't you think you're overreacting a bit?"
    show mscg4 002
    spamadd "What?{p=0.5}{noalt}*{/noalt} WHAT?"
    show mscg4 003
    spamadd "You can't be SERIOUS right now."
    show mscg4 004
    tenna "It's not that big of a deal!"
    tenna "Stuff like this happens all the time, right?{p=0.5}{noalt}*{/noalt} It'll be super easy to fix,{w=0.2} and{nw=0.2}"
    show mscg4 005
    spamadd "It {noalt}IS{/noalt}{alt}is{/alt} a big deal,{w=0.2} you f{nw=0.5}"
    show mscg4 006
    extend "{cps=25}ffffffffffffffffff{/cps}{nw}"
    if persistent.glitches:
        show mscg4 007 at jump
    else:
        show mscg4 007 at shock
    play sfx spamlaugh
    $ renpy.pause(2.0, hard=True)
    show mscg4 008
    spamadd "Why{w=0.5} do you do this."
    spamadd "Why do you{w=0.5} ALWAYS do this?"
    show mscg4 009
    tenna "Huh?"
    show mscg4 010
    if persistent.glitches:
        spamadd "Every {noalt}$#!$ING{/noalt}{alt}beeping{/alt} time I have a problem,{w=0.2} you just"
    else:
        spamadd "Every {sc=3}$#!$ING{/sc} time I have a problem,{w=0.2} you just"
    show mscg4 011
    spamadd "\"Oh,{w=0.2} don't do that,{w=0.2} Spammy!\"{p=0.5}{noalt}*{/noalt} \"You're just overreacting!\""
    show mscg4 012
    spamadd "\"Don't worry,{w=0.2} big shot!\"{p=0.5}{noalt}*{/noalt} \"Being upset is a waste of time!\""
    show mscg4 013
    tenna "I didn't.{w=0.2}.{w=0.2}.{nw}"
    play sfx whipcrack
    if persistent.glitches:
        show mscg4 014 at jump
    else:
        show mscg4 014 at shock
    if persistent.glitches:
        spamadd "You DID,{w=0.2} so SHUT THE {noalt}f$!#]{/noalt}{alt}beep{/alt} UP."
        spamadd "You're always just--{w=0.5} shutting down EVERYTHING I say." 
        spamadd "YOU DON'T EVEN REALIZE WHAT {noalt}YOU''rE{/noalt}{alt}you're{/alt} DOING."
    else:
        spamadd "You DID,{w=0.2} so {sc=3}SHUT THE f$!#] UP.{/sc}"
        spamadd "You're always just--{w=0.5} shutting down {sc=3}EVERYTHING{/sc} I say."
        spamadd "{sc=3}YOU DON'T EVEN REALIZE WHAT YOU''rE DOING.{/sc}" # SELF VOICING FIX
    show mscg4 015
    tenna "I didn't know that you--{nw=0.1}"
    if persistent.glitches:
        show mscg4 016 at jump
        spamadd "SHUT!!!!!!!!!!!!{nw=0.2}"
        show mscg4 016 at jump
        extend "{p=0}{noalt}*{/noalt} U P !!!!!!!!!!!!!!"
    else:
        show mscg4 016 at shock
        spamadd "{sc=5}SHUT!!!!!!!!!!!!{/sc}{nw=0.2}"
        show mscg4 016 at shock
        extend "{p=0}{noalt}*{/noalt} {sc=5}U P !!!!!!!!!!!!!!{/sc}"
    show mscg4 017
    $ renpy.pause(2.0, hard=True)
    tenna "..."
    show mscg4 018 9a
    alt "Spamton breathes heavily."
    $ renpy.pause(1.8, hard=True)
    show mscg4 019
    $ renpy.pause(2.0, hard=True)
    show mscg4 020
    spamadd "I thought"
    show mscg4 021
    spamadd "you cared."
    $ renpy.pause(2.0, hard=True)
    show mscg4 022 with Dissolve(0.5)
    $ _history = False
    tenna "I{nw}"
    $ _history = True
    tenna_shh "I{fast}.{w=0.2}.{w=0.2}."
    $ renpy.pause(1.0, hard=True)
    show mscg4 020
    $ renpy.pause(2.0, hard=True)
    show mscg4 023 with Dissolve(0.2)
    alt "Spamton loses his smile in a panic."
    $ renpy.pause(2.0, hard=True)
    scene black
    spamadd "...{w=0.5} tch."
    stop music fadeout 1.0
    alt "Spamton runs away."
    play sfx runaway
    $ renpy.pause(4.0, hard=True)

    ## may change this later for re-watching
    jump spam_returnshard

### RETURN TO SPAMTON SHOP
label spam_returnshard:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene black
    show spamshop_bg2 zorder 0
    show spamshop_bg zorder 2
    if persistent.glitches:
        show spamshop_glitchNo zorder 1:
            xpos 1460
    else:
        show spamshop_glitch zorder 1:
            xpos 1460
    show spamshop_spamton e_neutral at left zorder 3
    if persistent.glitches:
        show spamshop_spamton e_eyes
    else:
        show spamshop_spamton e_eyes at shakingcg
    spamton "[[Wake up! Wake up!] ALREADY!!!"
    show spamshop_spamton at yreset
    spamton "[persistent.mc!u] !!!!{p=0.2}{noalt}*{/noalt} WHAT THE {noalt}[[h3ck]{/noalt}{alt}heck{/alt}???"
    spamton "I THOUGHT YOU NEARLY {noalt}PERISSSHED{/noalt}{alt}perished{/alt} ONn ME!"
    if persistent.glitches:
        show spamshop_spamton e_laugh
    else:
        show spamshop_spamton e_laughg
    spamton "YIKES!!!!!!!!{p=0.5}{noalt}*{/noalt} YOU'D THINK THAT [[decorative rocks] WAS SOME KIND OF [[Memory Sticks] [[HALF OFF!!]"
    pause 1.0
    "You shove the green shard into your pocket."
    play music dialtone
    jump shop_spam


######################################################
##### TENNA ADMITS NOT LIKING SPAMTON
label memoryshard5:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    spamton_sub "WE DON'T NEED ANYONE ELSE!!!"
    spamton_sub "WE DON'T NEED [[[[Easels]] or [[[[CRTs]]!{w=0.2} WE DON'T NEED ANY [[[[Man, Woman, or Child]] [[[[At Half Price]]!!"
    spamton_sub "..."
    spamton_sub "{color=[c_vessel]}[[{space=80}]{/color}{alt}redacted{/alt}!!!{w=0.5} DON'T BELIEVE [[[[Anything You See On TV!]]"
    spamton_sub "THE MAN'S A CRIMINAL,{w=0.2} I TELL YOU!!"
    spamton_sub "A CRIMINAL!!"
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music glowingsnow fadein 1.0
    scene darkgrey
    show staticoverlay zorder 99
    show mscg5 001
    with Dissolve(1.0)
    alt "Tenna and Spamton are lounging together on a couch, both holding drinks of some sort."
    tenna "Y'know,{w=0.5} it's funny."
    show mscg5 002
    tenna "I never used to like you at all,{w=0.2} haha!"
    show mscg5 003
    $ renpy.pause(2.0, hard=True)
    spamadd_shh ".{w=0.2}.{w=0.2}."
    show mscg5 004
    spamadd "...{w=0.2} What?"
    show mscg5 005
    tenna "Remember the time we first met?"
    show mscg5 006
    tenna "I was losing my mind.{p=0.5}{noalt}*{/noalt} Everything was starting to go downhill for me,{w=0.2} ahah."
    show mscg5 007
    tenna "But then you --{w=0.2} YOU,{w=0.2} of ALL PEOPLE! --{w=0.5} happened to just..."
    show mscg5 008
    tenna "Walk up to me and tell me my show was...{w=0.5} entertaining?"
    tenna "Hahaha.{p=0.5}{noalt}*{/noalt} It was so..."
    show mscg5 009
    alt "Tenna looks at his glass solemnly."
    $ renpy.pause(2.0, hard=True)
    show mscg5 010
    tenna "I knew asking you to be on was gonna be the best decision of my life!"
    show mscg5 011
    tenna "It was like an angel just fell right into my lap!{p=0.5}{noalt}*{/noalt} So...{w=0.2} thank you for that."
    show mscg5 012
    tenna "You made my life worth living,{w=0.2} Spammy."
    alt "Spamton has a look of distress across his face."
    $ renpy.pause(2.0, hard=True)
    show mscg5 013
    tenna "Hahaha!{p=0.2}{noalt}*{/noalt} What's THAT expression for?"
    play sfx plop
    show mscg5 014
    tenna "Intimidated by how handsome I look when I'm being honest?"
    show mscg5 015
    spamadd "NO,{w=0.2} not THAT, you--{nw=0.2}"
    show mscg5 016
    tenna "Hey,{w=0.2} hey,{w=0.5} while I'm thinking of it..."
    show mscg5 017
    tenna "I had something I wanted to ask you."
    show mscg5 018
    $ renpy.pause(1.0, hard=True)
    scene black
    with Dissolve(0.2)
    $ renpy.pause(1.0, hard=True)
    play sfx cloth
    alt "Tenna scoots closer to Spamton."
    $ renpy.pause(2.0, hard=True)
    tenna "Would you..."
    stop music fadeout 2.0
    $ renpy.pause(4.0, hard=True)

    ## may change this later for re-watching
    jump spam2_returnshard

### RETURN TO DIRT LUMP ROOM
label spam2_returnshard:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene junkyard3 with Dissolve(1.0)
    pause 1.0
    "...{w=0.5} You shove the green shard into your pocket."
    if itm_greenshard1 in inventory and itm_greenshard2 in inventory and itm_greenshard3 in inventory:
        call greentriple from _call_greentriple
    play music dump
    jump ex_lumproom


######################################################
##### ACCEPTS PROPOSAL
label memoryshard6:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    spamton_sub "ONLY TO {noalt}[[$!$!]{/noalt}{alt}beep{/alt} ME OVER RIGHT AT THE [[Good part]!?"
    spamton_sub "WHAT ARE YOU,{w=0.2} A [[Gameshow Host]?!"
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music glowingsnowS
    show staticoverlay zorder 99
    show mscg6 001
    with Dissolve(3.0)
    alt "Tenna and Spamton are lounging together on a couch, both holding drinks of some sort."
    $ renpy.pause(1.0, hard=True)
    spamadd "You...{w=0.5} huh?"
    show mscg6 002
    tenna "I'm serious."
    show mscg6 003
    $ renpy.pause(2.0, hard=True)
    show mscg6 004
    spamadd "...{w=0.2} You've had too damn much to drink."
    show mscg6 005
    tenna "Hahaha!{p=0.2}{noalt}*{/noalt} No, no,{w=0.2} really!"
    show mscg6 006
    tenna "It's...{w=0.5} been on my mind a lot lately."
    show mscg6 007
    spamadd "What,{w=0.2} so you can use my fame for yourself even more?"
    show mscg6 008
    tenna "Wha--{w=0.2}{cps=60} No!{w=0.2} N-{w=0.1} no, not that!!{p=0.2}{noalt}*{/noalt} Never that!{/cps}"
    show mscg6 009
    tenna "{cps=25}I really do care,{w=0.5} I promise...{/cps}"
    show mscg6 010
    alt "Spamton glances off to the side with uncertainty."
    $ renpy.pause(3.0, hard=True)
    spamadd ".{w=0.2}.{w=0.2}."
    show mscg6 011
    spamadd "I wanna trust you,{w=0.5} big guy.{p=0.5}{noalt}*{/noalt} I really do."
    show mscg6 012
    spamadd "But you do realize everything about you is a neon red flag,{w=0.2} right?"
    show mscg6 013
    tenna "Is it the jacket?{nw=0.5}"
    show mscg6 014
    extend "{p=0}{noalt}*{/noalt} I can get a different colored one,{w=0.2} you know!"
    show mscg6 015
    spamadd "No, you stupid--{nw=0.5}"
    show mscg6 016
    if persistent.glitches:
        show mscg6a 016a at jump
    else:
        show mscg6a 016a at shock
    play sfx spamlaugh
    alt "Spamton laughs heartily at Tenna's remark."
    $ renpy.pause(2.0, hard=True)
    hide mscg6a
    show mscg6 017
    spamadd "You know what?{p=0.5}{noalt}*{/noalt} You're right."
    show mscg6 018
    spamadd "You're too damn stupid to screw me over."
    show mscg6 019
    alt "Tenna looks back at Spamton with confusion."
    $ renpy.pause(2.0, hard=True)
    show mscg6 020
    spamadd "So,{w=0.5} sure."
    scene black
    spamadd "Why the hell not?"
    stop music fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    ## may change this later for re-watching
    jump spam3_returnshard

### RETURN TO EYE ROOM / PREV STARWALKER ROOM
label spam3_returnshard:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene junkyard6 with Dissolve(1.0)
    pause 1.0
    "...{w=0.5} You shove the green shard into your pocket."
    if itm_greenshard1 in inventory and itm_greenshard2 in inventory and itm_greenshard3 in inventory:
        call greentriple from _call_greentriple_1
    play music dump
    jump ex_starroom


######################################################
##### SPILLED COFFEE (seen after getting all spam shards)
label memoryshard8:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    spamton_sub "They're gonna regret leaving me."
    spamton_sub "If this all works out,{w=0.2} I won't even need Him anymore."
    spamton_sub "Soon,{w=0.5} I'll be a big shot,{w=0.2} all on my own."
    spamton_sub "So long as I don't...{w=0.5} get too attached."
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    play music greenroom fadein 1.0
    show staticoverlay zorder 99
    alt "Spamton is walking down a hall at Tenna's studio."
    show mscg8 001
    with Dissolve(0.5)
    play sfx step1
    show mscg8 002
    $ renpy.pause(1.0, hard=True)
    play sfx2 step2
    show mscg8 001
    $ renpy.pause(1.0, hard=True)
    play sfx step1
    show mscg8 003
    $ renpy.pause(1.0, hard=True)
    play sfx plop
    if persistent.glitches:
        show mscg8 004
    else:
        show mscg8 004 with vpunch
    $ renpy.pause(0.5, hard=True)
    alt "Someone bumped into Spamton, spilling coffee onto his face and clothes."
    show mscg8 005
    tenna "Whoops!{w=0.2} Sorry about that!"
    show mscg8 006
    spamglass "Oh, gimmie a break!{w=0.2} You did that on purpose!"
    show mscg8 007
    tenna "What?{p=0.2}{noalt}*{/noalt} Why would I do that??"
    show mscg8 008
    spamglass "I SAW you--{nw=0.2}"
    show mscg8 009
    tenna "It was an accident!{w=0.2} Promise!{p=0.2}{noalt}*{/noalt} TV's honor!"
    show mscg8 010
    tenna "Look, I,{w=0.2} uh--{w=0.5} why don't I help you with that?"
    show mscg8 011
    spamglass "Get lost."
    show mscg8 012
    spamglass "I'll deal with it myself."
    show mscg8 013
    tenna "H-{w=0.1} hey!"
    show mscg8 014
    tenna "You're the guest at MY studio and this is MY fault,{w=0.2} so let me help!"
    show mscg8 015
    spamglass "Hell no."
    show mscg8 016
    tenna "Here--{w=0.2} there's a sink in here."
    show mscg8 017
    spamglass "What the--{w=0.2} HEY!"
    play sfx dooropen
    show blackpng
    show mscg8 018
    $ renpy.pause(1.0, hard=True)
    play sfx doorclose
    alt "Tenna dragged Spamton into the break room."
    $ renpy.pause(2.0, hard=True)
    hide blackpng with Dissolve(0.5)
    spamglass "Don't you have other shit to do?"
    show mscg8 019
    tenna "Here."
    show mscg8 020
    tenna "I take it you DEFINITELY don't want me touching your face,{w=0.2} but..."
    show mscg8 021
    alt "Spamton stares at the wet towel Tenna is offering him."
    $ renpy.pause(2.0, hard=True)
    show mscg8 022
    alt "Spamton deadpans at Tenna."
    $ renpy.pause(2.0, hard=True)
    play sfx whip
    show mscg8 023
    if persistent.glitches:
        pass
    else:
        with vpunch
    $ renpy.pause(0.5, hard=True)
    play sfx plop
    show mscg8 024
    $ renpy.pause(0.5, hard=True)
    show mscg8 025
    alt "Spamton snatched the towel out of Tenna's hand, wiped off his own face--"
    alt "{noalt}--{/noalt}before pointing an accusatory finger at Tenna while offering back the towel."
    spamglass "You're not subtle."
    show mscg8 026
    spamglass "But..."
    show mscg8 027
    spamglass "{cps=60}Thanks, I guess.{/cps}"
    show mscg8 028
    play sfx step1
    $ renpy.pause(0.5, hard=True)
    play sfx2 step2
    $ renpy.pause(0.5, hard=True)
    play sfx step1
    $ renpy.pause(0.5, hard=True)
    play sfx2 dooropen
    $ renpy.pause(1.0, hard=True)
    play sfx doorclose
    alt "Spamton stormed out of the room, leaving Tenna to watch with a puzzled expression."
    $ renpy.pause(1.0, hard=True)
    show blackpng with Dissolve(0.5)
    show mscg8 029
    $ renpy.pause(2.0, hard=True)
    hide blackpng with Dissolve(1.0)
    $ renpy.pause(1.0, hard=True)
    show mscg8 030
    alt "Spamton contemplates what just happened."
    $ renpy.pause(2.0, hard=True)
    play sfx whipcrack
    if persistent.glitches:
        show mscg8 031
    else:
        show mscg8 031 at vpunch
    spamglass "DAMMIT!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    $ renpy.pause(2.0, hard=True)

    ## may change this later for re-watching
    return

### COMING FROM OTHER SHARDS
label greentriple:
    pause 1.0
    "...{w=0.2} That's strange."
    "The shard drew two things closer to it like a magnet."
    play sfx sparklegem
    show itemframe i_greenmem at truecenter with easeinbottom
    pause 1.0
    "All three of the green MemoryShards have connected into one."
    "But before you could inspect them any further--"
    scene black
    stop music
    "{noalt}--{/noalt} something overcame your senses again."
    call memoryshard8 from _call_memoryshard8

    ## AUTOSAVE
    $ renpy.save("mainfile")
    
    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    if memsh_location == "ex_lumproom":
        scene junkyard3 with Dissolve(1.0)
    elif memsh_location == "ex_starroom":
        scene junkyard6 with Dissolve(1.0)
    pause 1.0
    show itemframe i_greenmem at truecenter with easeinbottom
    "You glanced down at the MemoryShards."
    show itemframe i_greenmemS
    play loop rumble
    "They started to tremble in your hand..."
    pause 2.0
    stop loop
    play sfx soulcrack 
    show itemframe i_greenmemSh
    pause 1.0
    "The MemoryShard shattered."
    pause 0.5
    hide itemframe with easeoutbottom
    play sfx plop
    pause 1.0
    "You try to put them back into your pocket,{w=0.2} but now they seem to be repelling each other..."
    "...{w=0.2} You suppose you can put each one in a different pocket."
    pause 1.0
    play music dump
    return



############################################################################################################
################## MIKE MEMORYSHARD
label memoryshard9:
    $ quick_menu = False
    $ memsh_cutscene = True
    pause 1.0
    play ambiance wind
    $ renpy.pause(2.0, hard=True)
    gp_sub "Mike has NEVER been here!!!{w=0.2} Not ONCE!!!"
    gp_sub "Who's Mike?!{w=0.2} Who is he?!"
    gp_sub "'cause none of us have ever seen him!"
    gp_sub "None of us!{w=0.2} Ever!"
    stop ambiance fadeout 2.0
    $ renpy.pause(3.0, hard=True)

    $ quick_menu = True
    $ multichar = True
    scene darkgrey
    show black
    show vignetteoverlay zorder 99
    alt "Someone is breaking glass and ripping paper."
    play sfx glass2
    $ renpy.pause(1.5, hard=True)
    play sfx2 glass1
    $ renpy.pause(1.0, hard=True)
    play sfx rip3
    $ renpy.pause(3.0, hard=True)
    play sfx rip2
    $ renpy.pause(0.5, hard=True)
    play sfx2 rip1
    $ renpy.pause(1.0, hard=True)
    play sfx beepLo
    $ renpy.pause(3.0, hard=True)
    play sfx drop
    play music dumpS
    hide black
    show mscg9 001
    if persistent.glitches:
        pass
    else:
        with vpunch
    alt "Tenna slams open a door and starts walking down a hallway."
    $ renpy.pause(3.0, hard=True)
    show black
    $ renpy.pause(2.0, hard=True)
    hide black
    play sfx step1
    show mscg9 002
    $ renpy.pause(0.5, hard=True)
    show black
    $ renpy.pause(1.0, hard=True)
    hide black
    play sfx2 step2
    show mscg9 003
    $ renpy.pause(0.5, hard=True)
    show black
    $ renpy.pause(1.0, hard=True)
    hide black
    play sfx step1
    show mscg9 002
    $ renpy.pause(0.5, hard=True)
    show black
    $ renpy.pause(1.0, hard=True)
    hide black
    play sfx2 step2
    show mscg9 003
    $ renpy.pause(0.5, hard=True)
    show black
    $ renpy.pause(1.0, hard=True)
    hide black
    play sfx step1
    show mscg9 002
    $ renpy.pause(0.5, hard=True)
    show black
    $ renpy.pause(1.0, hard=True)
    hide black
    show mscg9 004
    alt "Pippins has entered the hallway."
    gp "Oh!{w=0.2} Uh, hey--{w=0.2} Mr. Tenna?{p=0.5}{noalt}*{/noalt} You doin' alright over here?"
    gp "I heard something crashing {cps=55}and banging so {/cps}{cps=50}I start{/cps}{cps=40}ed wander{/cps}{nw}"
    show mscg9 005
    extend "{cps=30}ing over {/cps}{cps=25}to check and see what.{w=0.2}.{w=0.2}.{/cps}"
    show mscg9 006
    alt "Tenna's screen is blank as he stares silently."
    $ renpy.pause(5.0, hard=True)
    show mscg9 007
    $ renpy.pause(1.0, hard=True)
    show mscg9 008
    alt "A bead of sweat drops down Pippins's face as he stares back."
    $ renpy.pause(2.0, hard=True)
    show mscg9 009
    $ renpy.pause(2.0, hard=True)
    play sfx plop
    show mscg9 010
    alt "Tenna kneels down and places his hands against Pippins's shoulders."
    $ renpy.pause(2.0, hard=True)
    tenna "You aren't going anywhere,{w=0.5} right?"
    show mscg9 011
    gp "{cps=25}...{/cps} {w=0.5}huh?"
    show mscg9 012
    tenna "You're not going to make empty promises and leave me in the dust,{w=0.2} too,{w=0.5} RIGHT?"
    show mscg9 013
    $ renpy.pause(2.0, hard=True)
    show mscg9 014
    gp "Hey...{p=0.5}{noalt}*{/noalt} H-{w=0.1} hey, Mr. Tenna,{w=0.2} that's--"
    gp "Where's this coming from?{w=0.5} Are you--{nw=0.2}"
    show mscg9 015
    tenna "Just say you're not.{p=0.5}{noalt}*{/noalt} Please."
    if persistent.glitches:
        show mscg9
        tenna_shh "P{w=0.2}l{w=0.2}e{w=0.2}a{w=0.2}s{w=0.2}e{w=0.2}."
    else:
        show mscg9 at shakingcg
        tenna_shh "{sc=3}P{w=0.2}l{w=0.2}e{w=0.2}a{w=0.2}s{w=0.2}e{w=0.2}.{/sc}"
    show mscg9 016 at yreset
    $ renpy.pause(3.0, hard=True)
    show mscg9 017
    gp "Y...{w=0.5} yeah!{p=0.8}{noalt}*{/noalt} A'course!"
    gp "Why would I...{w=0.5} ever wanna do something as stupid as that?"
    show mscg9 018
    $ renpy.pause(2.0, hard=True)
    show mscg9 019a
    alt "A Cheshire-like grin appears on Tenna's screen."
    $ renpy.pause(1.0, hard=True)
    show mscg9 021 at jump
    play sfx sparkleglock
    if persistent.glitches:
        tenna_shh "{image=txt_greatG}{alt}Great!{/alt}"
    else:
        tenna_shh "{image=txt_great}{alt}Great!{/alt}"
    show mscg9 022
    tenna "Now,{w=0.2} I'm gonna go talk to Mike.{p=0.5}{noalt}*{/noalt} He always knows what to say in times like this,{w=0.2} haha."
    show mscg9 023
    tenna "See you later,{w=0.2} Pippins!"
    show mscg9 024
    play sfx stepping
    pause 1.0
    alt "Pippins watches as Tenna walks away."
    stop sfx fadeout 5.0
    $ renpy.pause(4.0, hard=True)
    gp_shh ".{w=0.2}.{w=0.2}."
    show mscg9 025
    gp "Who is \"Mike\"?"
    scene black
    stop music
    $ renpy.pause(2.0, hard=True)

    ## may change this later for re-watching
    jump mike_returnshard

### RETURN TO GAMEROOM (MIKE)
label mike_returnshard:    
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ memsh_cutscene = False
    $ multichar = False
    "You began to open your eyes."
    scene junkyard5 with Dissolve(1.0)
    pause 1.0
    "...{w=0.5} You shove the blue shard into your pocket."
    play music dump
    jump ex_gameroom