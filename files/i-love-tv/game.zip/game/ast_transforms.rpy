############################################################################################################
################## POSITIONS

### tenna
transform tenpos_left:
    xalign 0.05
    yanchor 1.0
    ypos 1.11
transform tenpos_farleft:
    xalign -0.03
    yanchor 1.0
    ypos 1.11
transform tenpos_center:
    xalign 0.6
    yanchor 1.0
    ypos 1.11
transform tenpos_right:
    xalign 1.12
    yanchor 1.0
    ypos 1.11
transform tenpos_inright:
    xalign 0.95
    yanchor 1.0
    ypos 1.11
transform tenpos_game:
    xalign 1.0
    yanchor 1.0
    ypos 1.1
transform tenpos_offcen:
    xalign 0.45
    yanchor 1.0
    ypos 1.11
transform tenpos_offcen2:
    xalign 0.65
    yanchor 1.0
    ypos 1.11

### spamton
transform spampos_center:
    xalign 0.52
    yalign 1.4
transform spampos_right:
    xalign 0.9
    yalign 1.4
transform spampos_left:
    xalign 0.1
    yalign 1.4
transform spampos_inleft:
    xalign 0.2
    yalign 1.4

### mike
transform mikepos_center:
    xalign 0.5
    yalign 1.1
transform mikepos_right:
    xalign 0.95
    yalign 1.1
transform mikepos_inright:
    xalign 0.75
    yalign 1.1
transform mikepos_left:
    xalign 0.05
    yalign 1.1
transform mikepos_inleft:
    xalign 0.2
    yalign 1.1

transform mikepos_offsceenright:
    xalign 1.5
    yalign 1.1

### small mike / costume
transform cospos_center:
    xalign 0.45
    yalign 1.25
transform cospos_center_fl:
    xalign 0.6
    yalign 1.25
transform cospos_right:
    xalign 0.95
    yalign 1.25
transform cospos_right_fl:
    xalign 1.15
    yalign 1.25
transform cospos_right2:
    xalign 0.8
    yalign 1.25
transform cospos_right2_fl:
    xalign 0.95
    yalign 1.25
transform cospos_left:
    xalign -0.15
    yalign 1.25
transform cospos_left_fl:
    xalign 0.05
    yalign 1.25

### gaster
transform gastpos_center:
    xalign 0.5
    yalign 1.11

### fountain
transform dfountain_pos:
    xpos 320
    ypos 90
    

######################################################
##### LEGEND OF TENNA
transform dialoguepos_hide:
    xpos 418
    ypos 850
transform dialoguepos:
    xpos 418
    ypos 660

transform gamepos:
    xpos 431
    ypos 93
transform gamepos_tenna:
    xpos 0.3
    ypos 0.27
    yanchor 0.0
transform gamepos_vess:
    xpos 0.35
    ypos 0.34
    yanchor 0.0

transform gamepos_enemy_st:
    xpos 0.8
    ypos 0.34
    yanchor 0.0
transform gamepos_enemy_fin:
    xpos 0.6

transform gamepos_crt_vess:
    xpos 0.32
    ypos 0.4
transform gamepos_crt_jongler:
    xpos 0.61
    ypos 0.38
transform gamepos_crt_mike:
    xpos 0.61
    ypos 0.39
transform gamepos_crt_friend:
    xpos 0.62
    ypos 0.41



############################################################################################################
################## ANIMATIONS

init:
    # droop
    transform droop:
        ease 0.3 yoffset 10

    # rise
    transform rise:
        ease 0.3 yoffset -10

    # reset droop/rise without jump
    transform yreset:
        yoffset 0

    # ease yreset
    transform yease:
        ease 0.3 yoffset 0

    # sprite startled
    transform shock:
        ease .06 yoffset 24
        ease .06 yoffset -24
        ease .05 yoffset 20
        ease .05 yoffset -20
        ease .04 yoffset 16
        ease .04 yoffset -16
        ease .03 yoffset 12
        ease .03 yoffset -12
        ease .02 yoffset 8
        ease .02 yoffset -8
        ease .01 yoffset 4
        ease .01 yoffset -4
        ease .01 yoffset 0

    # sprite jumps
    transform jump:
        ease .04 yoffset 24
        ease .04 yoffset 20
        ease .03 yoffset 16
        ease .02 yoffset 12
        ease .01 yoffset 8
        ease .01 yoffset 4
        ease .01 yoffset 0

    # sprite wiggles
    transform wiggle:
        ease 0.3 xoffset 4 yoffset 2
        ease 0.3 xoffset 7 yoffset -7
        ease 0.3 xoffset -4 yoffset -2
        repeat

    # wiggle (x only)
    transform xwiggle:
        ease 0.3 xoffset 10
        ease 0.3 xoffset -10
        repeat

    # sprite shakes
    transform shaking:
        ease 0.1 xoffset 4 yoffset 2
        ease 0.1 xoffset 7 yoffset -7
        ease 0.1 xoffset -4 yoffset -2
        repeat
    
    # shake (less intense, mostly for cg's)
    transform shakingcg:
        xoffset 1
        pause 0.05
        yoffset 1
        pause 0.05
        xoffset -1
        pause 0.05
        yoffset -1
        pause 0.05
        xoffset 0
        pause 0.05
        yoffset 0
        pause 0.05
        repeat

    # TENNA SHRINKS 1
    transform shrink:
        ease 0.3 zoom 0.95

    # TENNA SHRINKS 2
    transform shrinks:
        ease 0.3 zoom 0.9

    # TENNA SHRINKS 3
    transform shrinkss:
        ease 0.3 zoom 0.85

    # TENNA SHRINKS 4
    transform shrinksss:
        ease 0.3 zoom 0.8

    # RESTORE TENNA TO NORMAL SIZE
    transform zreset:
        ease 0.3 zoom 1.0

    # lean right
    transform leanright:
        ease 0.5 xoffset 10

    transform leanrightL:
        ease 0.8 xoffset 20

    transform leanrightQ:
        ease 0.2 xoffset 10

    transform leanrightLQ:
        ease 0.5 xoffset 100

    transform leanrightLQ_mike:
        ease 0.2 xoffset 50

    # lean left
    transform leanleft:
        ease 0.5 xoffset -10

    transform leanleftL:
        ease 0.8 xoffset -20

    transform leanleftQ:
        ease 0.2 xoffset -10
    
    transform leanleftL2:
        ease 0.5 xoffset -30

    

    ######################################################
    ##### SCENE SPECIFIC
    # chromatic aberration
    transform crt_chroma:
        shader "rgb_split"
        u_intensity 1.0
        u_angle 0

    # intro soul bob
    transform soulbop:
        xpos 0.45
        ypos 0.42
        linear 0.5 yoffset 10
        linear 0.5 yoffset 5
        linear 0.5 yoffset 0
        linear 0.5 yoffset -5
        linear 0.5 yoffset -10
        linear 0.5 yoffset -5
        linear 0.5 yoffset 0
        linear 0.5 yoffset 5
        repeat

    # SPAMTON DEAL CUTSCENE
    transform spamhand_wiggle:
        xpos 0.4
        ypos 0.56
        ease 0.3 xoffset 2 yoffset 1
        ease 0.3 xoffset 3 yoffset -3
        ease 0.3 xoffset -2 yoffset -1
        repeat

    transform spameyes_shaking:
        xpos 0.59
        ypos 0.39
        linear 0.05 xoffset 1 yoffset 1
        linear 0.05 xoffset -2 yoffset -2
        repeat

    # INTRO ZOOMS FOR TENNA
    transform zoom0:
        xpos 0.5
        ypos 0.5
        zoom 0.1

    transform zoom1:
        ease 3 zoom 0.15 xoffset -15 yoffset 5

    transform zoom2:
        ease 5 zoom 0.3 xoffset -60 yoffset 10

    transform zoom3:
        ease 5 zoom 0.7 xoffset -170 yoffset 30

    transform zoom3z:
        zoom 0.7

    # ZOOM IN FOR END TENNA ROUTE
    transform zoom_in1:
        zoom 1.1
        yoffset 90

    transform zoom_in2:
        zoom 1.2
        yoffset 160

    transform zoom_in3:
        zoom 1.3
        yoffset 240

    transform zoom_in4:
        zoom 1.4
        yoffset 320

    # ZOOM OUT CG TENNA FREAK OUT
    transform zoomout1_st:
        zoom 1.1
        xalign 0.5
        yalign 0.5

    transform zoomout1:
        ease 1.5 zoom 1.0

    # BOARD DROP
    transform dropin:
        xalign 0.5
        ypos -1.0
        linear 0.4 ypos 0.008
        ease 0.2 ypos -0.08
        linear 0.2 ypos 0.0
        ease 0.2 ypos -0.008
        linear 0.1 ypos 0.0

    # for the second quiz board only
    transform dropin2:
        xpos 0.13
        ypos -1.0
        linear 0.4 ypos 0.008
        ease 0.2 ypos -0.08
        linear 0.2 ypos 0.0
        ease 0.2 ypos -0.008
        linear 0.1 ypos 0.0

    # BOARD FALL AWAY
    transform fallaway:
        anchor (0.5, 0.8)
        ease 0.5 rotate 50
        ease 0.3 rotate 40
        ease 0.3 rotate 49
        ease 0.3 rotate 46
        ease 0.2 rotate 45
        ease 0.2 rotate 46
        linear 1.5 ypos 5.0

    # special spamton leaving
    transform spampos_offscreenleft:
        ease 1.0 xalign -0.5

    # special mike moving
    transform mikepos_offcenease:
        ease 0.5 xalign 0.8

    # starwalker ascend
    transform starascend:
        yalign 1.5
        linear 3.0 ypos -1.0
        
    transform starascend2:
        yalign 1.5
        linear 3.0 rotate -1080

    # angel spamton
    transform angelzoom:
        zoom 0.5
        ease 1.0 zoom 1.0 

    transform angelmove:
        xalign 0.25
        ease 0.5 xalign 0.75 yalign 0.25
        ease 0.7 xalign 0.5 yalign 0.5