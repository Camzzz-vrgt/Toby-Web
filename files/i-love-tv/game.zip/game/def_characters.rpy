############################################################################################################
################## DATE INFO

######################################################
##### DATE CLASSES
init -2 python:
    import math

    class DateChar:
        def __init__(self, fp, lp, hb, char=""):
            self.char = char
            self.hb = hb
            self.fp = fp
            self.maxfp = fp
            self.lp = lp
            self.maxlp = lp


######################################################
##### DATE CHARACTERS
default ten = DateChar(50,100,3,char="date_ten")
default spam = DateChar(100,50,3,char="date_spam")
default mke = DateChar(50,50,3,char="date_mke")
default vess_hp = 3



############################################################################################################
################## ACTUAL CHARACTERS

######################################################
##### TALKING BLIPS
init python:
    ## standard text
    def voice_text(event, **kwargs):
        if event == "show":
            renpy.music.play("audio/sfx/voice_text.wav", channel="sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.music.stop(channel="sound")

    ## date menu text
    def voice_text2(event, **kwargs):
        if event == "show":
            renpy.music.play("audio/sfx/voice_text2.wav", channel="sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.music.stop(channel="sound")

    ## tenna voice
    def voice_ten(event, **kwargs):
        vc_blip = 0
        while vc_blip < 100:
            if event == "show":
                renpy.music.queue(renpy.random.choice(["audio/sfx/voice_ten1.wav", "audio/sfx/voice_ten2.wav", "audio/sfx/voice_ten3.wav", 
                "audio/sfx/voice_ten4.wav", "audio/sfx/voice_ten5.wav", "audio/sfx/voice_ten6.wav", "audio/sfx/voice_ten7.wav",
                "audio/sfx/voice_ten8.wav", "audio/sfx/voice_ten8.wav", "audio/sfx/voice_ten9.wav", "audio/sfx/voice_ten10.wav"]), channel="sound", loop=False)
            elif event == "slow_done" or event == "end":
                renpy.music.stop(channel="sound")
            vc_blip += 1

    ## spamton voice
    def voice_spam(event, **kwargs):
        if event == "show":
            renpy.music.play("audio/sfx/voice_spam.wav", channel="sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.music.stop(channel="sound")

    ## gaster voice
    def voice_wdg(event, **kwargs):
        vc_blip = 0
        while vc_blip < 100:
            if event == "show":
                renpy.music.queue(renpy.random.choice(["audio/sfx/voice_wdg1.wav", "audio/sfx/voice_wdg2.wav", "audio/sfx/voice_wdg3.wav", 
                "audio/sfx/voice_wdg4.wav", "audio/sfx/voice_wdg5.wav", "audio/sfx/voice_wdg6.wav", "audio/sfx/voice_wdg7.wav"]), channel="sound", loop=False)
            elif event == "slow_done" or event == "end":
                renpy.music.stop(channel="sound")
            vc_blip += 1

    ## legend of tenna
    def voice_lot(event, interact=True, **kwargs):
        if event == "show":
            renpy.music.play("audio/sfx/voice_lot.wav", channel="sound", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.music.play("audio/sfx/voice_lot_end.wav", channel="sound", loop=False)


######################################################
##### CHARACTERS / SPEAKERS
define rq = Character("Menu", color="#aaaaaa", what_prefix="{noalt}*{/noalt} ", what_color="#aaaaaa", what_slow_cps=0) # repeat "question" (when prompting a menu)
define date = Character("Menu", color="#aaaaaa", callback=voice_text2, what_prefix="{noalt}*{/noalt} ", what_color="#aaaaaa", advance=False) # date info box
define quiet = Character("Menu", color="#aaaaaa", what_prefix="{noalt}*{/noalt} ") # no callback
define narr_lot = Character("Game", color="#aaaaaa", callback=voice_lot, what_font="fnt-game.otf", screen="lottxt", ctc="lot_ctc", ctc_position="fixed",
                            what_size=55, what_line_spacing=0, what_xmaximum=900, what_ymaximum=175, what_textshader="rgb_text") # legend of tenna version

define narrator = Character("Me", color="#FF54A6", callback=voice_text, what_prefix="{noalt}*{/noalt} (", what_suffix=")") # when there's no specified speaker
define nar_quiet = Character("Me", color="#FF54A6", what_prefix="{noalt}*{/noalt} (", what_suffix=")") # quiet narrator

define tenna = Character("Tenna", color="#D61D4E", callback=voice_ten, what_prefix="{noalt}*{/noalt} ", image="tenside")
define tenna_shh = Character("Tenna", color="#D61D4E", what_prefix="{noalt}*{/noalt} ", image="tenside") # no callback
define tenna_fun = Character("Tenna", color="#D61D4E", what_prefix="{noalt}*{/noalt} {sc=2}{font=fnt-cali.ttf}{i}(", what_suffix="){/i}{/font}{/sc}{fast}", image="tenside") # the italicized speech
define tenna_funG = Character("Tenna", color="#D61D4E", what_prefix="{noalt}*{/noalt} {font=fnt-cali.ttf}{i}(", what_suffix="){/i}{/font}{fast}", image="tenside") # no shaky text for self voice
define tenna_sub = Character("Tenna", color="#D61D4E", callback=voice_ten, window_style="centertxt") # center on screen
define tenna_bub = Character("Tenna", color="#D61D4E", kind=bubble, image="tenna", callback=voice_ten, what_font="fnt-game.otf") # speech bubble ver
define tenna_lot = Character("Tenna?", color="#D61D4E", callback=voice_lot, what_font="fnt-game.otf", screen="lottxt", ctc="lot_ctc", ctc_position="fixed",
                            what_size=55, what_line_spacing=0, what_xmaximum=900, what_ymaximum=175, what_textshader="rgb_text") # legend of tenna version

define spamton = Character("Spamton", color="#00C000", callback=voice_spam, what_prefix="{noalt}*{/noalt} ", image="spamside")
define spamglass = Character("Spamton", color="#00C000", callback=voice_spam, what_prefix="{noalt}*{/noalt} ", image="spamglassside") # glasses side image
define spamadd = Character("Spamton", color="#00C000", callback=voice_spam, what_prefix="{noalt}*{/noalt} ", image="spamaddside") # past side image
define spamadd_shh = Character("Spamton", color="#00C000", what_prefix="{noalt}*{/noalt} ", image="spamaddside") # past side image ; no callback
define spamton_shh = Character("Spamton", color="#00C000", what_prefix="{noalt}*{/noalt} ", image="spamside") # no callback
define spamton_sub = Character("Spamton", color="#00C000", callback=voice_spam, window_style="centertxt") # center on screen

define gp = Character("Pippins", color="#0000FF", callback=voice_text, what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="pipside")
define gp_shh = Character("Pippins", color="#0000FF", what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="pipside") # no callback
define gp_sub = Character("Pippins", color="#0000FF", callback=voice_text, what_slow_cps=60, window_style="centertxt") # center on screen

define mike = Character("Mike", color="#0000FF", callback=voice_text, what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="mikeside")
define mike_shh = Character("Mike", color="#0000FF", what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="mikeside") # no callback
define mike_no = Character("Mike?", color="#0000FF", callback=voice_text, what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="pipside") # when mike identity revealed but he doesnt give his old name
define mike_no_img = Character("Mike?", color="#0000FF", callback=voice_text, what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="mikeside") # when mike identity revealed but he doesnt give his old name SIDE IMAGE SMALL michael
define mike_noshh = Character("Mike?", color="#0000FF", what_prefix="{noalt}*{/noalt} ", what_slow_cps=60, image="pipside") # when mike identity revealed but he doesnt give his old name, no callback

### Minor chars
define gaster = Character("???", color="#ffffff", callback=voice_wdg, what_font="fnt-gaster.otf", what_slow_cps=20)
define gaster_wd = Character("???", color="#ffffff", callback=voice_wdg, what_font="fnt-wingdings.ttf", what_slow_cps=20)
define gaster_rq = Character("Menu", color="#aaaaaa", what_font="fnt-gaster.otf", what_color="#aaaaaa", what_slow_cps=0) # repeat "question" (when prompting a menu)

define starwalker = Character("Starwalker", color="#FFF200", callback=voice_text, what_prefix="{noalt}*{/noalt} ")


######################################################
##### STYLES
style centertxt:
    text_align 0.5
    xcenter 0.3
    yalign 0.5

screen lottxt:
    hbox:
        xpos 70
        ypos 660
        xfill True

        text what id "what"