############################################################################################################
################## CALL THINGS

######################################################
##### DATE INTRO SEQUENCE
label date_intro:
    $ quick_menu = False
    show blackpng
    show soul_im at truecenter
    pause 0.1
    play sfx datestart
    show soul_im datestart
    pause 0.3
    show soul_im
    hide soul_im with moveoutbottom
    pause 0.1
    hide blackpng
    $ quick_menu = True
    return


######################################################
##### HEARTBREAK SEQUENCE
label heartbreak_ani:
    $ renpy.music.set_volume(0.0, channel='music')
    $ quick_menu = False
    show blackpng
    if date_hb == 3:
        if currentdate in ["quiz", "park"]:
            show heartbreak soultv_crack1 at truecenter
        elif currentdate in ["shop", "eye"]:
            show heartbreak soulgrn_crack1 at truecenter
        elif currentdate == "secret":
            show heartbreak souldice_crack1 at truecenter
    elif date_hb == 2:
        if currentdate in ["quiz", "park"]:
            show heartbreak soultv_crack2 at truecenter
        elif currentdate in ["shop", "eye"]:
            show heartbreak soulgrn_crack2 at truecenter
        elif currentdate == "secret":
            show heartbreak souldice_crack2 at truecenter
    elif date_hb == 1:
        if currentdate in ["quiz", "park"]:
            show heartbreak soultv_crack3 at truecenter
        elif currentdate in ["shop", "eye"]:
            show heartbreak soulgrn_crack3 at truecenter
        elif currentdate == "secret":
            show heartbreak souldice_crack3 at truecenter
    pause 0.4
    play sfx soulcrack
    pause 1.5
    $ date_hb -= 1
    if date_hb > 0:
        alt "His \"heart\" cracked."
    else:
        alt "His \"heart\" broke."
    $ renpy.music.set_volume(1.0, channel='music')
    hide heartbreak
    hide blackpng
    $ quick_menu = True
    return


######################################################
##### TRIPLE HEARTBREAK
label heartbreak_triple_ani:
    $ renpy.music.set_volume(0.0, channel='music')
    $ quick_menu = False
    show blackpng zorder 99

    ### 3 HEARTS LEFT
    if currentend == "tenna" and ten_failed and ten.hb == 3:
        $ ten.hb -= 1
        show heartbreak soultv_crack1 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    elif currentend == "spamton" and spam_failed and spam.hb == 3:
        $ spam.hb -= 1
        show heartbreak soulgrn_crack1 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    elif (currentend == "mike" or currentdate == "secret") and mke_failed and mke.hb == 3:
        $ mke.hb -= 1
        show heartbreak souldice_crack1 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    
    ### 2 HEARTS LEFT
    if currentend == "tenna" and ten_failed and ten.hb == 2:
        $ ten.hb -= 1
        show heartbreak soultv_crack2 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    elif currentend == "spamton" and spam_failed and spam.hb == 2:
        $ spam.hb -= 1
        show heartbreak soulgrn_crack2 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    elif (currentend == "mike" or currentdate == "secret") and mke_failed and mke.hb == 2:
        $ mke.hb -= 1
        show heartbreak souldice_crack2 at truecenter zorder 100
        pause 0.4
        play sfx soulcrack
        pause 1.5
    
    ### 1 HEART LEFT
    if currentend == "tenna" and ten_failed:
        $ ten.hb -= 1
        show heartbreak soultv_crack3 at truecenter zorder 100
    elif currentend == "spamton" and spam_failed:
        $ spam.hb -= 1
        show heartbreak soulgrn_crack3 at truecenter zorder 100
    elif (currentend == "mike" or currentdate == "secret") and mke_failed:
        $ mke.hb -= 1
        show heartbreak souldice_crack3 at truecenter zorder 100
    pause 0.4
    play sfx soulcrack
    pause 1.5
    alt "His \"heart\" broke."
    $ renpy.music.set_volume(1.0, channel='music')
    hide heartbreak
    hide blackpng
    $ quick_menu = True
    $ currentend = None
    return


######################################################
##### HEARTBREAK REPAIR / RESTORE
label restore_ani:
    $ renpy.music.set_volume(0.0, channel='music')
    $ quick_menu = False
    show blackpng zorder 99
    if date_hb == 2:
        if currentdate in ["quiz", "park"]:
            show heartbreak soultv_restore1 at truecenter zorder 100
        elif currentdate in ["shop", "eye"]:
            show heartbreak soulgrn_restore1 at truecenter zorder 100
        elif currentdate == "secret":
            show heartbreak souldice_restore1 at truecenter zorder 100
    elif date_hb == 1:
        if currentdate in ["quiz", "park"]:
            show heartbreak soultv_restore2 at truecenter zorder 100
        elif currentdate in ["shop", "eye"]:
            show heartbreak soulgrn_restore2 at truecenter zorder 100
        elif currentdate == "secret":
            show heartbreak souldice_restore2 at truecenter zorder 100
    pause 0.4
    play sfx soulrestore
    pause 1.5
    alt "His \"heart\" was repaired."
    $ date_hb += 1
    $ renpy.music.set_volume(1.0, channel='music')
    hide heartbreak
    hide blackpng
    $ quick_menu = True
    return



############################################################################################################
################## SCREENS

######################################################
##### DATE STATS FP/LP
default date_fp = None
default date_maxfp = None
default date_lp = None
default date_maxlp = None
default date_name = None

screen datestats:
    frame:
        padding(10,10)
        if currentdate == "quiz":
            xalign 0.39
            yalign 0.04
        else:
            xalign 0.5
            yalign 0.01
        hbox:
            null width 1
            add date_name yalign 0.5
            spacing 10
            vbox:
                hbox:
                    text _("{color=[c_kindness]}FP{/color}") size 22 yalign 0.5
                    spacing 5
                    bar:
                        xmaximum 200
                        value date_fp
                        range date_maxfp
                        left_bar "gui/bar/right.png"
                        right_bar "gui/bar/fp.png"
                spacing 5
                hbox:
                    text _("{color=[c_passion]}LP{/color}") size 22 yalign 0.5
                    spacing 5
                    bar:
                        xmaximum 200
                        value date_lp
                        range date_maxlp
                        left_bar "gui/bar/right.png"
                        right_bar "gui/bar/lp.png"
            
            vbox:
                yalign 0.4
                spacing 5
                null width 25

                ### TENNA HEARTBREAK
                if currentdate in ["quiz", "park"]:
                    if date_hb == 3:
                        add hb_red_full
                        add hb_red_full
                        add hb_red_full
                    elif date_hb == 2:
                        add hb_red_empty
                        add hb_red_full
                        add hb_red_full
                    elif date_hb == 1:
                        add hb_red_empty
                        add hb_red_empty
                        add hb_red_full
                    elif date_hb == 0:
                        add hb_red_empty
                        add hb_red_empty
                        add hb_red_empty

                ### SPAMTON HEARTBREAK
                elif currentdate in ["shop", "eye"]:
                    if date_hb == 3:
                        add hb_green_full
                        add hb_green_full
                        add hb_green_full
                    elif date_hb == 2:
                        add hb_green_empty
                        add hb_green_full
                        add hb_green_full
                    elif date_hb == 1:
                        add hb_green_empty
                        add hb_green_empty
                        add hb_green_full
                    elif date_hb == 0:
                        add hb_green_empty
                        add hb_green_empty
                        add hb_green_empty

                ### MIKE HEARTBREAK
                elif currentdate == "secret":
                    if date_hb == 3:
                        add hb_blue_full
                        add hb_blue_full
                        add hb_blue_full
                    elif date_hb == 2:
                        add hb_blue_empty
                        add hb_blue_full
                        add hb_blue_full
                    elif date_hb == 1:
                        add hb_blue_empty
                        add hb_blue_empty
                        add hb_blue_full
                    elif date_hb == 0:
                        add hb_blue_empty
                        add hb_blue_empty
                        add hb_blue_empty

    frame:
        padding(15,15)
        xpos 0.05
        ypos 0.8
        vbox:
            null width 1
            text "[persistent.mc]" size 32 xalign 0.5
            null height 10
            hbox:
                spacing 5
                null height 25
                if vess_hp == 3:
                    add lot_full
                    add lot_full
                    add lot_full
                elif vess_hp == 2:
                    add lot_empty
                    add lot_full
                    add lot_full
                elif vess_hp == 1:
                    add lot_empty
                    add lot_empty
                    add lot_full
                elif vess_hp == 0:
                    add lot_empty
                    add lot_empty
                    add lot_empty


######################################################
##### CHECK FP/LP
screen check_fplp:
    on 'show' action PauseAudio('sound', value=True)
    use rt_screen

    modal True
    tag menu

    add "gui/overlay/confirm.png"

    vbox:
        xalign 0.5
        yalign 0.5
        
        hbox:
            xalign 0.5
            ### TENNA STATS
            frame:
                padding(15,15)
                vbox:
                    null width 1
                    text _("{color=#D61D4E}Tenna{/color}") size 22 xalign 0.5
                    null height 10
                    hbox:
                        text _("{color=[c_kindness]}FP{/color}") size 22 yalign 0.5
                        spacing 5
                        bar:
                            xmaximum 200
                            value ten.fp
                            range ten.maxfp
                            left_bar "gui/bar/right.png"
                            right_bar "gui/bar/fp.png"
                    null height 5
                    hbox:
                        text _("{color=[c_passion]}LP{/color}") size 22 yalign 0.5
                        spacing 5
                        bar:
                            xmaximum 200
                            value ten.lp
                            range ten.maxlp
                            left_bar "gui/bar/right.png"
                            right_bar "gui/bar/lp.png"

            ### SPAMTON STATS
            null width 10
            frame:
                padding(15,15)
                vbox:
                    null width 1
                    text _("{color=#00C000}Spamton{/color}") size 22 xalign 0.5
                    null height 10
                    hbox:
                        text _("{color=[c_kindness]}FP{/color}") size 22 yalign 0.5
                        spacing 5
                        bar:
                            xmaximum 200
                            value spam.fp
                            range spam.maxfp
                            left_bar "gui/bar/right.png"
                            right_bar "gui/bar/fp.png"
                    null height 5
                    hbox:
                        text _("{color=[c_passion]}LP{/color}") size 22 yalign 0.5
                        spacing 5
                        bar:
                            xmaximum 200
                            value spam.lp
                            range spam.maxlp
                            left_bar "gui/bar/right.png"
                            right_bar "gui/bar/lp.png"

            ### MIKE STATS
            if mke_unlock:
                null width 10
                frame:
                    padding(15,15)
                    vbox:
                        null width 1
                        text _("{color=#0000FF}Mike{/color}") size 22 xalign 0.5
                        null height 10
                        hbox:
                            text _("{color=[c_kindness]}FP{/color}") size 22 yalign 0.5
                            spacing 5
                            bar:
                                xmaximum 200
                                value mke.fp
                                range mke.maxfp
                                left_bar "gui/bar/right.png"
                                right_bar "gui/bar/fp.png"
                        null height 5
                        hbox:
                            text _("{color=[c_passion]}LP{/color}") size 22 yalign 0.5
                            spacing 5
                            bar:
                                xmaximum 200
                                value mke.lp
                                range mke.maxlp
                                left_bar "gui/bar/right.png"
                                right_bar "gui/bar/lp.png"

        if foundendguide:
            null height 20
            imagebutton:
                idle "endingguide"
                hovered [Play("sfx", menuhover), SetVariable("imghover", True)]
                unhovered SetVariable("imghover", False)
                action Call("endguide_alt")
        
        textbutton _("[[RETURN]"):
            text_outlines gui.quick_button_text_outlines
            text_size gui.quick_button_text_size
            xalign 0.5
            action Return()

    if imghover:
        text _("{size=-10}Click for alt text\n(Press V to enable self-voicing)\n(This will exit the menu)") xpos 30 yalign 0.95

### alt text for ending guide
label endguide_alt:
    show endingguide at truecenter
    alt "There's a house containing a red star."
    alt "There's a building containing a green heart."
    alt "There's a TV containing a blue cube. The game console is yellow."
    alt "Red Star to Green Heart = Red and Green"
    alt "Red Star to Blue Cube = Red and Blue"
    alt "Green Heart to Blue Cube = Green and Blue"
    alt "Red Star to Green Heart to Red and Green to Blue Cube = Red and Green and Blue"
    hide endingguide
    return


######################################################
##### QUIZ
default quiz_question = "Test question?"
default quiz_answer1 = "First answer"
default quiz_answer2 = "Second answer"
default quiz_answer3 = "Third answer"
default quiz_answer4 = "Fourth answer"
default quiz_selected = 0

style quizzes_text is text:
    outlines [(4, "#599EFF", 0, 0 )]
    size 64

screen quiztext:
    vbox:
        style_prefix "quizzes"
        xpos 0.16
        yalign 0.22
        text "{size=+10}[quiz_question]"
        null height 20
        text "[quiz_answer1]" xoffset 100
        text "[quiz_answer2]" xoffset 100
        text "[quiz_answer3]" xoffset 100
        text "[quiz_answer4]" xoffset 100

    if quiz_selected == 1:
        add soul xpos 0.18 yalign 0.265
    elif quiz_selected == 2:
        add soul xpos 0.18 yalign 0.35
    elif quiz_selected == 3:
        add soul xpos 0.18 yalign 0.435
    elif quiz_selected == 4:
        add soul xpos 0.18 yalign 0.515
    else:
        pass


######################################################
##### TALK/ACT/ITEM
style dating_hbox is hbox:
    xalign 0.5
    yalign 0.7
    spacing 50

screen tendate_select:
    style_prefix "dating"
    hbox:
        ### "TALK" BUTTON
        imagebutton:
            idle "tn_talk_idle"
            hover "tn_talk_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("tendate_talk")]

        ### "ACT" BUTTON
        imagebutton:
            idle "tn_act_idle"
            hover "tn_act_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("tendate_act")]

        ### "ITEM" BUTTON
        imagebutton:
            idle "tn_item_idle"
            hover "tn_item_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("tendate_item")]

screen spamdate_select:
    style_prefix "dating"
    hbox:
        ### "TALK" BUTTON
        imagebutton:
            idle "sp_talk_idle"
            hover "sp_talk_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("spamdate_talk")]

        ### "ACT" BUTTON
        imagebutton:
            idle "sp_act_idle"
            hover "sp_act_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("spamdate_act")]

        ### "ITEM" BUTTON
        imagebutton:
            idle "sp_item_idle"
            hover "sp_item_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("spamdate_item")]

screen mikedate_select:
    style_prefix "dating"
    hbox:
        ### "TALK" BUTTON
        imagebutton:
            idle "gp_talk_idle"
            hover "gp_talk_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("mikedate_talk")]

        ### "ACT" BUTTON
        imagebutton:
            idle "gp_act_idle"
            hover "gp_act_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("mikedate_act")]

        ### "ITEM" BUTTON
        imagebutton:
            idle "gp_item_idle"
            hover "gp_item_hover"
            hovered Play("sfx", menuhover)
            action [Play("sfx", select), Jump("mikedate_item")]