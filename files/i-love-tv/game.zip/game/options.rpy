﻿############################################################################################################
################## CONFIG
define config.name = _("I Love TV!") # A human-readable name of the game. The _() surrounding the string marks it as eligible for translation.
define gui.show_name = False # Determines if the title given above is shown on the main menu screen.

define config.version = "1.1" # The version of the game.

define config.window_icon = "gui/window_icon.png" # The icon displayed on the taskbar or dock. Changes on route

define config.has_autosave = False # turns off autosave to prevent errors with other saving
### https://lemmasoft.renai.us/forums/viewtopic.php?p=575975#p575975

## A short name for the game used for executables and directories in the built
## distribution. This must be ASCII-only, and must not contain spaces, colons,
## or semicolons.
define build.name = "ILoveTV"

define build.itch_project = "zirkkun/i-love-tv" # The username and project name associated with an itch.io project

## Game's about screen. Leave a blank line between paragraphs.
define gui.about = _p("""The Mr. \"Ant\" Tenna dating sim where everything is Totally Normal!

I Love TV! is entirely free-to-play with no intention of making a profit from, misusing, or demoralizing Toby Fox's content. The project is made entirely out of fun and appreciation for Deltarune. Please, if you have not already, support Toby Fox and the official release of UNDERTALE and DELTARUNE!
""")


######################################################
##### AUDIO
define config.has_sound = True
define config.has_music = True
define config.has_voice = False

define config.main_menu_music = silence # default for intro sequence; changes on route


######################################################
##### TRANSITIONS
## Entering or exiting the game menu.
define config.enter_transition = None
define config.exit_transition = None

define config.intra_transition = None # Between screens of the game menu.
define config.after_load_transition = None # A transition that is used after a game has been loaded.
define config.end_game_transition = None # Used when entering the main menu after the game has ended.

## Transitions used to show and hide the dialogue window
define config.window_show_transition = None
define config.window_hide_transition = None

## If "show," always displayed.
## If "hide," only displayed when dialogue is present.
## If "auto," the window is hidden before scene statements and shown again once dialogue is displayed.
define config.window = "hide"


######################################################
##### SHADERS
## https://github.com/AgentAlpha81/RGB-Split
define config.gl2 = True # enable shaders
define config.default_textshader = 'typewriter' # enable textshaders



############################################################################################################
################## SETTING DEFAULTS
default preferences.text_cps = 35 # text speed. 0 is infinite
default preferences.afm_time = 15 # larger number = longer wait. total range is 0-30



############################################################################################################
################## SAVES + DISTRIBUTION (i'm too scared to touch this)

## Save directory ##############################################################
##
## Controls the platform-specific place Ren'Py will place the save files for
## this game. The save files will be placed in:
##
## Windows: %APPDATA\RenPy\<config.save_directory>
##
## Macintosh: $HOME/Library/RenPy/<config.save_directory>
##
## Linux: $HOME/.renpy/<config.save_directory>
##
## This generally should not be changed, and if it is, should always be a
## literal string, not an expression.

define config.save_directory = "ILoveTV-1750304621"

## Build configuration #########################################################
##
## This section controls how Ren'Py turns your project into distribution files.

init python:

    ## The following functions take file patterns. File patterns are case-
    ## insensitive, and matched against the path relative to the base directory,
    ## with and without a leading /. If multiple patterns match, the first is
    ## used.
    ##
    ## In a pattern:
    ##
    ## / is the directory separator.
    ##
    ## * matches all characters, except the directory separator.
    ##
    ## ** matches all characters, including the directory separator.
    ##
    ## For example, "*.txt" matches txt files in the base directory, "game/
    ## **.ogg" matches ogg files in the game directory or any of its
    ## subdirectories, and "**.psd" matches psd files anywhere in the project.

    ## Classify files as None to exclude them from the built distributions.

    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)

    ## To archive files, classify them as 'archive'.

    # build.classify('game/**.png', 'archive')
    # build.classify('game/**.jpg', 'archive')

    ## Files matching documentation patterns are duplicated in a mac app build,
    ## so they appear in both the app and the zip file.

    build.documentation('*.html')
    build.documentation('*.txt')