############################################################################################################
################## MIKE VERSION
label lot_mike:
    ### RESETTING IF FAILED
    $ lot_life = 3
    $ lot_boss_life = 3
    if lot_mike_cat:
        $ lot_boss_life -= 1
    if lot_mike_cowboy:
        $ lot_boss_life -= 1

    show screen lot_crtbars onlayer master
    play sfx lot_enter
    show hero_wit_gnr idle at gamepos_crt_vess zorder 97:
        shader "rgb_split"
        u_intensity 5.0
        u_angle 0
    play ambiance ocean
    pause 2.0
    show hero_wit_gnr walk
    pause 4.5
    show hero_wit_gnr walk2
    pause 0.5

label lot_mike_battle:
    if not lot_mike_cat:
        show pluey idle zorder 97:
            xpos 0.8
            ypos 0.39
            shader "rgb_split"
            u_intensity 5.0
            u_angle 0
        show pluey at gamepos_crt_mike with MoveTransition(2.0)
        $ lot_enemy_act = "Flirt"

    elif not lot_mike_cowboy:
        show jongler idle zorder 97:
            xpos 0.8
            ypos 0.38
            shader "rgb_split"
            u_intensity 5.0
            u_angle 0
        show jongler at gamepos_crt_jongler with MoveTransition(2.0)
        $ lot_enemy_act = "Talk"

    elif not lot_mike_small:
        show battat walk zorder 97:
            xpos 0.8
            ypos 0.39
            shader "rgb_split"
            u_intensity 5.0
            u_angle 0
        show battat at gamepos_crt_mike with MoveTransition(2.0)
        show battat idle
        $ lot_enemy_act = "Talk"

    elif not lot_mike_friend:
        $ lot_mike_friend = True
        show friend walk zorder 97:
            xpos 0.8
            ypos 0.4
            shader "rgb_split"
            u_intensity 5.0
            u_angle 0
        show friend at gamepos_crt_friend with MoveTransition(2.0)
        show friend idle
        
        ## "crash" LoT
        stop ambiance
        $ renpy.pause(1.0, hard=True)
        hide lot_crtbars
        hide friend
        hide hero_wit_gnr
        play sfx tvstatic
        show staticoverlay at crt_chroma zorder 97
        $ renpy.pause(4.0, hard=True)
        hide staticoverlay
        hide crtoverlay
        show white
        play sfx tvturnoff1
        hide white
        if not persistent.glitches:
            show tv_shutdown
        pause 0.5
        play sfx2 tvturnoff2
        pause 2.0
        hide tv_shutdown
        $ mke_unlock = True
        $ mke_game = True
        ## AUTOSAVE
        $ renpy.save("mainfile")
        "The game turned itself off."
        "Despite your best efforts,{w=0.2} it refused to turn back on."
        "You reach to grab the cartridge from the console, but...{w=0.5} it apparently disappeared."
        return

    menu lot_mike_battle_turn:
        rq "What will you do?"
        "Flirt":
            $ lot_act = "Flirt"
        "Talk":
            $ lot_act = "Talk"

    play sfx lot_sparkle
    show hero_wit_gnr flirt

    if lot_enemy_act == lot_act:
        if not lot_mike_cat:
            show pluey blush
        elif not lot_mike_cowboy:
            show jongler blush
        elif not lot_mike_small:
            show battat blush
    else:
        if not lot_mike_cat:
            show pluey hurt
        elif not lot_mike_cowboy:
            pass
        elif not lot_mike_small:
            show battat hurt

    pause 1.0

    ## SUCCESS
    if lot_enemy_act == lot_act:
        $ lot_boss_life -=1

        play sfx lot_defeatrun
        show lot_sweat flicker:
            xpos 0.58
            ypos 0.36
            shader "rgb_split"
            u_intensity 5.0
            u_angle 0
        if not lot_mike_cat:
            $ lot_mike_cat = True
            show pluey blushR
            pause 0.0
            show pluey:
                xpos 0.8
            with MoveTransition(0.5)
            hide pluey
        elif not lot_mike_cowboy:
            $ lot_mike_cowboy = True
            show jongler blushR
            pause 0.0
            show jongler:
                xpos 0.8
            with MoveTransition(0.5)
            hide jongler
        elif not lot_mike_small:
            $ lot_mike_small = True
            show battat blushR
            pause 0.0
            show battat:
                xpos 0.8
            with MoveTransition(0.5)
            hide battat
        
        hide lot_sweat
        pause 1.0
        show hero_wit_gnr walk2
        pause 0.5
        jump lot_mike_battle

    ## FAIL
    else:
        $ lot_life -= 1

        if not lot_mike_cat:
            show pluey idle
        elif not lot_mike_cowboy:
            pass
        elif not lot_mike_small:
            show battat idle

        play sfx lot_ouch
        show hero_wit_gnr damage ani
        show lot_slash ani:
            xpos 0.38
            ypos 0.4
        pause 1.0
        hide lot_slash

        ## GAME OVER
        if lot_life == 0:
            jump lot_mike_gameover

        jump lot_mike_battle_turn


label lot_mike_gameover:
    stop ambiance
    hide hero_wit_gnr
    $ renpy.pause(1.0, hard=True)
    hide lot_crtbars
    hide pluey
    hide jongler
    hide battat
    play sfx tvstatic
    show staticoverlay at crt_chroma zorder 97
    $ renpy.pause(4.0, hard=True)
    hide staticoverlay
    hide crtoverlay
    show white
    play sfx tvturnoff1
    hide white
    if not persistent.glitches:
        show tv_shutdown
    pause 0.5
    play sfx2 tvturnoff2
    pause 2.0
    hide tv_shutdown
    "Game over{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}?"
    "Maybe you could try again..."
    menu:
        rq "Try again?"
        "Yes":
            "You restart the console."
            play sfx item
            if not persistent.glitches:
                show tv_turnon zorder 97
            show crtoverlay zorder 98
            pause 1.0
            hide tv_turnon
            jump lot_mike

        "No":
            "You decide this isn't worth your time."
            $ inventory.append(itm_cartridge2)
            return