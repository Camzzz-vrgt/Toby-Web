############################################################################################################
################## MIKE AND TENNA
label secret_ending_battenna:
    $ rightclick_icon = True

    ## AUTOSAVE
    $ renpy.save("mainfile")

    scene junkyard5 with Dissolve(1.0)
    pause 1.0
    show tenna upright chest confused flipped at tenpos_left with easeinleft
    tenna "Well,{w=0.2} we're here,{w=0.2} [persistent.mc]!"
    tenna "Where is that person you were telling me about...?"
    "You tell Tenna that he should be showing up soon."
    show tenna upright back confused flipped at jump
    tenna "Okay.{p=0.2}{noalt}*{/noalt} I trust you."
    show tenna upright back frown flipped at droop
    tenna "It's just...{nw=0.5}"
    show tenna upright back blank flipped at rise
    extend "?!"
    show costume pointing smile at cospos_right2 with easeinright
    play music sneaking
    show tenna slouch claw panic flipped at jump
    $ multichar = True
    tenna "MIKE?!{p=0.5}{noalt}*{/noalt} You ARE here?!"
    show costume pointing nervous at jump
    mike_no_img "Boss...!"
    show costume down frown at leanleftL
    mike_no_img "Tenna,{w=0.2} it's really you...{p=0.5}{noalt}*{/noalt} Ah, geez,{w=0.2} I'm real sorry I didn't find you sooner..."
    show tenna upright chest confused flipped at leanrightL
    tenna "I was looking all over for you!{p=0.5}{noalt}*{/noalt} I even called out to you..."
    show costume tie nervous at droop
    mike_no_img "I've been tryin' to find you for a while now,{w=0.2} too.{p=0.2}{noalt}*{/noalt} Believe me,{w=0.2} it's been a heck of a time."
    show costume tie frown 
    mike_no_img "This Dark World's huge.{w=0.2} Way too big if ya ask me.{p=0.5}{noalt}*{/noalt} Can't even begin to explain how long it's taken to even get here."
    show costume pointing frown at jump
    mike_no_img "Couldn't have done it without help,{w=0.2} actually..."
    show tenna upright back awkward flipped at jump
    tenna "[persistent.mc]...{w=0.2} is there nothing you can't do?!{w=0.2} Haha!"
    if itm_ring in inventory:
        show tenna upright chest awkward flipped
        tenna "Wait.{p=0.5}{noalt}*{/noalt} Does that mean,{w=0.2} then...?"
        show costume down frown
        mike_no_img "Huh?{w=0.5} Mean what,{w=0.2} boss?"
        show tenna upright back panic flipped at jump
        tenna "Oh,{w=0.2} haha,{w=0.2} well,{w=0.2} it's probably nothing.{w=0.5} Just,{w=0.2} um."
        show tenna upright pointing oh flipped
        tenna "[persistent.mc],{w=0.2} was MIKE the one that gave you that ring...?"
        show costume pointing nervous at jump
        mike_no_img "H- huh?!{w=0.2} Hold on, hold on,{w=0.2} WHAT ring?!{p=0.5}{noalt}*{/noalt} I didn't give anybody any rings!!{p=0.5}{noalt}*{/noalt} No rings here,{w=0.2} no sirree!!"
        show costume tie nervous at wiggle
        mike_no_img "I wouldn't do that,{w=0.2} hahaha!!{p=0.5}{noalt}*{/noalt} Not a ring guy,{w=0.2} nope,{w=0.2} wouldn't go near one ever,{w=0.2} nope!!!"
        mike_no_img "Not,{w=0.2} I mean,{w=0.2} unless you asked.{w=0.5} Or wanted one."
        show costume pointing nervous at jump
        mike_no_img "FOR SOME REASON. NOT THAT ANY SPRING TO MIND OR ANYTHING.{p=0.1}{noalt}*{/noalt} HAHAHA."
    else:
        show tenna upright pointing oh flipped
        tenna "Wait,{w=0.2} so,{w=0.2} have you been with Mike this whole time,{w=0.2} then...?"
        show costume tie frown at jump
        mike_no_img "Hold on, here.{p=0.5}{noalt}*{/noalt} I only met,{w=0.2} uh,{w=0.5} [persistent.mc]{w=0.2} pretty recently."
        show tenna upright back awkward flipped at jump
        tenna "Haha,{w=0.2} well,{w=0.2} I haven't known [persistent.mc] for very long either!"
        show tenna upright chest panic flipped
        tenna "It was...{w=0.5} Um.{nw=0.5}"
        show tenna upright pointing weak flipped at jump
        extend "{p=0}{noalt}*{/noalt} Actually,{w=0.2} I don't know how much time has passed, haha!"
        show tenna upright back frown flipped at droop
        tenna "Not without any working clocks..."
        show costume pointing smile at jump
        mike_no_img "YOU TOO??{p=0.5}{noalt}*{/noalt} Oh, good gravy,{w=0.2} I've been losing my freaking mind out here and that has NOT been helping."
        show costume tie nervous at wiggle
        mike_no_img "Has it been one day??{w=0.2} Four??{w=0.2} Four HOURS???{w=0.2} Can't tell!!"
        show costume tie frown
        mike_no_img "Not really helped by the fact that I've not really been able to talk to another living being besides myself for that time too--"
        show costume pointing nervous at jump
        mike_no_img "but it's FINE,{w=0.2} totally and absolutely FINE,{w=0.2} because now you're actually here and everything--!"

    show tenna slouch claw panic flipped at jump
    tenna "MIKE, calm down!!{w=0.2} I get it already!!"
    show costume pointing frown at droop
    mike_no_img "...{w=0.5} Ah."
    show costume tie nervous
    mike_no_img "Ahem.{nw=0.5}"
    show costume pointing smile at jump
    extend " Yep, yep.{w=0.2} Sorry about that,{w=0.2} boss!{p=0.5}{noalt}*{/noalt} Got a little caught up in my thoughts there,{w=0.2} you understand!!"
    show tenna upright chest confused flipped at rise
    tenna "Right{w=0.2}.{w=0.2}.{w=0.2}."
    show tenna upright back frown flipped
    tenna "I see you're...{w=0.2} in a TALKATIVE mood today..."
    tenna "...{nw=0.5}"
    show tenna upright chest neutral flipped at jump
    extend " any chance you could change that?"
    show costume tie nervous at jump
    mike_no_img "What--{w=0.2} No??"
    show tenna upright back smile flipped at jump
    tenna "Okay, okay!{w=0.2} Haha,{w=0.2} sorry!"
    show tenna stretch shrug smile at jump
    tenna "I'd been visualizing our reunion happening when you were in a more...{w=0.2} cuddly, cat-like mood."
    show tenna upright pointing smile flipped at jump
    tenna "But don't worry about that!!{w=0.2} Be in whatever mood you need to.{p=0.5}{noalt}*{/noalt} Don't let my sappy needs bother you any,{w=0.2} haha!"
    show tenna upright back awkward flipped
    show costume tie frown
    pause 2.0
    show costume down frown at droop
    mike_no_img "Yeah,{w=0.5} a'course,{w=0.2} boss."
    mike_no_img "Definitely not in a cat mood right now.{w=0.5} Sorry."
    show costume pointing frown at rise
    mike_no_img "Look,{w=0.2} see,{w=0.2} so,{w=0.2} let me just cut to the chase, here,{w=0.2} alright?"
    show costume tie frown
    mike_no_img "We've gotta go, soon,{w=0.2} like as-soon-as-possible-ASAP."
    show tenna upright chest confused flipped at jump
    tenna "Go?{p=0.5}{noalt}*{/noalt} Go WHERE?"
    show costume pointing smile at jump
    mike_no_img "Home.{p=0.5}{noalt}*{/noalt} Our new home,{w=0.2} that is."
    show costume tie smile
    mike_no_img "That little fluffy prince invited us to a new Dark World to live in.{p=0.5}{noalt}*{/noalt} He's already made a room for you and everything."
    show tenna panic flustered flipped at jump
    tenna "A room for--?!"
    show costume pointing frown
    mike_no_img "But we've gotta be QUICK.{w=0.2} There's only so much time left."
    show tenna upright chest confused flipped at droop
    tenna "Time left until...{w=0.2} what, exactly?"
    show costume tie frown
    mike_no_img "I,{w=0.2} uh."
    show costume tie nervous at droop
    mike_no_img "Don't{w=0.5} know."
    pause 1.0
    show tenna upright chest panic flipped
    tenna "You...{w=0.5} don't know?"
    show costume pointing nervous at wiggle
    mike_no_img "Thaaat is what I said,{w=0.2} yep,{w=0.2} uh-huh,{w=0.2} good listening, boss,{w=0.2} hahaha."
    pause 1.0
    show tenna upright chest blank flipped
    tenna "Mike,{w=0.5} are you okay?"
    show tenna upright back panic flipped at jump
    tenna "You seem...{w=0.5} more nervous than usual."
    show tenna upright back confused flipped
    tenna "Did something happen while I was gone?{p=0.5}{noalt}*{/noalt} Don't tell me the Lightners also..."
    show costume at jump
    mike_no_img "Threw me out?{w=0.2} No, nope,{w=0.2} nothing remotely like that."
    show costume down frown
    mike_no_img "I'm here outta my own free will."
    show costume pointing frown
    mike_no_img "You weren't in Castle Town with everybody else who moved in from TV World..."
    show costume tie frown
    mike_no_img "Lightners wouldn't tell me what they did with ya when I asked,{w=0.2} either."
    show costume down frown at jump
    mike_no_img "I took it upon myself to find ya and bring ya home,{w=0.2} with everybody else."
    show tenna upright chest confused flipped
    tenna "Mike...?"
    pause 1.0
    show tenna upright pressed smile flipped at rise
    tenna "Ahh,{w=0.2} Mike,{w=0.2} I'm INCREDIBLY touched!{p=0.2}{noalt}*{/noalt} Golly,{w=0.2} I'm practically moved to {nw}"
    play sfx splat
    extend "{image=txt_tears}{alt}tears{/alt}!"
    show tenna upright pointing smile flipped at jump
    tenna "The fact that you cared enough to drop everything just to find me...{w=0.2} and to hear there's a room with my name on it waiting for me?"
    show tenna upright pressed smile flipped at wiggle
    tenna "All the pain over the last however-long is just melting away!{p=0.2}{noalt}*{/noalt} Haha,{w=0.2} it's practically a{nw}"
    play sfx ten_hope
    if persistent.glitches:
        extend " {image=txt_dreamG}{alt}dream{/alt}{w=0.2} come true!"
    else:
        extend " {image=txt_dream}{alt}dream{/alt}{w=0.2} come true!"
    pause 1.0
    show tenna upright chest frown flipped at yreset
    pause 1.0
    tenna "But, seriously...{nw=0.5}"
    stop music
    show tenna upright back frown flipped at droop
    extend " are you okay?"
    show tenna upright back panic flipped
    tenna "You{w=0.5} look almost faint."
    pause 2.0
    show costume down nervous
    mike_no_img "H-{w=0.1} hey,{w=0.5} what's the big idea...?"
    show costume pointing nervous at jump
    mike_no_img "Mike's always been here for ya,{w=0.2} never not!{w=0.2} Never-ever!{p=0.5}{noalt}*{/noalt} I'm always okay,{w=0.2} always in tip-top shape!"
    show costume pointing smile
    mike_no_img "You shouldn't ever have to worry about a single thing while I'm still kickin',{w=0.2} got that?"
    show costume tie nervous at droop
    mike_no_img "Why are you...{w=0.5} asking if I'm okay?"
    show costume pointing nervous
    mike_no_img "Boss,{w=0.2} are YOU okay?"
    show tenna upright back nose flipped
    play music dumpS
    tenna "...{w=0.5} Do you really have to ask that,{w=0.2} Mike?"
    show tenna stretch shrug weak flipped at jump
    tenna "We're in a DUMP,{w=0.2} for goodness's sake.{p=0.5}{noalt}*{/noalt} I think it's pretty obvious I'm not okay."
    show tenna upright back frown flipped
    tenna "Until today,{w=0.2} I thought I'd be living out my last few days here.{p=0.2}{noalt}*{/noalt} Alone."
    show tenna upright back nosed at jump
    tenna "I distracted myself with the few nice things I could find.{p=0.2}{noalt}*{/noalt} Anything to make the pain less."
    show tenna stretch shrug weak at wiggle
    tenna "I tried telling myself it'll all eventually be okay,{w=0.2} but..."
    show tenna stretch raised cheer at jump
    tenna "Well,{w=0.2} to be frank,{w=0.5} it just made everything hurt even more, haha!!"
    show tenna upright chest awkward flipped at jump
    tenna "That's when [persistent.mc] found me...{p=0.5}{noalt}*{/noalt} Now even you're back,{w=0.2} Mike!"
    show tenna upright back frown flipped at droop
    tenna "Admittedly,{w=0.2} it's hard for me to trust it won't all just go POOF in the next five minutes or so, like everything else..."
    show tenna upright chest neutral flipped at jump
    tenna "Oh,{w=0.2} nevermind.{p=0.5}{noalt}*{/noalt} You don't wanna hear about all the horrible things I've been through AGAIN,{w=0.2} haha!"
    show costume tie nervous at droop
    mike_no_img "Tenna...?"
    pause 1.0
    show costume tie frown
    mike_no_img "I...{w=0.5} wait,{w=0.2} hold on a sec."
    show tenna upright pointing oh flipped at jump
    tenna "Yes,{w=0.2} Mike?"
    show costume down frown 
    mike_no_img "I...{w=0.5} I know I said we're on a time crunch,{w=0.2} and that's still true,{w=0.2} but I've just..."
    mike_no_img "I've gotta say something.{p=0.5}{noalt}*{/noalt} And that something..."
    pause 1.0
    show costume down nervous
    mike_no_img "...{w=0.5} is \"I'm sorry.\""
    pause 1.0
    show tenna upright chest panic flipped at jump
    tenna "Um.{p=0.5}{noalt}*{/noalt} \"Sorry\" for what?{w=0.2} Haha."
    show costume down frown
    mike_no_img "Back in TV World."
    show costume tie nervous
    mike_no_img "We...{w=0.5} I followed along with everybody else and left when you were at your lowest."
    show costume tie frown
    mike_no_img "I shoulda known better than anyone else that this was the worst thing I could have possibly decided to do."
    show costume tie nervous
    mike_no_img "Boss,{w=0.2} {noalt}y'see{/noalt}{alt}ya see{/alt},{w=0.2} it's..."
    pause 1.0
    show costume pointing frown
    mike_no_img "It's so hard to watch somebody you care about go so off the rails that they start hurting people without thinking twice."
    show costume down frown
    mike_no_img "Nothin' I could say even slowed you down.{p=0.5}{noalt}*{/noalt} I'd never seen you get that bad before..."
    show tenna upright back confused flipped
    show costume down nervous
    mike_no_img "I didn't know what to do other than just save myself from being the next thing you lashed out at."
    show costume at wiggle
    mike_no_img "But...{w=0.5} b'cause of that you...{p=0.5}{noalt}*{/noalt} You got stuck in this hellish place and..."
    show costume tie nervous
    mike_no_img "It's my fault,{w=0.5} ain't it?"
    show tenna slouch claw panic flipped at jump
    tenna "M-{w=0.1} Mike, are you crying?"
    show tenna upright chest confused flipped
    tenna "I...{w=0.2} wasn't even aware you COULD--{nw=0.2}"
    if persistent.glitches:
        show costume pointing angry at jump
    else:
        show costume pointing angry at shock
    mike_no_img "Absolutely not!{p=0.2}{noalt}*{/noalt} I'd...{w=0.2} n-{w=0.1} never do that!{w=0.2} Never!"
    show costume pointing nervous at wiggle
    mike_no_img "Mike's here to support YOU!{w=0.2} That's what I've always done,{w=0.2} and always WILL DO!"
    show tenna slouch claw panic flipped at droop
    tenna "Mike...?"
    show costume tie nervous
    mike_no_img "I'm okay,{w=0.2} you don't need to worry about me,{w=0.2} didn't I just get done saying all that crap already?!{p=0.2}{noalt}*{/noalt} How many times I gotta repeat myself?!"
    if persistent.glitches:
        show tenna slouch claw angry flipped at jump
    else:
        show tenna slouch claw angry flipped at shock
    tenna "MIKE!"
    show costume down nervous at jump
    mike_no_img "WHAT?!"
    tenna "Are you {nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend "STUPID?!"
    show costume tie nervous at jump
    mike_no_img "T-{w=0.1} Tenna??"
    show tenna upright pointing oh flipped at rise
    tenna "Didn't {color=[c_star]}I{/color} just get done telling {color=[c_star]}YOU{/color} how repeating this rhetoric of being okay doesn't actually help?!"
    show costume pointing nervous
    mike_no_img "I mean,{w=0.2} boss,{w=0.2} w-{w=0.1} with all due respect 'n all,{w=0.2} that's about yourself...{w=0.5} I can still--{nw=0.5}"
    show tenna upright chest angry flipped at jump
    tenna "MIKE,{w=0.2} stop it already!{p=0.5}{noalt}*{/noalt} What's gotten into you?!"
    show costume at droop
    mike_no_img "Ahh,{w=0.2} c'mon,{w=0.2} Tenna,{w=0.5} what's the problem...?"
    show costume tie nervous
    mike_no_img "Can't we at least save this arguing for while we're heading home or something...?"
    show tenna slouch claw angry flipped at jump
    tenna "AND ANOTHER THING!{p=0.2}{noalt}*{/noalt} You better tell me what your \"time limit\" nonsense is about,{w=0.2} mister!"
    tenna "I am {nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend "NOT going through this whole shebang again!"
    show costume pointing nervous at wiggle
    mike_no_img "I-{w=0.1} I'm being honest, boss,{w=0.2} I don't know what'll happen once time's up!"
    show tenna upright chest angry flipped at jump
    tenna "Why even is there a time limit,{w=0.2} huh?{p=0.2}{noalt}*{/noalt} What's going on?{w=0.2} Are you even Mike?"
    show costume tie nervous at droop
    mike_no_img "That's--?!"
    show costume pointing angry at rise
    mike_no_img "You're asking that NOW?"
    show tenna slouch claw angry flipped at jump
    tenna "What's THAT supposed to mean?!"
    show costume tie nervous at droop
    mike_no_img "N-{w=0.1} nothing!!{p=0.2}{noalt}*{/noalt} Nothing, I swear, just--{w=0.2} a slip of the tongue!!"
    menu:
        "Mike should say something":
            $ multichar = False
            "You elbow Mike,{w=0.2} quietly encouraging him to speak up."

        "...":
            if persistent.glitches:
                show tenna at jump
            else:
                show tenna at shock
            tenna "NOTHING?{nw=0.2}"
            show tenna stretch shrug smile flipped at jump
            extend " Oh,{w=0.2} JOY!"
            show tenna upright chest angry flipped at jump
            tenna "You know,{w=0.2} I'd be filthy rich if I had a nickel for every time someone I cared about said that the MOMENT I showed concern for them!!"
            show costume pointing nervous at wiggle
            mike_no_img "B-{w=0.1} boss,{w=0.2} this isn't like that,{w=0.2} I swear!"
            menu:
                "Mike should say something":
                    $ multichar = False
                    "You elbow Mike,{w=0.2} quietly encouraging him to speak up."

                "...":
                    show tenna upright back frown flipped
                    tenna "I'm sick of all this lying and pretending, {w=0.2}Mike!"
                    show tenna slouch panic panic flipped
                    tenna "I can't take it anymore!{w=0.2} It's not helping!!"
                    show tenna slouch panic static flipped at wiggle
                    tenna "I've been lied to by HIM,{w=0.2} by my own FAMILY,{w=0.2} by my own EMPLOYEES..."
                    if persistent.glitches:
                        show tenna upright pointing weak flipped
                    else:
                        show tenna upright pointing weak flipped at shaking
                    tenna "...{w=0.2} and by my ONLY REMAINING FRIEND, too,{w=0.2} APPARENTLY."
                    show tenna stretch shrug weak
                    tenna "Why does no one think I can handle the truth?!"
                    show costume tie nervous at droop
                    mike_no_img "T...{w=0.5} Tenna..."
                    menu:
                        "Mike should say something":
                            $ multichar = False
                            "You elbow Mike,{w=0.2} quietly encouraging him to speak up."

                        "...":
                            show tenna slouch panic panic
                            tenna "Is it because I lash out?{w=0.2} Is it because I get frustrated?"
                            show tenna slouch claw angry
                            tenna "Because, really,{w=0.2} I only get MORE annoyed the more it just STACKS UP!"
                            show costume down nervous at wiggle
                            mike_no_img "T...{w=0.2} T{noalt}-{/noalt}..."
                            if persistent.glitches:
                                show tenna slouch claw angry flipped at jump
                            else:
                                show tenna slouch claw angry flipped at shock
                            tenna "What NOW?{p=0.2}{noalt}*{/noalt} Haha,{w=0.2} you've practically lost your voice!?"
                            show tenna upright pointing weak flipped
                            tenna "Mike,{w=0.2} you weren't even this terrified when you LEFT."
                            if persistent.glitches:
                                show tenna slouch claw angry flipped at jump
                            else:
                                show tenna slouch claw angry flipped at shock
                            tenna "You weren't even this scared when I told you about the damn contract!"
                            menu:
                                "Mike needs to say something":
                                    $ multichar = False
                                    "You loudly say Mike needs to speak up."

    $ multichar = True
    show tenna upright back confused flipped at jump
    tenna "[persistent.mc]?"
    show costume tie nervous at wiggle
    $ multichar = False
    "Mike can't bring himself to speak.{p=0.5}{noalt}*{/noalt} He just keeps shaking his head at you."
    $ multichar = True
    show tenna upright back frown flipped
    tenna "...{w=0.5} I took it too far again,{w=0.2} didn't I?"
    show tenna slouch panic panic at wiggle
    tenna "Haha,{w=0.2} why is it so hard to just...{w=0.5} control myself sometimes?"
    show tenna upright back confused flipped at jump
    tenna "I'm sorry,{w=0.2} Mike,{w=0.2} I..."
    show costume down nervous
    stop music fadeout 1.0
    mike_no_img "D...{w=0.5} d..."
    pause 1.0
    show tenna upright chest confused flipped
    tenna "...{w=0.2} Mike?"
    show tenna upright chest neutral flipped
    tenna "Haha.{p=0.5}{noalt}*{/noalt} Sorry,{w=0.2} I didn't catch what you said there."
    show costume pointing nervous
    mike_no_img "...{w=0.5} D...{w=0.2} don't...{w=0.5} call me that."
    pause 1.0
    show tenna upright back confused flipped
    tenna "Did I say something weird?"
    show costume pointing frown at droop
    mike_no_img "I'm..."
    pause 2.0
    show costume down frown
    mike_no_img "{cps=35}You...{w=0.5} were right.{/cps}"
    show costume down nervous
    mike_no_img "{cps=35}I'm...{w=0.5} I'm not Mike.{p=0.5}{noalt}*{/noalt} I've never been Mike.{/cps}"
    mike_no_img "{cps=35}I've been...{w=0.5} lying to you this whole time.{/cps}"
    show costume down frown
    mike_no_img "{cps=35}I'm sorry.{/cps}"
    pause 2.0
    show tenna upright back panic flipped
    tenna "Haha,{w=1.0} what?"
    show tenna upright pointing weak flipped
    tenna "I don't really understand.{p=0.5}{noalt}*{/noalt} Do you mean,{w=0.2} you've been using a different name this whole time?"
    show tenna stretch shrug smile flipped
    tenna "I can't say I mind one way or another what you go by."
    show costume down nervous
    mike_no_img "N-{w=0.1} no,{w=0.2} not...{w=0.5} that."
    show costume down frown
    mike_no_img "I..."
    show costume tie nervous
    mike_no_img "{cps=35}I don't know who your friend Mike is.{p=0.5}{noalt}*{/noalt} I've been trying to find him for years,{w=0.5} but I kept running into dead ends.{/cps}"
    show tenna upright back nose flipped at jump
    show costume at wiggle
    mike_no_img "{cps=35}I told myself this would be temporary,{w=0.2} just so ya wouldn't be so miserable all the time.{/cps}"
    show costume pointing nervous
    mike_no_img "{cps=35}\"This'll be over when I find the real Mike,\"{w=0.2} I kept sayin'.{/cps}"
    show costume tie nervous
    mike_no_img "{cps=35}But that didn't happen.{p=0.2}{noalt}*{/noalt} It's been,{w=0.2} uh,{w=0.5} ten or so years.{/cps}"
    show tenna slouch claw panic flipped at jump
    tenna "T- TEN--?!"
    show costume down nervous
    mike_no_img "{cps=35}I'm sorry.{p=0.5}{noalt}*{/noalt} I'm real sorry,{w=0.2} Tenna.{/cps}"
    show costume pointing nervous
    mike_no_img "{cps=35}I didn't want to hurt you even more.{p=0.5}{noalt}*{/noalt} I really wanted to make things better,{w=0.2} but I just...{w=0.5} I went ahead and screwed up everything.{/cps}"
    pause 1.0
    show costume down frown at droop
    pause 2.0
    show tenna upright back frown flipped at jump
    pause 2.0
    show tenna upright back frown at jump
    tenna "...{nw=0.5}"
    play music lostgirl
    extend " Thank you for telling me."
    show tenna upright pointing oh flipped at jump
    tenna "You're right,{w=0.5} I'm not happy to hear that."
    show tenna stretch shrug weak flipped at jump
    tenna "It...{w=0.5} hurts quite a lot,{w=0.2} actually!"
    show tenna upright back frown flipped at droop
    tenna "Haha,{w=0.2} I'm...{w=0.5} not ready for all THAT to sink in later."
    show tenna upright back blank flipped at rise
    tenna "But...{w=0.5} thank you for trusting me with the truth."
    show costume tie frown at rise
    mike_no_img "...?{alt}hm?{/alt}"
    show costume down frown
    mike_no_img "Uh.{w=0.5} You're...{w=0.2} welcome...?"
    pause 2.0
    show costume down nervous
    mike_no_img "I really ruined everything here,{w=0.2} huh,{w=0.2} didn't I..."
    show tenna upright back nose flipped
    tenna "Well,{w=0.2} if {color=[c_star]}I{/color} can be honest for a second..."
    show tenna upright pointing oh flipped
    tenna "There's still a part of me that's overjoyed to know you cared enough to come looking for me when no one else bothered."
    show costume down frown at droop
    mike_no_img "Oh, come on,{w=0.2} don't bother with that.{p=0.5}{noalt}*{/noalt} I'm not even the guy you thought I was."
    show tenna upright back frown flipped
    tenna "No,{w=0.2} you're not.{p=0.5}{noalt}*{/noalt} It really stings knowing that the Mike I once called my friend is just...{w=0.5} gone."
    show tenna upright back nose flipped
    tenna "That being said..."
    show tenna upright back neutral flipped at jump
    tenna "The other \"Mike\" I still call my friend is standing right in front of me."
    show tenna upright pointing oh flipped at jump
    tenna "He's still here for me,{w=0.2} through thick and thin."
    show tenna upright pressed smile flipped at rise
    tenna "I can't say that about...{w=0.5} pretty much anyone else I've ever known,{w=0.2} haha."
    show costume tie nervous at jump
    mike_no_img "You're giving me way too much credit."
    show costume pointing frown
    mike_no_img "If I were you,{w=0.2} I woulda just thrown my ass to the curb by now."
    show tenna upright chest awkward flipped at jump
    tenna "Oh, no,{w=0.2} that's absolutely not happening.{p=0.2}{noalt}*{/noalt} Even if your ass is strangely variable."
    mike_no_img "...{nw=0.5}"
    show costume tie awkward at jump
    extend " wait what--{nw=0.2}"
    show tenna upright pointing oh flipped at jump
    tenna "Mike--{w=0.2} or, well.{p=0.2}{noalt}*{/noalt} What's your real name,{w=0.2} actually?"
    show costume pointing angry
    mike_no_img "We're just not gonna--{nw=0.2}"
    show costume down frown at jump
    extend " okay,{w=0.2} whatever."
    show costume pointing frown
    mike_no_img "My name?{w=0.5} It's,{w=0.2} uh..."
    pause 2.0
    show tenna upright back panic flipped at jump
    tenna "Haha.{w=0.5} Don't tell me you FORGOT it or something...?"
    show costume pointing nervous at jump
    mike_no_img "N-{w=0.1} no,{w=0.2} it's not that."
    show costume tie nervous
    mike_no_img "I'm{w=0.2}.{w=0.2}.{w=0.2}."
    pause 1.0
    show costume pointing nervous at wiggle
    mike_no_img "D...{w=0.5} do you know how hard it is to search for someone while overheating in a thick costume that half-blinds you,{w=0.2} by the way?"
    mike_no_img "Hahahahaha...{w=0.5} ha."
    show tenna upright chest frown flipped
    tenna "...{w=0.5} Are you trying to change the subject on me?"
    show costume tie nervous
    mike_no_img "What?{p=0.5}{noalt}*{/noalt} Pfft.{w=0.2} Hahaha.{p=0.5}{noalt}*{/noalt} What?"
    show tenna upright back frown flipped
    tenna "Is there a reason you're not answering my question?"
    show costume tie frown at yreset
    mike_no_img "..."
    pause 1.0
    show costume down frown
    mike_no_img "Yeah."
    mike_no_img "I...{w=0.5} hold on."
    show costume down frown flipped at cospos_right2_fl
    show costume at jump
    mike_no_img "I'm...{w=0.2} sick of wearing this costume."
    show tenna upright chest neutral flipped at jump
    tenna "Okay.{w=0.2} I'll wait."
    $ multichar = False
    "You offer Mike an enthusiastic thumbs up."
    $ multichar = True
    show costume tie awkward at cospos_right2
    show costume at jump
    mike_no_img "D-{w=0.1} don't look at me like that!"
    show costume tie frown flipped at cospos_right2_fl
    hide costume with easeoutright
    pause 1.0
    show tenna panic flustered flipped at jump
    pause 0.5
    show tenna upright back awkward at jump
    pause 2.0
    show mike standing nervous at mikepos_offsceenright
    show mike at mikepos_right with MoveTransition(1.5,time_warp=_warper.ease)
    pause 1.0
    mike_no "So...{w=0.2} yeah."
    show mike standing sigh
    mike_no "I've just been...{w=0.2} using Mike's name.{p=0.5}{noalt}*{/noalt} I'm probably nothing like the Mike you knew."
    show tenna upright back blank flipped at jump
    pause 1.0
    tenna "Ah..."
    show tenna upright chest panic flipped
    tenna "I'm...{w=0.2} guessing your name is Pippins,{w=0.2} then?"
    show mike standing nervous at mikepos_offcenease
    gp "Technically,{w=0.2} yeah."
    show mike standing sigh
    gp "But{w=0.5} after using the name \"Mike\" for ten years?"
    show mike tie nervous
    gp "I think it's broken my brain."
    show mike standing conflicted
    gp "I get sick to my stomach hearing someone call me \"Pippins\" nowadays.{p=0.2}{noalt}*{/noalt} But if somebody calls me \"Mike\"...?"
    show mike standing nervous
    gp "It actually feels...{w=0.2} more like me at this point."
    show tenna upright chest confused flipped
    pause 1.0
    show mike standing sigh at droop
    gp "Sorry I stole your friend's identity."
    show tenna slouch claw panic flipped at jump
    tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}?{p=0.2}{noalt}*{/noalt} I wasn't thinking about that at all!"
    show tenna upright pointing oh flipped at jump
    tenna "What I was GOING to say was--{p=0.5}{noalt}*{/noalt} If you still want to be called Mike,{w=0.2} then I'm not going to stop calling you Mike."
    show mike standing conflicted at rise
    gp "...{w=0.5} Why?"
    show tenna upright chest neutral flipped at jump
    tenna "Why not?"
    show tenna upright chest smile flipped
    tenna "You're by far not the first person I've known to change their name or identity."
    show tenna stretch shrug smile flipped at jump
    tenna "It wouldn't even be that weird if the other Mike showed up again!{p=0.2}{noalt}*{/noalt} Lots of people are named \"Mike\"!"
    show tenna upright pointing smile flipped at jump
    tenna "So if going by \"Mike\" makes you happy,{w=0.5} I'll keep calling you Mike."
    show mike standing awkward at droop
    mike "..."
    pause 1.0
    show mike standing sigh
    mike "I should tell you,{w=0.2} too..."
    show mike tie nervous
    mike "I wasn't the only one doing this.{p=0.2}{noalt}*{/noalt} I hired two other guys to be \"Mike,\" too--"
    show tenna upright chest blank flipped at jump
    tenna "That explains why your ass was so variable."
    mike "-- so don't be mad at them on account of m...{nw=0.5}"
    show mike standing indifferent
    extend " wait,{w=0.2} what?"
    if persistent.glitches:
        show mike arms avert
    else:
        show mike arms avert at shakingcg
    mike "HEY,{w=0.2} just how much were you staring at our asses?!"
    show tenna upright pointing oh flipped at jump
    tenna "Wait,{w=0.2} if the other two were also Mike..."
    show tenna upright pointing weak flipped
    tenna "When you went from being talkative to cat-like to clumsy--{w=0.5} was that you three swapping places...?"
    show mike arms freakout
    mike "You're just not gonna--{nw=0.2}"
    show mike standing indifferent at yreset
    extend " wait--{nw=0.5}"
    if persistent.glitches:
        show mike arms freakout at jump
    else:
        show mike arms freakout at shock
    extend " {noalt}IT{/noalt}{alt}it{/alt} WASN'T OBVIOUS TO YOU AT ALL??"
    show tenna panic panic flipped at jump
    tenna "W-{w=0.1} well! I...{w=0.2} really didn't put much thought into it."
    show mike standing pout at yreset
    show tenna upright chest frown flipped
    tenna "I thought it was a bit strange,{w=0.2} but I guess...{nw=0.5}"
    show tenna at droop
    extend "{p=0}{noalt}*{/noalt} The idea of three people pretending to be my only friend felt too outlandish to be true?"
    show tenna upright back frown flipped
    tenna "I also didn't really want Mike to be gone,{w=0.2} either,{w=0.2} haha."
    show tenna upright back nose flipped
    tenna "Accepting the antics was a lot easier..."
    show tenna upright back nosed flipped at shrink
    tenna "Maybe it's my fault for letting you three lie to me instead of picking up on it sooner..."
    show mike standing conflicted at leanleftL
    mike "Oh, geez,{w=0.2} Tenna,{w=0.2} that's not what I meant!!"
    show mike standing nervous
    mike "It's not your fault...{w=0.5} THAT of ALL THINGS is NOT your fault."
    show mike standing sigh at droop
    mike "There's...{w=0.5} There's a lotta things I'm definitely still mad at you about-- {nw}"
    show mike arms freakout at jump
    extend "BUT THIS ISN'T ONE OF THEM!"
    show tenna upright back nose flipped
    tenna "Ah...{nw=0.5}"
    show tenna at shrinks
    extend " But you...{w=0.2} ARE still...?"
    show tenna upright back nosed flipped
    show mike standing conflicted at leanleftL2
    mike "Tenna...!{p=0.2}{noalt}*{/noalt} Augh."
    show mike arms avert at jump
    mike "Look, LOOK!!{w=0.5} I'm not perfect,{w=0.2} you're not perfect,{w=0.2} nobody's perfect!!{p=0.5}{noalt}*{/noalt} I messed up,{w=0.2} you messed up,{w=0.5} WHATEVER!"
    show mike standing nervous at droop
    mike "I just wanna go home...{w=0.5} and I just can't call it home without you there."
    show mike tie blush at wiggle
    mike "A-{w=0.1} Alright!? That's {noalt}IT{/noalt}{alt}it{/alt}!!"
    show tenna upright back nose flipped
    tenna "You...?"
    pause 2.0
    show tenna upright pressed smile flipped at zreset
    tenna "Oh,{w=0.2} MIKE!{p=0.5}{noalt}*{/noalt} How do you ALWAYS know the right thing to say?"
    show tenna upright chest confused flipped at wiggle
    tenna "I...{w=0.5} really missed you SO much,{w=0.2} haha..."
    show mike standing conflicted at leanrightLQ_mike
    mike "H-{w=0.1} Hey, hey, hold on, hold ON here!{w=0.5} I didn't even say anything all that special,{w=0.2} don't get all sentimental on me!!"
    show mike standing sigh
    mike "Let's...{w=0.2} just go home already."
    show mike standing wink
    mike "Everybody's waitin' for you,{w=0.2} y'know."
    show mike standing nervous
    mike "We'll still have to find a way outta here,{w=0.2} but...{p=0.5}{noalt}*{/noalt} I don't wanna find out what'll happen if I run out of time."
    show tenna upright back confused flipped at jump
    tenna "You really don't know?"
    show mike tie nervous at droop
    mike "Nope.{w=0.2} Not a clue.{p=0.2}{noalt}*{/noalt} And it's kind of terrifying me."
    show mike standing conflicted at yreset
    mike "But if we make it back in time...{w=0.2} then it won't really matter.{w=0.2} Right?"
    show mike standing nervous
    mike "I could explain the rest to you on the way back,{w=0.2} if you really wanna hear about it so bad."
    show tenna upright chest frown flipped
    tenna "..."
    show tenna upright back smile flipped at jump
    tenna "No,{w=0.2} it's okay.{w=0.2} I believe you."
    show tenna upright pointing oh flipped
    tenna "When I can see your face clearly like this,{w=0.2} now I can tell you've got this sort of..."
    show tenna upright pointing smile flipped at jump
    tenna "Well,{w=0.2} the look on your face just screams \"sincere\" to me!"
    show tenna upright chest smile flipped
    show mike standing awkward at droop
    mike "I..."
    pause 1.0
    show mike tie awkward at rise
    mike "O-{w=0.1} okay.{w=0.2} Sure.{p=0.5}{noalt}*{/noalt} Whatever makes you happy."
    show mike standing pout at jump
    mike "Guess we should just...{w=0.2} start searching for the exit, then,{w=0.2} huh?"
    $ multichar = False
    "You pop in to say that you have a plan that might work."
    $ multichar = True
    show tenna upright pressed smile flipped at rise
    tenna "[persistent.mc],{w=0.2} impressive as ever!{p=0.2}{noalt}*{/noalt} You don't even NEED a gold {nw}"
    play sfx sparkleglock
    if persistent.glitches:
        extend "{image=txt_starG}{alt}star{/alt} when you're already shining so bright on your own!"
    else:
        extend "{image=txt_star}{alt}star{/alt} when you're already shining so bright on your own!"
    show tenna upright pointing oh flipped at jump
    tenna "What's the plan?"
    $ multichar = False
    "You suggest heading over to the mattress that you found not too far from here."
    $ multichar = True
    show mike standing indifferent
    show tenna upright back nose flipped
    tenna_shh "........................"
    show tenna upright back awkward flipped at jump
    tenna "Haha.{w=0.5} Just for clarification,{w=0.2} [persistent.mc]...{p=0.5}{noalt}*{/noalt} What is it you're implying we do?"
    $ multichar = False
    "You say it'll make sense in a few minutes."
    $ multichar = True
    show tenna upright chest awkward flipped at jump
    tenna "O-{w=0.1} oh!"
    show tenna slouch whisper smug flipped
    tenna "Well,{w=0.2} alrighty then,{w=0.2} if you say so..."
    show mike arms avert at jump
    mike "Don't get all excited about it,{w=0.2} what, what?!"
    show mike tie awkward at jump
    mike "Have you always been this much of a pervert and I just haven't been paying attention?!"
    show tenna upright back awkward flipped at jump
    tenna "P-{w=0.1} pervert?!{p=0.2}{noalt}*{/noalt} That's a bit harsh,{w=0.2} don't you think??"
    show mike standing awkward
    mike "Tell that to my ass that you apparently keep staring at!!"
    show tenna panic flustered flipped at jump
    tenna "I...!"
    show tenna upright back awkward flipped at wiggle
    tenna "You know what? I'm just not going to reply to that."
    show mike arms freakout at jump
    mike "Are you for--{nw=0.2}"
    show mike standing sigh
    extend " sigh.{w=0.2} Nope.{w=0.2} Nevermind."
    show mike tie nervous
    mike "[persistent.mc],{w=0.2} just lead us home before I completely lose my marbles."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    $ multichar = False
    "You lead Tenna and Mike to the mattress not too far from here."

    # TO UNIVERSAL ENDING
    $ end_battenna = "done"
    jump ending_universal