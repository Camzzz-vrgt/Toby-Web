############################################################################################################
################## HEALTHBAR SCREENS
screen lot_healthbar:
    hbox:
        xpos 0.25
        ypos 0.7
        if lot_life == 3:
            add lot_full
            add lot_full
            add lot_full
        elif lot_life == 2:
            add lot_full
            add lot_full
            add lot_empty
        elif lot_life == 1:
            add lot_full
            add lot_empty
            add lot_empty
        elif lot_life == 0:
            add lot_empty
            add lot_empty
            add lot_empty

screen lot_bossbar:
    hbox:
        xpos 0.655
        ypos 0.7
        if lot_boss_life == 3:
            add lot_boss_full
            add lot_boss_full
            add lot_boss_full
        elif lot_boss_life == 2:
            add lot_boss_empty
            add lot_boss_full
            add lot_boss_full
        elif lot_boss_life == 1:
            add lot_boss_empty
            add lot_boss_empty
            add lot_boss_full
        elif lot_boss_life == 0:
            add lot_boss_empty
            add lot_boss_empty
            add lot_boss_empty

screen lot_crtbars:
    zorder 90
    hbox:
        xpos 0.25
        ypos 0.7
        if lot_life == 3:
            add lot_full_rgb
            add lot_full_rgb
            add lot_full_rgb
        elif lot_life == 2:
            add lot_full_rgb
            add lot_full_rgb
            add lot_empty_rgb
        elif lot_life == 1:
            add lot_full_rgb
            add lot_empty_rgb
            add lot_empty_rgb
        elif lot_life == 0:
            add lot_empty_rgb
            add lot_empty_rgb
            add lot_empty_rgb

    hbox:
        xpos 0.655
        ypos 0.7
        if lot_boss_life == 3:
            add lot_boss_full_rgb
            add lot_boss_full_rgb
            add lot_boss_full_rgb
        elif lot_boss_life == 2:
            add lot_boss_empty_rgb
            add lot_boss_full_rgb
            add lot_boss_full_rgb
        elif lot_boss_life == 1:
            add lot_boss_empty_rgb
            add lot_boss_empty_rgb
            add lot_boss_full_rgb
        elif lot_boss_life == 0:
            add lot_boss_empty_rgb
            add lot_boss_empty_rgb
            add lot_boss_empty_rgb



############################################################################################################
################## TV TIME 2 HOUSE MAP
screen lot_housemap:
    imagemap:
        xpos 431
        ypos 93

        ground 'lot_house'
        hover 'lot_houseH'

        hotspot (80,470,80,80) clicked Jump("lot_greenleft") # first house, green on left
        hotspot (240,390,80,80) clicked Jump("lot_blueleft") # second house, blue on left
        hotspot (400,470,80,80) clicked Jump("lot_orangeleft") # third house, orange on left
        hotspot (560,390,80,80) clicked Jump("lot_greenright") # fourth house, green on right
        hotspot (720,550,80,80) clicked Jump("lot_blueright") # fifth house, blue on right
        hotspot (880,390,80,80) clicked Jump("lot_orangeright") # sixth house, orange on right

    if lot_key:
        imagebutton:
            xpos 1311
            ypos 163

            idle "lot_door"
            hover "lot_doorH"
            action Jump("lot_lockdoor")



############################################################################################################
################## LEGEND OF TENNA VARIABLES

######################################################
##### PARK DATE GAME
default lot_replay = False # if replaying
default lot_played = False # played thru to the quit option at least once

default lot_life = 3 # how much health player has
default lot_act = None # either "Talk" or "Flirt"

default lot_enemy = "" # randomly generated
default lot_enemy_act = "" # what act using for enemy

default lot_boss_life = 3 # how much health boss has
default lot_boss_act = "" # what act using for boss

### tutorial variables
default lot_tutorial = False # seen tutorial
default lot_tutorial_boss = False # tutorial for boss seen
default lot_tutorial_enemy = False # seen tutorial for enemy 

default lot_tutorial_win = False # won the tutorial or not
default lot_tutorial_fail = 0 # how many times failed the tutorial

### enemy variables (if fought or not)
default lot_repeat = False # if it is a repeat
default lot_repeat_seen = False # if seen tenna's dialogue explaining it
default lot_flowey = False


######################################################
##### TV TIME 2
default lot_2_entry = False # walked in for the first time
default lot_greenLsee = False # seen the greenleft house
default lot_greenRsee = False # seen the greenright house
default lot_blueLsee = False # seen the blueleft house
default lot_blueRsee = False # seen the blueright house
default lot_orangeLsee = False # seen the orangeleft house
default lot_orangeRsee = False # seen the orangeright house
default lot_key = False # access to key door


######################################################
##### MIKE VERSION
default lot_mike_cat = False # fought cat mike
default lot_mike_cowboy = False # fought cowboy mike
default lot_mike_small = False # fought small mike
default lot_mike_friend = False # seen friend