############################################################################################################
################## ACTUAL GAME OVER

######################################################
##### GAME OVER SCREEN
screen gameover:
    tag menu

    add gameovertext:
        xalign 0.5
        ypos 100

    hbox:
        style_prefix "mainpointer"
        xalign 0.5
        ypos 900
        
        textbutton _("SLEEP") action [Hide(screen="nomenu"), FileLoad("mainfile", slot=True, confirm=False)]
        null width 200
        textbutton _("WAKE UP") action Quit(confirm=True)

screen nomenu:
    key "K_ESCAPE" action NullAction()
    key "mouseup_3" action NullAction()
    key "K_MENU" action NullAction()
    key "K_PAUSE" action NullAction()


######################################################
##### GAME OVER LABEL
label gameover:
    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    hide screen datestats
    show screen nomenu

    stop music
    scene black with Dissolve(0.2)
    pause 0.5
    play sfx bump
    if persistent.glitches:
        pass
    else:
        with vpunch
    pause 1.0
    "Your body gave out from a lack of energy." 

    play music drone
    $ renpy.pause (3.0, hard=True)
    if persistent.gameover == 0:
        $ persistent.gameover += 1
        show text _("You're beginning to wake up...") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("But, is that really what you desire in this moment?") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("If you wish, I will restore the connection.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("This will set you back to your last SAVE.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Do not fret. I am sure you have not lost much progress at all.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Otherwise, if you are bored...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Feel free to open your eyes.") with dissolve
        pause
        hide text with dissolve

    elif persistent.gameover == 1:
        $ persistent.gameover += 1
        show text _("You seem troubled by your percieved \"failures.\"") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("This is not a failure, you know. This is a learning experience.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("But, of course, what you do with your time is up to you.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Will you wake up?") with dissolve
        pause
        hide text with dissolve

    else:
        show text _("Hello again, player.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Do not worry. Whatever you are trying to accomplish...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("You will achieve it.") with dissolve
        pause
        hide text with dissolve

    stop music fadeout 0.5
    $ renpy.pause (1.0, hard=True)
    play music faintcourage
    call screen gameover with Dissolve(0.2)
    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## NO ENDING CONTINGENCY
label ending_none:
    if not persistent.playthru:
        $ quick_menu = False
        $ skipyes = False
        $ _skipping = False
        show screen nomenu
    else:
        $ memsh_cutscene = True
    $ renpy.choice_for_skipping()

    scene black
    play music faintcourageSl
    $ renpy.pause(3.0, hard=True)

    ### SEEING THIS WITHOUT HAVING SEEN BEFORE/DONE MIKE THING
    if not mke_special:
        show text _("It seems you have reached... an end.") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("I presume this is not the end you set out to achieve.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("However, there is not much more I can provide you with.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("After all, each story ceases at some point.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Nothing can go on for eternity...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("... that being said,") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)

    ### FAILED MIKE ENDING AFTER BEING GIVEN A SECOND CHANCE
    else:
        show text _("I see that did not go well for you, either.") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("That is quite unfortunate...") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("But you need not be upset, player.") at truecenter with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)

    ### IF YOU DIDN'T UNLOCK MIKE DATE AT ALL
    if not mke_unlock:
        show text _("There is one you have yet to meet.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Someone not unlike you...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Someone seeking out the same individual as you were.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Of course, you two will no longer be able to find the television.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("But you could meet this other individidual, instead...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (2.0, hard=True)
        show text _("... or not. The decision is yours to make.") with dissolve
        pause
        menu:
            "Find him":
                $ mke_special = True
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("Fascinating.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("Allow me to assist you...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("I will place you in the room necessary to find him,") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("and you will not be able to exit.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("That is, provided you do not later choose to RESET instead.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("After all, these are your only remaining two options.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("As for the room itself...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("I recommend looking for a hidden yellow box,\nsomewhere you might not initially see.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause (1.0, hard=True)
                show text _("That paper you found might be a helpful guide.") with dissolve
                pause
                
                ## AUTOSAVE
                $ renpy.save("mainfile")

                stop music
                hide text
                pause 1.0
                
                $ quick_menu = True
                $ skipyes = True
                $ _skipping = True
                $ memsh_cutscene = False
                hide screen nomenu

                scene junkyard5 with Dissolve(2.0)
                play music dump
                jump ex_gameroom

            "Wake up":
                hide text with dissolve
                show text _("As you wish.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("If you are ever to return...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("I shall be waiting") with dissolve
                pause
                stop music
                show text _("the exact moment you arrive.")
                pause
                scene black
                $ renpy.pause(1.0, hard=True)
                $ renpy.quit()

    ### FAILED EVERY ENDING
    else:
        show text _("If you so desired, you can RESET.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("This will roll back the clock, although not everything will be erased.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Otherwise...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("I suppose we could stand here, in the bridge between Light and Dark.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("But I assume you will not be able to stay for very long...") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("Everyone wakes up from dreams eventually.") with dissolve
        pause
        hide text with dissolve
        $ renpy.pause (1.0, hard=True)
        show text _("What shall it be, player?") with dissolve
        pause
        menu:
            "Go back to sleep":
                $ end_wdg = True
                hide text with dissolve
                jump gaster_reset

            "Wake up":
                hide text with dissolve
                show text _("As you wish.") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("If you are ever to return...") with dissolve
                pause
                hide text with dissolve
                $ renpy.pause(1.0, hard=True)
                show text _("I shall be waiting") with dissolve
                pause
                stop music
                show text _("the exact moment you arrive.")
                pause
                scene black
                $ renpy.pause(1.0, hard=True)
                $ renpy.quit()



############################################################################################################
################## COMING BACK FROM AN ENDING
label cont_postend:
    $ quick_menu = True
    hide screen nomenu
    scene black    
    show junkspam with Dissolve(2.0)
    pause 1.0

    ### refresh variables
    $ end_tenna = False
    $ end_spamton = False
    $ end_mike = False

    $ end_spamtenna = None
    $ end_battenna = None
    $ end_spamtat = None
    $ end_triple = None

    $ end_triple_ten = False
    $ end_triple_spam = False
    $ end_triple_mke = False

    $ multichar = False
    $ cont_reload = True
    $ rightclick_icon = False
    $ currentend = None

    "You are set back to where you were before obtaining any endings."
    "If you would like,{w=0.2} you can explore the remaining options you have in this SAVE."
    "Otherwise,{w=0.2} you can start back from the beginning with a RESET."
    
    pause 1.0
    play music dump
    jump ex_spamshop



############################################################################################################
################## RESET
label gaster_reset:
    ## if not from in-game menu
    if not wdg_talkingto:
        if not end_wdg:
            scene black
            play music gasterwaltz fadein 1.0
        pause 1.0
        show gaster neutral at gastpos_center with Dissolve(1.0)
        pause 1.0

    ## don't have the letter from Spamton yet
    if not persistent.loveletter:
        show gaster frown with Dissolve(0.5)
        gaster "It seems {p=0.5}you do not yet have {p=0.5}what is required."
        show gaster frowne
        gaster "Your {color=[c_star]}Determination{/color} {p=0.5}is lacking"
        show gaster neutral
        gaster "Therefore, {p=0.5}you cannot Reset on your own."
        gaster "You will need {p=0.5}some assistance."
        show gaster smile with Dissolve(0.5)
        gaster "Perhaps if you were to {p=0.5}find something that could..."
        gaster "Rewrite the game {p=0.5}on its own?"
        show gaster smilee
        gaster "This could be utilized {p=0.5}to amplify your strength."
        show gaster frown with Dissolve(0.5)
        gaster "But, {p=0.5}until then..."
        if wdg_talkingto:
            jump wdg_menu
        else:
            play sfx disappear
            stop music
            scene black
            $ renpy.pause(3.0,hard=True)
            return

    ## anything else
    else:
        gaster "So you wish to {p=0.5}Reset."
        show gaster smile with Dissolve(0.5)
        if not persistent.prevreset:
            gaster "You wish to experience this world {p=0.5}a second time."
            gaster "The story will generally {p=0.5}be the same."
            gaster "But you may notice {p=0.5}some slight differences."
            show gaster smilee with Dissolve(0.5)
            gaster "After all, {p=0.5}we are simply turning back the clock."
            gaster "Erasing what has happened {p=0.5}and implimenting a sense of déjà vu."
            gaster "The three of them, too, experience this {p=0.5}as nothing more than a dream."
            pause 1.0
            show gaster frown with Dissolve(0.5)
            gaster "I am boring you with my rambling, {p=0.5}am I not?"
            gaster "Allow me to skip to the point."
            show gaster smile with Dissolve(0.5)
            gaster "You have {p=0.5}two options."
            gaster "You may {color=[c_passion]}Reset{/color}, {p=0.5}as stated."
            gaster "The three will retain {p=0.5}some memories {p=0.5}if you choose this."
            show gaster smilee
            gaster "Otherwise... {p=0.5}You may {color=[c_passion]}True Reset{/color}."
            gaster "This will erase {p=0.5}all of their memories {p=0.5}and destroy your letter."
            show gaster side
            gaster "In fact, {p=0.5}even I may not remember you."
            gaster "That...{w=0.2} \"worm\" {p=0.5}is quite powerful."
        
        else:
            gaster "I cannot say {p=0.5}I am surprised."
            gaster "Repeat your time here {p=0.5}as much as you would like."
            show gaster smilee
            gaster "You simply supply me {p=0.5}with more information."
            show gaster neutral with Dissolve(0.5)
            gaster "As usual, {p=0.5}you have two options."
    
    ### continue
    show gaster neutrale
    gaster "Player. {p=0.5}The choice is yours."


    ### RESET DECISION
    menu:
        rq "Reset save data?"
        "Yes":
            menu:
                rq "Is this a True Reset?"
                "Yes":
                    $ persistent._clear()
                    $ erase_saves()
                    show gaster neutral
                    gaster "Your data {p=0.5}has been completely Reset."
                    show gaster neutrale
                    gaster "You will now {p=0.5}wake up."
                    play sfx disappear
                    stop music
                    scene black

                    ## RESTART GAME
                    $ renpy.pause(3.0, hard=True)
                    $ renpy.quit()
                
                "No":
                    $ persistent.tenroute_fin = False
                    $ persistent.spamroute_fin = False
                    $ persistent.route = "Tenna"
                    $ erase_saves()
                    show gaster neutral
                    gaster "You Reset, {p=0.5}but their memories remains."
                    show gaster neutrale
                    gaster "You will now {p=0.5}go back to sleep."
                    $ persistent.prevreset = True
                    play sfx disappear
                    stop music
                    scene black

                    $ quick_menu = True
                    $ skipyes = True
                    $ _skipping = True
                    $ memsh_cutscene = False
                    hide screen nomenu
                    
                    ## JUMP TO BEGINNING
                    $ renpy.pause(3.0,hard=True)
                    jump tennastart

                "Nevermind, don't reset":
                    pass
        
        "No":
            pass
    
    show gaster neutral with Dissolve(0.5)
    gaster "Then I shall await {p=0.5}your inevitable return."
    if not wdg_talkingto:
        play sfx disappear
        stop music
        scene black
        $ renpy.pause(3.0,hard=True)
    return