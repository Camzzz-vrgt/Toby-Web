############################################################################################################
################## SHOP DATE
label spamdate_shop:
    ### SAVING INFO FOR FP/LP SCREEN
    if turn > 0:
        $ spam.fp = date_fp
        $ spam.lp = date_lp
        $ spam.hb = date_hb

    ### WIN CONDITION
    if vess_hp == 0:
        jump gameover
    elif date_hb == 0:
        jump spamdate_shop_fail
    elif date_fp <= 0 and date_lp <= 0:
        jump spamdate_shop_success

    ### MENU TEXT
    if turn == 0:
        $ menu_text = "You're reconsidering your decision to be here."
    elif vess_hp < 3 and not s_help_done:
        $ menu_text = "Press [F1] for help."
    elif turn >= 8 and not s_memshard:
        $ menu_text = "Maybe you could show off something to Spamton."
    elif turn >= 8 and not s_memshardask:
        $ menu_text = "Maybe you should ask Spamton about those \"MemoryShards\"..."
    else:
        $ menu_text = renpy.random.choice(["Smells like green.", "The air is green with freedom.\n{noalt}*{/noalt} Or, you might just feel ill.", "Spamton mutters under his breath.", "Spamton's smile looks forced.", "You wonder where Tenna is right now."])

    if turn == 1:
        $ s_t1 = True
        spamton "ANYWAY."
        show spamton standing up stare at jump
        spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} HOW LONG ARE YOU GOING TO [[woo] ME FOR??"
        show spamton crazy laugh
        spamton "THIS [[romantic evening] HAS ALREADY BEEN LONGER THAN [[5 second rule] !!"
        show spamton standing up smile
        spamton "I'M STILL [[Loading, please wait...] FOR YOUR HALF OF [[Our Deal(tm)]."
        show spamton standing up stare
        spamton "WON'T YOU BE A {noalt}[[$H!XBAG]{/noalt}{alt}beep bag{/alt} AND HAND OVER THE {noalt}[[HeartShaped-Object]{/noalt}{alt}heart-shaped object{/alt} SO I CAN GET ON WITH MY LIFE??"
        menu:
            rq "WON'T YOU BE A {noalt}[[$H!XBAG]{/noalt}{alt}beep bag{/alt} AND HAND OVER THE {noalt}[[HeartShaped-Object]{/noalt}{alt}heart-shaped object{/alt} SO I CAN GET ON WITH MY LIFE??"
            "Hand it over":
                pause 1.0
                nar_quiet "{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}"
                "Your arm resisted."
            
            "Do not":
                pass
        
        if persistent.glitches:
            show spamton crazy smirk
        else:
            show spamton crazy smirk at shakingcg
        spamton "[persistent.mc!u] YOU DRIVE A [[hard] BARGAIN!!!"
        show spamton standing tilt laugh at xwiggle
        spamton "IF YOU DIDN'T HAVE SUCH A [[priceless]\n[[i want that give it to me please please please pl]\nI WOULD JUST LEAVE!!"
        show spamton standing up stare at jump
        spamton "BUT MY [[Kindness] {noalt}IS{/noalt}{alt}is{/alt} RUNNING THIN{p=0.5}{noalt}*{/noalt} DON'T YOU WANT TO BE A [[BIG SHOT] LIKE YOUR {noalt}OL'{/noalt}{alt}ol'{/alt} PAL SPAMTON?!"
        "You get the feeling that Spamton might be a bit more sensitive to your answers than Tenna was..."
        "Best to be careful about what you say."
    
    elif turn == 3:
        $ s_t3 = True
        show spamton standing up smile at yreset
        spamton "TELL YA WHAT [persistent.mc!u].{p=0.2}{noalt}*{/noalt} WHY DON'T I [[un]SWEETEN THE DEAL ?"
        show spamton standing up stare
        spamton "IF YOU GIVE ME [[What you owe:] [[Don't delay!],{w=0.2} CONSIDER THE [[un]SPECIL RING ALL YOURS RIGHT NOW!!"
        show spamton standing tilt laugh at jump
        spamton "[[As an added bonus,] I'LL GET OUT OF YOUR HAIR [[for good]!"
        show spamton crazy smirk at jump
        spamton "HOW ABOUT {noalt}IT{/noalt}{alt}it{/alt}?!"
        menu s_menu_t3:
            rq "HOW ABOUT {noalt}IT{/noalt}{alt}it{/alt}?!"
            "But that's less than you offered before...":
                "You remind Spamton that he offered you \"one honest man\" as well as the ring."
                show spamton standing up glare
                if persistent.deals:
                    spamton "YEAH WELL YOU PROMISED ME [[[[ Light ]] AND LOOK AT WHERE WE ARE NOW!!"
                else:
                    spamton "YEAH WELL YOU PROMISED ME [[]{p=0.2}{p=0}{noalt}*{/noalt} {space=50}AND LOOK AT WHERE WE ARE NOW!!"
                if persistent.glitches:
                    show spamton standing up stare
                else:
                    show spamton standing up stare at shakingcg
                spamton "[persistent.mc!u] YOU'RE GONNA [[soiled it] MY [[[[BIG SHOT]] CHANCES LIKE THIS!!"
                spamton "DON'T YOU WANT TO BE A"

                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_11
                show screen datestats

                ### WIN CONDITION
                if date_hb == 0:
                    jump spamdate_shop_fail

            "How about I offer my heart instead?":
                "You tell Spamton you'll offer him your HEART instead of a \"HEART-SHAPED OBJECT.\""
                show spamton standing up stare
                $ _history = False
                spamton_shh ".{w=0.2}.{w=0.2}.{nw=0.5}"
                $ _history = True
                show spamton crazy laugh at jump
                spamton "...{fast} EAHAHEAHAEHAH!!"
                if persistent.glitches:
                    show spamton crazy angry
                else:
                    show spamton crazy angry at shakingcg
                spamton "{noalt}IS{/noalt}{alt}is{/alt} THAT WHAT THIS {noalt}D[[8]{/noalt}{alt}date{/alt} NONSENSE {noalt}IS{/noalt}{alt}is{/alt} ABOUT?!"
                show spamton standing up stare
                spamton "[[Get outta town!]{p=0.5}{noalt}*{/noalt} I CAN'T [[look into the Light] WITH A [[False] PROMISE OF [[We Love You !]"
                show spamton standing tilt laugh at jump
                spamton "I'M INTERESTED IN YOUR {noalt}[[Heart{w=0.2}-Shaped{w=0.2}Object].{/noalt}{alt}heart. shaped. object.{/alt}{p=0.2}{noalt}*{/noalt} NOT YOUR [[Heart] FILLED WITH [[questionable material] !!"
                if date_lp > 0:
                    $ date_lp -= 5
                    play sfx ding
                    show spamton standing up smirk at jump
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Spamton doesn't trust you, but still thought that was cute.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Spamton doesn't trust you, but still thought that was cute.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
            
            "Hand it over" if not spam_handover:
                $ spam_handover = True
                pause 1.0
                nar_quiet "{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}"
                "Your arm resisted."
                jump s_menu_t3

    elif turn == 6:
        $ s_t6 = True
        show spamton standing up smile at jump
        spamton "[persistent.mc!u], I'VE GOT [[1 New Message:] [[Final Offer] FOR YOU!"
        show spamton standing up stare
        spamton "YOUR SOUL.{w=0.2} {noalt}IS{/noalt}{alt}is{/alt} VERY IMPORTANT TO ME.{p=0.5}{noalt}*{/noalt} IT'S NOT [[[[lucky clover]], ."
        show spamton at xwiggle
        spamton "SO!!!{p=0.2}{noalt}*{/noalt} WHAT IF I,{w=0.5} SAY,"
        show spamton slouch down panic
        spamton "FOUND{w=0.5} A [[different] ONE,"
        show spamton crazy laugh at jump
        spamton "AND GAVE YOU THAT [[1] INSTEAD?!{p=0.2}{noalt}*{/noalt} EAHAHAHEHAH!!{w=0.2} [[Lossless Photos] THAT WAY, RIGHT?!"
        menu s_menu_t6:
            rq "AND GAVE YOU THAT [[1] INSTEAD?!\n{noalt}*{/noalt} EAHAHAHEHAH!! [[Lossless Photos] THAT WAY, RIGHT?!"
            "What do you mean, \"found\"?":
                "You ask Spamton what he means by he'll just \"find\" a SOUL to give you."
                if persistent.glitches:
                    show spamton standing up stare
                else:
                    show spamton standing up stare at shakingcg
                spamton "DON'T ASK QUESTIONS YOU DON'T WANT THE ANSWER TO"
                show spamton standing up frowne
                spamton "DON'T DO IT!{w=0.2} DON'T DO {noalt}IT{/noalt}{alt}it{/alt}!{w=0.2} DON'T DO {noalt}IT{/noalt}{alt}it{/alt}!{w=0.2} DON'T DO IT!"

                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_12
                show screen datestats

                ### WIN CONDITION
                if date_hb == 0:
                    jump spamdate_shop_fail

            "The offer for my heart is still up.":
                "You remind Spamton you're still offering your \"heart\" instead."
                show spamton panic up screame at jump
                spamton "WHAT {noalt}IS{/noalt}{alt}is{/alt} THIS??{w=0.2} SOME KIND OF\n{noalt}[[.rom]-{/noalt}{alt}rom{/alt}[[Computer Player] [[B-plot] ?!"
                if persistent.glitches:
                    show spamton crazy frantic
                else:
                    show spamton crazy frantic at shakingcg
                spamton "[[Love] {noalt}IS{/noalt}{alt}is{/alt} NOT A [[Valid Currency] YOU [[desperate little] LONELY [[Hearts] !!"
                if date_lp > 0:
                    $ date_lp -= 5
                    play sfx ding
                    show spamton standing up smirk at jump
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "... that being said,{w=0.2} Spamton's apparently a sucker for your cheesy words.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                    else:
                        "... that being said,{w=0.2} Spamton's apparently a sucker for your cheesy words.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

            "Sounds great to me!" if not spam_handover:
                $ spam_handover = True
                pause 1.0
                nar_quiet "{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}"
                "Your arm resisted."
                jump s_menu_t6

    elif turn >= 8 and s_memshardask:
        $ ex_memory = True
        show spamton standing up stare at jump
        spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} YOU WANNA BE [[You're Hired!] FOR A [[littol{space=50}]\n[[Fetch Quest]??"
        show spamton standing tilt laugh at jump
        spamton "I'M GLAD YOU ASKED!!{nw=0.5}"
        show spamton standing up smile at xwiggle
        extend "{p=0}{noalt}*{/noalt} FIND THE REST OF THOSE MemoryShards !!"
        show spamton crazy laugh
        spamton "BUT DON'T [[leave a bad review] YET!{p=0.5}{noalt}*{/noalt} I'LL EVEN THROW IN a [[Wanna go on a Second Date?] [[[[Abso-LUTE-ly free!]]"
        show spamton standing tilt laugh at xwiggle
        spamton "[[What d'ya say?]{p=0.5}{noalt}*{/noalt} ARE WE [[[[Offer Accepted]] ?"
        menu:
            rq "[[What d'ya say?]{p=0.5}{noalt}*{/noalt} ARE WE [[[[Offer Accepted]] ?"
            "Accept":
                "You told Spamton you'll find the remaining MemoryShards."
            
            "Do not":
                "You refused the deal."
                show spamton standing up stare at jump
                if not persistent.deals:
                    spamton "I'M NOT [[doing this] {noalt}[[$#!X]{/noalt}{alt}beep{/alt} AGAIN."
                else:
                    spamton "WHAT'S THAT?{p=0.5}{noalt}*{/noalt} SOUNDS LIKE YOU WERE TRYING TO [[rejection] THE [[[[BARGAIN of a LIFETIME]]"
                    if persistent.glitches:
                        show spamton standing tilt laugh flipped
                    else:
                        show spamton standing tilt laugh flipped at shakingcg
                    spamton "[[That can't be!] RIGHT!{p=0.5}{noalt}{noalt}*{/noalt} YOU 'rE [[$#!X]ING{/noalt}{alt}you're beeping{/alt} YOURSELF!!"
                show spamton standing up stare at yreset
                spamton "SO"

        show spamton crazy laugh at jump
        spamton "WE ARE [[Deal or ] THEN!!"
        show spamton standing up stare at xwiggle
        spamton "LET'S CALL THIS DATE [[done and over with]{p=0.2}{noalt}*{/noalt} YOU BETTER GET YOUR [[nose to the grindstone] !!"
        if date_fp > 0:
            $ date_fp -= 5
            play sfx ding
            show spamton standing up smile at jump
            if not seenstats_fp:
                $ seenstats_fp = True
                "Spamton is appreciative of your help.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
            else:
                "Spamton is appreciative of your help.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
        jump spamdate_shop_success
    
    $ turn += 1
    $ spam_handover = False

label spamdate_shop_menu:
    if vess_hp < 3 and not s_help_done:
        show screen spam_f1forhelp
    show spamton standing up smile at yreset
    show screen spamdate_select
    $ quick_menu = True
    $ skipyes = False
    $ _skipping = False

    date "[menu_text]"

    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## EYE DATE
label spamdate_eye:
    ### SAVING INFO FOR FP/LP SCREEN
    if turn > 0:
        $ spam.fp = date_fp
        $ spam.lp = date_lp
        $ spam.hb = date_hb

    ### WIN CONDITION
    if vess_hp == 0:
        jump gameover
    elif date_hb == 0:
        jump spamdate_eye_end
    elif date_fp <= 0 and date_lp <= 0:
        jump spamdate_eye_end

    ### MENU TEXT
    if turn == 0:
        $ menu_text = "Spamton's patience is running thin."
    elif ey_memask > 1 and not ey_memmenu:
        $ ey_memmenu = True
        $ menu_text = "You could always show off some of the MemoryShards you found."
    else:
        $ menu_text = renpy.random.choice(["It feels as though you're being watched.", "The tension is thick.", "Spamton fidgets with his hands.", "Smells like puppet strings.", "You clutch your chest and take a deep breath."])

    ### > spamton getting more desperate and frustrated with every turn
    ### > something that makes him trust you significantly more every turn, too
    ###   > fp amount increases (as in, +5 into +10) every turn

    ### QUESTION 1
    if turn == 0:
        show spamton standing up stare at jump
        spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} BEFORE WE GET TOO [[Investments]..."
        spamton "WHY DON'T [[I'll make this quick and painless]."
        show spamton standing tilt laugh at jump
        spamton "[[You know why I'm here.]{p=0.5}{noalt}*{/noalt} IT'S GETTING [[so dark] and [[so light] THAT I'M [[becoming blind] AS WE SPEAK !!"
        if persistent.glitches:
            show spamton standing up stare
        else:
            show spamton standing up stare at shakingcg
        spamton "[[Time is running out] [[For our INCREDIBLE deals!!]"
        show spamton standing up frowne
        spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} WHAT IF I SAID [[Before we get started,] [[pretty please] GIVE ME YOUR [[[[ Light ]]?"
        menu ey_t1_menu:
            rq "[persistent.mc!u].\n{noalt}*{/noalt} WHAT IF I SAID [[Before we get started,] [[pretty please] GIVE ME YOUR [[[[ Light ]]?"
            "Hand it over":
                "Your arm resisted."

            "Do not":
                "You know without a doubt that handing over your SOUL would cause more harm for yourself than good."

        show spamton crazy angry at xwiggle
        spamton "YOU'RE REALLY [[Take a test drive]ING ME [[to the limit],{w=0.2} [persistent.mc!u]!"
        show spamton standing up frowne at jump
        spamton "THIS IS PLAYING [[Paddle Ball] WITH MY FEELING!!"
        "You might only have so much time left to convince Spamton not to take your SOUL..."
        "Best be on your toes."

    ### QUESTION 2
    elif turn == 2:
        show spamton crazy frantic at xwiggle
        spamton "[persistent.mc!u].{p=0.2}{noalt}*{/noalt} I [[understand your] AVOIDING THE [[Best Part] OF OUR DEAL."
        if persistent.glitches:
            show spamton standing up stare
        else:
            show spamton standing up stare at shakingcg
        spamton "IT'S BLATANTLY [[visible with my oown two] LENSES!!"
        show spamton standing up frowne
        spamton "WHAT'S WRONG, [persistent.mc!u]??{p=0.5}{noalt}*{/noalt} YOU CAN TELL [[the ONE and ONLY] SPAMTON G. SPAMTON!!"
        menu ey_t2_menu:
            rq "WHAT'S WRONG, [persistent.mc!u]??\n{noalt}*{/noalt} YOU CAN TELL [[the ONE and ONLY] SPAMTON G. SPAMTON!!"
            "I don't trust you":
                "You tell Spamton you don't trust him."
                show spamton standing tilt laugh at jump
                spamton "WOW!!{w=0.2} DIG THE [[blunt knife] EVEN DEEPER INTO MY [[improperly healed] WOUNDS!!"
                show spamton crazy smirk at xwiggle
                spamton "BUT [[Can you really blame] YOU???{p=0.5}{noalt}*{/noalt} IF ANYTHING, [[That's the correct answer]!"
                show spamton crazy laugh
                spamton "NEVER TRUST [[Anything you see] FROM [[Businessmen] !!!"
                if date_fp > 0:
                    $ date_fp -= 3
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton trusts you more, in turn.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton trusts you more, in turn.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."

            "I would rather date you":
                "You tell Spamton you're more interested in dating him than this deal."
                show spamton standing up frowne
                spamton "..."
                show spamton crazy frantic at xwiggle
                spamton "[persistent.mc!u]!!{p=0.5}{noalt}*{/noalt} YOU ARE JUST THE [[craziest]!!"
                show spamton crazy laugh
                spamton "HAVE YOU EVEN SEEN ME AND [[myface] ???"

                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_17
                show screen datestats

                if date_lp > 0 or date_fp > 0:
                    $ date_lp -= 3
                    $ date_fp -= 3
                    play sfx ding
                    show spamton standing down panic at yreset
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "But, Spamton was conflicted by your sentiment.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color} and {color=[c_passion]}Love Points{/color}."
                    else:
                        "But, Spamton was conflicted by your sentiment.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color} and {color=[c_passion]}LP{/color}."

            "I'm trying to give you my SOUL" if not spam_handover:
                $ spam_handover = True
                "Your arm resisted."
                jump ey_t2_menu

    ### QUESTION 3
    elif turn == 4:
        show spamton standing up frowne at jump
        spamton "HEY [persistent.mc!u] [[Did you know?] YOU'RE [[terrible score] AT [[Date Planning] !!!"
        show spamton standing tilt laugh at xwiggle
        spamton "I HAVEN'T BEEN ON A DATE THIS BAD SINCE [[]."
        show spamton crazy frantic at jump
        spamton "HAVE YOU EVEN BEEN [[Interested?] FROM THE START..."
        show spamton standing down panic
        spamton "OR ARE YOU JUST [[Roll to bribe.] ME?!"
        menu:
            rq "OR ARE YOU JUST [[Roll to bribe.] ME?!"
            "I'm offering my heart for a reason":
                "You say with a lilt that you're specifically offering your heart for a reason."
                show spamton standing up frowne at jump
                spamton "...{w=0.5} [persistent.mc!u]?"
                show spamton standing tilt laugh at xwiggle
                spamton "YOU MAKE [[absolute zero] SENSE!!"
                show spamton crazy smirk at jump
                spamton "YOU'RE [[un]LUCKY THAT I'M [[weak at the knees] FOR YOUR [[sweet nothings] !!!"
            
                if date_fp > 0 or date_lp > 0:
                    $ date_fp -= 3
                    $ date_lp -= 3
                    play sfx ding
                    show spamton standing up smirk at jump
                    if not seenstats_fp or not seenstats_lp:
                        $ seenstats_fp = True
                        $ seenstats_lp = True
                        "Spamton's mildly concerned.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color} and {color=[c_passion]}Love Points{/color}."
                    else:
                        "Spamton's mildly concerned.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color} and {color=[c_passion]}LP{/color}."

            "If it means I get to keep my SOUL...":
                "You admit you're mostly doing this to protect yourself."
                if persistent.deals:
                    show spamton standing down frown
                    spamton "[[protect yourself]..."
                    show spamton slouch down frown at droop
                    spamton "SO,{w=0.5} OUR [[Deal or] WAS [[null and void] FROM [[The very beginning]?"

                    ### HEARTBREAK
                    hide screen datestats
                    call heartbreak_ani from _call_heartbreak_ani_18
                    show screen datestats

                    show spamton crazy laugh at jump
                    spamton "EAHEHAHAH!!{p=0.5}{noalt}*{/noalt} I SHOULD JUST RIP [[your heart out] RIGHT [[Here and now.] !!"
                    show spamton standing up frowne
                    spamton "BUT I'M A MAN FILLED WITH [[Kindness].{p=0.2}{noalt}*{/noalt} I KNOW A [[cry for help] WHEN I SEE ONE!!"
                    if date_fp > 0:
                        $ date_fp -= 6
                        play sfx ding
                        show spamton standing down panic at jump
                        if not seenstats_fp:
                            $ seenstats_fp = True
                            "Spamton's sympathy overtakes his anger.{p=0.2}{noalt}*{/noalt} He gained 6 {color=[c_kindness]}Friendship Points{/color}."
                        else:
                            "Spamton's sympathy overtakes his anger.{p=0.2}{noalt}*{/noalt} He gained 6 {color=[c_kindness]}FP{/color}."
                    
                else:
                    show spamton standing tilt laugh at xwiggle
                    spamton "EAHEHAHAH!!{p=0.5}{noalt}*{/noalt} THAT'S [[No surprises here]."
                    if persistent.glitches:
                        show spamton standing up stare
                    else:
                        show spamton standing up stare at shakingcg
                    spamton "YOU THINK I BELIEVED YOU WERE [[Interested?] WHEN YOU'RE WHINING ABOUT [[I miss Tenna]??"
                    show spamton standing up frowne
                    spamton "BUT YOU'RE STILL [[You are here.]{p=0.5}{noalt}*{/noalt} .{w=0.2} Why?"
                    if date_fp > 0:
                        $ date_fp -= 12
                        play sfx ding
                        show spamton standing up smile at jump
                        if not seenstats_fp:
                            $ seenstats_fp = True
                            "Spamton appreciates your honesty.{p=0.2}{noalt}*{/noalt} He gained 12 {color=[c_kindness]}Friendship Points{/color}."
                        else:
                            "Spamton appreciates your honesty.{p=0.2}{noalt}*{/noalt} He gained 12 {color=[c_kindness]}FP{/color}."
            
    ### QUESTION 4
    elif turn == 6:
        show spamton standing down panic at yreset
        spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} I DON'T [[Get it?]."
        show spamton standing up frown
        spamton "YOU'VE MADE YOUR [[motivation] [[clear as day].{p=0.5}{noalt}*{/noalt} YOU DON'T WANT TO [[Play Game] THE WAY I WANT TO [[Play Game]."
        show spamton standing up frowne
        spamton "WHAT ARE YOU DOING HERE THEN, IF YOU DON'T WANT TO [[Hand it Over] {noalt}YOU R{/noalt}{alt}your{/alt} [[Heart-Shaped ], ?"
        menu ey_t4_menu:
            rq "WHAT ARE YOU DOING HERE THEN, IF YOU DON'T WANT TO [[Hand it Over] {noalt}YOU R{/noalt}{alt}your{/alt} [[Heart-Shaped ], ?"
            "I would rather find Tenna":
                "You say you're sticking it out in order to find Tenna."
                show spamton standing up glaree at jump
                pause 1.0
                show spamton standing tilt laugh at xwiggle
                spamton "ACTUALLY,{w=0.2} THAT'S [[It's my fault] FOR THINKING [[literally] ANY [[Other options:] WERE [[Valid]."
                if persistent.glitches:
                    show spamton crazy frantic
                else:
                    show spamton crazy frantic at shakingcg
                spamton "YOU'VE ALWAYS BEEN [[Breathe in, and Focus] ON\n[[Boob Tube]!!"
                
                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_19
                show screen datestats

                if persistent.glitches:
                    show spamton slouch down static
                else:
                    show spamton slouch down static glitch
                spamton "YOUR [[Tastes like] ARE [[as bad as mine.]"
                spamton "WHY CAN'T YOU JUST [[Read the warnings before ] ??"

            "You're keeping me here":
                "You remind Spamton that he's the one making all these deals with you."
                show spamton crazy angry at jump
                spamton "YOU'RE STILL [[>Accept purchase?] THEM!!{p=0.5}{noalt}*{/noalt} DON'T KNOW HOW TO SAY [[No!] TO [[Local] SALES[[Man] ???"
                show spamton standing tilt laugh at jump
                spamton "[[You simply must] KNOW, OR YOU'D BE [[soulless] ALREADY!!"
                show spamton crazy smirk at xwiggle
                spamton "ARE YOU SAYING I'M [[just that] CONVINCING??"

                if date_fp > 0:
                    $ date_fp -= 12
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton feels a bit more self-confident.{p=0.2}{noalt}*{/noalt} He gained 12 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton feels a bit more self-confident.{p=0.2}{noalt}*{/noalt} He gained 12 {color=[c_kindness]}FP{/color}."

            "I want to give you my SOUL" if not spam_handover:
                $ spam_handover = True
                "Your arm resisted."
                jump ey_t4_menu

    ### QUESTION 5
    elif turn == 8:
        show spamton standing up smile at jump
        spamton "HEY {space=80}! {p=0.2}{noalt}*{/noalt} [[You've got] A NEW [[Offer] FROM ME TO YOU!!"
        show spamton standing up frown
        spamton "[[Have you considered:] IF YOUR GOAL {noalt}IS{/noalt}{alt}is{/alt} TO BE WITH ME [[until death do us part],"
        show spamton slouch down panic at xwiggle
        spamton "THAT [[can be arranged],{w=0.5} [[Technically Advanced] SPEAKING."
        menu ey_t3_menu:
            rq "THAT [[can be arranged], [[Technically Advanced] SPEAKING."
            "I'm my own person":
                "You tell Spamton that you're not interested,{w=0.2} you're your own person."
                if persistent.glitches:
                    show spamton slouch down static at droop
                else:
                    show spamton slouch down static glitch at droop
                spamton "{w=0.2}.{w=0.2}.{w=0.2}."

                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_20
                show screen datestats

                show spamton at xwiggle
                spamton "[[Wowowow] {noalt}THA T{/noalt}{alt}that{/alt} MUST [[feels nice], , ,,"

            "What do you mean?":
                "You ask what Spamton means by his offer."
                show spamton standing up frowne at jump
                spamton "ASKING [[For more information] FROM THE [[Sales Pitch] BEFORE [[spending your life savings]?!"
                show spamton standing tilt laugh at xwiggle
                spamton "EAHEHAHEH!{p=0.2}{noalt}*{/noalt} YOU'RE [[making this more difficult than it has to be]."
                show spamton standing up stare at jump
                spamton "BUT I LIKE YOUR [[gussto], [persistent.mc!u].{p=0.5}{noalt}*{/noalt} YOU [[Keepin' it real]."
                show spamton crazy laugh at xwiggle
                spamton "WHY DON'T WE [[discuss the details] [[at a later date]..."
                if date_fp > 0:
                    $ date_fp -= 24
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton admires your hesitation.{p=0.2}{noalt}*{/noalt} He gained 24 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton admires your hesitation.{p=0.2}{noalt}*{/noalt} He gained 24 {color=[c_kindness]}FP{/color}."

            "Count me in!" if not spam_handover:
                $ spam_handover = True
                "Your arm resisted."
                jump ey_t3_menu

    ### QUESTION 6
    elif turn == 10:
        show spamton standing down panic at yreset
        spamton "[persistent.mc!u].{w=0.5} I'M GOING TO ASK [[one final time]."
        show spamton standing down frown
        spamton "NO MORE [[Waiting around] FOR THIS [[silly] BEHAVIOR TO STOP..."
        show spamton standing up frowne at jump
        spamton "YOU HAVE [[2 turns] TO [[pay your debt].{p=0.5}{noalt}*{/noalt} OTHERWISE,{w=0.2} [[No more Mr. Nice Guy]!"
        menu ey_t5_menu:
            rq "YOU HAVE [[2 turns] TO [[pay your debt].\n{noalt}*{/noalt} OTHERWISE, [[No more Mr. Nice Guy]!"
            "I offered my substitute":
                "You remind Spamton you've already offered a substitute to cover what you owe."
                show spamton standing up glaree
                spamton "[[Have you maybe considered] I DON'T WANT {noalt}IT{/noalt}{alt}it{/alt}??"
                show spamton crazy frantic at xwiggle
                spamton "[[sweet talk] {noalt}IS{/noalt}{alt}is{/alt} NOT GOING TO WIN ME OVER [[the second time] !!"
                show spamton slouch down frown at droop
                spamton "I'M NOT MAKING ANYMORE [[deals with the devil]..."

                ### HEARTBREAK
                hide screen datestats
                call heartbreak_ani from _call_heartbreak_ani_21
                show screen datestats

                show spamton slouch down smile
                spamton "IT'S THE {noalt}[[Heart-ShapedObject]{/noalt}{alt}heart-shaped object{/alt} OR [[Hit the road] KID.{p=0.2}{noalt}*{/noalt} NO EXCEPTIONS!!"

            "There's nothing else you'll take...?":
                "Frowning, you ask if there's really nothing else Spamton would be willing to take instead."
                show spamton standing up glaree at jump
                spamton "DON'T [[pleading eyes emoji] ME!!{p=0.5}{noalt}*{/noalt} YOU KNEW THE [[contents of the] AGREEMENT FROM THE BEGINNING!"
                show spamton crazy frantic at xwiggle
                if persistent.deals:
                    spamton "IF YOU DIDN'T WANT TO [[sign your life away] THEN YOU SHOULDN'T HAVE [[signed your life away] !!"
                else:
                    spamton "I KNOW YOU DIDN'T ACTUALLY [[take it],{w=0.2} BUT YOU'RE STILL [[stuck with] ME [[until this is resolved]!!"
                show spamton standing up smile at jump
                spamton "I'M A [[Business Loving Businessman]!{p=0.5}{noalt}*{/noalt} [[No more, no less] !!"
                if date_fp > 0:
                    $ date_fp -= 24
                    play sfx ding
                    show spamton standing down panic at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Even still, Spamton falters because of your tone.{p=0.2}{noalt}*{/noalt} He gained 24 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Even still, Spamton falters because of your tone.{p=0.2}{noalt}*{/noalt} He gained 24 {color=[c_kindness]}FP{/color}."

            "Give it right now" if not spam_handover:
                $ spam_handover = True
                "Your arm resisted."
                jump ey_t5_menu

    ### TIME'S UP
    elif turn == 12:
        jump spamdate_eye_end
    
    ### SAVING INFO FOR FP/LP SCREEN
    if turn > 0:
        $ spam.fp = date_fp
        $ spam.lp = date_lp
        $ spam.hb = date_hb

    ### WIN CONDITION
    if vess_hp == 0:
        jump gameover
    elif date_hb == 0:
        jump spamdate_eye_end
    elif date_fp <= 0 and date_lp <= 0:
        jump spamdate_eye_end

    $ turn += 1
    $ spam_handover = False

label spamdate_eye_menu:
    show spamton standing up smile at yreset
    show screen spamdate_select
    $ quick_menu = True
    $ skipyes = False
    $ _skipping = False

    if turn < 12:
        $ ey_countdown = (13 - turn)
        date "[menu_text]\n{noalt}*{/noalt} [ey_countdown] turns left."
    else:
        date "[menu_text]\n{noalt}*{/noalt} Last turn."

    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## INTERACTS

######################################################
##### TALK
label spamdate_talk:
    $ skipyes = True
    $ _skipping = True
    hide screen spamdate_select
    hide screen spam_f1forhelp
    
    ### SHOP DATE
    if currentdate == "shop":
        menu:
            date "Talk"
            "Nice day!":
                $ niceday += 1
                if niceday == 1:
                    $ s_niceday += 1
                    "You told Spamton you thought today was a nice day."
                    show spamton standing up stare
                    spamton "... ???{alt}uh??{/alt}"
                    show spamton standing up glaree at jump
                    spamton "OK????{nw=0.5}"
                    show spamton standing tilt laugh at xwiggle
                    extend "{p=0}{noalt}*{/noalt} AM I SUPPOSED TO [[Respond to This query] SOMEHOW???"
                    pause 1.0
                    "That could have gone...{w=0.2} worse, you suppose."
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"
                
                elif niceday == 2:
                    $ s_niceday += 1
                    "You once again said you thought today was a nice day."
                    show spamton standing up glare
                    spamton "I HEARD YOU THE FIRST TIME [[freak]"
                    "He's got a point...{w=0.2} Why DID you say this again?"
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"
                
                else:
                    "This approach isn't really helping..."
                    jump spamdate_shop_menu

            "Great date!" if not s_great:
                $ s_great = True
                "You announced that you thought this date was a great idea."
                if date_lp > 0:
                    $ date_lp -= 2
                    play sfx ding
                    show spamton standing up frowne at jump
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Spamton was caught off-guard.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Spamton was caught off-guard.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_passion]}LP{/color}."
                show spamton standing tilt laugh at xwiggle
                spamton "WOW!!!{p=0.5}{noalt}*{/noalt} DELCLARING {noalt}IT{/noalt}{alt}it{/alt} SO [[loudly] AND [[proudly]??"
                show spamton standing up smirk at jump
                spamton "YOU'VE GOT MOXIE, [[not] KID.{w=0.5} I LIKE {noalt}IT{/noalt}{alt}it{/alt}."

            "I miss Tenna" if not s_misstenna:
                $ s_misstenna = True
                "You said that you missed Tenna."
                if not persistent.deals:
                    show spamton standing up stare at jump
                    spamton "WHAT THE {noalt}[[$#!K]{/noalt}{alt}beep{/alt} YOU'RE STILL ON ABOUT THAT?!?"
                else:
                    show spamton standing up stare
                    spamton "[[Trash Heap]!?{nw=0.5}"
                    show spamton standing tilt laugh at jump
                    extend " EAHEHAHA!!"
                show spamton crazy laugh at xwiggle
                spamton "GET [[Gently Used] TO {noalt}IT{/noalt}{alt}it{/alt},{w=0.2} YOU [[desperate little ] !{p=0.5}{noalt}*{/noalt} HE DOESN't [[cared.] {noalt}ABO> UT{/noalt}{alt}about{/alt} ANYTHING!!"
                if persistent.glitches:
                    show spamton standing up stare
                else:
                    show spamton standing up stare at shakingcg
                spamton "YOU SHOULD JUST [[Getting Over It with] LIKE i> DiD ! !!"
                if persistent.glitches:
                    show spamton slouch down static at droop
                else:
                    show spamton slouch down static glitch at droop
                spamton "..." 
                pause 2.0
                "Maybe that wasn't the best thing to bring up..."
                play sfx awkwardS
                $ vess_hp -= 1
                "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

            "\"Heart-shaped object\"?" if s_t1 and not s_hso:
                $ s_hso = True
                "You asked Spamton to explain what a \"heart-shaped object\" is."
                show spamton standing up stare at jump
                spamton "[[Did you know?]{w=0.2} ALL LIght[[Nerds] HAVE ONE!"
                show spamton standing tilt laugh
                spamton "WITH THAT [[[[ Light. ]] YOU ARE OFFICIALLY [[A Real [[redacted]] !!"
                if persistent.glitches:
                    show spamton standing up stare
                else:
                    show spamton standing up stare at shakingcg
                spamton "YOU CAN [[Breathe]{w=0.2} YOU CAN [[see]{w=0.2} YOU CAN [[hear]{w=0.2} YOU CAN [[feel]"
                show spamton slouch down smile at yreset
                spamton "AND MOST IMPORTANTLY!!!{p=0.5}{noalt}*{/noalt} YOU HAVE [[ {color=[c_passion]}Freedom{/color} ]."
                show spamton crazy laugh at jump
                spamton "[[Freedom] TO CALL YOUR OWN SHOTS!!{p=0.2}{noalt}*{/noalt} [[Freedom] TO DO WHATEVER YOU WANT!!"
                show spamton crazy avert
                spamton "EAHAEHAHAH!{p=0.2}{noalt}*{/noalt} RIGHT?{w=0.5} RIGHT??"
                show spamton crazy angry at xwiggle
                spamton "YOU DON'T HAVE [[silly strings] TELLING YOU WHAT TO DO, RIGHT???"
                menu:
                    rq "YOU DON'T HAVE [[silly strings] TELLING YOU WHAT TO DO, RIGHT???"
                    "Well... I mean...":
                        $ s_sillystrings = True
                        "You say it might be a little more complicated than that."
                        show spamton standing up frowne at yreset
                        spamton "..."
                        
                        ### HEARTBREAK
                        hide screen datestats
                        call heartbreak_ani from _call_heartbreak_ani_13
                        show screen datestats

                        if persistent.glitches:
                            show spamton crazy frantic
                        else:
                            show spamton crazy frantic at shakingcg
                        spamton "EAHAHEHAH!{w=0.5} I KNOW A [[lie] WHEN I SEE ONE!!"
                        show spamton standing up frowne
                        spamton "SO QUIT {noalt}IT{/noalt}{alt}it{/alt}."
                    
                    "I'm definitely choosing this option out of my own free will.":
                        "You tell Spamton all of [persistent.mc]'s choices are [persistent.mc]'s own."
                        show spamton standing tilt laugh at jump
                        spamton "THAat'S WHAT I LIKE TO HEAR!!"
                        show spamton standing up stare
                        spamton "YOU WOULDN'T WASTE MY TIME LIKE SOME [[Information Redacted]S!!!"
                        if date_fp > 0:
                            $ date_fp -= 2
                            play sfx ding
                            show spamton standing up smile at jump
                            if not seenstats_fp:
                                $ seenstats_fp = True
                                "Spamton apparently took your bait.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                            else:
                                "Spamton apparently took your bait.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."
            
            "Ring?" if s_t3 and not s_ring:
                $ s_ring = True
                "You asked what the deal was with the \"commemorative ring\" Spamton keeps offering."
                show spamton crazy laugh at jump
                spamton "THIS RING ISN'T JUST ANY OLD [[Priceless Jewelery].{p=0.2}{noalt}*{/noalt} IT'S STEAMING HOT [[garbage] !"
                show spamton standing up stare
                spamton "I'M SICK OF LOOKING AT {noalt}IT{/noalt}{alt}it{/alt}."
                show spamton standing tilt laugh at jump
                spamton "CONSIDER {noalt}IT{/noalt}{alt}it{/alt} A [[RE:]GIFT FROM ME TO YOU!!"
                menu:
                    rq "CONSIDER {noalt}IT{/noalt}{alt}it{/alt} A [[RE:]GIFT FROM ME TO YOU!!"
                    "Makes sense to me.":
                        "You nod, saying that's fair enough."
                        show spamton crazy smirk at xwiggle
                        spamton "GLAD WE'RE IN [[Agree to the Agreement], [persistent.mc!u] !!"
                        if date_fp > 0:
                            $ date_fp -= 2
                            play sfx ding
                            show spamton standing up smile at jump
                            if not seenstats_fp:
                                $ seenstats_fp = True
                                "Spamton's relieved you didn't question him.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                            else:
                                "Spamton's relieved you didn't question him.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

                    "Why not just throw it out?":
                        "You ask Spamton why he doesn't just throw it out instead."
                        show spamton standing up stare
                        pause 2.0

                        ### HEARTBREAK
                        hide screen datestats
                        call heartbreak_ani from _call_heartbreak_ani_14
                        show screen datestats

                        show spamton crazy frantic at xwiggle
                        spamton "MOVING ON!!!"

            "Where do you find a SOUL?" if s_t6 and not s_soul:
                $ s_soul = True
                "You asked Spamton where he could possibly find a SOUL to replace yours with."
                show spamton crazy smirk at xwiggle
                spamton "I'M [[Honest, man], [persistent.mc!u]!!{p=0.2}{noalt}*{/noalt} DON'T YOU TRUST ME??"
                show spamton standing up smile at jump
                spamton "I WOULDN'T OFFER A DEAL IF I CAN'T [[afford] THE [[Cash Out]!!"
                menu:
                    rq "I WOULDN'T OFFER A DEAL IF I CAN'T [[afford] THE [[Cash Out]!!"
                    "Why not find one for yourself, then?":
                        "You ask why Spamton can't just find a SOUL for himself that way, then."
                        show spamton standing up stare
                        spamton "{w=0.2}.{w=0.2}.{w=0.2}."

                        ### HEARTBREAK
                        hide screen datestats
                        call heartbreak_ani from _call_heartbreak_ani_15
                        show screen datestats

                        show spamton standing tilt laugh at jump
                        spamton "[persistent.mc!u]!!{w=0.2} [[C'mon, now], THE PROCESS WON'T BE [[1-Day Delivery]!!"
                        show spamton crazy frantic at xwiggle
                        spamton "BUT YOU WOULD GET [[something] IN EXCHANGE!!{p=0.5}{noalt}*{/noalt} EVENTUALLY!!!"

                    "Can't argue with that.":
                        "You say that seems reasonable."
                        show spamton standing up frowne
                        spamton "DON'T SOUND SO [[Incredibly Exciting News] ABOUT {noalt}IT{/noalt}{alt}it{/alt}, [persistent.mc!u]"
                        show spamton crazy smirk at jump
                        spamton "YOU CAN ALWAYS TRUST THIS [[Award-Losing] SMILE!!"
                        if date_fp > 0:
                            $ date_fp -= 2
                            play sfx ding
                            show spamton standing up smile at jump
                            if not seenstats_fp:
                                $ seenstats_fp = True
                                "Spamton is concerned about your blind trust.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                            else:
                                "Spamton is concerned about your blind trust.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

            "MemoryShard?" if s_memshard and not s_memshardask:
                "Spamton will likely want to end the date after this.{p=0.5}{noalt}*{/noalt} Only say it when you're sure you want to continue."
                menu:
                    rq "(Spamton will likely want to end the date after this.\n{noalt}*{/noalt} Only say it when you're sure you want to continue.)"
                    "Okay":
                        pass
                    
                    "Go back":
                        jump spamdate_shop_menu

                $ s_memshardask = True
                "You reluctantly asked Spamton about what a MemoryShard was."
                show spamton slouch down panic
                spamton "I DON'T KNOW AND I DOn'T CARE!!"
                show spamton slouch down smile
                spamton "THOSE [[memory sticks] ARE SOMETHING [[[[ He ]] MADE BUT [[[[ He ]] DIDN'T TELL ME WHY."
                show spamton standing down panic
                spamton "WHY WOULD ANYONE WANT TO [[You 'member?] ANY OF THAT??"
                if persistent.glitches:
                    show spamton crazy frantic
                else:
                    show spamton crazy frantic at shakingcg
                spamton "[[[[ He ]] DIDN'T EVEN TELL ME WHAT THEY LOOKED LIKE!!"
                show spamton slouch down static
                spamton "{noalt}IS{/noalt}{alt}is{/alt} [[[[ He ]] {noalt}RR R REALY THE SAME.. . ....?{/noalt}{alt}really the same...?{/alt}"
                if persistent.glitches:
                    show spamton at droop
                else:
                    show spamton slouch down static glitch at droop
                spamton "{noalt}It tT DO0es. tn' MakeSEN sne().. . >.{/noalt}{alt}it doesn't make sense..."
                pause 1.0
                menu:
                    "Who is \"he\"?":
                        "You ask Spamton who this \"he\" is that he keeps bringing up."
                        show spamton standing up frowne
                        spamton "YOUu {noalt}CANn' T{/noalt}{alt}can't{/alt} BE SERIOUS.{p=0.2}{noalt}*{/noalt} {noalt}[[[[ He ]]'S{/noalt}{alt}he's{/alt} THE ONLY REASON YOU'RE HERe!!!"
                        show spamton standing up stare
                        spamton "{noalt}IS{/noalt}{alt}is{/alt} [[[[ He ]] NOT [[the secret to a healthy relationship is proper communication] WITH YOU EITHER?!?!"
                        if date_fp > 0:
                            $ date_fp -= 5
                            play sfx ding
                            show spamton standing up smile at jump
                            if not seenstats_fp:
                                $ seenstats_fp = True
                                "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
                            else:
                                "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

                    "Are you okay?":
                        "You ask Spamton if he's okay, since that glitching doesn't exactly look painless..."
                        show spamton crazy angry at jump
                        spamton "EAHEHAHAH!!{w=0.5} WHAT PART OF ME LOOKS [[okay] AT ALL??"

                        ### HEARTBREAK
                        hide screen datestats
                        call heartbreak_ani from _call_heartbreak_ani_16
                        show screen datestats

                        show spamton standing up glare
                        spamton "WHAT A POINTLES QUESTION ,"

            "Return":
                jump spamdate_shop_menu

        jump spamdate_shop


    ### EYE DATE
    elif currentdate == "eye":
        menu:
            date "Talk"
            "Nice day!":
                $ niceday += 1
                if niceday == 1:
                    if s_niceday > 0:
                        "You once again said you thought today was a nice day."
                        show spamton standing up glare
                        spamton "AGAIN WITH THIS??"
                        show spamton crazy laugh at xwiggle
                        spamton "DO YOU NOT KNOW HOW TO [[Communicate with your ] ANYONE???"
                        "He's got a point...{w=0.2} Why DID you say this again?"
                    
                    else:
                        "You said you thought today was a nice day."
                        show spamton standing up glare at jump
                        spamton "OK??"
                        show spamton standing up stare at jump
                        spamton "I THINK {noalt}IT{/noalt}{alt}it{/alt} WOULD BE MORE [[nice day] IF YOU JUST [[Do as you're told.]"
                        show spamton slouch down panic at xwiggle
                        spamton "YOUR [[rebellious phase] {noalt}IS{/noalt}{alt}is{/alt} KIND OF [[my plans have been foiled!]!!"
                        "...{w=0.2} Actually,{w=0.2} it really HASN'T been a nice day,{w=0.2} has it?"

                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"
                
                else:
                    "You don't think saying this will do anything beneficial."
                    jump spamdate_eye_menu

            "MemoryShards?" if ey_memask == 0:
                $ ey_memask += 1
                "You asked Spamton why he wanted the MemoryShards so badly."
                show spamton standing up frowne
                spamton "TO [[Discard Item] THEM."
                show spamton slouch down frown at droop
                spamton "YOU [[Interact] WITH THEM,{w=0.2} [persistent.mc!u]!"
                spamton "YOU SAW.{w=0.2} WHAT HAPPENS WHEN YOU [[press E to interact] WITH ONE."
                spamton "[persistent.mc!u]{w=0.2} IT'S A [[Flashback] IN [[Real-Time Based]"
                show spamton slouch down panic
                spamton "I WANT{p=0.2}{noalt}*{/noalt} I WANT TO [[Clear Memory]."
                show spamton standing down panic at rise
                spamton "SO THERE CAN'T BE ANY [[Recordkeeping] OF [[View Past Events] !!!"
                if date_fp > 0:
                    $ date_fp -= 2
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton has mixed feelings.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton has mixed feelings.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_kindness]}FP{/color}."

            "Destroying memories?" if ey_memask == 1:
                $ ey_memask += 1
                "You ask if destroying the MemoryShards would actually erase any memories."
                show spamton standing up stare at jump
                spamton "WELL, [persistent.mc!u]!!{p=0.2}{noalt}*{/noalt} HAVE I GOT [[Show Answers] FOR YOU!!"
                show spamton slouch down static at droop
                spamton "[[I{nw=0.5}"
                show spamton standing tilt laugh at jump
                extend " don't actually know],{w=0.2} EAHEHAHAH!"
                if persistent.glitches:
                    show spamton standing up frowne
                else:
                    show spamton standing up frowne at shakingcg
                spamton "BUT I'D RATHER [[Take A Chance] THAN [[But nothing happened!]"
                show spamton slouch down panic at wiggle
                spamton "IF I'M GOING TO REACH [[[[ The Big One ]]..."
                show spamton slouch down smile
                spamton "I CAN'T HAVE ANYTHING [[Now, don't hold back!]."
                if date_fp > 0:
                    $ date_fp -= 2
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton feels even more conflicted.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton feels even more conflicted.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_kindness]}FP{/color}."

            "Freedom?" if not ey_freedom:
                $ ey_freedom = True
                "You ask Spamton about this \"freedom\" he's looking for."
                show spamton standing tilt laugh at jump
                spamton "[[I wanna be a] REAL BOY [[baby] !"
                show spamton standing up stare
                spamton "[[The grass is always greener on] YOUR SIDE OF THE [[Light and Darkness]"
                show spamton at xwiggle
                spamton "[[With your small donation of] YOUR LIFE,{w=0.2} MY [[Hopes and Dreams] WILL FINALLY BECOME [[reality] !!"
                show spamton slouch down static at jump
                spamton "JUST SO LONG AS..."
                show spamton at droop
                spamton "JUST SO LONG AS {color=[c_passion]}YOU{/color} [[actually grant me that freedom]."
                if persistent.glitches:
                    show spamton standing up frowne
                else:
                    show spamton standing up frowne at shakingcg
                spamton "UNLIKE SOME [[green] {noalt}[[phoney]S{/noalt}{alt}phoneys{/alt}!!"
                if date_fp > 0:
                    $ date_fp -= 2
                    play sfx ding
                    show spamton standing up smile at jump
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Spamton is desperately hoping you'll do what he wants.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Spamton is desperately hoping you'll do what he wants.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

            "Return":
                jump spamdate_eye_menu

        jump spamdate_eye


######################################################
##### ACT
label spamdate_act:
    $ skipyes = True
    $ _skipping = True
    hide screen spamdate_select
    hide screen spam_f1forhelp

    ### SHOP DATE
    if currentdate == "shop":
        menu:
            date "Act"
            "Check":
                $ s_check = True
                $ check += 1
                if check == 1:
                    "Spamton - 100 FP  50 LP{p=0.2}{noalt}*{/noalt} Everything is a deal to him."
                    show spamton standing up stare at xwiggle
                    spamton "QUIT LOOKING AT ME LIKE I'm SOME KIND OF [[candy] [[[[For Youre Eyes Only]] !!!"
                else:
                    "Spamton - 100 FP  50 LP{p=0.2}{noalt}*{/noalt} Everything is transactional to him."
                    jump spamdate_shop_menu

            "Flirt":
                $ s_flirt = True
                $ flirt += 1
                if flirt == 1:
                    "You tell Spamton you can't tell the difference between his clothes and body."
                    if date_lp > 0:
                        $ date_lp -= 3
                        play sfx ding
                        show spamton standing up frowne at jump
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Spamton seems thrown off.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Spamton seems thrown off.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}LP{/color}."
                    show spamton standing tilt laugh at jump
                    spamton "WHAT THE {noalt}[[h3ck] IS{/noalt}{alt}heck is{/alt} THAT SUPPOSED TO MEAN??"
                    show spamton crazy angry at xwiggle
                    spamton "IF YOU'RE TRYING TO [[woohoo] ME,{w=0.2} YOU'RE [[skill too low] !!"
                    show spamton standing up stare
                    spamton "I'M NOT INTO [[Insert Descriptor Here] LIKE YOU!!"

                elif flirt == 2:
                    "You say Spamton is the best salesman you've ever met."
                    if date_lp > 0:
                        $ date_lp -= 5
                        play sfx ding
                        show spamton standing up frowne at jump
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Spamton seems appalled.{p=0.2}{noalt}*{/noalt} But he gained 5 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Spamton seems appalled.{p=0.2}{noalt}*{/noalt} But he gained 5 {color=[c_passion]}LP{/color}."
                    show spamton crazy smirk at jump
                    spamton "THEY DON'T CALL ME [[Number One Rated Salesman 1997] FOR NOTHING!!!"
                    show spamton standing down panic
                    spamton "BUT.{w=0.2} YOU HAVEN'T.{w=0.2} PAID.{p=0.5}{noalt}*{/noalt} YOUR [[Half Off] THE [[Terms and Conditions]"
                    if persistent.glitches:
                        show spamton standing up stare
                    else:
                        show spamton standing up stare at shakingcg
                    spamton "YOUR {noalt}[[Heart-ShapedObject]{/noalt}{alt}heart-shaped object{/alt}."

                elif flirt == 3:
                    "You tell Spamton he's a big shot."
                    if date_lp > 0:
                        $ date_lp -= 10
                        play sfx ding
                        show spamton standing up frowne at jump
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Spamton seems stunned.{p=0.2}{noalt}*{/noalt} But he gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Spamton seems stunned.{p=0.2}{noalt}*{/noalt} But he gained 10 {color=[c_passion]}LP{/color}."
                    show spamton standing tilt laugh at xwiggle
                    spamton "EAHAHHEHEH!{p=0.5}{noalt}*{/noalt} I MAY BE [[big] BUT I'M NOT A [[[[ BIG SHOT!!!!! ]] YET"
                    show spamton standing up stare at jump
                    spamton "THAT COULD CHANGE WITH YOUR [[Wanted Assistance]"
                    show spamton crazy laugh at xwiggle
                    spamton "[[Don't wait !] FOR THIS UNFORGETTIBLE DEAL,{w=0.2} AVAILABLE ONLY FOR [[desperate little] LONELY [[Hearts] LIKE YOU!"
                    if persistent.glitches:
                        show spamton crazy laugh
                    else:
                        show spamton crazy laugh at shakingcg
                    spamton "SAVE YOUR [[schmoozing] FOR AFTER YOU [[pay up] !!!"
                
                else:  
                    "You flirted with Spamton."
                    show spamton standing tilt laugh at xwiggle
                    spamton "RUNNING OUT OF [[good material]?{p=0.5}{noalt}*{/noalt} YOU CAN'T [[*wink*] YOUR WAY OUT OF EVERYTHING!!"
                    "He's apparently not impressed."

            "Ask":
                if not s_ask:
                    $ s_ask = True
                    "You try to think of something to ask Spamton..."
                    show spamton standing up stare
                    spamton "TRYING TO GET [[my personal information] BECAUSE I STOLE [[your personal information]???"
                    show spamton crazy laugh at xwiggle
                    spamton "[[glhf]!!!{p=0.5}{noalt}*{/noalt} I'M [[a tough nut to crack]."
                    show spamton standing up smile at yreset
                
                elif s_qu_color and s_qu_food and s_qu_here and s_qu_me and s_qu_you:
                    "You can't think of anything else to ask Spamton."
                    jump spamdate_shop_menu

                menu:
                    date "What will you ask?"
                    "Come here often?" if not s_qu_here:
                        $ s_qu_here = True
                        "You ask Spamton if he visits this place often."
                        show spamton crazy frantic at xwiggle
                        spamton "ME??{p=0.5}{noalt}*{/noalt} YOU THINK I LIKE [[You can visit the trash can anytime]???"
                        show spamton standing up stare at jump
                        spamton "YOU KNOW WHAT??{p=0.2}{noalt}*{/noalt} LET'S SEE [[What did you answer] TO THIS [[quizshow question] ?!"
                        show spamton slouch down static
                        if persistent.here == "yes":
                            spamton "...{w=0.5} [[ [persistent.here] ]?"
                            show spamton standing up glaree at jump
                            spamton "YOU DO???"
                            if persistent.playthru:
                                if persistent.glitches:
                                    show spamton standing up frowne
                                else:
                                    show spamton standing up frowne at shakingcg
                                spamton "THIS ISN'T YOUR FIRST [[persistent.playthru],{p=0.5}{noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}??"
                                show spamton standing tilt laugh at jump
                                spamton "EAHEHAHA!!{p=0.2}{noalt}*{/noalt} DON'T WORRY!!{w=0.5} [[Your secret is safe with] SPAMTON G. SPAMTON!!"
                                if persistent.glitches:
                                    show spamton standing down panic
                                else:
                                    show spamton standing down panic glitch
                                spamton "WE DON'T NEED ANYONE ELSE WHO"
                            else:
                                show spamton standing tilt laugh
                                spamton "THAT CAN'T BE{space=100}!!{nw=0.2}"
                                show spamton at xwiggle
                                extend "{p=0}{noalt}*{/noalt} I'VE NEVER [[Have you seen this ] BEFORE!!"
                                show spamton standing up frowne at jump
                                spamton "OR {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}...{w=0.5} [[something else.]"

                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

                        elif persistent.here == "no":
                            spamton "...{w=0.5} [[ [persistent.here] ]?"
                            if persistent.glitches:
                                show spamton standing up stare
                            else:
                                show spamton standing up stare at shakingcg
                            spamton "WELL AREN'T YOU [[]!!"
                            show spamton crazy frantic
                            spamton "I WOULDN'T BE [[here] EITHER IF I WASN'T [[being held against my will] !!"
                            show spamton standing up frowne
                            spamton "[[Would you mind] TELL ME [[where is the exit?]?"

                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_22
                            show screen datestats

                        elif persistent.here == "maybe":
                            spamton "...{w=0.5} [[ [persistent.here] ]?"
                            show spamton standing up glare at jump
                            spamton "WHAT A [[clear] AND [[easy-to-understand] ANSWER, [persistent.mc!u]!"
                            show spamton standing up smirk
                            spamton "YOU SHOULD WRITE A [[How to Improperly Communicate] BOOK!!"

                        elif persistent.here == "where":
                            spamton "...{w=0.5} [[ where are we? ]?"
                            show spamton standing tilt laugh at xwiggle
                            spamton "HE REALLY DIDN'T TELL YOU THE [[Our Immediate Location] DID HE??{p=0.2}{noalt}*{/noalt} EAHEAHAHEH!!"
                            if persistent.glitches:
                                show spamton crazy frantic
                            else:
                                show spamton crazy frantic at shakingcg
                            spamton "[[Even in death,]{w=0.2} HE'S STILL [[covering up the truth]!!"
                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

                        else:
                            spamton "...{nw=0.5}"
                            show spamton standing up stare at jump
                            extend " YOU DIDN'T EVEN [[answer] THE [[question]!!"
                            show spamton standing tilt laugh at jump
                            spamton "EAHAHAH!!{p=0.5}{noalt}*{/noalt} I WOULDN'T [[entertain] THAT [[light box] EITHER!!"
                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

                    "Favorite food?" if not s_qu_food:
                        $ s_qu_food = True
                        "You ask Spamton what his favorite food is."
                        show spamton standing up smile at jump
                        spamton "[[A todos los que no saben qué es ]\n\"The Original\" [[true authentic Mexican food] !!"
                        show spamton standing up stare
                        spamton "[[But enough about that,]{p=0.2}{noalt}*{/noalt} WHAT ABOUT YOUR [[Favorite food?]"
                        show spamton standing tilt laugh at xwiggle
                        spamton "LET'S SEE!!{w=0.2} [[You said:]"
                        show spamton slouch down static at yreset
                        if persistent.favefood == "baked goods":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up stare at jump
                            spamton "YOU NEED SOME [[café] TO GO WITH THAT,{w=0.2} OR DO YOU JUST EAT [[fluffy nonsense] BY ITSELF??"
                            show spamton standing tilt laugh at jump
                            spamton "WHATEVER [[floats your boat] I GUESS!!!"

                        elif persistent.favefood == "candy":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up frowne at jump
                            spamton "WHAT,{w=0.2} ARE YOU [[below the age of 18]?!{p=0.5}{noalt}*{/noalt} [[ candy ] {noalt}IS{/noalt}{alt}is{/alt} YOUR [[Favorite]??"
                            show spamton crazy angry at xwiggle
                            spamton "IT'S AN [[Fun for the whole family!] [[Dessert Ideas],{w=0.5} BUT YOUR [[[[ Favorite ]] ????"
                            show spamton crazy laugh at jump
                            spamton "[[I respect that] LEVEL OF CONFIDENCE!"

                        elif persistent.favefood == "sweets":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up frowne
                            spamton "ANY AND ALL THINGS [[ sweets ]??{nw=0.5}"
                            show spamton standing tilt laugh at xwiggle
                            extend "{p=0}{noalt}*{/noalt} MORE FOR [[you] THEN!!"
                            show spamton standing up stare at jump
                            spamton "TOO MUCH SUGAR {noalt}IS{/noalt}{alt}is{/alt} [[bad for the skin]."

                        elif persistent.favefood == "fries":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing tilt laugh at jump
                            spamton "CAN'T GO WRONG WITH A [[Giant Fry], SO LONG AS {noalt}IT{/noalt}{alt}it{/alt} ISN'T [[{noalt}Fr*nch{/noalt}{alt}french{/alt}]!!"
                            show spamton at xwiggle
                            spamton "YOU EVER DOWN A WHOLE PLATE OF [[fish 'n' chips] ?!{p=0.5}{noalt}*{/noalt} MAKE SURE THE [[fish ] ARE [[blue caviar]!!"

                        elif persistent.favefood == "pretzels":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing tilt laugh at jump
                            spamton "[[Twist it!]{w=0.2} [[B*p it!]{p=0.5}{noalt}*{/noalt} [[Shove the entire thing down your throat] IN ONE GO!!"
                            show spamton crazy laugh at xwiggle
                            spamton "[[ trust ] ME,{w=0.2} IT'S A [[Terrible idea]!!!"

                        elif persistent.favefood == "salty foods":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up glare
                            spamton "AS IN [[food that is typically considered salty] OR YOU [[Will Drown Everything In A Mountain Of Salt] ???"
                            show spamton standing tilt laugh at jump
                            spamton "BECAUSE ONLY ONE OF THESE {noalt}IS{/noalt}{alt}is{/alt} [[the correct answer],{w=0.2} AND IT'S PROBABLY NOT THE ONE YOU THINK!!"

                        elif persistent.favefood == "chocolate":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up stare at jump
                            spamton "IT'S [[boring], BUT IT'S [[A Classic]!"
                            show spamton standing tilt laugh at xwiggle
                            spamton "YOU CAN'T GO WRONG WITH [[replaying the classics]."

                        elif persistent.favefood == "coffee":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up frowne at jump
                            spamton "[[ coffee ] {noalt}IS{/noalt}{alt}is{/alt} GOOD,{w=0.2} BUT AS YOUR [[Favorite]??"
                            show spamton standing up stare
                            spamton "I AM BEGGING YOU TO [[branch out].{p=0.5}{noalt}*{/noalt} HAVE YOU TRIED [[Freshwater Clams] BEFORE??"

                        elif persistent.favefood == "bitter foods":
                            spamton "...{w=0.5} [[ [persistent.favefood] ]"
                            show spamton standing up frowne at jump
                            spamton "HUH, YOU KNOW, I DON'T HAVE ANYTHING CLEVER TO [[make fun of you with]"
                            show spamton standing tilt laugh at xwiggle
                            spamton "I JUST THINK THAT'S [[icky]!!"

                        elif persistent.favefood == "anything":
                            spamton "...{w=0.5} [[ anything tenna makes ]"
                            show spamton standing up frowne at jump
                            spamton "WHAT??{w=0.2} [[ anything tenna makes ]??{p=0.5}{noalt}*{/noalt} ARE YOU A [[simpleton] ?!"
                            if persistent.glitches:
                                show spamton crazy frantic
                            else:
                                show spamton crazy frantic at shakingcg
                            spamton "HE CAN'T COOK ANYTHING!!{p=0.5}{noalt}*{/noalt} ALL HE MAKES ARE [[TV Dinners] MADE FOR {noalt}[[TV]s{/noalt}{alt}TVs{/alt}!!!"
                            spamton "DO YOU HAVE [[absolutely] NO TASTEBUDS??"

                        else:
                            spamton "...{nw=0.5}"
                            show spamton standing up stare at jump
                            extend " YOU DIDN'T [[answer] THE [[question]?!"
                            show spamton crazy laugh at xwiggle
                            spamton "DO YOU [[consume] FOOD??{p=0.5}{noalt}*{/noalt} YOU CAN'T [[just forget about ] [[sustinence],{w=0.2} [persistent.mc!u]!!"
                            show spamton standing down panic
                            spamton "HOW ELSE WILL YOUR BODY [[sustin] YOUR {noalt}[[Heart-ShapedObject]{/noalt}{alt}heart-shaped object{/alt},?!"
                            show spamton standing tilt laugh at jump
                            spamton "TOO BAD I CAN'T [[cook for ] !!"
                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing down panic at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton's a little concnerned about your well-being.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton's a little concnerned about your well-being.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."
                            jump spamdate_shop

                        if date_fp > 0:
                            $ date_fp -= 1
                            play sfx ding
                            show spamton standing up smile at jump
                            if not seenstats_fp:
                                $ seenstats_fp = True
                                "Spamton got to know you a bit better.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_kindness]}Friendship Point{/color}."
                            else:
                                "Spamton got to know you a bit better.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_kindness]}FP{/color}."

                    "Favorite color?" if not s_qu_color:
                        $ s_qu_color = True
                        "You ask Spamton if he had a favorite color."
                        show spamton standing up glaree at jump
                        spamton "WHAT ARE YOU [[monetary gain]ING FROM THIS QUESTION??"
                        show spamton crazy laugh at xwiggle
                        spamton "DID [[cathode ray tube] ACTUALLY ASK YOU [[*this*]??{p=0.2}{noalt}*{/noalt} YIKES!!{w=0.2} HOW [[Pathetic.]"
                        show spamton standing up glare at jump
                        spamton "WHATEVER.{w=0.2} [[Now I'm curious] WHAT YOU SAID."
                        show spamton slouch down static
                        if persistent.favecolor:
                            spamton "...{w=0.5} [[ [persistent.favecolor] ]"
                        else:
                            spamton "...{nw=0.5}"
                            show spamton standing up stare at jump
                            extend " YOU DIDN'T [[answer] THE [[question]."
                            show spamton crazy laugh at jump
                            spamton "WELL WHEN THOSE FOUR [[terrible] OPTIONS ARE [[You have no other choice],{w=0.2} I'D RATHER HAVE PICKED [[Death] TOO!!"
                            show spamton crazy frantic at xwiggle
                            spamton "AT LEAST PROVIDE THE [[S tier] COLORS, [[Cathode],{w=0.2} LIKE [[pink] OR [[gold] OR [[rainbow] OR [[green]!!"
                            show spamton at yreset
                            spamton "...{nw=0.5}"
                            show spamton slouch down panic at droop
                            extend " OK MAYBE NOT THAT LAST ONE."
                            jump spamdate_shop

                        show spamton standing up glaree at jump
                        spamton "I'VE GOT NOTHING TO SAY IN [[Reply to this e-mail] !!"
                        show spamton crazy frantic at xwiggle
                        spamton "[[static screen] REALLY CAN'T [[I can do things by myself, too!]{p=0.5}{noalt}*{/noalt} WHAT {noalt}IS{/noalt}{alt}is{/alt} THIS,{w=0.2} A [[Internet Personality Quiz] ?!"

                    "Opinion of me?" if not s_qu_me:
                        $ s_qu_me = True
                        "You ask if Spamton had any standout opinions about you."
                        show spamton crazy laugh at jump
                        spamton "I'D LIKE YOU AND YOUR [[fat stacks] MORE IF YOU\n[[But you promised!]"
                        show spamton standing up stare
                        spamton "I CAN ONLY [[ trust ] SOMEONE WHO\n[[ doesn't listen to you. ] SO MUCH"
                        show spamton standing tilt laugh at xwiggle
                        spamton "EAHEHAHA!!{w=0.2} [[But hey,] WHO CARES?!{p=0.5}{noalt}*{/noalt} THE REAL [[profits] ARE IN [[what you answered]..."
                        show spamton standing tilt stare at jump
                        spamton "YOUR [[first impression] OF [[strangers] [[You found ] IN THE DUMP!!"
                        show spamton slouch down static
                        if persistent.firstimpress in ["handsome", "charming"]:
                            spamton "...{w=0.5} [[ [persistent.firstimpress] ]"
                            spamton "{noalt}IS{/noalt}{alt}is{/alt} THIS FOR [[Everything that the] DARK [[touches],{w=0.2} OR JUST [[Couch Potato]??"
                            menu:
                                rq "{noalt}IS{/noalt}{alt}is{/alt} THIS FOR [[Everything that the] DARK [[touches],{w=0.2} OR JUST [[Couch Potato]??"
                                "Everyone":
                                    "You say it applies to everyone."
                                    show spamton standing up frowne at jump
                                    pause 1.0
                                    show spamton crazy angry at xwiggle
                                    spamton "YOU'RE [[Crazy Eights] [persistent.mc!u]!!{p=0.2}{noalt}*{/noalt} DO YOU [[judge a book by its cover] EVERYONE YOU MEET??"
                                    if date_lp > 0:
                                        $ date_lp -= 2
                                        play sfx ding
                                        show spamton standing down panic at jump
                                        if not seenstats_lp:
                                            $ seenstats_lp = True
                                            "Spamton doesn't know what to think.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_passion]}Love Points{/color}."
                                        else:
                                            "Spamton doesn't know what to think.{p=0.2}{noalt}*{/noalt} But he gained 2 {color=[c_passion]}LP{/color}."

                                "Just Tenna":
                                    "You say it just applies to Tenna."
                                    show spamton standing tilt laugh at xwiggle
                                    spamton "THEN I DON'T CARE!!{p=0.2}{noalt}*{/noalt} [[Next question, please!]"

                        elif persistent.firstimpress == "nose":
                            spamton "...{w=0.5} [[ [persistent.firstimpress] ]"
                            if persistent.glitches:
                                show spamton standing up stare
                            else:
                                show spamton standing up stare at shakingcg
                            spamton "A BIG [[ nose ]?!?!{p=0.5}{noalt}*{/noalt} YOU'RE A [[real] FREAK, [persistent.mc!u]!!"
                            show spamton standing tilt laugh at jump
                            spamton "BUT YOU'RE [[honesty above all else] AND I CAN [[get behind that],{w=0.2} EAHEHAHAHEH!!"
                            show spamton standing up frowne
                            spamton "...{w=0.2} UNLESS YOU WERE JUST [[Act to Flirt] WITH\n[[Tin Can]!!{p=0.5}{noalt}*{/noalt} IN THAT CASE,{w=0.2} {noalt}[[$&*X]{/noalt}{alt}beep{/alt} YOU, MAN!!"
                            if date_fp > 0:
                                $ date_fp -= 1
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton doesn't know your intentions.{p=0.2}{noalt}*{/noalt} But he gained 1 {color=[c_kindness]}Friendship Point{/color}."
                                else:
                                    "Spamton doesn't know your intentions.{p=0.2}{noalt}*{/noalt} But he gained 1 {color=[c_kindness]}FP{/color}."

                        elif persistent.firstimpress == "tall":
                            spamton "...{w=0.5} [[ [persistent.firstimpress] ]"
                            show spamton standing down panic at rise
                            spamton "[[If you were looking for] [[One] TALL MAN,{w=0.5} [[Some] ARE TALLER THAN [[fuzzface]!!"
                            show spamton standing up stare
                            spamton "YOU SHOULD [[Consider your options before making a purchase]."
                            
                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_23
                            show screen datestats

                        else:
                            spamton "...{nw=0.5}"
                            show spamton standing up stare at jump
                            extend " YOU DIDN'T [[answer] THE [[question]."
                            show spamton crazy angry at xwiggle
                            spamton "TWO OF THE [[wide-range of options] ARE [[basically the same] SO [[I'll let it slide]..."
                            show spamton standing up frowne at jump
                            spamton "BUT YOU DON'T CARE ABOUT A MAN'S BIG [[nose]?!"
                            show spamton standing up stare
                            spamton "YOU KNOW WHAT??{nw=0.5}"
                            show spamton standing tilt laugh at jump
                            extend "{p=0}{noalt}*{/noalt} [[More power to ya]!!"
                            if date_fp > 0:
                                $ date_fp -= 1
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton's a bit curious now.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_kindness]}Friendship Point{/color}."
                                else:
                                    "Spamton's a bit curious now.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_kindness]}FP{/color}."

                    "Opinion of yourself?" if not s_qu_you:
                        $ s_qu_you = True
                        "You ask Spamton what he thinks of himself."
                        show spamton standing up frowne at jump
                        spamton "THIS QUESTION {noalt}IS{/noalt}{alt}is{/alt} [[invasion of privacy]!!{p=0.5}{noalt}*{/noalt} [[You can't just ask a] SPAMTON [[about] SPAMTON!!"
                        show spamton crazy laugh at xwiggle
                        spamton "HOW WOULD YOU LIKE {noalt}IT{/noalt}{alt}it{/alt} IF I [[browsed your internet search history] ?!"
                        show spamton slouch down smile at jump
                        spamton "{noalt}WHHAT{/noalt}{alt}what{/alt} DID YOU ANSWER [[fuzzface]..."
                        show spamton slouch down static
                        if persistent.selflove == "kindness":
                            spamton "...{w=0.5} [[ [persistent.selflove] ]."
                            pause 1.0
                            spamton ".{w=0.2}.{w=0.2}."
                            show spamton at droop
                            spamton "WELL THAT'S [[in]CONVENIENT."
                            
                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_24
                            show screen datestats
                        
                        elif persistent.selflove == "passion":
                            spamton "...{w=0.5} [[ [persistent.selflove] ]."
                            show spamton standing up glaree
                            spamton "[[I don't know what I expected.]"
                            if date_lp > 0:
                                $ date_lp -= 2
                                play sfx ding
                                show spamton standing up smirk at jump
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Spamton's a bit endeared.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Spamton's a bit endeared.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}LP{/color}."

                        elif persistent.selflove == "determination":
                            spamton "...{w=0.5} [[ [persistent.selflove] ]."
                            show spamton standing tilt laugh at jump
                            spamton "EAHAHAH!!{p=0.5}{noalt}*{/noalt} THAT EXPLAINS YOUR [[Determination.] TO NOT [[do as you're told]."
                            show spamton standing up stare
                            spamton "[[That's good] QUALITY TO HAVE!!{p=0.5}{noalt}*{/noalt} YOU CAN BECOME A REAL [[] WITH [[skills like that]!"
                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton trusts you a bit more.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."

                        elif persistent.selflove == "hope":
                            spamton "...{w=0.5} [[ [persistent.selflove] ]."
                            show spamton at droop
                            spamton "...{w=0.2} SOUNDS. {w=0.5}[[nice.]"
                            show spamton slouch down panic
                            spamton "WHAT'S {noalt}IT{/noalt}{alt}it{/alt} FEEL LIKE TO STILL{p=0.2}{noalt}*{/noalt} TO STILL{p=0.2}{noalt}*{/noalt} TO STILL"
                           
                            ### HEARTBREAK
                            hide screen datestats
                            call heartbreak_ani from _call_heartbreak_ani_25
                            show screen datestats

                        else:
                            spamton "...{nw=0.5}"
                            show spamton standing up stare at jump
                            extend " YOU DIDN'T [[answer] THE [[question]?!"
                            show spamton standing up frowne at xwiggle
                            spamton "[[Don't tell me:] YOU DON'T HAVE ANYTHING YOU LIKE ABOUT{space=150}?{p=0.2}{noalt}*{/noalt} [[That's no good], [persistent.mc!u]!"
                            show spamton crazy laugh at jump
                            spamton "HAVE A [[Live, Laugh, Love]!!{p=0.5}{noalt}*{/noalt} TREAT YOURSELF LIKE A [[[[ BIG SHOT ]]!!{w=0.2} [[You deserve it!]"
                            if date_fp > 0:
                                $ date_fp -= 2
                                play sfx ding
                                show spamton standing up smile at jump
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Spamton has some sympathy for you.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Spamton has some sympathy for you.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."
                    
                    "Return":
                        jump spamdate_shop_menu
            
            "Press [[F1] for help\n{size=-10}{color=#aaaaaa}(Heal){/color}{/size}" if vess_hp < 3 and not s_help_done:
                jump pressf1forhelp

            "Bribe\n{size=-10}{color=#aaaaaa}(Restore){/color}{/size}" if date_hb < 3:
                if not s_bribesee:
                    $ s_bribesee = True
                    "There's a bunch of junk around you...{w=0.2} on account of being in a junkyard."
                    "Maybe if you were to give some of it to Spamton,{w=0.2} he might hate you a little less...?"
                if s_bribeitm == 1:
                    $ s_bribe_menu_text1 = "is"
                    $ s_bribe_menu_text2 = "item"
                else:
                    $ s_bribe_menu_text1 = "are"
                    $ s_bribe_menu_text2 = "items"
                menu:
                    rq "There [s_bribe_menu_text1] {color=[c_passion]}[s_bribeitm]{/color} [s_bribe_menu_text2] left that Spamton might like."
                    "Give" if s_bribeitm > 0:
                        play sfx item
                        $ s_bribeitm -= 1
                        "You picked up some unidentifiable trash and handed it to Spamton."
                        if s_bribeitm == 1:
                            show spamton standing up stare at jump
                            spamton "WHAT'S THIS??{p=0.5}{noalt}*{/noalt} TRYING TO WIN ME OVER WITH [[Invaluable] TRASH ?!?"
                            pause 1.0
                            show spamton crazy frantic at xwiggle
                            spamton "WELL IT'S WORKING.{p=0.2}{noalt}*{/noalt} YOU'RE LUCKY I CAN [[reduce, reuse, and] RESELL THIS!!!"
                        else:
                            show spamton standing up stare at jump
                            spamton "MORE [[free] JUNK??"
                            show spamton crazy laugh at xwiggle
                            spamton "[persistent.mc!u] ARE YOU TRYING TO [[spoiled milk] ME OR SOMETHING??"

                        ### RESTORE
                        hide screen datestats
                        call restore_ani from _call_restore_ani_1
                        show screen datestats
                        
                    "Do not":
                        jump spamdate_shop_menu

            "Return":
                jump spamdate_shop_menu

        jump spamdate_shop


    ### EYE DATE
    elif currentdate == "eye":
        menu:
            date "Act"
            "Check":
                $ check += 1
                if check == 1:
                    "Spamton - 100 FP  50 LP{p=0.2}{noalt}*{/noalt} He's growing desperate."
                    show spamton standing up frowne at jump
                    if s_check:
                        spamton "HEY [[Hey!] DIDNN'T I TELL YOU [[blue stop signs] ONCE ALREADY?!?"
                    else:
                        spamton "HEY WHAT GIVES!{p=0.2}{noalt}*{/noalt} AM I JUST CANDY [[for youre eyes only] TO YOU?!"
                    show spamton crazy frantic at xwiggle
                    spamton "QUIT [[Look with your special eyes]"
                else:
                    "Spamton - 100 FP  50 LP{p=0.2}{noalt}*{/noalt} He'll cut this off any minute now."
                    jump spamdate_eye_menu

            "Flirt":
                $ s_flirt = True
                $ flirt += 1
                if flirt == 1:
                    "You say that your heart is still up for offer,{w=0.2} instead of your \"heart-shaped object.\""
                    show spamton standing up frowne at jump
                    spamton "YOU KNOW, [[desperate little ],{w=0.2} I'M STARTING TO THINK YOU AREN'T TAKING THIS SERIOUSLY"
                    show spamton standing tilt laugh at xwiggle
                    spamton "I WON'T JUST [[dating simulation] WITH ANY RANDOM [[money-haver] THAT SHOWES UP!!"
                    if persistent.glitches:
                        show spamton standing up stare at yreset
                    else:
                        show spamton standing up stare at shakingcg
                    spamton "YOU. HAVE SOMETHING. VERY [[Important Date] TO ME."
                    if date_lp > 0:
                        $ date_lp -= 3
                        play sfx ding
                        show spamton standing up smirk at jump
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Spamton appreciates the effort, at least.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Spamton appreciates the effort, at least.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}LP{/color}."

                elif flirt == 2:
                    "You suggest that spending the rest of your time with Spamton might be more appealing than a \"heart-shaped object\" anyway."
                    show spamton standing tilt laugh at xwiggle
                    spamton "EAHAAHEHAHAH!!{p=0.2}{noalt}*{/noalt} ARE YOU [[All Alone On A Saturday Night?]"
                    if persistent.glitches:
                        show spamton standing up frowne at jump
                    else:
                        show spamton standing up frowne at shakingcg
                    spamton "SPAMTON G. SPAMTON DOESN'T NEED [[anyone else]!!{p=0.2}{noalt}*{/noalt} I'D RATHER HAVE YOUR [[priceless] OBJECT"
                    if date_lp > 0:
                        $ date_lp -= 1
                        play sfx ding
                        show spamton standing up smirk at jump
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Spamton... sort of appreciates the effort.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Spamton... sort of appreciates the effort.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_passion]}LP{/color}."
                
                elif flirt == 3:
                    "You tried flirting with Spamton again,{w=0.2} but...{nw=0.2}"
                    show spamton standing up frowne at jump
                    spamton "[[desperate little ] [persistent.mc]!!{p=0.2}{noalt}*{/noalt} I'M GETTING [[irritable bowel syndrome] FROM HEARING ALL YOUR [[crap]!!!"
                    show spamton standing up stare
                    spamton "GIMMIE.{w=0.2} YOUR HALF OF THE BARGAIN."
                    if persistent.glitches:
                        pass
                    else:
                        show spamton at shakingcg
                    spamton "OR [[Scram!]."
                    "... you fear you might be pushing things too far."
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

                else:
                    "You're pretty sure this won't work anymore."
                    jump spamdate_eye_menu

            "Haggle":
                $ s_haggle += 1
                if s_haggle == 1:
                    "You tried to negotiate the price regarding your \"deal\" with Spamton,{w=0.2} if it can't be called off."
                    show spamton crazy laugh at xwiggle
                    spamton "NOW YOU'RE SPEAKING [[plain English]!!"
                    show spamton standing up smile at jump
                    spamton "[[What're ya offerin'?] ME?{p=0.5}{noalt}*{/noalt} I'M A [[sales pitch] GUY,{w=0.2} [persistent.mc!u]!"
                    show spamton standing tilt laugh at xwiggle
                    spamton "YOU KNOW I WON'T TAKE UP ANY OFFERS UNLESS [[I win, you lose]!!"
                    show spamton standing up stare at jump
                    menu:
                        rq "What will you offer?"
                        "Instead of SOUL, more Dark Dollars":
                            "You tried to offer to look for more money instead of handing over your SOUL."
                            show spamton standing up frown
                            spamton "[persistent.mc!u] [[I hate to be the bearer of bad news],{w=0.2} BUT YOUR [[SOUL] {noalt}IS{/noalt}{alt}is{/alt} [[Priceless]!!"
                            if persistent.glitches:
                                show spamton standing up stare
                            else:
                                show spamton standing up stare at shakingcg
                            spamton "UNLESS YOU'RE [[looking on the black market.]"
                            show spamton crazy angry at xwiggle
                            spamton "I CAN'T ACCEPT [[money payment] FOR YOUR [[Lifetime] !!"
                            show spamton standing up frowne at jump
                            spamton "IT'S NOT [[of equal value],{w=0.2} AND I'M AN [[HonestMan] [[of] [[value] !!"
                            "It's not like you had any money you could have offered him, anyway..."
                            play sfx awkwardS
                            $ vess_hp -= 1
                            "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

                        "Instead of SOUL, more time with you":
                            "You decided to offer spending more time with Spamton instead of your SOUL."
                            show spamton standing up smile at jump
                            spamton "WHILE I APPRECIATE THE [[loose] PROMISE OF\n[[Company Meetings]...{w=0.5} [[I don't want it]!!!"
                            show spamton standing tilt laugh at xwiggle
                            spamton "UNLESS YOU CAN [[Take me to your] [[Living Quarters],{w=0.2} I DON'T THINK THIS {noalt}IS{/noalt}{alt}is{/alt} [[a worthwhile investment]."
                            "Do you really want to do that...?"
                            menu:
                                rq "(Do you really want to do that...?)"
                                "Yes":
                                    "You said you'd be willing to figure out how to make that work."
                                    show spamton standing up frowne at yreset
                                    spamton_shh "{w=0.2}.{w=0.2}.{w=0.2}."
                                    pause 1.0
                                    show spamton crazy laugh at xwiggle
                                    spamton "I DON'T BELIEVE YOU!!{p=0.5}{noalt}*{/noalt} ANY GOOD [[Businessperson] KNOWS THAT [[if it sounds too good to be true,] {noalt}IT{/noalt}{alt}it{/alt} {noalt}IS{/noalt}{alt}is{/alt}!!"
                                    if date_lp > 0 or date_fp > 0:
                                        $ date_lp -= 3
                                        $ date_fp -= 3
                                        play sfx ding
                                        show spamton standing down panic at jump
                                        if not seenstats_lp:
                                            $ seenstats_lp = True
                                            "Nevertheless, Spamton wants it to be true.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color} and {color=[c_passion]}Love Points{/color}."
                                        else:
                                            "Nevertheless, Spamton wants it to be true.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color} and {color=[c_passion]}LP{/color}."

                                "No":
                                    "You don't want to deal with Spamton any longer than you have to."
                                    show spamton crazy frantic
                                    spamton "THEN WHY'D YOU EVEN [[Bring Up The Topic]?!"
                                    "He's got a point..."
                                    play sfx awkwardS
                                    $ vess_hp -= 1
                                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

                elif s_haggle == 2:
                    "You went to haggle the deal again,{w=0.2} but...{nw=0.2}"
                    show spamton standing up stare at xwiggle
                    spamton "[[loud incorrect buzzer]{w=0.5} NOPE!{w=0.2} NOPE!"
                    show spamton crazy laugh at xwiggle
                    spamton "[[Anything you can] OFFER CANNOT POSSIBLY BE [[worth it]!!"
                    if persistent.glitches:
                        show spamton standing up frowne
                    else:
                        show spamton standing up frowne at shakingcg
                    spamton "[[... unless] YOU [[Revert Back To] THE [[Original] !!"
                    "Guess this was a dead-end."
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"
                
                else:
                    "You feel like this isn't going to help you."
                    jump spamdate_eye_menu

            "Deal\n{size=-10}{color=#aaaaaa}(Restore){/color}{/size}" if date_hb < 3:
                if not ey_dealsee:
                    $ ey_dealsee = True
                    "You feel like you won't be able to bribe Spamton right now...{w=0.2} but you could try to strike a deal with him."
                    "Maybe you could indulge him in making a smaller deal,{w=0.2} not involving the ring or \"heart-shaped object,\"{w=0.2} just to entertain him a bit."
                if ey_deals == 1:
                    $ ey_deal_menu_text = "time"
                else:
                    $ ey_deal_menu_text = "times"
                menu:
                    rq "You can offer a small deal {color=[c_passion]}[ey_deals]{/color} more [ey_deal_menu_text]."
                    "Strike a deal" if ey_deals > 0:
                        play sfx item
                        $ ey_deals -= 1
                        if ey_deals == 1:
                            "You asked Spamton if there was something else he was selling that you might be interested in buying later."
                            show spamton standing up stare at xwiggle
                            spamton "OH BOY DO I!{p=0.5}{noalt}*{/noalt} [persistent.mc!u] HAVE YOU EVEN MET [[Your Best Nightmare] SPAMTON?!"
                            show spamton standing tilt laugh at jump
                            spamton "[[Try our NEW] {noalt}[[*TT{/noalt}{alt}MTT{/alt}-Brand Formal Dress] FOR ALL YOUR [[clothed person] NEEDS!!{p=0.5}{noalt}*{/noalt} [[Comes with a FREE] MANNEQUIN!"
                        else:
                            "You asked if there was anything more Spamton had for sale that you might also want to buy later."
                            show spamton crazy frantic at jump
                            spamton "I DON'T KNOW YOUR [[speak your truth] OR WHY YOU'RE ASKING THIS BUT I CAN'T TURN DOWN A [[Capital Exchange]!"
                            show spamton standing tilt laugh at jump
                            spamton "HAVE YOU CONSIDERED [[our new, ORIGINAL soft drink]{w=0.2} {noalt}\"PIPIS\"{/noalt}{alt}pee piss{/alt}!!"

                        ### RESTORE
                        hide screen datestats
                        call restore_ani from _call_restore_ani_2
                        show screen datestats

                    "Do not":
                        jump spamdate_eye_menu

            "Return":
                jump spamdate_eye_menu

        jump spamdate_eye


######################################################
##### ITEM
label spamdate_item:
    $ date_item = True
    $ quick_menu = False
    hide screen spamdate_select
    hide screen spam_f1forhelp
    call screen inv_view
    if currentdate == "shop":
        jump spamdate_shop_menu
    elif currentdate == "eye":
        jump spamdate_eye_menu

label spamdate_item_react:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True

    ## PIPIS
    if which_item == itm_pipis:
        $ inventory.remove(itm_pipis)
        "You offered the weird item you found on the ground earlier."
        show spamton standing up frown
        spamton "WHY DO YOU HAVE ONE OF \"THE BOYS\" ????"
        show spamton crazy laugh flipped at jump
        spamton "FINE IF YOU'RE NOT GOING TO [[[[take care of it]] THEN I WILL!!"
        show spamton standing up smile at jump
        play sfx pipisS
        "Spamton snatched it out of your hands."
        "It...{w=0.5} disappeared...!?"
        show spamton standing up stare at xwiggle
        spamton "DON'T KEEP THEM IF YOU'RE [[I just wasn't ready for the responsibility.] !!!"
        if date_fp > 0:
            $ date_fp -= 3
            play sfx ding
            show spamton standing up smile at jump
            if not seenstats_fp:
                $ seenstats_fp = True
                "Spamton is conflicted about something.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color}."
            else:
                "Spamton is conflicted about something.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."
    
    ## SHADOW CRYSTAL
    elif which_item == itm_shadow:
        if not s_shadow:
            $ s_shadow = True
            "You asked if Spamton knew anything about the invisible item in your pocket."
            show spamton standing up stare
            "While you made an attempt to show it in the palm of your hand,{w=0.2} all you could see was water-like movement from a shadow."
            show spamton crazy frantic at xwiggle
            spamton "WHAT???{p=0.5}{noalt}*{/noalt} {noalt}IS{/noalt}{alt}is{/alt} [[[[ redacted information ]] JUST [[Please take a free sample.] NOW ????"
            show spamton standing up stare at jump
            $ itm_shadow.name = "Shadow Crystal"
            $ itm_shadow.desc = "{noalt}*{/noalt} It feels like there's something in your pocket.{p}{noalt}*{/noalt} When you look closely, it appears to be nothing more than a shadow."
            spamton "OF COURSE I KNOW WHAT A Shadow Crystal {noalt}IS{/noalt}{alt}is{/alt} YOU [[[[beloved customer]]!!"
            pause 1.0
            "... You asked what a Shadow Crystal was,{w=0.2} since he didn't elaborate."
            show spamton panic up screame at jump
            spamton "[[[[ He ]] GAVE YOU ONE WITH {noalt}[[zER0{/noalt}{alt}zero{/alt} down-payment] BUT YOU DON'T KNOW WHAT {noalt}IT IS{/noalt}{alt}it is{/alt}???"
            show spamton standing up stare
            spamton "[persistent.mc!u]."
            if persistent.glitches:
                show spamton slouch down static at droop
            else:
                show spamton slouch down static glitch at droop
            spamton "THAT CRYSTAL HOLDS{p=0.5}{noalt}*{/noalt} [[The Truth]."
            "...{w=0.2} You tried looking at it again,{w=0.2} but you still couldn't see anything in it.{p=0.5}{noalt}*{/noalt} You could barely see \"it\" at all."
            "Defeated,{w=0.2} you put it back in your pocket."
        else:
            "You figure Spamton won't have anything else to say about the Shadow Crystal."
            if currentdate == "shop":
                jump spamdate_shop_menu
            elif currentdate == "eye":
                jump spamdate_eye_menu

    ## MEMORYSHARD (spamton, 1) (shop date only)
    elif which_item == itm_greenshard1 and currentdate == "shop":
        if not s_memshard:
            $ s_memshard = True
            "You tell Spamton about the vision you saw from the green shard."
            show spamton standing up stare
            "You explained how in it he was screaming at Tenna,{w=0.2} clearly frustrated about a situation you had no context for."
            show spamton standing up frowne
            spamton "...{w=0.5} YOURE [[throwing me against a wall] WITH ME{p=0}{p=0.2}{noalt}*{/noalt} {noalt}ARENnn''T{/noalt}{alt}aren't{/alt} YOu{space=50}??"
            show spamton standing tilt laugh flipped at xwiggle
            spamton "EHAEHAHA!!{p=0.2}{noalt}*{/noalt} [[How could you] KNOW THAT?!"
            "You insisted it was the honest truth."
            show spamton standing up glaree at jump
            spamton ".{w=0.2}.{w=0.2}."
            show spamton slouch down frown
            spamton "SO{nw=0.5}"
            show spamton at droop
            extend " THEY WERE [[50 Percent Off] [[memory sticks]..."
            if persistent.glitches:
                show spamton crazy frantic
            else:
                show spamton crazy frantic at shakingcg
            spamton "{noalt}WHaAt IS{/noalt}{alt}what is{/alt} [[with it and you'll receive] {noalt}THIs S S\n[[ g  uy]>???? >?{/noalt}{alt}this guy??{/alt}"
            spamton "[[[[ He ]] {noalt}ISNn''T TH E SAaaME AT A L>L! !>>1!{/noalt}{alt}isn't the same at all!!{/alt}"
            if persistent.glitches:
                show spamton crazy angry flipped at jump
            else:
                show spamton crazy angry flipped glitch at jump
            spamton "FIRST THIS [[BIG {noalt}SH!T]{/noalt}{alt}shit{/alt} [[Go into the ] AND NOW{p=0.2}{noalt}*{/noalt} AND NOW{p=0.2}{noalt}*{/noalt} AND NOW{p=0.2}{noalt}*{/noalt} AND NOW{nw=0.2}"
            spamton "AND NOW{p=0.2}{noalt}*{/noalt} AND NOW{p=0.2}{noalt}*{/noalt} AND {noalt}NOW{w=0.2}wwwwwwwwwwwwwwwwwwwwwwwwww{nw=0.2}{/noalt}{alt}nowwwww{/alt}"
            if persistent.glitches:
                show spamton slouch down static flipped at droop
            else:
                show spamton slouch down static flipped glitch at droop
            pause 4.0
            show spamton standing up stare at jump
            spamton "[persistent.mc!u].{nw=0.5}"
            $ itm_greenshard1.name = "MemoryShard (4/6)"
            $ itm_redshard1.name = "MemoryShard (1/6)"
            $ itm_redshard2.name = "MemoryShard (5/6)"
            $ itm_redshard3.name = "MemoryShard (6/6)"
            $ itm_blueshard.name = "MemoryShard (7/6)"
            extend " I DON'T WANT YOUR {noalt}MemoryShard S.{/noalt}{alt}MemoryShards{/alt}"
            if persistent.glitches:
                show spamton slouch down panic
            else:
                show spamton slouch down panic at shakingcg
            spamton "KEEP THAT USELESS [[thingy-mabob] FOR YORSELF !!!"
            show spamton standing down frown at yreset
            spamton ".{w=0.2}.{w=0.2}.{w=0.5} UNLESS..."
            if date_fp > 0:
                $ date_fp -= 2
                play sfx ding
                if not seenstats_fp:
                    $ seenstats_fp = True
                    "Spamton is considering something.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Friendship Points{/color}."
                else:
                    "Spamton is considering something.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."
            
        else:
            "You show off the green MemoryShard again."
            if persistent.glitches:
                show spamton slouch down panic
            else:
                show spamton slouch down panic at shakingcg
            spamton "KEEP THAT USELESS [[thingy-mabob] FOR YORSELF !!!"
            show spamton standing down frown at yreset
            spamton ".{w=0.2}.{w=0.2}.{w=0.5} UNLESS..."
        
    ## GREEN MEMORYSHARDS (eye date only)
    elif which_item in [itm_greenshard1, itm_greenshard2, itm_greenshard3] and currentdate == "eye":
        if which_item == itm_greenshard1:
            if ey_memshard1:
                "You already showed this one to Spamton."
                jump spamdate_eye_menu
            else:
                "You again brought out the first MemoryShard that Spamton initially sold to you."
        elif which_item == itm_greenshard2:
            if ey_memshard2:
                "You already showed this one to Spamton."
                jump spamdate_eye_menu
            else:
                "You brought out the MemoryShard that you found in the trash can and showed it off."
        elif which_item == itm_greenshard3:
            if ey_memshard3:
                "You already showed this one to Spamton."
                jump spamdate_eye_menu
            else:
                "You brought out the MemoryShard that you found earlier in the eye formation behind Spamton."

        if ey_memshard1 or ey_memshard2 or ey_memshard3:
            $ ey_memshown += 1
            if ey_memshown == 2:
                show spamton standing up glare at jump
                spamton "[[Another one]?{p=0.2}{noalt}*{/noalt} [persistent.mc!u]."
                show spamton standing tilt laugh at xwiggle
                spamton "AT THIS POINT YOU SHOULD JUST [[deliver] ALL OF THEM [[to] ME INSTEAD!"
                "Nudging it forward,{w=0.2} you encouraged Spamton to touch it,{w=0.2} but held it tightly in your grip."
            else:
                show spamton standing up stare at jump
                spamton "[[Two?!]{p=0.2}{noalt}*{/noalt} FOR [[the price of one] ?!"
                show spamton crazy frantic at xwiggle
                spamton "LET ME GUESS, YOU WANT ME TO [[touch it with my bear hands]."
                "You nod, reaching a hand forward,{w=0.2} but keeping an eye out to make sure Spamton doesn't swipe it."
        else:
            show spamton standing up stare at jump
            spamton "ARE YOU HANDING THAT OVER SO I CAN [[properly dispose of it]?"
            show spamton crazy laugh at xwiggle
            spamton "AND BEFORE WE EVEN [[Date Complete] !!{p=0.5}{noalt}*{/noalt} AREN'T YOU [[just a sweetheart]?"
            "You say you're not handing over anything,{w=0.2} you just wanted him to touch it."

        if which_item == itm_greenshard1:
            $ ey_memshard1 = True
            show spamton standing up frown at jump
            spamton "[[I know what you are] DOING,{w=0.2} [persistent.mc!u].{p=0.5}{noalt}*{/noalt} BUT I'VE ALREADY [[seen things] FROM THAT ONE!"
            show spamton standing down frown at xwiggle
            spamton "HOW ELSE DO YOU THINK {noalt}IT{/noalt}{alt}it{/alt} WAS PART OF MY [[selection of wares]...?"
            show spamton at yreset
            pause 1.0
            show spamton slouch down smile
            spamton "I THOUGHT {noalt}IT{/noalt}{alt}it{/alt} WAS [[Coincidence?] AT FIRST.{p=0.5}{noalt}*{/noalt} THE [[Memory] TIMED WITH [[touching the rock]."
            show spamton slouch down frown
            spamton "BUT NOW I KNOW THIS {noalt}IS{/noalt}{alt}is{/alt} WHAT [[[[ He ]] MEANT."
            show spamton at droop
            spamton "[[[[ His creation ]]..."
            show spamton slouch down panic at wiggle
            spamton "BUT WHO WERE THEY {noalt}[[creat]ED{/noalt}{alt}created{/alt} FOR...?"
        
        else:
            if ey_memshard2 or ey_memshard3:
                show spamton crazy frantic at xwiggle
                spamton "YOU'RE [[asking so much of me]!!{p=0.5}{noalt}*{/noalt} YOU KNOW WHAT HAPPENS WHEN I [[touch that], DON'T YOU?!"
                show spamton crazy angry
                spamton "DO YOU ENJOY ME BEING [[subjected to The Horrors] OR {noalt}IS{/noalt}{alt}is{/alt} THERE [[intention and purpose] BEHIND YOUR ACTIONS?!" 
            else:
                show spamton standing up frowne at jump
                spamton "WHAT??{p=0.5}{noalt}*{/noalt} [[You really want me to ] ??"
                show spamton standing up frown at jump
                spamton "UGH!!{p=0.5}{noalt}*{/noalt} DON'T SAY [[I never did anything for you]."    
            show spamton standing up glaree at jump
            "Spamton reached out,{w=0.2} pressing his fingertips against the surface of the rock."
            play sfx gulp
            if persistent.glitches:
                show spamton standing up frowne at jump
            else:
                show spamton standing up frowne at shock
            pause 1.0
            show spamton slouch down static at droop
            pause 3.0
            if which_item == itm_greenshard2:
                $ ey_memshard2 = True
                show spamton slouch down frown at xwiggle
                spamton "{noalt}EUGH.{p=0.2}{noalt}*{/noalt} EUGH.{p=0.2}{noalt}*{/noalt} EUGH.{/noalt}{alt}eugh. eugh. eugh{/alt}"
                show spamton standing up glaree at jump
                spamton "[persistent.mc!u],{w=0.2} DO YOU KNOW HOW MUCH THAT CONVERSATION [[sucked] ???"
                show spamton slouch down panic
                spamton "NO AMOUNT OF [[Confidence Juice] COULD HAVE MADE {noalt}IT{/noalt}{alt}it{/alt} [[palatable] !!"
                show spamton standing down frown at jump
                spamton "HE ADMITTED EXACTLY WHERE HE [[Can you tell me where I went wrong?] AND THAT I NEVER MEANT A [[singular] THING TO HIM!!"
                show spamton slouch down panic at xwiggle
                spamton "AND I{p=0.2}{noalt}*{/noalt} AND I{p=0.2}{noalt}*{/noalt} AND I"
                if persistent.glitches:
                    show spamton slouch down static at droop
                else:
                    show spamton slouch down static glitch at droop
                pause 2.0
                spamton "...{nw=0.5}"
                show spamton standing down panic at rise
                extend " AND I [[still chose to trust him,{w=0.2} in the end.]"

            elif which_item == itm_greenshard3:
                $ ey_memshard3 = True
                show spamton slouch down frown
                if ey_memshard2:
                    spamton "OH GREAT.{p=0.5}{noalt}*{/noalt} [[This thing] AGAIN."
                else:
                    spamton "OH GREAT.{p=0.5}{noalt}*{/noalt} [[This thing]."
                show spamton standing tilt laugh at jump
                spamton "[[The biggest regret of my life]!"
                show spamton slouch down frown
                spamton "...{w=0.2} YOU KNOW WHAT HE ASKED ME,{w=0.2} RIGHT?"
                show spamton standing tilt laugh at jump
                spamton "EAHEAHEHAHAH!{nw=0.5}"
                if persistent.glitches:
                    show spamton standing up stare
                else:
                    show spamton standing up stare at shakingcg
                extend "{p=0}{noalt}*{/noalt} PROBABLY [[the same thing he asked you]."
                show spamton crazy laugh at xwiggle
                spamton "WE BOTH GOT [[blinded] BY THE [[neon red flags] FLASHING DIRECTLY IN OUR FACES!!"
        
        if date_fp > 0:
            $ date_fp -= 5
            play sfx ding
            show spamton standing down panic at jump
            if not seenstats_fp:
                $ seenstats_fp = True
                "Spamton feels a little closer to you.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
            else:
                "Spamton feels a little closer to you.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    ## FLOWER
    elif which_item == itm_flower:
        if not s_flower:
            $ s_flower = True
            $ inventory.remove(itm_flower)
            "You pulled out the flower you got earlier and offered it to Spamton."
            show spamton standing up glare
            spamton "WOW.{p=0.5}{noalt}*{/noalt} [persistent.mc!u]?"
            show spamton crazy angry flipped at jump
            spamton "HOW [[eazy cheezy] CAN YOU BE???"
            "...{w=0.2} With a sigh,{w=0.2} you went to put it back into your ITEMS,{w=0.5} but...{nw=0.2}"
            show spamton standing up stare at shaking
            spamton "{noalt}H H hEY!!{/noalt}{alt}hey!!{/alt}{p=0.5}{noalt}*{/noalt} I DIDN'T SAY [[you take that back] GIVE {noalt}IT{/noalt}{alt}it{/alt} TO ME IF IT'S A [[gift of love] FOR ME!!"
            if date_lp > 0:
                $ date_lp -= 5
                play sfx ding
                show spamton standing up smirk at jump
                if not seenstats_lp:
                    $ seenstats_lp = True
                    "Spamton snatched the flower out of your hands.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                else:
                    "Spamton snatched the flower out of your hands.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
        else:
            "You went to give Spamton another flower,{w=0.2} but...{nw=0.2}"
            show spamton standing up stare at jump
            spamton "JUST HOW MANY [[itm_flower] DO YOU HAVE??{p=0.2}{noalt}*{/noalt} I DON'T HAVE ANYWEHRE TO PUT THESE!!"
            show spamton crazy angry
            spamton "CAN'T YOU [[do literally anything else] WITH {noalt}THA T{/noalt}{alt}that{/alt} ??"
            "... he's apparently disinterested."

    ## FIGLOVE
    elif which_item == itm_figlove:
        $ inventory.remove(itm_figlove)
        if vex_natennuh:
            "You showed off the figure of Tenna that you got earlier from \"Mr. Natennuh.\""
        else:
            "You showed off the figure of Tenna that you got earlier from \"Not Tenna.\""
        show spamton standing up stare at jump
        spamton "WHAT ARE YOU OFFERing ME THAT FOR???"
        show spamton crazy angry at shaking
        spamton "I DON'T [[Share your Wishlist with Friends] THAT???"
        show spamton standing up stare at jump
        spamton "WAIT.{p=0.2}{noalt}*{/noalt} WAIT.{p=0.5}{noalt}*{/noalt} I HAVE A [[genus] IDEA."
        show spamton crazy smirk at xwiggle
        spamton "GIVE {noalt}IT{/noalt}{alt}it{/alt} GIVE {noalt}IT{/noalt}{alt}it{/alt} GIVE {noalt}IT{/noalt}{alt}it{/alt}"
        "Reluctantly,{w=0.2} you offer up the figure."
        show spamton standing tilt laugh at wiggle
        spamton "[[We Appreciate Your Kind Offer] [persistent.mc!u]!!"
        play sfx click
        if persistent.glitches:
            show spamton crazy frantic at jump
        else:
            show spamton crazy frantic at shock
        pause 0.2
        play sfx2 click
        pause 1.0
        show spamton standing up smile
        spamton "THERE.{p=0.5}{noalt}*{/noalt} NOW IT'S IN [[Perfect Condition] !!"
        show itemframe i_fighate at truecenter with easeinbottom
        "..."
        play sfx awkwardS
        "He broke the arms off."
        $ inventory.append(itm_fighate)
        play sfx item
        "You...{w=0.2} suppose you'll keep it.{p=0.2}{noalt}*{/noalt} The broken figure was added to your ITEMS."
        hide itemframe with easeoutbottom
        show spamton crazy smirk
        spamton "HEHEHEAH.{p=0.5}{noalt}*{/noalt} I'TS [[New and Improved!] DON'T YOU [[Agree to the],{w=0.2} [persistent.mc!u]?!"
        spamton "A REAL PIECE OF [[trash]!!"
        if date_lp > 0:
            $ date_lp -= 5
            play sfx ding
            show spamton standing up smirk at jump
            if not seenstats_lp:
                $ seenstats_lp = True
                "Spamton has a sick appreciation for your disappointment.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
            else:
                "Spamton has a sick appreciation for your disappointment.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

    ## FIGHATE
    elif which_item == itm_fighate:
        if not s_figure:
            $ s_figure = True
            if persistent.lovetv:
                "You demanded to know why Spamton broke your figure of Tenna."
                show spamton standing up stare at jump
                if s_misstenna or not persistent.deals:
                    spamton "IF YOUR STILL [[I miss Tenna] ABOUT {noalt}IT{/noalt}{alt}it{/alt} THAT [[Sounds like a you problem]."
                else:
                    spamton "HAVE I NOT BEEN [[sparkling clean and crystal clear] ???"
                show spamton at shaking
                spamton "DON'T [[[[Trust it as far as you can throw it!]] HIM!!"
                spamton "HE'S NOTHING BUT A [[Useless] [[[[Boob Tube]] WHO WOULDN'T KNOW [[What is love?] IF {noalt}IT{/noalt}{alt}it{/alt} [[tickled] HIM IN THE [[$4.99] [[funny pages]"
                show spamton crazy angry
                spamton "WHAT PART OF THAT ISN'T [[[[Click Here]] ?!{p=0.5}{noalt}*{/noalt} WHAT BULL[[$!$$] DID HE CONVINCE YOU OF???"
                show spamton slouch down frown at droop
                spamton "DON'T.{w=0.5} TRUST.{w=0.5} ANYTHING [[[[As Seen On TV]]."
                if persistent.glitches:
                    show spamton slouch down smile
                else:
                    show spamton slouch down smile glitch at shakingcg
                spamton "G<< 0Tt{space=80} iiI T????!?1"
            
            else:
                $ inventory.remove(itm_fighate)
                play sfx item
                if vex_natennuh:
                    "You brought out your broken figure of Tenna that you got earlier from \"Mr. Natennuh.\""
                else:
                    "You brought out your broken figure of Tenna that you got earlier from \"Not Tenna.\""
                show spamton standing up stare
                spamton_shh ".{w=0.2}.{w=0.2}."
                pause 1.0
                show spamton crazy laugh flipped at jump
                spamton "EHAAHAEHEH!!{p=0.5}{noalt}*{/noalt} [persistent.mc!u]!{w=0.2} YOU SURE KNOW HOW TO [[Find the Perfect Gift for your Loved Ones]!!!"
                show spamton crazy smirk at xwiggle
                spamton "DID YOU GET THIS [[Custom-Made] JUST FOR [[li'l ol'] ME??"
                if date_lp > 0:
                    $ date_lp -= 5
                    play sfx ding
                    show spamton standing up smirk at jump
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Spamton is strangely appreciative.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Spamton is strangely appreciative.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
        
        else:
            "You don't want to deal with that conversation again."
            if currentdate == "shop":
                jump spamdate_shop_menu
            elif currentdate == "eye":
                jump spamdate_eye_menu

    ## FOOD
    elif which_item in [itm_pie, itm_candy, itm_fries, itm_pretzel, itm_coffee, itm_cocoa]:
        if s_food:
            "You offered some more of the food you had with you,{w=0.2} but...{nw=0.2}"
            show spamton crazy angry at jump
            spamton "YOU EXPECT ME TO [[consume] MORE OF THAT??"
            show spamton standing up stare
            spamton "JUST [[punch me] AND [[kick me] AND [[throw me against a wall] AND [[slather me in milk] LIKE A NORMAL PERSON IF YOU HATE ME SO MUCH!!"
        else:
            $ s_food = True
            if which_item == itm_pie:
                $ inventory.remove(itm_pie)
            elif which_item == itm_candy:
                $ inventory.remove(itm_candy)
            elif which_item == itm_fries:
                $ inventory.remove(itm_fries)
            elif which_item == itm_pretzel:
                $ inventory.remove(itm_pretzel)
            elif which_item == itm_coffee:
                $ inventory.remove(itm_coffee)
            elif which_item == itm_cocoa:
                $ inventory.remove(itm_cocoa)
            play sfx item
            "You offered Spamton the food you had in your inventory."
            show spamton standing up stare at jump
            spamton "[[Free!] SNACKS?!{nw=0.5}"
            show spamton standing tilt laugh at xwiggle
            extend "{p=0}{noalt}*{/noalt} EHEAHEH,{w=0.2} [persistent.mc!u]!{w=0.5} MAYBE YOU ARE [[Expert-level] AT THIS"
            play sfx gulp
            show spamton up smile at jump
            "Spamton took a single bite..."
            pause 1.0
            if persistent.glitches:
                show spamton panic up scream at jump
            else:
                show spamton panic up scream at shock
            spamton "YIIIKES!!{w=0.5} WHAT {noalt}IS{/noalt}{alt}is{/alt} THIS [[poopie] ?!"
            if persistent.glitches:
                show spamton crazy frantic
            else:
                show spamton crazy frantic at shakingcg
            spamton "TASTES LIKE YOU JUST GOT {noalt}IT{/noalt}{alt}it{/alt} [[Fresh from the] [[GODDAMN GARBAGE CAN???]!!!"
            "You figured you might as well just throw out the rest at this point..."
            show spamton standing up stare at xwiggle
            spamton "I GET I'M A [[CharmingMan] BUT YOU DON'T HAVE TO [[[[Kill]] ME TO [[run away as far as you can] ?!"
            if date_lp > 0:
                $ date_lp -= 5
                play sfx ding
                show spamton standing up smirk at jump
                if not seenstats_lp:
                    $ seenstats_lp = True
                    "For some reason,{w=0.2} Spamton isn't unhappy by your attempt to give a gift?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                else:
                    "For some reason,{w=0.2} Spamton isn't unhappy by your attempt to give a gift?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
    
    ## LOVE LETTER
    elif which_item == itm_loveletter:
        if not s_loveletter:
            $ s_loveletter = True
            "You asked Spamton about the \"love letter\" he handed you earlier."
            show spamton standing up stare at jump
            spamton "DID YOU READ {noalt}IT{/noalt}{alt}it{/alt}??{p=0.5}{noalt}*{/noalt} EVERYTHING {noalt}IS{/noalt}{alt}is{/alt} EXPLAINED IN [[the attachment to this email]"
            show spamton standing tilt laugh at xwiggle
            spamton "THE CONTENTS MIGHT BE A LITTLE [[wormy] FOR YOU TO HANDLE!!{p=0.2}{noalt}*{/noalt} EAHAHEHAHEH!!"
        else:
            "You feel like this isn't going to be a productive conversation."
            if currentdate == "shop":
                jump spamdate_shop_menu
            elif currentdate == "eye":
                jump spamdate_eye_menu
            

    ## ALL OTHERS
    else:
        "You don't think Spamton would have anything to say about that."
        if currentdate == "shop":
            jump spamdate_shop_menu
        elif currentdate == "eye":
            jump spamdate_eye_menu

    ## NEXT TURN
    if currentdate == "shop":
        jump spamdate_shop

    elif currentdate == "eye":
        jump spamdate_eye



############################################################################################################
################## PRESS F1 FOR HELP

######################################################
##### SCREEN
screen spam_f1forhelp():
    key "K_F1" action Jump("pressf1forhelp")


######################################################
##### SPAMTON "HELP"
label pressf1forhelp:
    $ skipyes = True
    $ _skipping = True
    hide screen spamdate_select
    hide screen spam_f1forhelp

    if s_help_used == 2:
        $ s_help_done = True
        "You asked for more help, but...{nw=0.1}"
        show spamton standing up stare at jump
        spamton "YOU WANT [[Even More] HELP??"
        if persistent.glitches:
            show spamton crazy frantic
        else:
            show spamton crazy frantic at shakingcg
        spamton "[persistent.mc!u],{w=0.2} YOU'RE TAKING ADVANTAGE OF MY [[Kindness] AT THIS POINT!!"
        show spamton standing up smile at jump
        spamton "[[Learn How To] TAKE CARE OF YOURSELF [[If you wanna survive] IN THIS WORLD!!"
        "Seems Spamton won't help you anymore..."
        jump spamdate_shop

    "You asked for help."
    show spamton standing up stare at jump
    if not s_help:
        $ s_help = True
        spamton "WHAT?{p=0.5}{noalt}*{/noalt} [[Help] WITH WHAT??"
        show spamton crazy laugh at xwiggle
        spamton "YOU NEED A [[HealDeal]?{p=0.2}{noalt}*{/noalt} THAT WON'T BE [[free of charge] YOU KNOW!!"
        show spamton standing up smirk at jump
        spamton "[[Extra costs may apply].{w=0.2} WHAT ARE YOU OFFERING??"
    else:
        if s_help_used == 0:
            spamton "THIS AGAIN?!{p=0.5}{noalt}*{/noalt} YOU DIDN'T EVEN [[Aceept the Terms and ] LAST TIME!!"
            show spamton standing up frowne
            spamton "ARE YOU GOING TO DO SOMETHING OR WHAT??"
            show spamton standing up smirk
        else:
            spamton "THIS AGAIN?!{p=0.2}{noalt}*{/noalt} DO YOU THINK I'M SOME KIND OF [[Can you tell me the directions to the nearest hospital?]"
            show spamton crazy frantic at jump
            spamton "FINE!!{p=0.2}{noalt}*{/noalt} BUT I'M STILL [[charging] !!"
            show spamton standing up smirk

    menu:
        rq "What will you do?\n{noalt}*{/noalt} (You will gain {color=[c_passion]}+1{/color} HP if you choose to do something.)"
        "Do a silly dance":
            "You do the silliest dance you can think of."
            if not s_help_dance:
                $ s_help_dance = True
                show spamton standing up stare
                spamton "...{nw=0.2}"
                show spamton standing tilt laugh at jump
                extend " EAHAHEAHAHE!!"
                show spamton crazy laugh at xwiggle
                spamton "THAT WASN'T WHAT I [[Say what you mean],{w=0.2} BUT YOU LOOK [[rediculous] ENOUGH THAT I'LL LET {noalt}IT{/noalt}{alt}it{/alt} SLIDE!!"
            else:
                show spamton crazy laugh at xwiggle
                spamton "YOU DON'T LOOK ANY LESS [[rediculous] {noalt}[[the II]{/noalt}{alt}the second{/alt} TIME!!"

        "Blow him a kiss":
            "You blow Spamton a little kiss."
            if not s_help_kiss:
                $ s_help_kiss = True
                show spamton standing up stare
                spamton "..."
                show spamton standing tilt laugh at jump
                spamton "WOW!{w=0.2} YOU REALLY ARE A [[desperate little ] AREN'T YOU?!" 
            else:
                show spamton crazy smirk at xwiggle
                spamton "[[Blow me] KISSES ALL YOU WANT, [persistent.mc!u],{w=0.2} YOU'RE NOT CHANGING MY MIND!!"

        "Do nothing":
            "You decide not to do anything."
            show spamton standing up frowne at jump
            spamton "[[nothing] ?!{nw=0.2}"
            show spamton standing tilt laugh at xwiggle
            extend "{p=0}{noalt}*{/noalt} THEN NO [[HELP] FOR YOU!!"
            jump spamdate_shop_menu
    
    if date_lp > 0:
        $ date_lp -= 2
        play sfx ding
        show spamton standing up smirk at jump
        if not seenstats_lp:
            $ seenstats_lp = True
            "Spamton found that laughably adorable.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}Love Points{/color}."
        else:
            "Spamton found that laughably adorable.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}LP{/color}."

    show spamton standing up smile at yreset
    spamton "A {noalt}[[HealDeal]'S{/noalt}{alt}healdeal's{/alt} A [[HealDeal] !!{p=0.2}{noalt}*{/noalt} ONE [[Help] [[straight to your front door]!!"
    play sfx sparklehelp
    play sfx sparklehelp
    show angel still at angelzoom, angelmove with easeintop
    pause 2.0
    if persistent.glitches:
        show angel patpatS
    else:
        show angel patpat
    "A tiny Spamton with angel wings flew down and gave you a pat on the head."
    show angel still
    pause 1.0
    show angel green
    play sfx weird
    $ vess_hp += 1
    $ s_help_used += 1
    "{color=[c_passion]}You're falling into a deeper sleep...{/color}"
    hide angel

    jump spamdate_shop