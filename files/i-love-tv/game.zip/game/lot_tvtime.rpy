############################################################################################################
################## TV TIME 2 VERSION

######################################################
##### NAVIGATION
label lot_tvtime2:    
    play music paradise
    $ memsh_cutscene = True
    show blackpng
    show lot_tvtime2_map at gamepos zorder 0
    show lot_tvtime2_tree at gamepos zorder 1:
        shader "rgb_split"
        u_intensity 5.0
        u_angle 0

    if lot_greenLsee and lot_greenRsee and lot_blueLsee and lot_blueRsee and lot_orangeLsee and lot_orangeRsee:
        $ lot_key = True
        play sfx lot_doorS
        pause 1.0

        $ _skipping = True
        call lot_dia_in from _call_lot_dia_in_7
        narr_lot "THE DOOR HAS OPENED."
        call lot_dia_out from _call_lot_dia_out_7
        $ _skipping = False

    show screen lot_housemap onlayer master zorder 1 

    if not lot_2_entry:
        $ lot_2_entry = True
        play sfx lot_enter
    show hero_wit_gnr idle zorder 2:
        pos(831,324)
        shader "rgb_split"
        u_intensity 4.0
        u_angle 0

    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### DIARY 1 / GREEN HOUSE ON LEFT
label lot_greenleft:
    show hero_wit_gnr walkL:
        pos(771,324)
    show hero_wit_gnr walkL with MoveTransition(1.6): # 4 tiles
        pos(451,324)
    show hero_wit_gnr:
        pos(511,324)
    show hero_wit_gnr walkD with MoveTransition(1.2): # 3 tiles
        pos(511,563)
    show hero_wit_gnr idle:
        pos(511,563)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in
    tenna_lot "IT'S ODD WHAT PEOPLE WILL CHOOSE\nTO THROW AWAY, ISN'T {noalt}IT{/noalt}{alt}it{/alt}...?"
    tenna_lot "A BUNCH OF OLD CARTRIDGES, CONTROLLERS,\nSYSTEMS, EVEN SOMETHING I CAN\nMODIFY THE GAMES WITH!"
    tenna_lot "EVEN A BUNCH OF OTHER TVs."
    tenna_lot "WHO WOULD'VE THOUGHT... LIGHTNERS WOULD\nCONSIDER THESE TYPES OF THINGS TRASH."
    tenna_lot "..."
    tenna_lot "I GUESS I WON'T BE BORED, AT LEAST, RIGHT?"
    tenna_lot "HAHA..."
    call lot_dia_out from _call_lot_dia_out
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout
    
    $ lot_greenLsee = True
    jump lot_tvtime2


######################################################
##### DIARY 2 / BLUE HOUSE ON LEFT
label lot_blueleft:
    show hero_wit_gnr walkL:
        pos(771,324)
    show hero_wit_gnr walkL with MoveTransition(0.8): # 2 tiles
        pos(621,324)
    show hero_wit_gnr:
        pos(670,324)
    show hero_wit_gnr walkD with MoveTransition(0.8): # 2 tiles
        pos(670,483)
    show hero_wit_gnr idle:
        pos(670,483)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin_1
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in_1
    tenna_lot "WHY DID THEY THROW ME OUT...?\nDID I DO SOMETHING WRONG? DID THEY JUST LIE\nTO ME FROM THE BEGINNING?!"
    tenna_lot "SUSIE SEEMED SO EARNEST AND CARING...\nDID {color=[c_vessel]}[[{space=80}]{/color}{alt}redacted{/alt} SAY SOMETHING TO HER TO CHANGE HER MIND?"
    tenna_lot "MAYBE THEY BOTH RECONSIDERED {noalt}IT{/noalt}{alt}it{/alt} AFTER\nSLEEPING. IT'S NOT LIKE I WAS ALL THAT\nNICE TO THEM THAT NIGHT, HAHA."
    tenna_lot "I JUST..."
    tenna_lot "WHY COULDN'T THEY UNDERSTAND?!\nALL THE PAIN AND SUFFERING AND LONELINESS\nI'VE DEALT WITH?!"
    tenna_lot "I HAD TO DO SOMETHING. ANYTHING!\n{noalt}IT{/noalt}{alt}it{/alt} WASN'T THE BEST OF CIRCUMSTANCES..."
    tenna_lot "... AH."
    tenna_lot "I DID {noalt}IT{/noalt}{alt}it{/alt} AGAIN, DIDN'T I?"
    call lot_dia_out from _call_lot_dia_out_1
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout_1
    
    $ lot_blueLsee = True
    jump lot_tvtime2


######################################################
##### DIARY 3 / ORANGE HOUSE ON LEFT
label lot_orangeleft:
    show hero_wit_gnr walkD with MoveTransition(1.2): # 3 tiles
        pos(831,563)
    show hero_wit_gnr idle:
        pos(831,563)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin_2
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in_2
    tenna_lot "WHY DID I START WRITING STUFF IN HERE\nWHEN I COULD HAVE JUST USED A DIARY\nOR SOME OTHER KIND OF PAPER??"
    tenna_lot "THE THOUGHT OF THROWING EVERYTHING\nINTO A GAME SPACE FELT SO NATURAL AT FIRST..."
    tenna_lot "I DID THIS ALL THE TIME BACK IN TV WORLD!"
    tenna_lot "I SUPPOSE IT'S A BIT DIFFERENT WHEN\nI'M WRITING {noalt}IT{/noalt}{alt}it{/alt} ALL DOWN INSTEAD OF\nSHOUTING INTO A VOID, HAHA."
    tenna_lot "BUT {noalt}IT{/noalt}{alt}it{/alt} DOESN'T FEEL ALL THAT GREAT TO\nSHOUT {noalt}IT{/noalt}{alt}it{/alt} INTO THE VOID I'M CURRENTLY IN..."
    tenna_lot "HAHA... HA."
    call lot_dia_out from _call_lot_dia_out_2
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout_2
    
    $ lot_orangeLsee = True
    jump lot_tvtime2


######################################################
##### DIARY 4 / GREEN HOUSE ON RIGHT
label lot_greenright:
    show hero_wit_gnr walk with MoveTransition(0.8): # 2 tiles
        pos(990,324)
    show hero_wit_gnr walkD with MoveTransition(0.8): # 2 tiles
        pos(990,483)
    show hero_wit_gnr idle:
        pos(990,483)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin_3
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in_3
    tenna_lot "HOW LONG HAS {noalt}IT{/noalt}{alt}it{/alt} BEEN BY NOW?\nIT FEELS LIKE FOREVER WITH NOTHING ELSE\nTO DO."
    tenna_lot "THERE'S NO FUNCTIONAL CLOCKS, AND I CAN'T\nTELL WHAT TIME {noalt}IT{/noalt}{alt}it{/alt} {noalt}IS{/noalt}{alt}is{/alt} IN THE LIGHT WORLD,\nEITHER..."
    tenna_lot "MAYBE I SHOULDN'T HAVE WASTED THE ENERGY\nREPAIRING MYSELF, HAHA."
    tenna_lot "BUT I CAN'T SHAKE THIS NAGGING FEELING...\nSURELY, SOMEONE WILL HELP ME EVENTUALLY."
    tenna_lot "HAHA, NOT THAT ANYONE ELSE EVER HAS\nBEFORE! NOT MIKE, NOT... HIM..."
    tenna_lot "SHOULDN'T {noalt}IT{/noalt}{alt}it{/alt} BE OBVIOUS NO ONE CARES ABOUT ME?!"
    call lot_dia_out from _call_lot_dia_out_3
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout_3
    
    $ lot_greenRsee = True
    jump lot_tvtime2


######################################################
##### DIARY 5 / BLUE HOUSE ON RIGHT
label lot_blueright:
    show hero_wit_gnr walk with MoveTransition(1.6): # 4 tiles
        pos(1151,324)
    show hero_wit_gnr walkD with MoveTransition(1.6): # 4 tiles
        pos(1151,643)
    show hero_wit_gnr idle:
        pos(1151,643)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin_4
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in_4
    tenna_lot "WHERE {noalt}IS{/noalt}{alt}is{/alt} THIS LINGERING HOPE EVEN COMING FROM?"
    tenna_lot "WOULDN'T {noalt}IT{/noalt}{alt}it{/alt} BE EASIER IF I JUST\nACCEPTED THE TRUTH? MY OBVIOUS FATE...?"
    tenna_lot "BUT EVERY TIME I THINK ABOUT DOING THAT...\nIT'S COMPLETELY TERRIFYING, HAHA..."
    tenna_lot "THIS ISN'T REALLY THE END FOR ME,\n{noalt}IS IT{/noalt}{alt}is it{/alt}...?"
    tenna_lot "I KNOW I WASN'T AS GOOD OF A PERSON AS\nI COULD HAVE BEEN, BUT IT'S NOT GOING TO\nEND LIKE THIS..."
    tenna_lot "... RIGHT?"
    call lot_dia_out from _call_lot_dia_out_4
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout_4
    
    $ lot_blueRsee = True
    jump lot_tvtime2


######################################################
##### DIARY 6 / ORANGE HOUSE ON RIGHT
label lot_orangeright:
    show hero_wit_gnr walk with MoveTransition(2.4): # 6 tiles
        pos(1310,324)
    show hero_wit_gnr walkD with MoveTransition(0.8): # 2 tiles
        pos(1310,483)
    show hero_wit_gnr idle:
        pos(1310,483)

    ## TRANSITION
    call lot_tvtime2_transin from _call_lot_tvtime2_transin_5
    
    ## DIALOGUE
    $ _skipping = True
    call lot_dia_in from _call_lot_dia_in_5
    tenna_lot "IF ONLY I COULD HAVE SAID I WAS SORRY, HAHA."
    tenna_lot "BUT, {noalt}IT{/noalt}{alt}it{/alt} COULDN'T HAVE BEEN ALL MY FAULT!"
    tenna_lot "HE COULD HAVE TOLD ME SOMETHING WAS\nWRONG, HE COULD HAVE TRIED TO CALL ME!!"
    tenna_lot "THE FAMILY DIDN'T TRUST ME AT ALL!\nTHEY JUST TREATED ME LIKE JUNK AND THREW ME OUT!!"
    tenna_lot "MIKE... EVEN MIKE...\nWHY DID MIKE LEAVE ME?"
    tenna_lot "IF HE HAD A PROBLEM WITH SOMETHING\nHE SHOULD HAVE JUST TOLD ME!!"
    tenna_lot "..."
    tenna_lot "OR... WAS THERE SOMETHING ELSE, AGAIN?"
    tenna_lot "BUT, NO, I...\n{noalt}IT{/noalt}{alt}it{/alt}..."
    tenna_lot "{noalt}IT{/noalt}{alt}it{/alt} WASN'T ALL MY FAULT.\nNO. {noalt}IT{/noalt}{alt}it{/alt} COULDN'T BE.\nTHERE HAS TO BE SOMETHING ELSE"
    tenna_lot "..."
    tenna_lot "THEN WHY DOES {noalt}IT{/noalt}{alt}it{/alt}"
    call lot_dia_out from _call_lot_dia_out_5
    $ _skipping = False
    
    ## TRANSITION BACK
    call lot_tvtime2_transout from _call_lot_tvtime2_transout_5
    
    $ lot_orangeRsee = True
    jump lot_tvtime2


######################################################
##### DOOR EXIT
label lot_lockdoor:
    show hero_wit_gnr walk with MoveTransition(2.4): # 6 tiles
        pos(1311,324)
    show hero_wit_gnr walkU with MoveTransition(0.8): # 2 tiles
        pos(1311,163)
    show hero_wit_gnr idle2:
        pos(1311,163)

    $ _skipping = True
    show black zorder 10
    hide lot_tvtime2_map
    hide lot_housemap
    hide lot_tvtime2_tree
    stop music
    play sfx lot_escape
    pause 4.0
    "The game froze."
    "No matter how many times or how hard you mash buttons,{w=0.2} nothing happens."
    "You figure there's nothing else left to do here."
    hide hero_wit_gnr
    hide black
    hide crtoverlay
    show white
    play sfx tvturnoff1
    hide white
    if not persistent.glitches:
        show tv_shutdown
    pause 0.5
    play sfx2 tvturnoff2
    pause 2.0
    hide tv_shutdown
    pause 1.0
    return



############################################################################################################
################## TRANSITIONS
label lot_tvtime2_transin:
    show black zorder 10
    hide lot_tvtime2_map
    hide lot_housemap
    hide lot_tvtime2_tree
    stop music
    play sfx lot_escape
    pause 2.0
    show lot_tvtime2_tenmap zorder 11 at gamepos
    show lot_tenna hurt zorder 12:
        pos(1070,243)
        shader "rgb_split"
        u_intensity 4.0
        u_angle 0
    pause 1.0
    show hero_wit_gnr idle zorder 12:
        pos(912,881)
        shader "rgb_split"
        u_intensity 4.0
        u_angle 0
    show hero_wit_gnr walkU with MoveTransition(1.6): # 4 tiles
        pos(912,562)
    show hero_wit_gnr idle2:
        pos(912,562)
    return

label lot_tvtime2_transout:
    pause 1.0
    show hero_wit_gnr walkD with MoveTransition(1.6): # 4 tiles
        pos(912,881)
    hide lot_tenna
    hide hero_wit_gnr
    hide lot_tvtime2_tenmap
    play sfx lot_escape
    pause 2.0
    hide black
    return


######################################################
##### STUPID DIALOGUE WORKAROUND
label lot_dia_in:
    play sfx lot_lift
    show lot_dialogue at dialoguepos_hide zorder 96
    show lot_dialogue at dialoguepos with MoveTransition(0.1)
    return

label lot_dia_out:
    stop sound
    hide lot_dialogue
    return