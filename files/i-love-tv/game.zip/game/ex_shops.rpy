############################################################################################################
################## NOT MR TENNA'S
screen shop_notmrtenna:
    modal True

    vbox:
        xpos 1000
        ypos 250
        hbox:
            ## FLOWER
            if itm_flower in inventory:
                pass
            else:
                imagebutton:
                    idle "flower"
                    hover "flowerH"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", itm_flower.name), SetVariable("which_desc", itm_flower.desc)]
                    unhovered SetVariable("imghover", False)
                    action Jump("shop_nmt_buy")

                null width 40
                
            ## DVD
            if itm_dvd in inventory:
                pass
            else:
                imagebutton:
                    idle "dvd"
                    hover "dvdH"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", itm_dvd.name), SetVariable("which_desc", itm_dvd.desc)]
                    unhovered SetVariable("imghover", False)
                    action Jump("shop_nmt_buy")
        
        hbox:
            ## TENNA FIGURE
            if itm_fighate in inventory or itm_figlove in inventory:
                pass
            else:
                if persistent.lovetv:
                    imagebutton:
                        idle "figlove"
                        hover "figloveH"
                        hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", itm_figlove.name), SetVariable("which_desc", itm_figlove.desc)]
                        unhovered SetVariable("imghover", False)
                        action Jump("shop_nmt_buy")
                else:
                    imagebutton:
                        idle "fighate"
                        hover "fighateH"
                        hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", itm_fighate.name), SetVariable("which_desc", itm_fighate.desc)]
                        unhovered SetVariable("imghover", False)
                        action Jump("shop_nmt_buy")

                null width 40

            ## MEMORYSHARD 1
            if itm_redshard1 in inventory:
                pass
            else:
                imagebutton:
                    idle "redshard1"
                    hover "redshard1H"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", itm_redshard1.name), SetVariable("which_desc", itm_redshard1.desc)]
                    unhovered SetVariable("imghover", False)
                    action Jump("shop_nmt_buy")

    if imghover == True:
        text "[which_item]":
            outlines [ (3, "#000000", 0, 0 ) ]
            textalign 0.5
            xalign 0.5
            ypos 820

        text "[which_desc]":
            outlines [ (3, "#000000", 0, 0 ) ]
            textalign 0.5
            xalign 0.5
            ypos 900

    textbutton _("[[RETURN]"):
        style "return_button"
        action [Function(renpy.hide_screen, "shop_notmrtenna"), Jump("shop_nmt")]


######################################################
##### NOT MR TENNA'S DEFAULT TALK VARIABLES
default vex_deftenna = False # convo about it being tenna
default vex_pipisask = False # asking about pipis
default vex_natennuh = False # mr. natennuh
default vex_behind = False # behind the board convo
default vex_behind2 = False # behind the board convo2
default vex_rsh1ask = False # ask about the red shard flashback

### seen dialogue
default vex_sellsee = False # selling items
default vex_flowsee = False # buying flower
default vex_dvdsee = False # buying dvd
default vex_figsee = False # buying figure
default vex_rsh1see = False # buying memoryshard


######################################################
##### NOT MR TENNA'S SHOP INTERACTS
label shop_nmt:
    $ skipyes = True
    $ _skipping = True

    ## FOR ITEMS (DEBUG)
    if debugtesting == True:
        if persistent.favecolor:
            $ flow_ran = persistent.favecolor
        if persistent.programs:
            $ dvd_ran = persistent.programs
        if persistent.favefood != "anything" or persistent.favefood != None:
            $ food_ran = persistent.favefood

    ## IMAGE REFRESH
    show tenshop -e_frown -e_awkward -e_blush

    ## MENU TEXT
    if vex_natennuh == True:
        $ menu_text = "Apparently, this is Mr. Natennuh."
    else:
        $ menu_text = "This is certainly NOT Mr. \"Ant\" Tenna."
    
    menu shop_nmt_menu:
        date "[menu_text]"
        "Buy":
            show screen shop_notmrtenna
            $ skipyes = False
            $ _skipping = False
            $ renpy.pause(hard=True)
            $ renpy.choice_for_skipping()

        "Sell":
            if vex_sellsee == False:
                $ vex_sellsee = True
                show tenshop e_awkward
                tenna "Uhh..."
                tenna "I didn't know you had anything TO sell,{w=0.2} but sure!{p=0.2}{noalt}*{/noalt} Why not!"
                show tenshop -e_awkward
                tenna "What'cha got for me?"
            menu:
                date "Tenna asks, \"What'cha got for me?\""
                "Weird item" if itm_pipis in inventory:
                    if not vex_pipisask:
                        $ vex_pipisask = True
                        show tenshop e_frown
                        tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}--?!"
                        tenna "How'd THAT get here??"
                        show tenshop e_awkward
                        tenna "...{w=0.5} W-{w=0.1} wait,{w=0.2} I can't just BUY that from you!"
                    else:
                        show tenshop e_frown
                        tenna "There's no way that..."
                        tenna "..."
                        pause 1.0
                        tenna "No.{p=0.5}{noalt}*{/noalt} He couldn't possibly..."
                        show tenshop e_awkward
                        tenna "Huh?{p=0.5}{noalt}*{/noalt} I already told you!{w=0.2} The answer's no!!"
                        tenna "You DEFINITELY can't just sell THAT to me!"
                        show tenshop e_frown
                        tenna "That's..."
                        pause 1.0
                        show tenshop e_awkward
                        tenna "Just get rid of it!{p=0.2}{noalt}*{/noalt} It's not worth any money!!"
                        show tenshop e_frown
                        tenna "..."

                "[itm_flower.name]" if itm_flower in inventory:
                    show tenshop e_frown
                    tenna "Oh.{p=0.5}{noalt}*{/noalt} You{w=0.5} want to sell the flower."
                    pause 1.0
                    show tenshop -e_frown
                    tenna "Haha!{w=0.2} That's cute, [persistent.mc]!{p=0.5}{noalt}*{/noalt} If you're trying to gift it back to me,{w=0.2} you should save that for later!"

                "[itm_dvd.name]" if itm_dvd in inventory:
                    show tenshop e_frown
                    tenna "The...{w=0.2} DVD?"
                    tenna "You want to SELL that...?"
                    tenna "..."
                    pause 1.0
                    show tenshop -e_frown
                    tenna "Oh,{w=0.2} I get it!"
                    tenna "This is your roundabout way of asking me to play it for you,{w=0.2} isn't it?"
                    tenna "You're funny, [persistent.mc]!{p=0.2}{noalt}*{/noalt} You really know how to keep me on my toes!"

                "The Tenna figure" if itm_fighate in inventory or itm_figlove in inventory:
                    show tenshop e_frown
                    tenna "The figure?!"
                    show tenshop e_awkward
                    tenna "N- {w=0.1}no way,{w=0.2} haha!{p=0.5}{noalt}*{/noalt} That little guy's priceless!"

                "The red shard" if itm_redshard1 in inventory:
                    show tenshop e_awkward
                    tenna "Huh?{p=0.2}{noalt}*{/noalt} Why would you wanna sell that rock?"
                    show tenshop e_frown
                    tenna "Do you not like it...?"
                    tenna "You kept staring at it after you took it,{w=0.2} though!"

                "I don't have anything." if not itm_dvd in inventory and not itm_flower in inventory and not itm_fighate in inventory and not itm_figlove in inventory and not itm_redshard1 in inventory and not itm_pipis in inventory:
                    show tenshop e_frown
                    tenna "Oh."
                    show tenshop -e_frown
                    tenna "Haha!{p=0.2}{noalt}*{/noalt} Just pullin' my leg,{w=0.2} eh?"
                    show tenshop e_awkward
                    tenna "That's fine, too!{p=0.2}{noalt}*{/noalt} Japes are always fun!"

                "Return":
                    jump shop_nmt
            
            jump shop_nmt
        
        "Talk":
            menu shop_nmt_talk:
                rq "Talk"                   
                "Your shop":
                    if vex_natennuh:
                        "You asked \"Mr. Natennuh\" where the shop came from."
                    else:
                        "You asked \"Not Tenna\" where the shop came from."
                    tenna "Oh,{w=0.2} this?"
                    tenna "I already had a bunch of scrap board--{nw=0.1}"
                    show tenshop e_frown
                    tenna "I mean."
                    show tenshop e_awkward
                    tenna "I've...{w=0.2} always had this shop!"
                    tenna "I just...{w=0.2} recently moved locations!{p=0.5}{noalt}*{/noalt} Yeah!"
                
                "About yourself":
                    if vex_natennuh:
                        "You asked \"Mr. Natennuh\" to tell you more about himself."
                    else:
                        "You asked \"Not Tenna\" to tell you more about himself."
                    show tenshop e_awkward
                    tenna "What,{w=0.2} me?"
                    tenna "Pfft.{p=0.2}{noalt}*{/noalt} Oh,{w=0.2} you know,{w=0.2} it's just,"
                    show tenshop -e_awkward
                    tenna "Business as usual,{w=0.2} haha!{p=0.5}{noalt}*{/noalt} There's a lot of work that goes into being a TV host, after all!"
                    show tenshop e_awkward
                    tenna "I mean--{w=0.2} a shop owner!"
                    tenna "Haha,{w=0.2} oops!{p=0.2}{noalt}*{/noalt} Slip of the tongue there!"
                    show tenshop e_frown
                    tenna "..."
            
                "You're definitely Tenna." if not vex_deftenna:
                    $ vex_deftenna = True
                    "You tell \"Not Tenna\" that he's definitely Tenna."
                    tenna "Tenna?{p=0.5}{noalt}*{/noalt} No, no.{w=0.2} That's not my name."
                    show tenshop e_awkward
                    tenna "Haha,{w=0.2} what a silly thing to suggest to a passerby you've totally never met before!"
                    show tenshop -e_awkward
                    tenna "I don't even have the same color suit as that guy!"
                    show tenshop e_awkward
                    tenna "...{w=0.2} That guy who.{w=0.5} I definitely don't know."
            
                "*NEW* Who are you, then?" if vex_deftenna and not vex_natennuh:
                    $ vex_natennuh = True
                    "You ask what this mysterious person's name is if it's not Tenna."
                    show tenshop e_awkward
                    tenna "Oh,{w=0.2} well,{w=0.2} that's..."
                    show tenshop e_frown
                    pause 1.0
                    show tenshop -e_frown
                    tenna "I'm...{w=0.5} Mr.{w=0.5} Not Tenna.{w=0.2}..?{nw=0.2}"
                    tenna "I mean."
                    tenna "Mr.{w=0.2} Natennuh!{p=0.5}{noalt}*{/noalt} Yeah,{w=0.2} that's it."

                "Who are you, then?" if vex_natennuh:
                    "You ask what this mysterious person's name is if it's not Tenna."
                    show tenshop e_awkward
                    tenna "Mr. Natennuh!{p=0.5}{noalt}*{/noalt} Yep,{w=0.2} that's it."
                    
                "Behind the shop" if not vex_behind:
                    $ vex_behind = True
                    if vex_natennuh == True:
                        "You asked \"Mr. Natennuh\" what was behind the shop."
                    else:
                        "You asked \"Not Tenna\" what was behind the shop."
                    if ten_moveboard:
                        tenna "Oh."
                        show tenshop e_awkward
                        tenna "You, uh.{p=0.5}{noalt}*{/noalt} Saw that,{w=0.2} huh."
                    elif q_dump > 0:
                        tenna "This again?"
                    else:
                        tenna "Oh!"
                        show tenshop e_awkward
                        tenna "Well, uh..."
                    tenna "Don't worry about it!{p=0.2}{noalt}*{/noalt} I promise it can't hurt you or anything!"
                    show tenshop e_frown
                    tenna "It's just,{w=0.5} y'know..."
                    show tenshop e_awkward
                    tenna "Your run-of-the-mill unsettling Dark World!{p=0.2}{noalt}*{/noalt} Yeah,{w=0.2} that's it!"

                "*NEW* Behind the shop" if vex_behind and not vex_behind2:
                    $ vex_behind2 = True
                    "You insist that you want to know what's behind the shop."
                    show tenshop e_frown
                    tenna "Hey, now..."
                    pause 1.0
                    if ten_moveboard:
                        tenna "Just...{w=0.2} don't think about the stuff back there,{w=0.2} okay?"
                        tenna "I know.{p=0.5}{noalt}*{/noalt} It's not pretty."
                    else:
                        tenna "Don't...{w=0.5} look over there."
                        tenna "Make sure not to move any of the boards,{w=0.2} okay?"
                        tenna "It's{w=0.5} not pretty back there."
                    show tenshop -e_frown
                    tenna "But don't worry!{p=0.2}{noalt}*{/noalt} Good ol' Mr. Tenna will always be here to keep you safe and happy,{w=0.2} [persistent.mc]!"
                    show tenshop e_awkward
                    tenna "That's enough for you, isn't it?"
                    show tenshop e_blush
                    tenna "You haven't left me yet,{w=0.2} so that's something,{w=0.2} haha...!"
                    show tenshop e_frown
                    tenna "..."

                "Behind the shop" if vex_behind2:
                    "You insist that you want to know what's behind the shop."
                    show tenshop e_frown
                    tenna "Hey, now..."
                    pause 1.0
                    if ten_moveboard:
                        tenna "Just...{w=0.2} don't think about the stuff back there,{w=0.2} okay?"
                        tenna "I know.{p=0.5}{noalt}*{/noalt} It's not pretty."
                    else:
                        tenna "Don't...{w=0.5} look over there."
                        tenna "Make sure not to move any of the boards,{w=0.2} okay?"
                        tenna "It's{w=0.5} not pretty back there."
                    show tenshop -e_frown
                    tenna "But don't worry!{p=0.2}{noalt}*{/noalt} Good ol' Mr. Tenna will always be here to keep you safe and happy,{w=0.2} [persistent.mc]!"
                    show tenshop e_awkward
                    tenna "That's enough for you, isn't it?"
                    show tenshop e_blush
                    tenna "You haven't left me yet,{w=0.2} so that's something,{w=0.2} haha...!"
                    show tenshop e_frown
                    tenna "..."

                "Return":
                    jump shop_nmt

            show tenshop -e_frown -e_awkward -e_blush
            jump shop_nmt_talk

        "Done":
            ## has all items
            if itm_dvd in inventory and itm_flower in inventory and (itm_fighate in inventory or itm_figlove in inventory) and itm_redshard1 in inventory:
                tenna "All done?{w=0.2} Great!{p=0.5}{noalt}*{/noalt} TV-tastic, even!"
                tenna "I think it's time for me to pack up shop myself!"
                show tenshop e_frown
                tenna "Just gimmie a second here..."
                jump parkstart

            ## has some items but not all
            elif itm_dvd in inventory or itm_flower in inventory or itm_fighate in inventory or itm_figlove in inventory or itm_redshard1 in inventory:
                show tenshop e_awkward
                tenna "Hold on a sec!{p=0.2}{noalt}*{/noalt} Don't you wanna look around some more?"

            ## has no items
            else:
                show tenshop e_awkward
                tenna "Wait,{w=0.2} but--{w=0.2} you didn't{w=0.5} get anything...??"
            jump shop_nmt


######################################################
##### NOT MR TENNA'S BUYING MENU
label shop_nmt_buy:
    $ skipyes = True
    $ _skipping = True
    $ imghover = False
    hide screen shop_notmrtenna
            
    ## FLOWER
    if which_item == itm_flower.name:
        if not vex_flowsee:
            $ vex_flowsee = True
            tenna "That flower's quite pretty,{w=0.2} don'tcha think?"
            if persistent.favecolor:
                tenna "Its [persistent.favecolor] hue suits you well,{w=0.2} actually!"
                show tenshop e_blush
                tenna "Can't imagine why,{w=0.2} haha!"
            else:
                tenna "Isn't the color perfect?"
                tenna "Maybe?{p=0.2}{noalt}*{/noalt} Hopefully?{p=0.2}{noalt}*{/noalt} Possibly?"
                show tenshop e_blush
                tenna "{nw=0.2}"
                if persistent.glitches:
                    tenna_funG "Please?"
                else:
                    tenna_fun "Please?" # SELF VOICING FIX

        show tenshop -e_blush
        menu:
            rq "Will you \"buy\" the [itm_flower.name]?{p=0}{noalt}*{/noalt} It costs D$[itm_flower.money]. You have D$[money]."
            "Yes":
                play sfx item
                $ inventory.append(itm_flower)
                "You \"bought\" the [itm_flower.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
            "No":
                pass

    ## DVD
    elif which_item == itm_dvd.name:
        if not vex_dvdsee:
            $ vex_dvdsee = True
            show tenshop e_frown
            tenna "I personally prefer VHS tapes, myself, BUT!"
            show tenshop -e_frown
            if persistent.programs:
                tenna "When I found a DVD with [persistent.programs] on it,{w=0.2} I just knew I had to grab it for ya!"
            else:
                tenna "I can easily still play this DVD with [dvd_ran] on it whenever you'd like!"
                show tenshop e_awkward
                tenna "...{w=0.2} or,{w=0.2} uh--{p=0.5}{noalt}*{/noalt} Mr. Tenna can do that for ya!"
                show tenshop -e_awkward

        menu:
            rq "Will you \"buy\" the [itm_dvd.name]?{p=0}{noalt}*{/noalt} It costs D$[itm_dvd.money]. You have D$[money]."
            "Yes":
                play sfx item
                $ inventory.append(itm_dvd)
                "You \"bought\" the [itm_dvd.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
            "No":
                pass
    
    ## FIGURE
    elif which_item == itm_fighate.name:
        if not vex_figsee:
            $ vex_figsee = True
            tenna "Oh,{w=0.2} that..."
            show tenshop e_frown
            tenna "..."
            show tenshop e_awkward
            tenna "I-{w=0.1} it's just a figure of m{w=0.5}mmmmm--Mr. Tenna!"
            show tenshop e_frown
            tenna "It's a little scuffed,{w=0.2} but..."
            show tenshop e_awkward
            tenna "It's still alright...!"
            show tenshop -e_awkward

        menu:
            rq "Will you \"buy\" the [itm_fighate.name]?{p=0}{noalt}*{/noalt} It costs D$[itm_fighate.money]. You have D$[money]."
            "Yes":
                play sfx item
                $ inventory.append(itm_fighate)
                "You \"bought\" the [itm_fighate.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
            "No":
                pass

    elif which_item == itm_figlove.name:
        if not vex_figsee:
            $ vex_figsee = True
            tenna "Oh!{p=0.2}{noalt}*{/noalt} That catch your eye?"
            show tenshop e_blush
            tenna "It's a figure of m{w=0.5}mmmmm--Mr. Tenna!"
            tenna "He looks cool as a cucumber,{w=0.2} doesn't he?"
            show tenshop -e_blush

        menu:
            rq "Will you \"buy\" the [itm_figlove.name]?{p=0}{noalt}*{/noalt} It costs D$[itm_figlove.money]. You have D$[money]."
            "Yes":
                play sfx item
                $ inventory.append(itm_figlove)
                "You \"bought\" the [itm_figlove.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
            "No":
                pass

    ## MEMORYSHARD 1
    elif which_item == itm_redshard1.name:
        if not vex_rsh1see:
            $ vex_rsh1see = True
            tenna "That rock's pretty,{w=0.2} don'cha think?"
            show tenshop e_frown
            tenna "I'm not EXACTLY sure where it came from, though..."
            show tenshop -e_frown
            tenna "Well,{w=0.2} feel free to keep it anyway!"
        
        menu:
            rq "Will you \"buy\" the [itm_redshard1.name]?{p=0}{noalt}*{/noalt} It costs D$[itm_redshard1.money]. You have D$[money]."
            "Yes":
                play sfx item
                $ inventory.append(itm_redshard1)
                "You \"bought\" the [itm_redshard1.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                "Although,{w=0.2} the moment you touched it..."
                stop music
                scene black
                "Something overcame your senses."
                jump memoryshard1
            "No":
                pass
    
    show screen shop_notmrtenna
    $ skipyes = False
    $ _skipping = False
    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## SPAMTON'S
screen shop_spamton:
    modal True

    frame:
        xpos 25
        ypos 30
        padding(30,20,30,20)
        text _("[money] kromer")

    vbox:
        xpos 1000
        ypos 250
        hbox:
            ## SHOVEL 
            if itm_shovel in inventory:
                pass
            else:
                imagebutton:
                    idle "shovel"
                    hover "shovelH"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", ss_shovel_name), SetVariable("which_desc", ss_shovel_desc)]
                    unhovered SetVariable("imghover", False)
                    action [SetVariable("which_item", itm_shovel.name), Jump("shop_spam_buy")]

                null width 40
                
            ## GET OUT OF HELL FREE CARD
            if itm_freecard in inventory or vex_starascend:
                pass
            else:
                imagebutton:
                    idle "freecard"
                    hover "freecardH"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", ss_freecard_name), SetVariable("which_desc", ss_freecard_desc)]
                    unhovered SetVariable("imghover", False)
                    action [SetVariable("which_item", itm_freecard.name), Jump("shop_spam_buy")]
        
        hbox:
            ## RING
            if itm_ring in inventory:
                pass
            else:
                imagebutton:
                    idle "ring"
                    hover "ringH"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", ss_ring_name), SetVariable("which_desc", ss_ring_desc)]
                    unhovered SetVariable("imghover", False)
                    action [SetVariable("which_item", itm_ring.name), Jump("shop_spam_buy")]

                null width 40

            ## MEMORYSHARD 4
            if itm_greenshard1 in inventory:
                pass
            else:
                imagebutton:
                    idle "greenshard1"
                    hover "greenshard1H"
                    hovered [Play("sfx", menuhover), SetVariable("imghover", True), SetVariable("which_item", ss_greenshard_name), SetVariable("which_desc", ss_greenshard_desc)]
                    unhovered SetVariable("imghover", False)
                    action [SetVariable("which_item", itm_greenshard1.name), Jump("shop_spam_buy")]

    if imghover == True:
        text "[which_item]":
            outlines [ (3, "#000000", 0, 0 ) ]
            textalign 0.5
            xalign 0.5
            ypos 820

        text "[which_desc]":
            outlines [ (3, "#000000", 0, 0 ) ]
            textalign 0.5
            xalign 0.5
            ypos 900

    textbutton _("[[RETURN]"):
        text_outlines [ (2, "#000000", 0, 0 ) ]
        style "return_button"
        action [Function(renpy.hide_screen, "shop_spamton"), Jump("shop_spam")]


######################################################
##### SPAMTON'S DEFAULT TALK VARIABLES
default vex_bought = False # if player has been able to buy anything
default vex_buytext = 0 # text player has seen when buying something
default vex_buyoption = False # if chosen yes/no buying (to avoid copy/pasting so much)
default vex_buyoption_check = False # if player has enough to pay for item

### talking
default vex_sellask = False # ask if can sell items
default vex_tenask = False # asked about tenna
default vex_spamdate1 = False # asked spamton on first date
default vex_spamdate2 = False # asked spamton on second date
default vex_here = False # asked about being here
default vex_here2 = False # asked about being here2
default vex_memory = False # checked in with memoryshards
default vex_mikeask = False # asked about Mike

### seen dialogue
default vex_shovsee = False # seen shovel
default vex_gsh1see = False # seen green shard
default vex_ringsee = False # seen ring
default vex_cardsee = False # seen ring


######################################################
##### SPAMTON'S SHOP INTERACTS
label shop_spam:
    $ skipyes = True
    $ _skipping = True
    show spamshop_spamton e_neutral at yreset

    if not vex_bought and persistent.deals:
        $ menu_text = "WELL IF {noalt}IT{/noalt}{alt}it{/alt} ISN'T MY BELOVED [Friend Request Accepted]!!{p}{noalt}*{/noalt} DID YOU FIND ANY [Kromer] ?"
    elif not vex_bought and not persistent.deals:
        $ menu_text = "WELL IF {noalt}IT{/noalt}{alt}it{/alt} ISN'T MY BE[hated] [Friend Request Rejected]!!{p}{noalt}*{/noalt} DID YOU FIND ANY [Kromer] ?"
    else:
        $ menu_text = "HEY EVERY{space=200}!{p}{noalt}*{/noalt} IT'S ME,{p}{space=100}{noalt}*{/noalt} {space=50}SPAMTON G.{space=200}SPAMTON!"

    menu shop_spam_menu:
        spamton "[menu_text]"
        "{size=+10}BUY!":
            show screen shop_spamton
            $ skipyes = False
            $ _skipping = False
            $ renpy.pause(hard=True)
            $ renpy.choice_for_skipping()
        "{size=+10}BUY MORE!!":
            show screen shop_spamton
            $ skipyes = False
            $ _skipping = False
            $ renpy.pause(hard=True)
            $ renpy.choice_for_skipping()

        "TALKING":
            menu shop_spam_talk:
                spamton "{noalt}TALKIn G?{/noalt}{alt}talking?{/alt}"
                ### BEFORE FIRST DATE
                "Sell?" if not spam_date1 and not vex_sellask:
                    $ vex_sellask = True
                    "You tried to sell something to Spamton."
                    show spamshop_spamton e_eyes at jump
                    spamton "[persistent.mc!u]!!!"
                    spamton "WHAT KIND OF [[Number One Rated Salesman 1997] WOULD I BE IF I BOUGHT EVERY [[useless junk] YOU SHOWED ME???"
                    spamton "NO!!!!"

                "*NEW* Heart-Shaped Object?" if not spam_date1 and vex_sellask and not vex_spamdate1:
                    "You went to offer your--{nw=0.2}"
                    "...{w=0.5} You decided to see if Spamton was interested in going on a date,{w=0.2} for some reason."
                    show spamshop_spamton e_eyes
                    spamton_shh ".{w=0.2}.{w=0.2}."
                    if persistent.glitches:
                        show spamshop_spamton e_laugh
                    else:
                        show spamshop_spamton e_laughf
                    spamton "EHAHAHEHEH!"
                    spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} [persistent.mc!u]!!!!"
                    show spamshop_spamton e_neutral at jump
                    spamton "DO YOU THINK I'M SOME KIND OF [[Hot Singles in Your Area] ??"
                    spamton "I MAY BE [[Desperate] BUT I WOn'T JUST GO ON A [[Plan Your Next Date Night] FOR FREE!!!"
                    show spamshop_spamton e_eyes
                    spamton "NO [[Date Ideas Under $10]{p=0.5}{noalt}*{/noalt} ThAT'LL COST YOU [[at least] 1000 KROMER."
                    call spamdate_check1 from _call_spamdate_check1
                    if spam_datecheck == True:
                        jump spamdate_shop_preamble

                "Date?" if not spam_date1 and vex_sellask and vex_spamdate1:
                    show spamshop_spamton e_eyes
                    spamton "[persistent.mc!u]!!!{p=0.5}{noalt}*{/noalt} DID YOU GET THE [[Kromer] FOR OUR [[specil date, very important date] ?"
                    call spamdate_check1 from _call_spamdate_check1_1
                    if spam_datecheck == True:
                        jump spamdate_shop_preamble

                "Kromer hint?" if not spam_date1:
                    "You asked Spamton how to find \"kromer.\""
                    if vex_bought:
                        if persistent.glitches:
                            show spamshop_spamton e_eyes
                        else:
                            show spamshop_spamton e_eyes at shakingcg
                        spamton "WHAT ARE YOU ASKING [[li'l old me] FOR?!{p=0.2}{noalt}*{/noalt} YOU ALREADY [[Lost and Found] SOME!"
                        if money == 1000 and itm_greenshard1 in inventory:
                            show spamshop_spamton e_laugh at yreset
                            spamton "JUST GIMMIE [[Your Life Savings] ALREADY!!"
                        elif itm_debit in inventory:
                            show spamshop_spamton e_laugh at yreset
                            spamton "HAVE YOU TRIED [[lending a hand] YOUR [[Bank Account Information] ??"
                        elif itm_freecard in inventory:
                            show spamshop_spamton e_laugh at yreset
                            spamton "HAVE YOU TRIED [[Look to the stars for inspiration!] YOUR [[Monopoly Money] ??"
                        elif itm_shovel in inventory:
                            show spamshop_spamton e_laugh at yreset
                            spamton "HAVE YOU TRIED [[Killing] YOUR [[dirty, dirty] ENEMIES ??"
                    else:
                        show spamshop_spamton e_laugh
                        spamton "[[That sounds like] YOUR PROBLEM!!"
                        if persistent.glitches:
                            pass
                        else:
                            show spamshop_spamton e_laughf
                        spamton "IF I HAD KROMER I WOULD HAVE BEEN EATING FOR [[weeklong sales]S!!"
                        show spamshop_spamton e_eyes at jump
                        spamton "BUT IF YOU ARE STILL [[[[{color=[c_power]}Determination.{/color}]] TO FIND SOME THEN MAYBE GO DIGGING THROUGH THE [[Trash Zone]"
                        show spamshop_spamton e_laugh
                        spamton "[[Our Best Deals] ARE ALWAYS [[recycled gifts] !!!"

                "Why are you here" if not vex_here and not spam_date1:
                    $ vex_here = True
                    "You asked Spamton why he's here."
                    show spamshop_spamton e_eyes
                    spamton "HEY{space=80}!{p=0.2}{noalt}*{/noalt} I'VE GOT A [[limited-time Survey] FOR YOU"
                    if persistent.glitches:
                        show spamshop_spamton e_static
                    else:
                        show spamshop_spamton e_staticg
                    spamton "{w=0.5}HE [[Abandoned you for the] TOO,{w=0.2} RIGHT"
                    if persistent.glitches:
                        show spamshop_spamton e_eyes
                    else:
                        show spamshop_spamton e_eyes at shakingcg
                    spamton "NO, NOT THAT [[cathode ray tube] {noalt}[[$#!&]{/noalt}{alt}beep{/alt} !!!"
                    if persistent.glitches:
                        show spamshop_spamton e_static at yreset
                    else:
                        show spamshop_spamton e_staticg at yreset
                    spamton "[[[[{fast} {cps=25}H{w=0.2}i{w=0.2}m{w=0.2}.{/cps} {cps=0}]]{/cps}"
                    pause 2.0
                    show spamshop_spamton e_eyes
                    spamton "DON'T [[look with your specil eyes] LIKE THAT!!{p=0.2}{noalt}*{/noalt} YOU KNOW WHO I'M TALKING ABOUT!!"
                    if persistent.glitches:
                        show spamshop_spamton e_laugh
                    else:
                        show spamshop_spamton e_laughf
                    spamton "HOW ELSE WOULD YOU BE [[click Here.]{p=0.1}{noalt}*{/noalt} [[Here.]{p=0.1}{noalt}*{/noalt} [[Here.] ?????"
                    if persistent.glitches:
                        show spamshop_spamton e_eyes
                    else:
                        show spamshop_spamton e_eyes at shakingcg
                    spamton "YOU'rE {noalt}N0T{/noalt}{alt}not{/alt} SUPPOSED TO BE [[Here.]{p=0.1}{noalt}*{/noalt} [[Here.]{p=0.1}{noalt}*{/noalt} [[Here.] !!!!!"

                "*NEW* Where even is \"here\"?" if vex_here and not spam_date1 and not vex_here2:
                    $ vex_here2 = True
                    "You asked Spamton where \"here\" even is."
                    show spamshop_spamton e_eyes
                    spamton "DIDN'T I [[Explain the Terms and Conditions] ALREADY???"
                    if persistent.glitches:
                        show spamshop_spamton e_laugh
                    else:
                        show spamshop_spamton e_laughg
                    spamton "THIS {noalt}[[[[h311scApe]] IS{/noalt}{alt}hellscape is{/alt} THE [[Your Local] DUMP.{p=0.2}{noalt}*{/noalt} WHAT MORE DO YOU WANT FROM ME???"
                    show spamshop_spamton e_eyes
                    "You try to explain that you woke up here and have no idea why or how."
                    show spamshop_spamton e_laugh at jump
                    spamton "[[I dunno how to tell you] I HAVE NO IDEA EITHER??{p=0.5}{noalt}*{/noalt} I'M NOT THE [[Your Search Engine of Choice] GUY!!!"

                "Where even is \"here\"?" if vex_here2 and not spam_date1:
                    "You asked Spamton where \"here\" even is."
                    show spamshop_spamton e_eyes
                    spamton "DIDN'T I [[Explain the Terms and Conditions] ALREADY???"
                    if persistent.glitches:
                        show spamshop_spamton e_laugh
                    else:
                        show spamshop_spamton e_laughg
                    spamton "THIS {noalt}[[[[h311scApe]] IS{/noalt}{alt}hellscape is{/alt} THE [[Your Local] DUMP.{p=0.2}{noalt}*{/noalt} WHAT MORE DO YOU WANT FROM ME???"
                    show spamshop_spamton e_eyes
                    "You try to explain that you woke up here and have no idea why or how."
                    show spamshop_spamton e_laugh at jump
                    spamton "[[I dunno how to tell you] I HAVE NO IDEA EITHER??{p=0.5}{noalt}*{/noalt} I'M NOT THE [[Your Search Engine of Choice] GUY!!!"

                "What happened to Tenna?" if not spam_date1:
                    if not vex_tenask:
                        $ vex_tenask = True
                        "You ask Spamton if he knows what happened to Tenna."
                        show spamshop_spamton e_eyes
                        spamton "WHY DO YOU CARE WHERE THAT [[Trash Heap] {noalt}IS{/noalt}{alt}is{/alt}??"
                        if persistent.glitches:
                            show spamshop_spamton e_laugh
                        else:
                            show spamshop_spamton e_laughg
                        spamton "YOU DON'T NEED [[cathode ray tube television] WHEN YOU'VE GOT{p=0.2}{noalt}*{/noalt} {space=500}SPAMTON G.{space=100}{w=0.2} SPAMTON!"
                        if persistent.glitches:
                            pass
                        else:
                            show spamshop_spamton e_laughf
                        play sfx spamlaugh
                        spamton_shh "[[[[Unintelligible Laughter]]{nw=0.5}"
                        spamton "[[[[Unintelligible Laughter]]{fast}{p=0}{noalt}*{/noalt} THAT DAMNED [[Boob Tube] WOULD JUST {noalt}[[&$!$]{/noalt}{alt}beep{/alt} YOU OVER ANYWAY!!"
                        spamton "JUST LIKE{p=0.2}{noalt}*{/noalt} JUST LIKE{p=0.2}{noalt}*{/noalt} JUST LIKE{p=0.2}{noalt}*{/noalt} JUST LIKE"
                        if persistent.glitches:
                            show spamshop_spamton e_static
                        else:
                            show spamshop_spamton e_staticg
                        spamton "..."
                        pause 1.0
                        show spamshop_spamton e_neutral
                        spamton "MOVING ON!!!!!!!"
                    else:
                        if persistent.glitches:
                            show spamshop_spamton e_eyes
                            spamton "I SAID [[ MOVING ON!!!!!!! ]"
                        else:
                            show spamshop_spamton e_eyes at shakingcg
                            spamton "I SAID [[{sc=2}MOVING ON!!!!!!!{/sc}]" # SELF VOICING FIX

                ### AFTER FIRST DATE
                "MemoryShards" if spam_date1:
                    if itm_greenshard1 in inventory and itm_greenshard2 in inventory and itm_greenshard3 in inventory:
                        "You pull out the MemoryShards from your pockets,{w=0.2} laying them out for Spamton to see."
                        if not vex_memory:
                            $ vex_memory = True
                            show spamshop_spamton e_laugh
                            spamton "LOOK AT YOU [[Go-getter]!!{p=0.5}{noalt}*{/noalt} THAT'S ALL THE [[shattered] PIECES."
                            show spamshop_spamton e_eyes
                            spamton "[[Hold it.]{p=0.5}{noalt}*{/noalt} WHAT {noalt}IS{/noalt}{alt}is{/alt} [[that one! that one!] ??"
                            play sfx sparkleglock
                            show itemframe i_redshard1 at truecenter zorder 99 with easeinbottom
                            pause 0.5
                            show spamshop_spamton e_neutral at jump
                            spamton "WHY {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt} [[[[color=#B34E3B]]?{p=0.2}{noalt}*{/noalt} WHERE DID YOU FIND THAT??"
                            hide itemframe with easeoutbottom
                            "Shrugging, you explain that you got it from Tenna."
                            show spamshop_spamton e_eyes
                            spamton "...{w=0.2} FROM.{w=0.5} [[Fuzzface] ?"
                            pause 1.0
                            show spamshop_spamton e_neutral at jump
                            spamton "HEY {noalt}HE Y,,{/noalt}{alt}hey,{/alt}{w=0.2} THIS WASN'T IN [[the contract] {noalt}BUUuUuuUT{/noalt}{alt}but{/alt} CAN I {noalt}CONVNICE{/noalt}{alt}convince{/alt} YOU TO [[do more work for less] ?"
                            show spamshop_spamton e_eyes
                            spamton "GET.{w=0.2} THE REST.{w=0.2} OF THOSE."
                            if itm_redshard1 in inventory and itm_redshard2 in inventory and itm_redshard3 in inventory:
                                "You tell Spamton you already have all three."
                                if persistent.glitches:
                                    pass
                                else:
                                    show spamshop_spamton at shakingcg
                                spamton "THE ENTIRE [[[[Collector's Edition]]???"
                            else:
                                "...{w=0.2} you suppose you don't have much choice."
                                show spamshop_spamton e_neutral at yreset
                                jump shop_spam_talk
                        
                        else:
                            if itm_redshard1 in inventory and itm_redshard2 in inventory and itm_redshard3 in inventory:
                                show spamshop_spamton e_neutral at jump
                                spamton "[[Nice Work] [persistent.mc!u]!!{p=0.2}{noalt}*{/noalt} YOU EVEN DID THE [[unpaid overtime] I ASKED FOR!!"
                            
                            else:
                                show spamshop_spamton e_eyes at jump
                                spamton "[[But wait!] YOU DIDN'T GET THE [[in the red] ONES."
                                show spamshop_spamton e_neutral
                                spamton "SORRY [[beloved customer] BUT THE DEAL'S BEEN [[Updated: Ver 1.1]"
                                show spamshop_spamton e_laugh at jump
                                spamton "COME BACK WHEN YOU'VE [[sucessfuly]\n[[[[doubled your workload]]!"
                                "You ask if Spamton at least has some idea of where you could find the remaining MemoryShards."
                                show spamshop_spamton e_eyes
                                spamton "DON'T LOOK AT ME, I JUST FOUND OUT THESE EXISTED [[3 seconds ago]???"
                                if itm_redshard3 not in inventory:
                                    spamton "I DON'T KNOW DID YOU CHECK THE [[Matresses for Sale 50%% Off] ??"
                                    show spamshop_spamton e_laugh
                                    spamton "PEOPLE ALWAYS HIDE [[the goods] [[[[Under the bed]]!!"
                                
                                elif itm_redshard2 not in inventory:
                                    spamton "I DON'T KNOW MAYBE YOU WERE TOO [[scared of the dark] TO [[Proceed.] ??"
                                    show spamshop_spamton e_laugh
                                    spamton "OR YOU COULD ALWAYS TRY [[Breaking and Entering]!!"
                                
                                show spamshop_spamton e_neutral at yreset
                                jump shop_spam_talk
                        
                        jump spamdate_eye_preamble

                    else:
                        "You asked Spamton if he had any ideas on where to find the remaining MemoryShards."
                        if itm_greenshard2 not in inventory:
                            show spamshop_spamton e_eyes
                            spamton "HAVE YOU TRIED [[You can visit the Garbage Can anytime!] ?"
                            show spamshop_spamton e_laugh
                            spamton "THE [[bottom of the barrel] [[Best Deals in the City] CAN BE FOUND [[at your local] TRASH!!"

                        elif itm_greenshard3 not in inventory:
                            show spamshop_spamton e_eyes
                            spamton "HAVE YOU TRIED [[staring into the eye of ] ?"
                            show spamshop_spamton e_laugh
                            spamton "JUST MAKE SURE YOU [[stab directly into the pupil] !!"

                "Date?" if spam_date1:
                    "You ask Spamton if he'd be willing to go on another date now."
                    show spamshop_spamton e_eyes
                    spamton "YOU WANT [[MORE] ??????{w=0.2} [[Already?] ????"
                    show spamshop_spamton e_laugh at jump
                    spamton "SORRY [[business partner] BUT [[You still owe me]!!!"
                    show spamshop_spamton e_neutral
                    spamton "I STILL NEED THOSE {noalt}MemoryShard S{/noalt}{alt}MemoryShards{/alt} [[on my desk, pronto!] BEFORE I GO ANYWHERE ELSE WITH YOU"

                "Seen anyone else?" if spam_date1 and not mke_unlock:
                    "You ask if Spamton has seen anyone else while in the dump."
                    show spamshop_spamton e_eyes
                    spamton "NO??{nw=0.5}"
                    show spamshop_spamton e_laugh at jump
                    extend "{p=0}{noalt}*{/noalt} NOT BESIDES [[Acknowledging the Existence of] THAT DAMmED [[vacuum tube]"
                    show spamshop_spamton e_eyes at jump
                    spamton "ARE YOU EXPECTING TO [[Find New Friends] HERE???{p=0.2}{noalt}*{/noalt} THAT'S [[having great material wealth]"
                    show spamshop_spamton e_neutral
                    spamton "ACTUALLY I {noalt}DON''T{/noalt}{alt}don't{/alt} REALLY CARE WHAT YOU DO.{p=0.5}{noalt}*{/noalt} FOLLOW THE [[yellow brick] OF YOUR HEART!!"
                    show spamshop_spamton e_eyes
                    spamton "...{w=0.2} BUT I RECCOMEND [[Dive for Hidden Deals] AT THE\n[[Television Set (with a free game console!)]"
                    spamton "YOU NEVER KNOW WHAT [[secrets lurk underneath]"

                "Who is Mike?" if spam_date1 and mke_unlock:
                    if not vex_mikeask:
                        $ vex_mikeask = True
                        "You asked Spamton if he'd ever heard of anyone named \"Mike.\""
                        if persistent.glitches:
                            show spamshop_spamton e_eyes
                        else:
                            show spamshop_spamton e_eyes at shakingcg
                        spamton "THIS {noalt}[[$#!X]{/noalt}{alt}beep{/alt} AGAIN?!?!?{p=0.2}{noalt}*{/noalt} DID [[cathode ray t] TELL YOU TO ASK ME THAT??"
                        spamton "I'M NOT TELLING YOU A [[status: single] THING!!{p=0.2}{noalt}*{/noalt} NOTHING!{w=0.2} NOTHING!{w=0.2} NOTHING!!"
                        spamton "WHY DOES EVERYONE KEEP ASKING ME ABOUT"
                        show spamshop_spamton e_static at yreset
                        pause 2.0
                        spamton "...{p=0.5}{noalt}*{/noalt} ...{w=0.2} Mike..."
                    else:
                        if persistent.glitches:
                            show spamshop_spamton e_eyes
                        else:
                            show spamshop_spamton e_eyes at shakingcg
                        spamton "I'M NOT TELLING YOU ANYTHING ABOUT MIKE!!!"

                "How did you get here" if spam_date1:
                    "You decide to ask how Spamton got here,{w=0.2} if he won't tell you why he's here."
                    show spamshop_spamton e_static
                    spamton "...{w=0.2} {color=[c_vessel]}[[{space=80}]{/color}{alt}redacted{/alt}.{w=0.5} THAT [[little sponge]."
                    if persistent.glitches:
                        show spamshop_spamton e_eyes
                    else:
                        show spamshop_spamton e_eyes at shakingcg
                    spamton "THEY REFUSED TO TAKE THE [[Deal] !!{w=0.2} NOT EVEN A [[HealDeal]!!{p=0.5}{noalt}*{/noalt} WHAT A BIG, HUGE, GIANT {noalt}[[meanie]{/noalt}{alt}mean E{/alt}!!"
                    show spamshop_spamton e_neutral at yreset
                    spamton "SO I TRIED A [[Neo] PLAN...{p=0.5}{noalt}*{/noalt} AND {noalt}IT{/noalt}{alt}it{/alt} WENT BAD!{w=0.2} REALLY REALLY REALLY [[catastropic] BAD!!"
                    if persistent.glitches:
                        show spamshop_spamton e_laugh at jump
                    else:
                        show spamshop_spamton e_laughf
                    spamton "EAHAHEHAHAHEAH!!{p=0.5}{noalt}*{/noalt} BUT I'M [[over it]"
                    if persistent.glitches:
                        show spamshop_spamton e_eyes
                    else:
                        show spamshop_spamton e_eyes at shakingcg
                    spamton "[[We all die eventually.]"

                "Return":
                    jump shop_spam

            show spamshop_spamton e_neutral at yreset
            jump shop_spam_talk

        "{size=-20}escape":
            if not spam_date1:
                if not vex_bought and money <= 0:
                    show spamshop_spamton e_eyes
                    spamton "DON'T FORGET THE KROMER!!"
                elif not vex_bought and money > 0:
                    if persistent.glitches:
                        show spamshop_spamton e_eyes
                    else:
                        show spamshop_spamton e_eyes at shakingcg
                    spamton "YoU BETTER [[SUBSCRIBE for more] !{p=0.2}{noalt}*{/noalt} I CAN SMELL THAT [[delisis] KROMER FROM HERE, [persistent.mc!u] !!!!!!!"
                else:
                    show spamshop_spamton e_laugh
                    spamton "{noalt}DON''t{/noalt}{alt}don't{/alt} FORGET YOUR [[[[Hyperlink Blocked]] ON THE WAY OUT!!"
            else:
                show spamshop_spamton e_eyes
                spamton "[[Memory].{w=0.2} [[Shards].{p=0.5}{noalt}*{/noalt} DONT FORGET!!"
            jump trns_ex_spamshop


######################################################
##### SPAMTON'S BUYING MENU
label shop_spam_buy:
    $ skipyes = True
    $ _skipping = True
    $ imghover = False
    hide screen shop_spamton

    if which_item == itm_shovel.name:
        if not vex_shovsee:
            $ vex_shovsee = True
            show spamshop_spamton e_laugh
            spamton "THAt'll BE [itm_shovel.money] KROMER."
    
        menu:
            rq "Will you buy the [itm_shovel.name]?{p=0}{noalt}*{/noalt} It costs [itm_shovel.money] kromer. You have [money] kromer."
            "Yes":
                $ vex_buyoption = True
            "No":
                $ vex_buyoption = False

    elif which_item ==  itm_freecard.name:
        if not vex_cardsee:
            $ vex_cardsee = True
            show spamshop_spamton e_laugh
            spamton "THAt'll BE [itm_freecard.money] KROMER."
    
        menu:
            rq "Will you buy the [itm_freecard.name]?{p=0}{noalt}*{/noalt} It costs [itm_freecard.money] kromer. You have [money] kromer."
            "Yes":
                $ vex_buyoption = True
            "No":
                $ vex_buyoption = False

    elif which_item ==  itm_ring.name:
        if not vex_ringsee:
            $ vex_ringsee = True
            show spamshop_spamton e_laugh
            spamton "THAt'll BE [itm_ring.money] KROMER."
    
        menu:
            rq "Will you buy the [itm_ring.name]?{p=0}{noalt}*{/noalt} It costs [itm_ring.money] kromer. You have [money] kromer."
            "Yes":
                $ vex_buyoption = True
            "No":
                $ vex_buyoption = False

    elif which_item == itm_greenshard1.name:
        if not vex_gsh1see:
            $ vex_gsh1see = True
            show spamshop_spamton e_laugh
            spamton "THAt'll BE [itm_greenshard1.money] KROMER."

        menu:
            rq "Will you buy the [itm_greenshard1.name]?{p=0}{noalt}*{/noalt} It costs [itm_greenshard1.money] kromer. You have [money] kromer."
            "Yes":
                $ vex_buyoption = True
            "No":
                $ vex_buyoption = False

    if vex_buyoption:
        if which_item == itm_greenshard1.name:
            if money < itm_greenshard1.money:
                $ vex_buyoption_check = False
            else:
                $ vex_buyoption_check = True
        elif which_item == itm_shovel.name:
            if money < itm_shovel.money:
                $ vex_buyoption_check = False
            else:
                $ vex_buyoption_check = True
        elif which_item == itm_freecard.name:
            if money < itm_freecard.money:
                $ vex_buyoption_check = False
            else:
                $ vex_buyoption_check = True
        elif which_item == itm_ring.name:
            if money < itm_ring.money:
                $ vex_buyoption_check = False
            else:
                $ vex_buyoption_check = True

        if vex_buyoption_check:
            if not vex_bought:
                $ vex_bought = True
                show spamshop_spamton e_eyes 
                spamton "YOU [[skill acquired] KROMER?!?{p=0.5}{noalt}*{/noalt} WHERE ???????????????"
                if persistent.glitches:
                    show spamshop_spamton e_laugh
                else:
                    show spamshop_spamton e_laughg
                spamton "ACTUALLY [[I don't care] JUST HAND {noalt}IT{/noalt}{alt}it{/alt} OVER!!!!!!"
            
            else:
                $ vex_buytext += 1
                if persistent.glitches:
                    show spamshop_spamton e_laugh
                else:
                    show spamshop_spamton e_laughg
                if vex_buytext == 1:
                    spamton "YUM YUM DELISIS KROMER"
                elif vex_buytext == 2:
                    spamton "REMEMBER THERE'S NO [[or your money back Guarantteed] !"
                else:
                    spamton "PLeASURE DOInG BUSINESS WITH{space=100}."
            
            play sfx item
            if which_item == itm_shovel.name:
                $ inventory.append(itm_shovel)
                $ money -= itm_shovel.money
                "You bought the [itm_shovel.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."

            elif which_item == itm_freecard.name:
                $ inventory.append(itm_freecard)
                $ money -= itm_freecard.money
                "You bought the [itm_freecard.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."

            elif which_item == itm_ring.name:
                $ inventory.append(itm_ring)
                $ money -= itm_ring.money
                "You bought the [itm_ring.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."

            elif which_item == itm_greenshard1.name:
                $ inventory.append(itm_greenshard1)
                $ money -= itm_greenshard1.money
                "You bought the [itm_greenshard1.name].{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                "Although,{w=0.2} the moment you touched it..."
                stop music
                scene black
                "Something overcame your senses."
                jump memoryshard4

        elif not vex_buyoption_check:
            show spamshop_spamton e_eyes
            spamton "[[Money] NO"
            if not vex_bought and money <= 0:
                spamton "YOU NEED [[Kromer] [[[[for all online purchases]]{p=0.2}{noalt}*{/noalt} DIDN'T I [[Warning! Warning!] YOU ALREADY????"
                spamton "WHAT DO YOU THINK THIS {noalt}IS{/noalt}{alt}is{/alt}????{p=0.2}{noalt}*{/noalt} [[Consider donating to your local charity] ?!?!?!"

    show spamshop_spamton e_neutral at yreset
    show screen shop_spamton
    $ skipyes = False
    $ _skipping = False
    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()
    

######################################################
##### spamton dialogue gay baby jail so it doesn't break my goddamn color coding
default ss_shovel_name = "[Ultra Strength] SHOVEL"
default ss_shovel_desc = "{noalt}*{/noalt} NEED SOMETHING TO [[Killed]] YOUR ENEMIES WITH??{p}{noalt}*{/noalt} LOOK NO FURTHER THAN THIS [[Top Quality]] [[Hunk Of Junk]]"
default ss_freecard_name = "GET OUT OF {noalt}[H3LL]{/noalt}{alt}hell{/alt} FREE"
default ss_freecard_desc = "{noalt}*{/noalt} SICK OF EBING STUCK IN [the Trash] ?{p}{noalt}*{/noalt} USE THIS TO GET OUT [[With Zero Strings Attached]]!!"
default ss_ring_name = "[[Commemorative Ring 1997]]"
default ss_ring_desc = "{noalt}*{/noalt} AN [[Unused]] [Silver Ring] IN [[Perfect!]] CONDITION!!{p}{noalt}*{/noalt} CHECK OUT THAT [real annd Legit] JEWEL!!"
default ss_greenshard_name = "[Green] ROCK"
default ss_greenshard_desc = "{noalt}*{/noalt} I DON'T KNOW WHAT [to tell you] IT'S JUST A {noalt}[X&!&]{/noalt}{alt}beep{/alt}ING ROCK"