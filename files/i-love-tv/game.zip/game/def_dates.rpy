############################################################################################################
################## DATE VARIABLE DEFAULTS
default turn = 0 # what turn it is
default check = 0 # how many times "Check" was used
default flirt = 0 # how may times flirted
default niceday = 0 # how many times "Nice Day!" was said

default menu_text = None # what the menu will read out
default currentdate = None # quiz, park, shop, eye
 

######################################################
##### TENNA QUIZ DATE
default q_bandage = False # asked about bandage on tenna's antenna
default q_escape = False # asked about "escape" question
default q_dump = 0 # asked about what's behind the board
default q_where = False # "where are we"
default q_stat = 0 # asked about the stats on the board
default q_none = 0 # refused to answer quiz questions
default q_item = 0 # items checked
default q_niceday = False # asked "nice day" multiple times in the quiz date
default q_flirt = False # flirted with tenna in the quiz date
default q_flirt2 = False # flirted with tenna in the quiz date multiple times
default q_turn = None # for certain menu text
default q_check = False # if checked tenna (used in park date)

### menu text
default q_menu_flirt = False
default q_menu_dump = False

### tenna's turn
default question = 1
default q1 = False
default q2 = False
default q3 = False
default q4 = False
default q5 = False
default q6 = False
default q7 = False
default q8 = False


######################################################
##### TENNA PARK DATE
default p_ten_date = False # if accepted date or not
default p_dateno = False # convo if you rejected date ; "hangout"
default p_dateyes = False # convo if you accepted date ; "date"
default p_niceday = False # said nice day
default p_iltv = 0 # how many times was i love tv said
default p_parkq = False # asked about park setting
default p_turn = None # for certain menu text
default p_behind = 0 # asked about behind the board
default p_flirt = False # did player flirt on the park date
default p_flirt2 = False # flirt thru tenna flirting back
default p_lot = False # player given tenna the "dvd" ; unlocks legend of tenna minigame
default p_played = False # if chose to play lot or not
default p_ten_comment = None # what comment when tenna flirts with player
default p_ten_flirt = None # what flirt tenna says to player
default p_foodq = False # asked about the food after getting some
default p_board = False # tried to move board before or not (with react, not ending date)
default p_foodkeep = False # if you kept the food from tenna (not necessarily candy)
default p_candy = False # if you kept the candy from tenna

### items
default p_pipis = False # shown tenna the pipis or not
default p_figure = False # shown tenna the figure or not
default p_shard = False # shown tenna the red shard or not

### ASK act
# if false, not asked yet
default p_qu_here = False 
default p_qu_blood = False
default p_qu_food = False
default p_qu_me = False
default p_qu_self = False

### menu text (false if not seen, true if seen)
default p_menu_flirt = False
default p_menu_here = False
default p_menu_food = False
default p_menu_hangout = False
default p_menu_game = False


######################################################
##### SPAMTON SHOP DATE ; REMEMBER TO UPDATE label spamdate_shop_fail IF YOU ADD ANY!!
default s_check = False # seen the check text
default s_niceday = 0 # if told spamton "nice day" (goes up with how many times)
default s_flirt = False # if flirted with on the shop date
default s_misstenna = False # said "i miss tenna"
default s_regret = False # said you don't regret going on a date
default s_great = False # said this date is great!
default s_hso = False # talked about heart shaped object
default s_ring = False # asked about ring
default s_soul = False # asked about the soul finding
default s_memshardask = False # asked about memoryshard
default s_sillystrings = False # if answered "well... i mean..." about if vess is being controlled
default s_help = False # seen the help text before
default s_help_used = 0 # how many times used help
default s_help_dance = False # done the dance before
default s_help_kiss = False # blown a kiss before
default s_help_done = False # spamton won't help anymore
default s_haggle = 0 # how many times haggled

default s_ask = False # if ask act
default s_qu_here = False # come here often
default s_qu_food = False # fave food
default s_qu_color = False # fave color
default s_qu_me = False # opinion of me
default s_qu_you = False # opinion of you

default s_t1 = False # seen the turn 1 text or not
default s_t3 = False # seen the turn 4 text or not
default s_t6 = False # seen the turn 6 text or not

default s_bribesee = False # if seen the tuto text for bribing/restoring
default s_bribeitm = 2 # how many items are available
default s_bribe_menu_text1 = "" # correct grammar for bribeitm
default s_bribe_menu_text2 = "" # correct grammar for bribeitm

### in case failed date, revert to these (saved as spam.fp/lp before first date)
default spamem_fp = 0
default spamem_lp = 0

### items
default s_shadow = False # offered the shadow crystal
default s_memshard = False # offered the memoryshard (spamton, 1)
default s_figure = False # shown spamton the fighate
default s_food = False # if given food before or no
default s_loveletter = False # if asked abt love letter for u already
default s_flower = False # gave him the flower already


######################################################
##### SPAMTON SECOND DATE
default ey_hso = False # tried to give soul
default ey_countdown = 0 # number of turns left

default ey_memask = 0 # asked about memoryshards
default ey_memmenu = False # seen the menu text about the memoryshards
default ey_freedom = False # asked about freedom

default ey_deals = 2 # how many deals are available
default ey_dealsee = False # seen the deal dialogue text
default ey_deal_menu_text = "" # correct grammar for dealsee

### items
default ey_memshard1 = False # showed off green memshard 1
default ey_memshard2 = False # showed off green memshard 2
default ey_memshard3 = False # showed off green memshard 3
default ey_memshown = 0 # how many shown off before


######################################################
##### MIKE SECRET DATE
default m_convo = 0 # convo with mike in "talk"
default m_check = False # if seen the menu_text for the first "check" int
default m_pet = 0 # how many times pet mike
default m_pet_lp = 5 # how much lp mike gains on headpat, goes down by 1 every time
default m_pet_no = False # seen the final dialogue for petting
default m_turn = 0 # save turn count for dialogue
default m_shadowconvo = 0 # convo with mike abt getting here/shadow crystal in "talk"
default m_flirt = False # if flirted with mike or not

default m_infosee = False # if seen the tuto text for infodumping
default m_info = 2 # how much info you have left
default m_info_menu_text = "" # correct grammar

### items
default m_shadow = False # shown the shadow crystal or not
default m_flower = False # given the flower to mike or not
default m_memshard = False # if shown memory shard
default m_food = False # if given food before or no