############################################################################################################
################## MOVE THE BOARD / POST QUIZ
label ex_postquiz:
    if vex_dumpview and vex_pipis:
        $ quick_menu = False
        pause 0.5
        jump postquiz2

    else:
        show screen ex_postquiz

        $ quick_menu = False
        $ skipyes = False
        $ _skipping = False
        $ renpy.choice_for_skipping()
        $ renpy.pause(hard=True)


######################################################
##### POSTQUIZ EXPLORE VARIABLES
default vex_dumpview = False
default vex_pipis = False
default vex_keepis = False # kept the pipis or not


######################################################
##### DUMP VIEW INTERACT
label ex_dumpview:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_postquiz

    if not vex_dumpview:
        $ vex_dumpview = True
        "You quietly take a closer look at your surroundings..."
        show itemframe i_dump at truecenter with easeinbottom
        "There seems to be a bunch of junk lying around."
        "A few things are in-tact,{w=0.2} but most of the trash is broken into irreparable pieces."
        "There's some severed wires,{w=0.2} scattered threads,{w=0.2} and strangely...{w=0.5} parts of a broken robotic arm."
        pause 1.0
        hide itemframe with easeoutbottom
        "You had to step away."
        "As you do so,{w=0.2} a piece of paper catches your foot."
        "You bend down to pick it up,{w=0.2} reading:"
        "\"If it seems you have reached [[The End.]{p=0.2}{noalt}*{/noalt} Go back to sleep.\""
        "...{w=0.2} unfortunately,{w=0.2} it flew out of your hand before you could put it into your ITEMS."
        $ persistent.itemheard = True
    else:
        "You don't want to go back over there."

    jump ex_postquiz


######################################################
##### PIPIS INTERACT
label ex_pipis:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_postquiz

    $ vex_pipis = True
    if itm_pipis in inventory:
        "There's nothing else of interest over there."
    else:
        "You spot something in particular over on the ground,{w=0.2} half-buried in the dirt."
        show itemframe i_pipis at truecenter with easeinbottom
        "...{w=0.5} You're not sure what this is."
        menu:
            date "Keep it anyway?"
            "Yes":
                $ vex_keepis = True
                play sfx item
                hide itemframe
                $ inventory.append(itm_pipis)
                $ persistent.itemheard = True

                ## AUTOSAVE
                $ renpy.save("mainfile")

                "You put it in your pocket,{w=0.2} for some reason.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
            
            "No":
                hide itemframe with easeoutbottom
                "You left the strange object alone."
    
    jump ex_postquiz



############################################################################################################
################## SPAMTON SHOP
label ex_spamshop:
    show screen ex_spamshop

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### SPAMTON SHOP EXPLORE VARIABLES
default vex_shovels = False # seen shovel text
default vex_shovelown = False # if owned shovel before (AVOIDING MONEY GLITCH AGAIN)


######################################################
##### SHOVEL INTERACT
label ex_shovels:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_spamshop

    if vex_shovelown:
        "You have done all that you can do."
    else:
        if not vex_shovels:
            show itemframe i_shovpile at truecenter with easeinbottom
            "In the near distance is a collection of abandoned shovels."
            "Most of them are stuck in the soggy soil,{w=0.2} unable to be moved by any force known to Earth."
            hide itemframe with easeoutbottom
            pause 0.2
            show itemframe i_shovel2 at truecenter with easeinbottom
            "Luckily,{w=0.2} there happens to be a singular loose shovel that can easily be picked up."
        else:
            show itemframe i_shovel2 at truecenter with easeinbottom
            "The singular shovel is still sitting atop the loose dirt."
        menu:
            rq "Pick up the shovel?"
            "Yes":
                play sfx item
                hide itemframe
                $ vex_shovelown = True
                $ inventory.append(itm_shovel2)
                "You picked up the weak shovel.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                "However, upon moving it,{w=0.2} you notice a flutter of something underneath the blade."
                "Using your newfound shovel, you sift the remaining dirt off of the paper-like object."
                play sfx item
                $ money += 10

                ## AUTOSAVE
                $ renpy.save("mainfile")

                "Turns out,{w=0.2} it was cash.{p=0.2}{noalt}*{/noalt} You found D$10."
           
            "No":
                hide itemframe with easeoutbottom
                if vex_shovels:
                    "Your opinion on the shovel remains stagnant."
                else:
                    "You decided that was too much power for one person to have."

    $ vex_shovels = True
    jump ex_spamshop



############################################################################################################
################## DIRT LUMP ROOM
label ex_lumproom:
    $ memsh_location = "ex_lumproom"
    show screen ex_lumproom

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### DIRT LUMP EXPLORE VARIABLES
default vex_dirtlump = False # interacted with dirt lump
default vex_dirtshov2 = False # combined shovel 2 w dirt lump... results in failure
default vex_dirtvictory = False # did they conquer the dirt lump
default vex_trash = False # interacted with trash before or not


######################################################
##### DIRT LUMP INTERACT
label ex_dirtlump:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_lumproom

    if vex_dirtvictory:
        "This dirt pile no longer holds any power over you."
    
    else:
        show itemframe i_lump1 at truecenter with easeinbottom
        if not vex_dirtlump:
            $ vex_dirtlump = True
            "You've come across a dirt lump."
            "It looms menacingly.{p=0.5}{noalt}*{/noalt} It's perhaps the strongest thing you've ever encountered."
            
            if itm_shovel in inventory:
                hide itemframe with easeoutbottom
                pause 0.2
                show itemframe i_shovel at truecenter with easeinbottom
                "The shovel you bought from Spamton just might be able to reveal what lurks beneath."
                menu:
                    rq "Give it a shot?"
                    "Absolutely":
                        "You pierce the earth with your shovel and begin to dig."
                        call ex_dirtlump2 from _call_ex_dirtlump2
                    "No thanks":
                        "Suit yourself."

            elif itm_shovel2 in inventory:
                hide itemframe with easeoutbottom
                pause 0.2
                show itemframe i_shovel2 at truecenter with easeinbottom
                "You consider digging into it with the shovel you found earlier."
                menu:
                    rq "Give it a shot?"
                    "Why not":
                        "You thrust the blade of the shovel into the dirt."
                        play sfx defeat
                        $ inventory.remove(itm_shovel2)
                        $ vex_dirtshov2 = True
                        "...{w=0.2} but the dirt lump was far too strong.{p=0.2}{noalt}*{/noalt} It broke your flimsy shovel clean in half."
                        "Guess there's no point in keeping it anymore..."
                    "No thanks":
                        "You figured it best to not challenge such a threatening opponent with a flimsy shovel."
            
            else:
                "Unfortunately,{w=0.2} you have no way of combating such an opponent."
        
        else:
            "You've returned to the revered dirt lump."
            
            if itm_shovel in inventory:
                "However, this time...{p=0.2}{noalt}*{/noalt} You came prepared."
                menu:
                    rq "Dig into the earth?"
                    "Absolutely":
                        "You pierce the earth with your shovel and begin to dig."
                        call ex_dirtlump2 from _call_ex_dirtlump2_1
                    "No thanks":
                        "Suit yourself."

            elif itm_shovel2 in inventory:
                "You consider the possibility of digging into it with the shovel you found earlier."
                menu:
                    rq "Give it a shot?"
                    "Why not":
                        "You decided to risk it all,{w=0.2} thrusting the blade of the shovel into the dirt."
                        play sfx defeat
                        $ inventory.remove(itm_shovel2)
                        $ vex_dirtshov2 = True
                        "...{w=0.2} but the dirt lump was far too strong.{p=0.2}{noalt}*{/noalt} It broke your flimsy shovel clean in half."
                        "Guess there's no point in keeping it anymore..."
                    "No thanks":
                        "You still would rather not risk the life of your flimsy shovel."

            else:
                if vex_dirtshov2:
                    "You mourn the loss of your flimsy shovel."
                else:
                    "There's still nothing you can do about this."
        
        hide itemframe with easeoutbottom

    jump ex_lumproom

label ex_dirtlump2:
    play sfx digging
    scene black with dissolve
    pause 6.5
    "You continued to dig for what felt like a millenia."
    show itemframe i_lump2 at truecenter with easeinbottom
    "But you've only made some very marginal progress..."
    hide itemframe with easeoutbottom
    play sfx digging
    pause 6.5
    play sfx dighit
    pause 1.0
    "Finally."
    show itemframe i_lump3 at truecenter with easeinbottom
    "You've reached what can only be the bottom."
    play sfx item
    $ money += 50
    $ vex_dirtvictory = True

    ## AUTOSAVE
    $ renpy.save("mainfile")

    "Your hard work has paid off in the form of more money.{p=0.2}{noalt}*{/noalt} You gained D$50."
    hide itemframe with easeoutbottom
    show junkyard3 with Dissolve(0.5)
    return


######################################################
##### LUMP ROOM MEMORYSHARD INTERACT
label ex_lumpshard:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_lumproom

    if itm_greenshard2 in inventory:
        "There's nothing else worth grabbing from the trash."
    else:
        show itemframe i_garbage at truecenter with easeinbottom
        if not vex_trash:
            $ vex_trash = True
            "A rather in-tact garbage can sits atop a pile of junk."
            "It looks mostly empty,{w=0.2} but you might be able to fish something out from the bottom."
        else:
            "The garbage can remains,{w=0.2} if you want to dig through it."
        menu:
            rq "Reach in?"
            "Yes":
                hide itemframe with easeoutbottom
                play sfx bump
                "You stick your hand inside..."
                play sfx sparkleglock
                show itemframe i_greenshard2 at truecenter with easeinbottom
                "You found a semi-translucent rock that was glistening at the bottom of the can."
                "This might be one of the \"MemoryShards\" Spamton was asking for..."
                play sfx item
                hide itemframe
                $ inventory.append(itm_greenshard2)
                "You picked up the green shard.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                "Although,{w=0.2} the moment you touched it..."
                stop music
                scene black
                "Something overcame your senses."
                jump memoryshard5
            
            "No":
                hide itemframe with easeoutbottom
                "You figure it's better if you don't dig through trash."

    jump ex_lumproom



############################################################################################################
################## NORTH SPAM ROOM
label ex_north:
    show screen ex_north

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)



############################################################################################################
################## MATTRESS ROOM
label ex_mattroom:
    $ memsh_location = "ex_mattroom"
    show screen ex_mattroom

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### MATTRESS EXPLORE VARIABLES
default vex_mattress = False # seen the mattress
default vex_creepyhand = False # seen the creepy hand
default vex_debithand = False # handed debit card or not


######################################################
##### MATTRESS INTERACT
label ex_mattress:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_mattroom

    show itemframe i_matt at truecenter with easeinbottom
    if not vex_mattress:
        $ vex_mattress = True
        "You've come across a mattress."
        "Strangely,{w=0.2} it appears unused,{w=0.2} despite being dirty."
    else:
        "The mattress remains."

    ## AUTOSAVE
    $ renpy.save("mainfile")

    menu:
        rq "Lay on it?"
        "Go ahead":
            "You decided to take a rest."
            stop music fadeout 1.0
            play sfx cloth
            scene black with Dissolve(2.0)
            pause 1.0
            jump neveruse

        "I'd rather not":
            hide itemframe with easeoutbottom
            "You decided to step away."
            jump ex_mattroom


######################################################
##### CREEPY HAND INTERACT
label ex_creepyhand:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_mattroom

    show itemframe i_hand at truecenter with easeinbottom
    if not vex_creepyhand:
        "An unsettling hand sticks out of a mound of garbage."
        "You swear it twitched,{w=0.2} almost like it's asking for something."
    else:
        "The hand remains outstretched,{w=0.2} waiting for something."

    if itm_debit in inventory:
        hide itemframe with easeoutbottom
        pause 0.2
        show itemframe i_debit at truecenter with easeinbottom
        "You suppose you could pretend to \"bribe\" it with the newly-emptied debit card."
        menu:
            rq "Hand it over?"
            "Yes":
                $ vex_debithand = True
                hide itemframe
                play sfx item
                $ inventory.remove(itm_debit)
                "You placed Starwalker's debit card in the palm of the creepy hand."
                "It closes slowly{w=0.2}.{w=0.2}.{w=0.2}."
                "It stays this way for quite a while,{w=0.5} before it miraculously snaps open again."
                play sfx item
                $ money += 1000

                ## AUTOSAVE
                $ renpy.save("mainfile")

                "There was a plethora of cash in it now.{p=0.5}{noalt}*{/noalt} You gained D$1000."
            
            "No":
                hide itemframe with easeoutbottom
                "Yeah, it probably wouldn't do anything."
    else:
        if vex_debithand:
            "You hopefully don't need to give it anything more."
        else:
            "You might be able to bribe it with some money-like object,{w=0.2} but you don't have anything like that right now."
        hide itemframe with easeoutbottom

    jump ex_mattroom



############################################################################################################
################## STARWALKER ROOM
label ex_starroom:
    $ memsh_location = "ex_starroom"
    show screen ex_starroom

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### STARWALKER VARIABLES
default vex_starwalker = False # interacted with starwalker or not, without item in pocket
default vex_starwalker2 = False # interacted with starwalker or not, with item in pocket
default vex_starascend = False # if starwalker has ascended
default vex_eye = False # interacted with creepy eye or not


######################################################
##### STARWALKER INTERACT
label ex_starwalker:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_starroom

    show starwalkerIm at center with Dissolve(0.2)
    starwalker "This dump is{p=0.5}{p=0}{space=400}{color=[c_star]}Pissing{/color} Me Off."
    starwalker "I'm the Original{p=0.5}{space=300}{color=[c_star]}Starwalker{/color}."
    if not vex_starwalker:
        $ vex_starwalker = True
        pause 1.0
        "It seems like he doesn't like this place."
    if itm_freecard in inventory:
        show itemframe i_freecard at truecenter with easeinbottom
        if not vex_starwalker2:
            "You consider giving him the \"Get Out Of {noalt}[[H3LL]{/noalt}{alt}hell{/alt} Free\" card in your pocket."
        menu:
            rq "Give it to him?"
            "Yes":
                $ vex_starascend = True
                $ inventory.remove(itm_freecard)
                hide itemframe
                play sfx item
                "You handed the fake board game playing card to Starwalker."
                stop music
                pause 2.0
                play sfx stardrop
                show starwalkerIm:
                    parallel:
                        starascend2
                    parallel:
                        starascend
                pause 2.0
                hide starwalkerIm
                "{cps=15}...{/cps}{w=0.5} he ascended."
                "Somehow."
                "You glanced to where Starwalker was previously standing,{w=0.2} finding that he left something behind."
                play sfx sparkleglock
                show itemframe i_debit at truecenter with easeinbottom
                "Apparently,{w=0.2} he dropped his debit card as he flew away."
                $ inventory.append(itm_debit)
                $ money += itm_debit.money
                play sfx item

                ## AUTOSAVE
                $ renpy.save("mainfile")

                "It still had money on it.{p=0.5}{noalt}*{/noalt} You obtained D$100...?"
                hide itemframe
                play music dump
            
            "No":
                hide itemframe with easeoutbottom
                "You figure it'd be a useless gift."
                if not vex_starwalker2:
                    $ vex_starwalker2 = True
                    starwalker "You are{w=0.2}{space=100}Pissing me off."
                else:
                    starwalker "You are still{w=0.2}{space=100}Pissing me off."
                hide starwalkerIm with Dissolve(0.2)
    else:
        "Maybe there's something that could help him get out of here..."
        hide starwalkerIm with Dissolve(0.2)

    jump ex_starroom


######################################################
##### EYE MEMORYSHARD INTERACT
label ex_eyeshard:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_starroom

    if itm_greenshard3 in inventory:
        "The eye offers nothing more than an ominous presence."
    else:
        show itemframe i_eye at truecenter with easeinbottom
        if not vex_eye:
            $ vex_eye = True
            "Now that you're looking at it,{w=0.2} the way the dump is arranged over here looks deliberately like an eye."
            "You could probably step closer to it, if you wanted."
        else:
            "The \"eye\" is creepy as ever."
        menu:
            rq "Approach the eye?"
            "Yes":
                hide itemframe with easeoutbottom
                play sfx waterwalk
                "You stroll along towards the eye-like crevice."
                pause 1.0
                stop sfx fadeout 0.5
                "As you get closer,{w=0.2} something appears to be shining at the pupil of the eye."
                play sfx sparkleglock
                show itemframe i_greenshard3 at truecenter with easeinbottom
                "It's a green-colored shard.{p=0.5}{noalt}*{/noalt} Seems painful to have shoved into your eye."
                "But this might be one of the \"MemoryShards\" Spamton was asking for..."
                play sfx item
                hide itemframe
                $ inventory.append(itm_greenshard3)
                "You picked up the green shard.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                "Although,{w=0.2} the moment you touched it..."
                stop music
                scene black
                "Something overcame your senses."
                jump memoryshard6
            
            "No":
                hide itemframe with easeoutbottom
                "You're unsettled by this discovery anyway."

    jump ex_starroom



############################################################################################################
################## GAME ROOM
label ex_gameroom:
    $ memsh_location = "ex_gameroom"
    show screen ex_gameroom

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)

######################################################
##### GAME ROOM VARIABLES
default vex_secretgame = False # interacted with game or not
default vex_playsecret = False # chose to play game or not
default vex_playtv = False # chose to play game or not


######################################################
##### GAME INTERACT
label ex_tv:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_gameroom

    show itemframe i_tv at truecenter with easeinbottom
    "There's a TV set up amongst the mud."
    if itm_cartridge1 in inventory and itm_cartridge2 in inventory:
        "You still have both of those game cartridges with you..."
        menu:
            rq "Play one of them?"
            "TV TIME 2":
                if lot_key:
                    "As you went to put the cartridge into the system,{w=0.2} you remembered it was frozen the last time you tried to play."
                    "No use in booting up a broken game..."
                    hide itemframe with easeoutbottom
                else:
                    hide itemframe
                    $ inventory.remove(itm_cartridge1)
                    play sfx item
                    
                    ## AUTOSAVE
                    $ renpy.save("mainfile")

                    "You put the cartridge into the game system."
                    call trns_tvtime2 from _call_trns_tvtime2
            
            "The one without a label":
                hide itemframe
                $ inventory.remove(itm_cartridge2)
                play sfx item
                    
                ## AUTOSAVE
                $ renpy.save("mainfile")

                "You put the cartridge into the game system."
                call trns_secretgame from _call_trns_secretgame
            
            "Do not":
                hide itemframe with easeoutbottom
                if not vex_playtv:
                    $ vex_playtv = True
                    "You decided you weren't interested in playing."
                else:
                    "You still don't want to play any games."

    elif itm_cartridge1 in inventory:
        "You still have that game cartridge labeled \"TV TIME 2...\""
        if lot_key:
            "... but,{w=0.2} it ended up freezing the last time you tried to play it."
            "No use in booting up a broken game."
            hide itemframe with easeoutbottom
        else:
            menu:
                rq "Play it?"
                "Yes":
                    hide itemframe
                    $ inventory.remove(itm_cartridge1)
                    play sfx item
                    
                    ## AUTOSAVE
                    $ renpy.save("mainfile")

                    "You put the cartridge into the game system."
                    call trns_tvtime2 from _call_trns_tvtime2_1
                
                "No":
                    hide itemframe with easeoutbottom
                    if not vex_playtv:
                        $ vex_playtv = True
                        "You decided you weren't interested in playing."
                    else:
                        "You still don't want to play the game."
    
    elif itm_cartridge2 in inventory:
        "You still have that game cartridge without a label..."
        menu:
            rq "Play it?"
            "Yes":
                hide itemframe
                $ inventory.remove(itm_cartridge2)
                play sfx item
                    
                ## AUTOSAVE
                $ renpy.save("mainfile")

                "You put the cartridge into the game system."
                call trns_secretgame from _call_trns_secretgame_1
            
            "No":
                hide itemframe with easeoutbottom
                if not vex_playsecret:
                    $ vex_playsecret = True
                    "You decided you weren't interested in playing."
                else:
                    "You still don't want to play the game."
    
    else:
        "It has a game system attached to it,{w=0.2} but you don't have any games."
        hide itemframe with easeoutbottom

    if lot_key and itm_redshard2 not in inventory:
        pause 0.5
        play sfx plop
        pause 0.5
        $ quick_menu = True
        "As you stepped away from the TV,{w=0.2} something caught your foot."
        play sfx sparkleglock
        show itemframe i_redshard2 at truecenter with easeinbottom
        if vex_natennuh:
            "It looked like a crystal,{w=0.2} similar to the one you got from \"Mr. Natennuh.\""
        else:
            "It looked like a crystal,{w=0.2} similar to the one you got from \"Not Tenna.\""
        "You're certain it wasn't there before you started the game."
        play sfx item
        hide itemframe
        $ inventory.append(itm_redshard2)
        "You picked up the red shard.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        "Although,{w=0.2} the moment you touched it..."
        stop music
        scene black
        "Something overcame your senses."
        jump memoryshard2

    elif mke_game and itm_blueshard not in inventory:
        pause 0.5
        play sfx plop
        pause 0.5
        $ quick_menu = True
        "As you stepped away from the TV,{w=0.2} something caught your foot."
        play sfx sparkleglock
        show itemframe i_blueshard at truecenter with easeinbottom
        "It looks like a cube-shaped crystal."
        "You're pretty sure it wasn't there before you started playing the game."
        play sfx item
        hide itemframe
        $ inventory.append(itm_blueshard)
        if s_memshard:
            $ itm_blueshard.name = "MemoryShard (7/6)"
        "You picked up the blue shard.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        "Although,{w=0.2} the moment you touched it..."
        stop music
        scene black
        "Something overcame your senses."
        jump memoryshard9

    jump ex_gameroom

label trns_tvtime2:
    $ memsh_cutscene = True
    stop music
    show blackpng
    play sfx plop
    pause 1.0
    show tvoverlay zorder 99 with Dissolve(1.0)
    pause 1.0
    play sfx item
    if not persistent.glitches:
        show tv_turnon zorder 97
    show crtoverlay zorder 98
    pause 1.0
    hide tv_turnon
    show lot_tvtime2_map at gamepos zorder 0
    show lot_tvtime2_tree at gamepos zorder 1:
        shader "rgb_split"
        u_intensity 5.0
        u_angle 0

    pause 1.0
    call lot_dia_in from _call_lot_dia_in_6
    narr_lot "WELCOME TO \"TV TIME 2\"!!"
    narr_lot "CLICK THE HOUSES TO MOVE.\nVISIT THEM ALL TO UNLOCK THE EXIT!"
    call lot_dia_out from _call_lot_dia_out_6

    ## go to the game and then come back
    call lot_tvtime2 from _call_lot_tvtime2

    $ inventory.append(itm_cartridge1)
    hide tvoverlay with Dissolve(1.0)
    pause 1.0
    hide blackpng
    $ memsh_cutscene = False
    play music dump

    ## AUTOSAVE
    $ renpy.save("mainfile")

    return

label trns_secretgame:
    $ memsh_cutscene = True
    stop music
    show blackpng
    play sfx plop
    pause 1.0
    show tvoverlay zorder 99 with Dissolve(1.0)
    pause 1.0
    play sfx item
    if not persistent.glitches:
        show tv_turnon zorder 97
    show crtoverlay zorder 98
    pause 1.0
    hide tv_turnon

    ## go to the game and then come back
    call lot_mike from _call_lot_mike

    pause 1.0
    hide tvoverlay with Dissolve(1.0)
    pause 1.0
    hide blackpng
    $ memsh_cutscene = False
    play music dump

    ## AUTOSAVE
    $ renpy.save("mainfile")

    return


######################################################
##### SECRET GAME INTERACT
label ex_secretgame:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_gameroom

    if not vex_secretgame:
        "You spotted something that stuck out amongst all the trash."
        play sfx sparkleglock
        show itemframe i_cartridge2 at truecenter with easeinbottom
        "It seems to be a game cartridge,{w=0.2} but the label has been ripped off."
    else:
        show itemframe i_cartridge2 at truecenter with easeinbottom
        "The game cartridge still remains in the trash."
    menu:
        rq "Pick it up?"
        "Yes":
            play sfx item
            hide itemframe
            $ inventory.append(itm_cartridge2)

            ## AUTOSAVE
            $ renpy.save("mainfile")

            "You picked it up and put it in your pocket.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        
        "No":
            hide itemframe with easeoutbottom
            if not vex_secretgame:
                $ vex_secretgame = True
                "You left the cartridge alone."
            else:
                "You still left the cartridge alone."
    
    jump ex_gameroom



############################################################################################################
################## OG ROOM
label ex_ogroom:
    show screen ex_ogroom

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### OG ROOM VARIABLES
default vex_pipis2 = False # if kept second pipis


######################################################
##### PIPIS INTERACT (variable is in other pipis interact)
label ex_pipis2:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_ogroom

    "You spot something in particular over on the ground,{w=0.2} half-buried in the dirt."
    show itemframe i_pipis at truecenter with easeinbottom
    "...{w=0.5} It's the same object from earlier."
    menu:
        date "Keep it this time?"
        "Yes":
            $ vex_pipis2 = True
            play sfx item
            hide itemframe
            $ inventory.append(itm_pipis)
            $ persistent.itemheard = True

            ## AUTOSAVE
            $ renpy.save("mainfile")

            "You put it in your pocket.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        
        "No":
            hide itemframe with easeoutbottom
            "You still left the strange object alone."
    
    jump ex_ogroom



############################################################################################################
################## TENNA'S HOUSE
label ex_tenhouse:
    if persistent.spamroute_fin and not ten_seen:
        jump ending_tenna
    show screen ex_tenhouse

    $ quick_menu = False
    $ skipyes = False
    $ _skipping = False
    $ renpy.choice_for_skipping()
    $ renpy.pause(hard=True)


######################################################
##### TENNA'S HOUSE VARIABLES
default vex_darkcandy = False # seen dark candy or not
default vex_darkpluck = False # plucked candy or not
default vex_fridge = False # seen fridge or not
default vex_flowerbox = False # seen flowerbox or not
default vex_tendoor = False # interacted with door or not
default vex_knockpull = None # knocked or opened door ; "knock" or "pull"
default vex_window = False # unlocked window interact or not
default vex_window2 = False # seen game in window or not


######################################################
##### DARK CANDY TREE INTERACT
label ex_darkcandy:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse

    show itemframe i_candy at truecenter with easeinbottom
    if not vex_darkcandy:
        $ vex_darkcandy = True

        if (persistent.favefood == "anything" or persistent.favefood == None) and food_ran == "candy":
            "There's a tree with more of that candy Tenna gave you earlier."
        elif persistent.favefood == "candy" or (persistent.favefood == "sweets" and sweets_ran == "candy"):
            "There's a tree with more of that candy Tenna gave you earlier."
        else:
            "There's a tree with some kind of star-like fruit on it."
            "Though,{w=0.2} when you get closer to it,{w=0.2} it smells more like marshmallows."
    else:
        "The candy tree remains."

    if itm_candy not in inventory:
        if vex_darkpluck:
            "But, you think you've had enough candy for one day."
            hide itemframe with easeoutbottom
        else:
            if (persistent.favefood == "anything" or persistent.favefood == None) and food_ran == "candy":
                "You could grab another one,{w=0.2} even though it wasn't that good the first time."
            elif persistent.favefood == "candy" or (persistent.favefood == "sweets" and sweets_ran == "candy"):
                "You could grab another one,{w=0.2} even though it wasn't that good the first time."
            else:
                "They're easily within reach,{w=0.2} so you could grab one if you wanted."
            menu:
                rq "Take one?"
                "Yes":
                    hide itemframe
                    play sfx item
                    $ inventory.append(itm_candy)
                    $ vex_darkpluck = True

                    ## AUTOSAVE
                    $ renpy.save("mainfile")

                    "You plucked one off of the tree.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                
                "No":
                    hide itemframe with easeoutbottom
                    "You decided you didn't need one."
    
    else:
        if (persistent.favefood == "anything" or persistent.favefood == None) and food_ran == "candy":
            if p_candy:
                "You still have the candy Tenna gave you earlier, though."
            elif vex_darkpluck:
                "You still have the second candy you picked earlier, though."
        elif persistent.favefood == "candy" or (persistent.favefood == "sweets" and sweets_ran == "candy"):
            if p_candy:
                "You still have the candy Tenna gave you earlier, though."
            elif vex_darkpluck:
                "You still have the second candy you picked earlier, though."
        else:
            if vex_darkpluck:
                "You still have the candy you picked earlier, though."
        hide itemframe with easeoutbottom

    jump ex_tenhouse


######################################################
##### FRIDGE INTERACT
label ex_fridge:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse

    "There's a broken fridge plugged into nothing."
    menu:
        rq "Open it?"
        "Yes":
            "You peek inside..."
            play sfx click
            pause 1.0
        "No":
            "There's no reason to open it."
            jump ex_tenhouse

    if vex_fridge:
        "There's nothing else in here that interests you."
        jump ex_tenhouse

    elif persistent.favefood == "anything" or persistent.favefood == None:
        if food_ran == "baked goods" or food_ran == "candy":
            show itemframe i_pie at truecenter with easeinbottom
            if food_ran == "baked goods":
                "It's a pie,{w=0.2} like the one Tenna offered you earlier."
            elif food_ran == "candy":
                "It's a pie that smells faintly of butterscotch and cinnamon."
        elif food_ran == "fries":
            show itemframe i_fries at truecenter with easeinbottom
            "It's a serving of fries,{w=0.2} like the one Tenna offered you earlier."
        elif food_ran == "pretzels":
            show itemframe i_pretzels at truecenter with easeinbottom
            "It's a large pretzel,{w=0.2} like the one Tenna offered you earlier."
        elif food_ran == "chocolate":
            show itemframe i_chocolate at truecenter with easeinbottom
            "It's a cup of hot chocolate,{w=0.2} like the one Tenna offered you earlier."
        elif food_ran == "coffee":
            show itemframe i_coffee at truecenter with easeinbottom
            "It's a cup of coffee,{w=0.2} like the one Tenna offered you earlier."
    else:
        if persistent.favefood == "sweets" or persistent.favefood == "baked goods" or persistent.favefood == "candy":
            show itemframe i_pie at truecenter with easeinbottom
            if sweets_ran == "candy" or persistent.favefood == "candy":
                "It's a pie that smells faintly of butterscotch and cinnamon."  
            else:
                "It's a pie,{w=0.2} like the one Tenna offered you earlier."          
        elif (persistent.favefood == "salty foods" and salty_ran == "fries") or persistent.favefood == "fries":
            show itemframe i_fries at truecenter with easeinbottom
            "It's a serving of fries,{w=0.2} like the one Tenna offered you earlier."
        elif (persistent.favefood == "salty foods" and salty_ran == "pretzels") or persistent.favefood == "pretzels":
            show itemframe i_pretzels at truecenter with easeinbottom
            "It's a large pretzel,{w=0.2} like the one Tenna offered you earlier."            
        elif (persistent.favefood == "bitter foods" and bitter_ran == "chocolate") or persistent.favefood == "chocolate":
            show itemframe i_chocolate at truecenter with easeinbottom
            "It's a cup of hot chocolate,{w=0.2} like the one Tenna offered you earlier."            
        elif (persistent.favefood == "bitter foods" and bitter_ran == "coffee") or persistent.favefood == "coffee":
            show itemframe i_coffee at truecenter with easeinbottom
            "It's a cup of coffee,{w=0.2} like the one Tenna offered you earlier."

    if not p_foodkeep:
        if (persistent.favefood == "anything" or persistent.favefood == None) and food_ran == "candy":
            pass
        elif persistent.favefood == "candy" or (persistent.favefood == "sweets" and sweets_ran == "candy"):
            pass
        else:
            "In fact...{w=0.5} it might actually be the same one."

    if itm_pie in inventory or itm_fries in inventory or itm_pretzel in inventory or itm_cocoa in inventory or itm_coffee in inventory:
        "But you already have some,{w=0.2} so you don't need anymore."
        hide itemframe with easeoutbottom
    else:
        menu:
            rq "Keep it?"
            "Yes":
                $ vex_fridge = True
                hide itemframe
                play sfx item
                if persistent.favefood == "anything" or persistent.favefood == None:
                    if food_ran == "baked goods" or food_ran == "candy":
                        $ inventory.append(itm_pie)
                    elif food_ran == "fries":
                        $ inventory.append(itm_fries)
                    elif food_ran == "pretzels":
                        $ inventory.append(itm_pretzel)
                    elif food_ran == "chocolate":
                        $ inventory.append(itm_cocoa)
                    elif food_ran == "coffee":
                        $ inventory.append(itm_coffee)
                
                else:
                    if persistent.favefood == "sweets" or persistent.favefood == "baked goods" or persistent.favefood == "candy":
                        $ inventory.append(itm_pie)
                    elif (persistent.favefood == "salty foods" and salty_ran == "fries") or persistent.favefood == "fries":
                        $ inventory.append(itm_fries)
                    elif (persistent.favefood == "salty foods" and salty_ran == "pretzels") or persistent.favefood == "pretzels":
                        $ inventory.append(itm_pretzel)
                    elif (persistent.favefood == "bitter foods" and bitter_ran == "chocolate") or persistent.favefood == "chocolate":
                        $ inventory.append(itm_cocoa)
                    elif (persistent.favefood == "bitter foods" and bitter_ran == "coffee") or persistent.favefood == "coffee":
                        $ inventory.append(itm_coffee)
                
                ## AUTOSAVE
                $ renpy.save("mainfile")

                if not p_foodkeep:
                    if (persistent.favefood == "anything" or persistent.favefood == None) and food_ran == "candy":
                        "You kept the food,{w=0.2} for some reason.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                    elif persistent.favefood == "candy" or (persistent.favefood == "sweets" and sweets_ran == "candy"):
                        "You kept the food,{w=0.2} for some reason.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                    else:
                        "You decided to keep the food this time,{w=0.2} for some reason.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                
                else:
                    "You kept the food,{w=0.2} for some reason.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."

            "No":
                hide itemframe with easeoutbottom
                "You don't need that at all."

    jump ex_tenhouse


######################################################
##### FLOWERBOX INTERACT
label ex_flowerbox:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse

    "A small garden is growing out of a handmade flowerbox."
    if not vex_flowerbox:
        $ vex_flowerbox = True
        "There's a bunch of flowers as well as some vegetables growing towards the back."
    
    if itm_flower not in inventory:
        show itemframe i_flower at truecenter with easeinbottom
        "You could pick one of the flowers,{w=0.2} if you really felt you needed to."
        menu:
            rq "Take one?"
            "Yes":
                hide itemframe
                play sfx item
                $ inventory.append(itm_flower)

                ## AUTOSAVE
                $ renpy.save("mainfile")

                "You reluctantly and carefully plucked one.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
           
            "No":
                hide itemframe with easeoutbottom
                "It's not your garden to mess with, after all."
    
    else:
        "You already have a flower, though."

    jump ex_tenhouse


######################################################
##### FRONT DOOR INTERACT
label ex_tendoor:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse

    if not vex_tendoor:
        "You walked up to the door on the little red house."
        "Considering the building looks like it was made from scrap wood,{w=0.2} you can't really tell if it's locked or not."
        menu:
            rq "What will you do?"
            "Knock":
                pause 0.5
                $ vex_knockpull = "knock"
                play sfx knock
                pause 3.0
                "...{w=0.5} No one answered."
            "Try to open door":
                $ vex_knockpull = "pull"
                "You tried pushing open the door,{w=0.2} to no avail."
                "Something must be jamming it shut from the other side."
            "Walk away":
                "You stepped away from the door."
                jump ex_tenhouse
        $ vex_tendoor = True
        $ vex_window = True
        "Though,{w=0.2} now that you're closer to the building...{p=0.5}{noalt}*{/noalt} It looks like the window is completely open."
    
    else:
        if vex_knockpull == "knock":
            "Seems no one's home."
        elif vex_knockpull == "pull":
            "The door won't budge."

    jump ex_tenhouse


######################################################
##### WINDOW INTERACT
label ex_window:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    hide screen ex_tenhouse

    "You peeked into the window on the house."
    if itm_cartridge1 not in inventory:
        show itemframe i_blanket at truecenter with easeinbottom
        if not vex_window2:
            "It looks like there's something tangled within a blanket on the floor."
            "There's no way you could fit through,{w=0.2} but you might be able to reach your arm inside."
        else:
            "That game cartridge is still on the floor."
        menu:
            rq "Try to reach in?"
            "Yes":
                hide itemframe with easeoutbottom
                play sfx plop
                if not vex_window2:
                    "You stick your arm through the window."
                else:
                    "You go to reach for the cartridge once again."
                play sfx sparkleglock
                show itemframe i_cartridge1 at truecenter with easeinbottom
                if not vex_window2:
                    $ vex_window2 = True
                    "You managed to fish out a game cartridge."
                menu:
                    rq "Keep it?"
                    "Yes":
                        hide itemframe
                        play sfx item
                        $ inventory.append(itm_cartridge1)

                        ## AUTOSAVE
                        $ renpy.save("mainfile")

                        "You obtained the game cartridge.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                    
                    "No":
                        hide itemframe with easeoutbottom
                        "It's not yours, after all."
            
            "No":
                hide itemframe with easeoutbottom
                "It's not your house, after all."
    
    else:
        show itemframe i_blanket2 at truecenter with easeinbottom
        "There doesn't seem to be anything else worth grabbing within reach."
        hide itemframe with easeoutbottom

    jump ex_tenhouse



############################################################################################################
################## DARKNESS HALLWAY
default vex_darksee = False # interacted with this before
default vex_darklocation = None # where are they coming from ; "north" or "og"

label ex_darkness:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True

    if not vex_darksee:
        pause 2.0
        "There seems to be nothing here...{w=0.2} but also nothing preventing you from going forward."
        menu:
            rq "Keep going?"
            "Yes":
                "You held a brave face and kept walking."
            "No":
                "You figured it would be best to turn back."
                jump trns_dark_north

        play sfx waterwalk
        pause 3.0
        stop sfx fadeout 1.0
        pause 1.0
        "The darkness just doesn't seem to end..."
        "You can't even see where you came from at this point."
        menu:
            rq "Keep going?"
            "I guess":
                "You suppose you've got nothing better to do."
            "Maybe not":
                "You figured it would be best to turn back."
                jump trns_dark_north

        play sfx waterwalk
        pause 3.0
        stop sfx fadeout 1.0
        pause 1.0
        "At long last,{w=0.2} there seems to be something visible in the distance."
        "How long has it been by now...?{p=0.5}{noalt}*{/noalt} It feels like hours,{w=0.2} but that can't be right."
        $ vex_darksee = True

    else:
        $ quick_menu = False
        $ skipyes = False
        $ _skipping = False
        pause 1.0

    if vex_darklocation == "north":
        $ rightclick_icon = True
        jump trns_dark_og
    elif vex_darklocation == "og":
        $ rightclick_icon = False
        jump trns_dark_north