############################################################################################################
################## GAME START
label lot_intro:
    show tenna upright pointing oh at jump
    if not lot_played:
        tenna "Let me set this up real quick here.{p=0.5}{noalt}*{/noalt} It'll be just ONE second!"
    else:
        tenna "I'll set things up again in a jiffy!{p=0.5}{noalt}*{/noalt} Just leave it to good ol' Mr. Tenna!"
    
    $ memsh_cutscene = True
    $ renpy.choice_for_skipping()
    hide screen datestats
    stop music
    hide tenna with easeoutright
    pause 1.0
    stop music
    play sfx slam
    scene black
    show parkboard2 zorder 98
    pause 2.0
    play sfx slideaway
    show tenna lotoverlay at tenpos_game zorder 100 with easeinright
    pause 1.0
    show tenna at jump

    if not lot_played:
        tenna_bub "Okay, this should work!"
        tenna_bub "I'll just sit here right next to you, alright?"
        tenna_bub "Annnnd..."
        play sfx item
        show map start at gamepos
        show lot_tenna idle at gamepos_tenna zorder 97
        pause 1.0
        show tenna at jump
        tenna_bub "Ta-da!"
        tenna_bub "It's a projector, so it's not the BEST it could be..."
        tenna_bub "But we make do and adapt! Right?!"
        tenna_bub "Haha..."
        pause 1.0
        show tenna at jump
        tenna_bub "A- anyway! My controller's already connected, so..."
        tenna_bub "Oh, silly me! I almost forgot!"
        play sfx sparkleglock
        show itemframe i_nes at truecenter zorder 100 with easeinbottom
        show tenna at jump
        tenna_bub "One controller, just for you!"
        play sfx item
        $ inventory.append(itm_nes)
        "You got the Game Controller.{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
        hide itemframe with easeoutbottom
        pause 0.5
        play sfx lot_enter
        show hero_wit_gnr idle at gamepos_vess zorder 97

    else:
        tenna_bub "Back in business!"
        tenna_bub "Ready whenever you are, [persistent.mc]!"
        play sfx lot_enter
        show hero_wit_gnr idle at gamepos_vess zorder 97


######################################################
##### PROPER START / WHERE TO GO WHEN RESTARTING
label lot:
    if lot_replay or lot_played:
        scene black
        show parkboard2 zorder 98
        show map start at gamepos
        show lot_tenna idle at gamepos_tenna zorder 97
        show hero_wit_gnr idle at gamepos_vess zorder 97
        show tenna lotoverlay at tenpos_game zorder 100

    $ lot_life = 3
    $ lot_repeat = False
    show screen lot_healthbar
    pause 1.0
    play music bigcityboard

    ## if beaten the tutorial
    if lot_tutorial_win:
        ## randomly choose an enemy
        $ lot_enemy = renpy.random.choice(["Shadowguy", "Flower"])

        if lot_enemy == "Shadowguy":
            $ lot_enemy_act = "Flirt"
            $ lot_boss_act = "Flirt"
            $ lot_repeat = True
        elif lot_enemy == "Flower":
            $ lot_enemy_act = "Flirt"
            $ lot_boss_act = "Talk"
            if lot_flowey:
                $ lot_repeat = True
    
    ## tutorial enemy
    else:
        $ lot_enemy = "Shadowguy"
        $ lot_enemy_act = "Flirt"
        $ lot_boss_act = "Flirt"

    show tenna at jump

    ## tutorial
    if not lot_tutorial_win:
        if lot_tutorial_fail == 1:
            tenna_bub "You didn't win last time, but that's a-okay!"
            tenna_bub "Now you've got more experience!"
            tenna_bub "I'm sure you'll get it this time."
        elif lot_tutorial_fail == 2:
            tenna_bub "Well, uh, you know what they say! Third time's the charm!"
            tenna_bub "Let's go ahead and try again, shall we?"
        elif lot_tutorial_fail == 3:
            tenna_bub "Okay, sure. Let's replay again."
            tenna_bub "You know, I'm starting to suspect you're doing this on purpose."
            tenna_bub "It's fine! Carry on, [persistent.mc]!"
        elif lot_tutorial_fail == 4:
            tenna_bub "You have to be doing this on purpose."
        elif lot_tutorial_fail >= 5:
            tenna_bub "Sure, [persistent.mc]."
            tenna_bub "Replay the tutorial as many times as you want."
        else:
            tenna_bub "Now that everything's set up, we're good to go!"
            tenna_bub "I'll show ya the ropes as we play."
            

    ## done with tutorial
    else:
        if lot_replay:
            $ lot_tentext = renpy.random.randint(1,4)
            if lot_tentext == 1:
                tenna_bub "Good luck, [persistent.mc]!"
            elif lot_tentext == 2:
                tenna_bub "Let's see what ENEMYs show up this time..."
            elif lot_tentext == 3:
                tenna_bub "I'd love to keep playing, [persistent.mc]!"
            elif lot_tentext == 4:
                tenna_bub "Let's go! One more time!"
        else:
            tenna_bub "It feels good to be playing another round!"
            tenna_bub "Don't you think, [persistent.mc]?"
            tenna_bub "I'm just really happy you're having so much fun with this, haha!"


######################################################
##### TRANSITION TO ENEMY
label lot_walking:
    show map world
    show lot_tenna walk
    show hero_wit_gnr walk

    ## tutorial
    if not lot_tutorial_win:
        if lot_tutorial_fail == 1:
            $ renpy.pause(4, hard=True)
            show tenna at jump
            tenna_bub "You remember what the strategy is, right?{nw=2}" (advance=False)
            $ renpy.pause(4, hard=True)
            show tenna at jump
            tenna_bub "No, I didn't assume you FORGOT, haha!{nw=2}" (advance=False)
            $ renpy.pause(6, hard=True)
        elif lot_tutorial_fail == 2:
            $ renpy.pause(5, hard=True)
            show tenna at jump
            tenna_bub "Don't worry about the past couple of times!{nw=2}" (advance=False)
            $ renpy.pause(3, hard=True)
            show tenna at jump
            tenna_bub "I'm sure you'll beat it this time!{nw=2}" (advance=False)
            $ renpy.pause(6, hard=True)
        elif lot_tutorial_fail == 3:
            $ renpy.pause(6, hard=True)
            show tenna at jump
            tenna_bub "You're... SURE you've got this?{nw=2}" (advance=False)
            $ renpy.pause(3, hard=True)
            show tenna at jump
            tenna_bub "Right, right, sorry!{nw=1}" (advance=False)
            tenna_bub "You're the one playing, not me, haha!{nw=2}" (advance=False)
            $ renpy.pause(4, hard=True)
        elif lot_tutorial_fail == 4:
            show tenna at jump
            tenna_bub "Could you at least... try to win this time?{nw=2}" (advance=False)
            $ renpy.pause(1,hard=True)
            show tenna at jump
            tenna_bub "Not to rain on your parade or anything!{nw=2}" (advance=False)
            tenna_bub "You do you! Do what makes you happy, of course!{nw=2}" (advance=False)
            tenna_bub "Haha...{nw=2}" (advance=False)
            $ renpy.pause(8, hard=True)
        elif lot_tutorial_fail >= 5:
            $ renpy.pause(20,hard=True)
        else:
            show tenna at jump
            tenna_bub "Onward, [persistent.mc]!{nw=1}" (advance=False)
            $ renpy.pause(3,hard=True)
            show tenna at jump
            tenna_bub "Keep going this direction and something'll show up!{nw=2}" (advance=False)
            $ renpy.pause(6,hard=True)
            show tenna at jump
            tenna_bub "Aaaaanny minute now...{nw=2}" (advance=False)
            $ renpy.pause(4, hard=True)

    ## not the tutorial        
    else:
        $ lot_tentext = renpy.random.randint(1,4)

        if lot_tentext == 1:
            $ renpy.pause(4,hard=True)
            show tenna at jump
            tenna_bub "So... you're having fun playing this, right?{nw=2}" (advance=False)
            $ renpy.pause(6, hard=True)
            show tenna at jump
            tenna_bub "Just checking!{nw=2}" (advance=False)
            $ renpy.pause(5, hard=True)
        elif lot_tentext == 2:
            $ renpy.pause(2,hard=True)
            show tenna at jump
            tenna_bub "This map always feels really long, doesn't it?{nw=2}" (advance=False)
            tenna_bub "I'm just so excited to see what you get next!{nw=2}" (advance=False)
            $ renpy.pause(5,hard=True)
            show tenna at jump
            tenna_bub "(... I really should have made this path shorter...){nw=2}" (advance=False)
            $ renpy.pause(3, hard=True)
        elif lot_tentext == 3:
            $ renpy.pause(2,hard=True)
            show tenna at jump
            tenna_bub "It's so much fun playing games with someone, isn't it?{nw=2}" (advance=False)
            $ renpy.pause(2, hard=True)
            show tenna at jump
            tenna_bub "Well, I think so, anyway!{nw=2}" (advance=False)
            tenna_bub "It's great just being able to be by your side!{nw=3}" (advance=False)
            $ renpy.pause(6,hard=True)
        elif lot_tentext == 4:
            $ renpy.pause(5,hard=True)
            if p_dateno:
                show tenna at jump
                tenna_bub "I'm having a great time hanging out with you, [persistent.mc].{nw=2}" (advance=False)
            else:
                show tenna at jump
                tenna_bub "I'm having a great time on this date with you, [persistent.mc].{nw=2}" (advance=False)
            $ renpy.pause(4, hard=True)
            show tenna at jump
            tenna_bub "Don't you agree?{nw=2}" (advance=False)
            $ renpy.pause(5, hard=True)
    
    hide map
    show map battle at gamepos
    show lot_tenna idleB
    show hero_wit_gnr walk2
    pause 0.5

    ## ENEMY APPEARS
    if lot_enemy == "Shadowguy":
        show shadowguy walk at gamepos_enemy_st zorder 97
        show shadowguy at gamepos_enemy_fin with MoveTransition(2.0)
        show shadowguy idle1

    elif lot_enemy == "Flower":
        show dino idle at gamepos_enemy_st zorder 97
        show dino at gamepos_enemy_fin with MoveTransition(2.0)

    show tenna at jump

    ## tutorial
    if not lot_tutorial_win:
        if lot_tutorial_fail == 1:
            tenna_bub "Back again!"
            tenna_bub "I'm sure you've got it this time."
        elif lot_tutorial_fail == 2:
            tenna_bub "Alright! You got this!"
        elif lot_tutorial_fail == 3:
            tenna_bub "Do you want a hint or something this time...?"
            tenna_bub "No? That's okay too!"
            tenna_bub "Do your best, [persistent.mc]!"
        elif lot_tutorial_fail == 4:
            tenna_bub "..."
        elif lot_tutorial_fail >= 5:
            pass
        else:
            tenna_bub "There it is! An ENEMY appeared!"
            tenna_bub "Though, you can't attack them! That'd be rude!"
            tenna_bub "There should be two options..."
            tenna_bub "Pick whichever you want!!"
            tenna_bub "Just know that some folks prefer one over the other."
            tenna_bub "They'll be sure to let you know if they're insulted!"

    ## not the tutorial
    else:
        if lot_repeat:
            if not lot_repeat_seen:
                $ lot_repeat_seen = True
                if lot_enemy == "Shadowguy":
                    tenna_bub "What? The tutorial one AGAIN?"
                else:
                    tenna_bub "What? This one AGAIN?"
                tenna_bub "Oh, uh..."
                tenna_bub "The ENEMYs are random, so it looks like we got a repeat!"
                tenna_bub "Sorry about that!"
                tenna_bub "It should be really easy to beat this time, though! You got this!"
            else:
                $ lot_tentext = renpy.random.randint(1,4)
                if lot_tentext == 1:
                    tenna_bub "Sigh. Another repeat."
                    tenna_bub "It's okay! It'll be easier this time!"
                elif lot_tentext == 2:
                    tenna_bub "Ah."
                    tenna_bub "Maybe I should have put in more ENEMYs..."
                    tenna_bub "I mean. Have fun, [persistent.mc]!"
                elif lot_tentext == 3:
                    tenna_bub "Well, we've seen this one before..."
                    tenna_bub "You remember how to beat it, right?"
                elif lot_tentext == 4:
                    tenna_bub "This one AGAIN?"
                    tenna_bub "Haha, um. I mean."
                    tenna_bub "I promise there's more variety! Just clear this and we'll get to it!"
        else:
            if lot_enemy == "Flower":
                tenna_bub "Oh, this one!"
                tenna_bub "I wonder if you can figure out the theme, haha!"


######################################################
##### ENEMY BATTLE
label lot_battle:
    menu:
        rq "What will you do?"
        "Flirt":
            $ lot_act = "Flirt"
        "Talk":
            $ lot_act = "Talk"

    play sfx lot_sparkle
    show hero_wit_gnr flirt

    if lot_enemy_act == lot_act:
        if lot_enemy == "Shadowguy":
            show shadowguy blush
        elif lot_enemy == "Flower":
            show dino blush
    else:
        if lot_enemy == "Shadowguy":
            show shadowguy hurt
        elif lot_enemy == "Flower":
            show dino idle2
    
    pause 1.0

    ## SUCCESS
    if lot_enemy_act == lot_act:
        play sfx lot_defeatrun
        show lot_sweat flicker:
            xpos 0.57
            ypos 0.32
        if lot_enemy == "Shadowguy":
            show shadowguy run
            show shadowguy at gamepos_enemy_st with MoveTransition(0.5)
            hide shadowguy
            hide lot_sweat
        elif lot_enemy == "Flower":
            show dino run 
            show dino at gamepos_enemy_st with MoveTransition(0.5) 
            hide dino
            hide lot_sweat

        pause 1.0
        show tenna at jump

        ## tutorial
        if not lot_tutorial_win:
            if not lot_tutorial_enemy:
                $ lot_tutorial_enemy = True
                if lot_tutorial_fail < 4:
                    tenna_bub "Looks like they got a bit flustered!"
                    tenna_bub "Your charm is just too much for them!"
                    tenna_bub "Now that you've beaten them, let's move on!"
                else:
                    tenna_bub "Wow! You actually made it through!"
                    tenna_bub "I'd say I'm impressed, but..."
                    tenna_bub "Well, let's try the BOSS this time!"
            elif not lot_tutorial_boss and lot_tutorial_fail > 3:
                tenna_bub "You finally got through! Good job!"
                tenna_bub "Let's FINALLY move on!!"
            else:
                if lot_tutorial_fail >= 3:
                    tenna_bub "Okay. Good."
                    tenna_bub "Now just... beat the BOSS this time."
                else:
                    tenna_bub "Good job, [persistent.mc]!"
                    tenna_bub "The ENEMY got flustered and ran away!"
                    tenna_bub "Let's move on to the BOSS now, shall we?"

        ## not tutorial
        else:
            $ lot_tentext = renpy.random.randint(1,4)
            if lot_repeat:
                if lot_tentext == 1:
                    tenna_bub "There you go! You nailed it!"
                    tenna_bub "It may be a repeat, but your success is still worth celebrating!"
                elif lot_tentext == 2:
                    tenna_bub "You're a practiced professional!"
                    tenna_bub "Let's keep going, shall we?"
                elif lot_tentext == 3:
                    tenna_bub "I knew you'd remember the strategy!"
                    tenna_bub "Isn't this game just so INVESTING?"
                elif lot_tentext == 4:
                    tenna_bub "SPLENDID! Time for the BOSS now!"
            else:
                if lot_tentext == 1:
                    tenna_bub "Nice job, [persistent.mc]! I knew you could do it!"
                elif lot_tentext == 2:
                    tenna_bub "You did that like an absolute PRO!"
                elif lot_tentext == 3:
                    tenna_bub "Haha! You're so good at this you don't even need me here!"
                    tenna_bub "..."
                    tenna_bub "Moving on!"
                elif lot_tentext == 4:
                    tenna_bub "TV-tastic performance, [persistent.mc]!!"
        
        jump lot_intermission

    ## FAIL
    else:
        $ lot_life -= 1

        if lot_enemy == "Shadowguy":
            show shadowguy idle1
        elif lot_enemy == "Flower":
            show dino idle

        play sfx lot_ouch
        show hero_wit_gnr damage ani
        show lot_slash ani:
            xpos 0.4
            ypos 0.35
        pause 1.0
        hide lot_slash

        ## GAME OVER
        if lot_life == 0:
            jump lot_gameover

        elif lot_life == 2:
            show tenna at jump

            ## tutorial
            if not lot_tutorial_win:
                if lot_tutorial_fail == 1:
                    tenna_bub "Nope, they don't like that one!"
                elif lot_tutorial_fail == 2:
                    tenna_bub "You... know that's not working, right?"
                elif lot_tutorial_fail == 3:
                    tenna_bub "Are you SURE you don't need a hint?"
                elif lot_tutorial_fail == 4:
                    tenna_bub "Ah."
                elif lot_tutorial_fail >= 5:
                    pass
                else:
                    tenna_bub "Yikes! Guess they didn't like that one."

            ## not tutorial
            else:
                if lot_repeat:
                    tenna_bub "Did you just want to see what happened...?"
                    tenna_bub "You've done this before, c'mon!"
                else:
                    tenna_bub "Seems that wasn't the right option!"
                
        elif lot_life == 1:
            show tenna at jump

            ## tutorial
            if not lot_tutorial_win:
                if lot_tutorial_fail == 1:
                    tenna_bub "Maybe try the other option?"
                elif lot_tutorial_fail == 2:
                    tenna_bub "Remember: there's two options, [persistent.mc]!"
                elif lot_tutorial_fail == 3:
                    tenna_bub "Haha..."
                elif lot_tutorial_fail == 4:
                    tenna_bub "..."
                elif lot_tutorial_fail >= 5:
                    pass
                else:
                    tenna_bub "Nope! Still not right!"

            ## not tutorial
            else:
                if lot_repeat:
                    tenna_bub "Really, [persistent.mc]?"
                    if lot_tutorial_fail >= 3:
                        tenna_bub "Again?"
                else:
                    tenna_bub "Haha! Are you just messing around?"
                    tenna_bub "There's. Only two options"

        jump lot_battle


######################################################
##### TRANSITION TO BOSS
label lot_intermission:
    stop music
    show hero_wit_gnr walk2
    $ lot_boss_life = 3

    if lot_enemy == "Shadowguy":
        show pluey idle at gamepos_enemy_st zorder 97
        show pluey at gamepos_enemy_fin with MoveTransition(2.0)
    elif lot_enemy == "Flower":
        show flowey idle at gamepos_enemy_st zorder 97
        show flowey at gamepos_enemy_fin with MoveTransition(2.0)
    
    play music southoftheborder
    show screen lot_bossbar

    pause 1.0
    show tenna at jump

    ## tutorial
    if not lot_tutorial_win:
        if not lot_tutorial_boss:
            $ lot_tutorial_boss = True
            tenna_bub "Welcome to your very first BOSS battle!"
            tenna_bub "The gameplay's pretty much the same, but..."
            tenna_bub "You'll need to do the right action THREE TIMES!"
            tenna_bub "Don't worry, I'm sure you've got this!"
        elif lot_tutorial_fail == 1 or lot_tutorial_fail == 2:
            tenna_bub "You'll need to do the right action THREE TIMES!"
        elif lot_tutorial_fail == 3:
            tenna_bub "Here's a tip-- choose the correct action THREE TIMES!"
        elif lot_tutorial_fail >= 4:
            pass

    ## not tutorial
    else:
        if lot_repeat:
            $ lot_tentext = renpy.random.randint(1,4)
            if lot_tentext == 1:
                tenna_bub "You've already fought this boss before, but..."
                tenna_bub "It's okay! It'll go EVEN better this time, right?"
                tenna_bub "You've got experience!!"
            elif lot_tentext == 2:
                tenna_bub "Alrighty, time for the RERUN on this boss battle!"
                tenna_bub "Things are ALWAYS better when you replay them!"
            elif lot_tentext == 3:
                tenna_bub "BOSS time!"
                tenna_bub "I trust you remember the strategy, [persistent.mc]!"
            elif lot_tentext == 4:
                tenna_bub "And now the moment you've been waiting for..."
                tenna_bub "The BOSS!"
                tenna_bub "Again."
        else:
            if lot_enemy == "Flower":
                $ lot_flowey = True
                tenna_bub "Yup, that's right!"
                tenna_bub "The theme was YELLOW!"
                if persistent.favecolor == "yellow":
                    tenna_bub "Hey, wasn't that your favorite color?"


######################################################
##### BOSS BATTLE
label lot_bossbattle:
    menu:
        rq "What will you do?"
        "Flirt":
            $ lot_act = "Flirt"
        "Talk":
            $ lot_act = "Talk"

    play sfx lot_sparkle
    show hero_wit_gnr flirt

    if lot_boss_act == lot_act:
        if lot_enemy == "Shadowguy":
            show pluey blush
        elif lot_enemy == "Flower":
            show flowey blush
    else:
        if lot_enemy == "Shadowguy":
            show pluey hurt
        elif lot_enemy == "Flower":
            pass
    
    pause 1.0

    ## SUCCESS
    if lot_boss_act == lot_act:
        $ lot_boss_life -= 1
        if lot_enemy == "Shadowguy":
            show pluey idle
        elif lot_enemy == "Flower":
            show flowey idle

        pause 0.5
        
        if lot_boss_life > 0:
            show tenna at jump
            
            ## tutorial
            if not lot_tutorial_win:
                if lot_boss_life == 2:
                    tenna_bub "You got it, [persistent.mc]!"
                    tenna_bub "Now just two more times!"
                else:
                    tenna_bub "Once more!"
            
            ## not tutorial
            else:
                $ lot_tentext = renpy.random.randint(1,4)
                if lot_boss_life == 2:
                    if lot_tentext == 1:
                        tenna_bub "You're really getting the hang of this, [persistent.mc]!"
                    elif lot_tentext == 2:
                        tenna_bub "You nailed it!"
                    elif lot_tentext == 3:
                        tenna_bub "Just two more of that and you're golden!"
                    elif lot_tentext == 4:
                        tenna_bub "Look at you go!"
                else:
                    if lot_tentext == 1:
                        tenna_bub "One more time!"
                    elif lot_tentext == 2:
                        tenna_bub "This isn't getting too repetitive, is it?"
                    elif lot_tentext == 3:
                        tenna_bub "Isn't this so much fun?!"
                    elif lot_tentext == 4:
                        tenna_bub "You don't even need me here to guide you!"
            
            show hero_wit_gnr walk2
            jump lot_bossbattle

        else:
            play sfx lot_defeatrun
            show lot_sweat flicker:
                xpos 0.57
                ypos 0.32
            pause 0.0
            if lot_enemy == "Shadowguy":
                show pluey blushR:
                    xpos 0.8
                with MoveTransition(0.5)
                hide pluey
                hide lot_sweat
            elif lot_enemy == "Flower":
                show flowey:
                    xpos 0.8
                with MoveTransition(0.5) 
                hide flowey
                hide lot_sweat

            stop music
            pause 1.0
            show hero_wit_gnr idle
            hide screen lot_bossbar
            play music pushingbuddies
            pause 1.0
            show tenna at jump

            ## tutorial
            if not lot_tutorial_win:
                $ lot_tutorial = True
                $ lot_tutorial_win = True
                if lot_tutorial_fail >= 4:
                    tenna_bub "Oh FINALLY."
                    tenna_bub "I mean."
                tenna_bub "Nice job, [persistent.mc]!"
                tenna_bub "You beat the tutorial!"
                if 4 > lot_tutorial_fail >= 1:
                    tenna_bub "It took a couple tries, but you got there!"
                    tenna_bub "That's what matters, isn't it?"
                elif lot_tutorial_fail == 4:
                    tenna_bub "Were you actually just struggling that entire time?"
                    tenna_bub "Ah, nevermind!"
                tenna_bub "Now you can play the rest of the game!"

            ## not tutorial
            else:
                $ lot_tentext = renpy.random.randint(1,4)
                if lot_repeat:
                    if lot_tentext == 1:
                        tenna_bub "Nice job, [persistent.mc]!"
                        tenna_bub "Hopefully we'll get a different ENEMY this next round..."
                    elif lot_tentext == 2:
                        tenna_bub "NICE! I knew you could do it!!"
                        tenna_bub "Of course, I already watched you do it before, haha."
                    elif lot_tentext == 3:
                        tenna_bub "Nothing stands in your way, [persistent.mc]!"
                    elif lot_tentext == 4:
                        tenna_bub "Doesn't matter how many times you do the same boss--"
                        tenna_bub "You always pass with FLYING colors, haha!"
                else:
                    if lot_tentext == 1:
                        tenna_bub "You're a STAR, [persistent.mc]!"
                        tenna_bub "The best charmer this side of the Dark Fountain!"
                    elif lot_tentext == 2:
                        tenna_bub "Is there no one who can resist your flirting techniques?"
                        tenna_bub "Hm? What? ME?"
                        tenna_bub "I thought it was already obvious I liked you, [persistent.mc]!"
                    elif lot_tentext == 3:
                        tenna_bub "That boss didn't stand a chance! Good job!!"
                    elif lot_tentext == 4:
                        tenna_bub "And that's a KNOCKOUT from [persistent.mc]'s corner!"
                        tenna_bub "You'll get everyone swooning over you in no time!"

            jump lot_replaymenu

    ## FAIL
    else:
        $ lot_life -= 1

        if lot_enemy == "Shadowguy":
            pass
        elif lot_enemy == "Flower":
            pass

        play sfx lot_ouch
        show hero_wit_gnr damage ani
        show lot_slash ani:
            xpos 0.4
            ypos 0.35
        pause 1.0
        hide lot_slash
        show pluey idle

        ## GAME OVER
        if lot_life == 0:
            jump lot_gameover
        
        elif lot_life == 2:
            show tenna at jump

            ## tutorial
            if not lot_tutorial_win:
                if lot_tutorial_fail == 0:
                    tenna_bub "Whoopsies! He doesn't like that, it seems."
                    tenna_bub "Must be the other option!"
                elif lot_tutorial_fail == 1:
                    tenna_bub "Nope, he doesn't like that one!"
                elif lot_tutorial_fail == 2:
                    tenna_bub "You... know that's not working, right?"
                elif lot_tutorial_fail == 3:
                    tenna_bub "Are you SURE you don't need any hints?"
                elif lot_tutorial_fail == 4:
                    tenna_bub "Ah."
                elif lot_tutorial_fail >= 5:
                    pass

            ## not tutorial
            else:
                if lot_repeat:
                    tenna_bub "Did you just want to see what happened...?"
                    tenna_bub "You've done this before, c'mon!"
                else:
                    tenna_bub "Seems that wasn't the right option!"

        elif lot_life == 1:
            show tenna at jump

            ## tutorial
            if not lot_tutorial_win:
                if lot_tutorial_fail == 0:
                    tenna_bub "Nope! Still not right!"
                    tenna_bub "Remember-- same CORRECT option THREE TIMES!"
                elif lot_tutorial_fail == 1:
                    tenna_bub "Maybe try the other option?"
                elif lot_tutorial_fail == 2:
                    tenna_bub "Remember: there's two options, [persistent.mc]!"
                elif lot_tutorial_fail == 3:
                    tenna_bub "Haha..."
                elif lot_tutorial_fail == 4:
                    tenna_bub "..."
                elif lot_tutorial_fail >= 5:
                    pass

            ## not tutorial
            else:
                if lot_repeat:
                    tenna_bub "Really, [persistent.mc]?"
                    if lot_tutorial_fail >= 3:
                        tenna_bub "Again?"
                else:
                    tenna_bub "Haha! Are you just messing around?"
                    tenna_bub "There's. Only two options"

        jump lot_bossbattle


######################################################
##### ASKING TO REPLAY / FINISHED
label lot_replaymenu:
    menu:
        rq "Did you want to keep playing?"
        "Yes":
            "You reach over to soft-reset the console back to the beginning of the stage."
            if not lot_played:
                $ lot_played = True
                "It strangely has a single button pre-made for this...?"
        "No":
            "You tell Tenna you're done playing."
            show tenna at jump
            tenna_bub "You want to quit?"
            tenna_bub "Already? We've barely started!"
            tenna_bub "There's... PROBABLY still more things to do!"
            tenna_bub "Honest! Why would I lie to you?"
            menu:
                rq "Do you want to keep playing?"
                "Yes":
                    "You said you changed your mind."
                    show tenna at jump
                    tenna_bub "GREAT! Let me just do a quick soft-reboot here..."
                    "Tenna reached over to soft-reset the console back to the beginning of the stage."
                    if not lot_played:
                        $ lot_played = True
                        "It strangely has a single button pre-made for this...?"
                "No":
                    "You assured Tenna you don't want to keep playing."
                    show tenna at jump
                    tenna_bub "... sigh."
                    tenna_bub "Alright, alright, I can't force you!"
                    tenna_bub "There's just so many things I was excited to show you, but..."
                    tenna_bub "No! No. It's fine!"
                    tenna_bub "Stick to your guns! Don't listen to a sad little TV like me!"
                    menu:
                        rq "Do you want to keep playing...?"
                        "Yes":
                            "You begrudingly said you changed your mind."
                            show tenna at jump
                            tenna_bub "Oh, WONDERFUL! Let me just do a quick soft-reboot here..."
                            "Tenna reached over to soft-reset the console back to the beginning of the stage."
                            if not lot_played:
                                $ lot_played = True
                                "It strangely has a single button pre-made for this...?"
                        "No":
                            $ lot_played = True
                            $ p_turn = turn
                            $ p_menu_game = False
                            $ memsh_cutscene = False
                            play sfx item
                            stop music
                            hide screen lot_healthbar
                            hide screen lot_bossbar
                            scene black
                            show parkboard2 zorder 98
                            show tenna lotoverlay at tenpos_game zorder 100
                            pause 0.5
                            "You turned off the console."
                            show tenna at droop
                            tenna_bub "O- oh."
                            tenna_bub "Haha, um."
                            hide tenna with easeoutright
                            pause 2.0
                            play sfx click
                            scene black
                            show junkyard
                            show parkboard at truecenter
                            pause 2.0
                            show tenna upright back frown at tenpos_center with easeinright
                            pause 1.0
                            tenna "Guess it's {nw}"
                            play sfx splat
                            if persistent.glitches:
                                extend "{image=txt_gameoverG}{alt}game over{/alt}{w=0.2} for now."
                            else:
                                extend "{image=txt_gameover}{alt}game over{/alt}{w=0.2} for now."
                            show screen datestats
                            play music quizL
                            jump tendate_park

    play sfx item
    stop music
    hide screen lot_bossbar
    $ lot_replay = True
    jump lot


######################################################
##### GAME OVER
label lot_gameover:
    hide hero_wit_gnr
    pause 0.5
    stop music
    show lot_tenna hurt
    pause 1.0
    show tenna at jump

    ## tutorial
    if not lot_tutorial_win:
        if lot_tutorial_fail == 1:
            tenna_bub "Oh, no. Again?"
            tenna_bub "This is getting a little embarrassing..."
            tenna_bub "But it's okay! Just one more round oughta do it."
        elif lot_tutorial_fail == 2:
            tenna_bub "... [persistent.mc]."
            tenna_bub "You sure you're okay?"
            tenna_bub "This is. REALLY easy."
            tenna_bub "Sorry, sorry, I shouldn't be so judgemental!"
        elif lot_tutorial_fail == 3:
            tenna_bub "... [persistent.mc]..."
            tenna_bub "... no, no. It's fine."
        elif lot_tutorial_fail == 4:
            tenna_bub "Is this fun for you?"
            tenna_bub "Haha, well, I aim to entertain, but..."
            tenna_bub "Just, maybe you could, y'know."
            tenna_bub "Do. ANYTHING else?"
        elif lot_tutorial_fail >= 5:
            tenna_bub "... I don't know what I expected, really."
        else:
            $ lot_tutorial = True
            tenna_bub "Whoops! Looks like you lost."
            tenna_bub "Not sure how, since it really wasn't that hard, but..."
            tenna_bub "Ah, nevermind!"
            tenna_bub "Why don't you give it another shot?"
        
        $ lot_tutorial_fail += 1

    ## not tutorial
    else:
        tenna_bub "Ah."
        tenna_bub "Well, that's unfortunate."
    
    jump lot_replaymenu