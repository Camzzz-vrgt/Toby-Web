############################################################################################################
################## QUIZ DATE
label tendate_quiz:
    ### MENU TEXT
    if turn == 0:
        $ menu_text = "Try TALKing or ACTing your way out of the situation."
    elif turn == 2:
        $ menu_text = "It might be in your favor to max out those affection bars..."
    elif flirt == 2 and q_turn == turn and not q_menu_flirt:
        $ q_menu_flirt = True
        $ menu_text = "Tenna really wishes he hadn't said that."
    elif q_stat == 2:
        $ q_stat += 1
        $ menu_text = "Seems he won't be of much real help."
    elif q_where == True:
        $ menu_text = "You're not really even sure where \"here\" is."
    elif q_dump == 1:
        $ menu_text = "Something doesn't seem right."
    elif q_dump == 2:
        $ menu_text = "Does the board look like it's made out of scrap?"
    elif q_dump == 3 and q_turn == turn and not q_menu_dump:
        $ q_menu_dump = True
        $ menu_text = "Tenna keeps a very close eye on the board."
    elif flirt == 1:
        $ menu_text = "Tenna is feeling a little sheepish."
    elif not q_bandage and check == 1:
        $ menu_text = "Tenna awkwardly pokes at his own antenna."
    elif niceday >= 3 or q_none > 0 or q_item >= 3:
        $ menu_text = "Tenna seems worried you aren't having fun."
    elif check == 2 or q_item >= 3:
        $ menu_text = "Tenna looks a bit self-conscious."
    else:
        $ menu_text = "You're taking a quiz now...?"

    ### QUESTION INTERACTIONS
    if question == 1 and not q1:
        $ q1 = True
        ### INTRO TEXT
        $ quiz_question = "QUIZ TIME!"
        $ quiz_answer1 = ""
        $ quiz_answer2 = ""
        $ quiz_answer3 = ""
        $ quiz_answer4 = ""

        play sfx item
        show screen quiztext
        pause 0.5
        play music quiz
        show tenna stretch raised cheer at jump
        tenna "See?{p=0.2}{noalt}*{/noalt} I can do things by myself, too!"
        show tenna upright card awkward at jump
        tenna "I mean."
        show tenna upright card awkward at wiggle
        tenna "H-{w=0.1} how about we just start?!{p=0.2}{noalt}*{/noalt} I bet you can't wait,{w=0.2} haha!!"
        "You have no idea what's going on."
        "Seems Tenna is eyeing your every move, though..."
        "You might have to play along in order to figure things out."

        ### QUESTION 1
        play sfx2 item
        $ quiz_question = "Come here often?"
        $ quiz_answer1 = "Yes"
        $ quiz_answer2 = "No"
        $ quiz_answer3 = "Maybe"
        $ quiz_answer4 = "Where are we?"
    
    elif question == 2 and not q2:
        $ q2 = True
        hide screen quiztext
        $ quiz_selected = 0

        ### QUESTION 2
        $ quiz_question = "First thing you notice?"
        $ quiz_answer1 = "Handsome"
        $ quiz_answer2 = "Charming"
        $ quiz_answer3 = "Big nose"
        $ quiz_answer4 = "Tall"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card neutral at jump
        tenna "What's the {nw}"
        play sfx ten_first
        if persistent.glitches:
            extend " {image=txt_firstG}{alt}first{/alt}{w=0.2} thing you notice about someone?"
        else:
            extend " {image=txt_first}{alt}first{/alt}{w=0.2} thing you notice about someone?"
        show tenna upright pressed smile at wiggle
        tenna "Wow,{w=0.2} such a range of options to choose from!"
        tenna "Personally,{w=0.2} I'd be most concerned about the third thing..."
        pause 1.0
        show tenna upright card confused at yreset
        pause 0.5
        show tenna upright card panic
        tenna "...{w=0.2} What??{nw=0.2}"
        if persistent.glitches:
            pass
        else:
            show tenna at shaking
        extend "{p=0}{noalt}*{/noalt} Don't act like you aren't thinking about it!"
        tenna "Everybody does it!!!"

    elif question == 3 and not q3:
        $ q3 = True
        hide screen quiztext
        $ quiz_selected = 0

        ### QUESTION 3
        $ quiz_question = "What's your favorite food?"
        $ quiz_answer1 = "Sweet"
        $ quiz_answer2 = "Salty"
        $ quiz_answer3 = "Bitter"
        $ quiz_answer4 = "Anything Tenna makes"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card neutral at jump
        tenna "What's your {nw}"
        play sfx ten_fave
        if persistent.glitches:
            extend "{image=txt_faveG}{alt}favorite{/alt} food?"
        else:
            extend "{image=txt_fave}{alt}favorite{/alt} food?"
        pause 1.0
        show tenna upright card panic at wiggle
        tenna "D-{w=0.1} don't look at me so suspiciously!"

    elif question == 4 and not q4:
        $ q4 = True
        hide screen quiztext
        $ quiz_selected = 0
        
        ### QUESTION 4
        $ quiz_question = "What's your favorite color?"
        $ quiz_answer1 = "Red"
        $ quiz_answer2 = "White"
        $ quiz_answer3 = "Black"
        $ quiz_answer4 = "Yellow"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card neutral at jump
        tenna "What's your {nw}"
        play sfx ten_fave
        if persistent.glitches:
            extend "{image=txt_faveG}{alt}favorite{/alt} color?"
        else:
            extend "{image=txt_fave}{alt}favorite{/alt} color?"
        pause 1.0
        show tenna upright card awkward
        tenna "...{w=0.2} What?"
        show tenna panic panic at jump
        tenna "It's an important question to ask!{p=0.2}{noalt}*{/noalt} How else would I be able to know?!"
        show tenna panic flustered
        tenna "It's not like this kind of thing comes up in regular conversation!!"

    elif question == 5 and not q5:
        $ q5 = True
        hide screen quiztext
        $ quiz_selected = 0

        $ quiz_question = "If you felt the need to{p}escape, how would you do it?"
        $ quiz_answer1 = ""
        $ quiz_answer2 = ""
        $ quiz_answer3 = ""
        $ quiz_answer4 = ""

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 0.5
        show tenna slouch claw panic
        tenna "Wh--"
        show tenna upright card panic at wiggle
        tenna "What's this question doing on here?{w=0.2} Haha."
        show tenna stretch shrug smile flipped
        tenna "Why would you feel the need to ESCAPE?{p=0.2}{noalt}*{/noalt} We're just having fun here!"
        show tenna upright chest angry at yreset
        tenna "I'm throwing that out!{p=0.2}{noalt}*{/noalt} Next question!!"
        $ q_escape = True
        play sfx2 item

        ### QUESTION 5
        $ quiz_question = "Fave TV programming?"
        $ quiz_answer1 = "Cooking shows"
        $ quiz_answer2 = "Music videos"
        $ quiz_answer3 = "Anime"
        $ quiz_answer4 = "Romance TV"

    elif question == 6 and not q6:
        $ q6 = True
        hide screen quiztext
        $ quiz_selected = 0

        ### QUESTION 6
        $ quiz_question = "What's your blood type?"
        $ quiz_answer1 = "A"
        $ quiz_answer2 = "B"
        $ quiz_answer3 = "AB"
        $ quiz_answer4 = "O"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card neutral at jump
        tenna "What's your blood type?"
        pause 1.0
        show tenna panic panic at jump
        tenna "It's a personality thing!!{p=0.2}{noalt}*{/noalt} Don't be weird!!"

    elif question == 7 and not q7:
        $ q7 = True
        hide screen quiztext
        $ quiz_selected = 0

        ### QUESTION 7
        $ quiz_question = "Best self quality?"
        $ quiz_answer1 = "Kindness"
        $ quiz_answer2 = "Passion"
        $ quiz_answer3 = "Determination"
        $ quiz_answer4 = "Hope"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card neutral at jump
        tenna "What quality do you value most about yourself?"
        tenna "...{nw=0.5}"
        show tenna upright card frown
        extend " What?{p=0.2}{noalt}*{/noalt} Is it too personal?"

    elif question == 8 and not q8:
        $ q8 = True
        hide screen quiztext
        $ quiz_selected = 0

        ### QUESTION 8
        $ quiz_question = "You..."
        $ quiz_answer1 = "Love TV"
        $ quiz_answer2 = "Love TV"
        $ quiz_answer3 = "Love TV"
        $ quiz_answer4 = "Love TV"

        show tenna upright card blank at jump
        tenna "Next question!"
        play sfx item
        show screen quiztext
        pause 1.0
        show tenna upright card awkward
        tenna "..."

    elif question > 8:
        jump postquiz

    $ turn += 1

label tendate_quiz_menu:
    show tenna upright card neutral at yreset
    show screen tendate_select
    $ quick_menu = True
    $ skipyes = False
    $ _skipping = False
    
    date "[menu_text]"

    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## PARK DATE
label tendate_park:
    ### TRANSITION TO END (full lp/fp)
    if date_fp <= 0 and date_lp <= 0 and p_played:
        "You figure there's really nothing else you can do right now,{w=0.2} but Tenna's probably going to keep you here unless you do something."
        "So,{w=0.2} you one again reach out and try to move the board aside...{nw=0.2}"
        jump tennaend

    ### MENU TEXT
    if p_dateno and p_turn == turn and not p_menu_hangout:
        $ p_menu_hangout = True
        $ menu_text = "This is apparently a \"friendly hangout\" now."
    elif turn >= 20 and not p_qu_here:
        $ menu_text = "Maybe you could try asking Tenna something."
    elif turn >= 20 and not itm_nes in inventory:
        if not itm_dvd in inventory:
            $ menu_text = "Maybe you could try playing the game with Tenna."
        else:
            $ menu_text = "Maybe you should give something to Tenna."
    elif turn >= 20 and p_behind >= 2:
        $ menu_text = "Maybe you could try moving the board now."
    elif p_behind == 2 and p_turn == turn:
        $ p_behind += 1
        $ menu_text = "Everything is fine.\n{noalt}*{/noalt} Everything is fine.\n{noalt}*{/noalt} Everything is fine."
    elif p_flirt2 and p_turn == turn and not p_menu_flirt:
        $ p_menu_flirt = True
        $ menu_text = "Tenna really hopes you trust his word."
    elif p_qu_here and p_turn == turn and not p_menu_here:
        $ p_menu_here = True
        $ menu_text = "Tenna really seems to hate talking about the location."
    elif p_qu_food and p_turn == turn and not p_menu_food:
        $ p_menu_food = True
        $ menu_text = "Tenna hasn't considered what he'd call his favorite food before."
    elif lot_played and p_turn == turn and not p_menu_game:
        $ p_menu_game = True
        $ menu_text = renpy.random.choice(["That game felt a little... boring.", "Was that game even complete?", "You aren't sure why Tenna had you play that game."])
    elif p_iltv >= 6 and p_turn == turn:
        $ menu_text = "You love TV, right?"
    else:
        $ menu_text = renpy.random.choice(["The ground feels glooby beneath your feet.", "Smells like broken CRTs.", "You wonder how long you'll be stuck here.", "The air is dusty.", "There is a dull breeze."])

    ### INTRO / ASK ABOUT DATE
    if turn == 0:
        play music quizL
        pause 0.5
        show tenna upright pointing smile at jump
        tenna "How about we enjoy a wonderful park date together?{p=0.2}{noalt}*{/noalt} Eh?{w=0.2} Ehh?"
        menu:
            rq "How about we enjoy a wonderful park date together?{p=0}{noalt}*{/noalt} Eh? Ehh?"
            "Sure":
                $ p_ten_date = True
                $ menu_text = "You're on a date now."
                show tenna stretch raised cheer at jump
                tenna "Haha,{w=0.2} I knew you'd love the idea!"
                if date_lp > 0:
                    play sfx ding
                    show tenna upright chest awkward at jump
                    $ date_lp -= 5
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna grins at your enthusiasm.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna grins at your enthusiasm.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

            "I didn't ask for this":
                $ p_ten_date = False
                $ menu_text = "Seems you weren't given a choice."
                show tenna upright back panic
                tenna "Well,{w=0.2} I mean..."
                tenna "I'm the one asking YOU,{w=0.2} haha."
                menu:
                    rq "I'm the one asking YOU, haha."
                    "Oh. Okay.":
                        show tenna upright back blank
                        tenna "..."
                        pause 1.0
                        tenna "Just."
                        show tenna upright back panic flipped at jump
                        tenna "\"Oh\"???{p=0.2}{noalt}*{/noalt} \"Okay\"???"
                        pause 1.0
                        show tenna upright back nose
                        tenna "...{w=0.5} well,{w=0.2} anyway..."
                        show tenna upright chest neutral at jump
                        tenna "Let's just get started!"
                    "No thanks.":
                        show tenna slouch claw panic at jump
                        tenna "What--{w=0.2} \"No\"??"
                        show tenna upright back frown at droop
                        tenna "But I set this up {nw}"
                        play sfx ten_heyevery
                        if persistent.glitches:
                            extend "{image=txt_specialG}{alt}special{/alt}{w=0.2} for you and everything..."
                        else:
                            extend "{image=txt_special}{alt}special{/alt}{w=0.2} for you and everything..."
                        if q_flirt:
                            show tenna upright pointing smile at jump
                            tenna "You even flirted with me before!"
                            if q_flirt2:
                                show tenna upright pointing oh
                                tenna "Multiple times!"
                            show tenna slouch whisper smug
                            tenna "You can't lie to me, [persistent.mc]--{w=0.2} you're at least a LITTLE interested."
                        show tenna upright chest smile at jump
                        tenna "Why not just give it a shot?{p=0.5}{noalt}*{/noalt} I promise I'm not THAT insufferable!"

                if date_fp > 0:
                    play sfx ding
                    show tenna upright chest neutral at jump
                    $ date_fp -= 5
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Tenna seems pretty insistent.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Tenna seems pretty insistent.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
            
    ### QUESTION WHY PLAYER IS HERE
    elif turn == 4:
        show tenna upright pointing oh at jump
        tenna "Oh, [persistent.mc]!{p=0.5}{noalt}*{/noalt} I had a question to ask you."
        if persistent.here:
            show tenna upright back neutral at jump
            if persistent.here == "yes":
                tenna "You said you'd been here before,{w=0.2} right?"
            elif persistent.here == "no":
                tenna "You said you haven't been here before,{w=0.2} so..."
            elif persistent.here == "maybe":
                tenna "You said you...{w=0.2} MIGHT have been here before??{p=0.2}{noalt}*{/noalt} Sooo..."
            elif persistent.here == "where":
                pass
        else:
            show tenna upright back frown flipped at jump
            tenna "You didn't answer my question about this, but..."
        show tenna upright chest awkward at jump
        if persistent.here != "where":
            tenna "What I wanted to ask you was--{w=0.2} what brings you here today??"
        else:
            tenna "What brings you here today??"
        show tenna stretch shrug smile
        tenna "I haven't seen you around myself,{w=0.2} so I was curious!"
        
        menu:
            rq "I haven't seen you around myself, so I was curious!"
            "Bored":
                $ menu_text = "Tenna is definitely questioning your choice of entertainment."
                "You tell Tenna you were just bored and found yourself here."
                show tenna slouch claw panic at droop
                tenna "Just BORED?!"
                show tenna upright chest neutral at yease
                tenna "This is...{w=0.2} definitely a choice for entertainment,{w=0.2} haha."
                show tenna upright back neutral flipped
                tenna "I mean--{nw=0.2}"
                show tenna stretch shrug smile flipped at jump
                extend " a GREAT choice!{p=0.2}{noalt}*{/noalt} It's a{nw}"
                play sfx sparkleglock
                if persistent.glitches:
                    extend " {image=txt_greatG}{alt}great{/alt}{w=0.1} choice!!!"
                else:
                    extend " {image=txt_great}{alt}great{/alt}{w=0.1} choice!!!"
                if date_fp > 0:
                    play sfx ding
                    show tenna upright chest neutral at jump
                    $ date_fp -= 5
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Tenna appreciates your honesty, at least.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Tenna appreciates your honesty, at least.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

            "Looking for love":
                $ menu_text = "Tenna doesn't know what to do with himself."
                "You tell Tenna that you're here because you're looking for love."
                show tenna panic flustered at jump
                tenna "Huh?!"
                if not p_ten_date:
                    show tenna upright chest awkward at jump
                    tenna "Oh, but--{w=0.5} right, you already said..."
                    if q_flirt or p_flirt:
                        show tenna at droop
                        tenna "Even though you..."
                    pause 1.0
                    show tenna stretch raised cheer flipped at jump
                    tenna "Hahaha!{p=0.2}{noalt}*{/noalt} Nevermind!!{w=0.2} Ignore me!!"
                else:
                    show tenna upright chest smile
                    tenna "Well, now!{nw=0.5}"
                    show tenna upright pointing oh at jump
                    extend "{p=0}{noalt}*{/noalt} You're direct!"
                    show tenna upright chest awkward at jump
                    if q_flirt or p_flirt:
                        tenna "I suppose that explains all the flirting, doesn't it?"
                        show tenna upright pressed smile at rise
                        tenna "Haha,{w=0.2} feel free to do that as much as you like!"
                    elif persistent.lovetv or p_iltv:
                        tenna "Is that what you meant when you so eagerly told me you Love TV?"
                        show tenna upright pressed smile at rise
                        tenna "Haha,{nw=0.2}"
                        show tenna at wiggle
                        if p_iltv > 3:
                            extend " and you said it so many times, too...!"
                        else:
                            extend " feel free to say it as many times as you'd like...!"
                    else:
                        show tenna slouch whisper smug
                        tenna "{nw=0.2}"
                        play sfx ten_sax
                        if persistent.glitches:
                            tenna_funG "Not that I'm complaining."
                        else:
                            tenna_fun "Not that I'm complaining." # SELF VOICING FIX
                if date_lp > 0:
                    play sfx ding
                    show tenna upright back awkward at jump
                    $ date_lp -= 10
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        if not p_ten_date:
                            "Tenna seems flattered anyway.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Tenna seems flattered.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                    else:
                        if not p_ten_date:
                            "Tenna seems flattered anyway.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                        else:
                            "Tenna seems flattered.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
    
    ### FOOD GIFT
    elif turn == 8:
        $ menu_text = "Tenna hopes he didn't accidentally hurt you in some way."
        show tenna upright back awkward at yreset
        tenna "By the way!{p=0.2}{noalt}*{/noalt} [persistent.mc],{w=0.2} I had something I wanted to give you."
        show tenna upright pointing oh at jump
        tenna "Ta-da!{p=0.2}{noalt}*{/noalt} I made it with {nw}"
        play sfx ten_aww
        if persistent.glitches:
            extend "{image=txt_loveG}{alt}love{/alt}{w=0.2} , just for you!"
        else:
            extend "{image=txt_love}{alt}love{/alt}{w=0.2} , just for you!"
        show tenna upright chest neutral
        play sfx sparkleglock
        
        ### RANDOM FOOD (either anything or no chosen option)
        if persistent.favefood == "anything" or persistent.favefood == None:
            $ food_ran = renpy.random.choice(["baked goods", "candy", "fries", "pretzels", "chocolate", "coffee"])

            if food_ran == "baked goods":
                show itemframe i_pie at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a slice of pie.{p=0.2}{noalt}*{/noalt} It smells faintly of cinnamon and butterscotch."
                "There's something off about it,{w=0.2} but the presentation is rather appealing."

            elif food_ran == "candy":
                show itemframe i_candy at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a fruit-like piece of candy.{p=0.2}{noalt}*{/noalt} It smells faintly of marshmallows."
                "Something about it looks like it grew in an awkward spot,{w=0.2} but it doesn't look inedible."

            elif food_ran == "fries":
                show itemframe i_fries at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a paper dish of fries.{p=0.2}{noalt}*{/noalt} It smells faintly as if they've been freshly made, somehow."
                "The dish doesn't seem to be in the best condition,{w=0.2} but the food looks okay."
            
            elif food_ran == "pretzels":
                show itemframe i_pretzels at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a large, singular pretzel.{p=0.2}{noalt}*{/noalt} It smells faintly as if they've been freshly made, somehow."
                "Something seems funky about the salt,{w=0.2} but it otherwise looks appealing."

            elif food_ran == "chocolate":
                show itemframe i_chocolate at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a cracked red mug.{p=0.2}{noalt}*{/noalt} It smells faintly of chocolate."
                "The mug looks worse for wear,{w=0.2} but the drink itself looks alright."

            elif food_ran == "coffee":
                show itemframe i_coffee at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a cracked yellow mug.{p=0.2}{noalt}*{/noalt} It smells faintly of coffee."
                "The mug looks worse for wear,{w=0.2} but the drink itself looks alright."

        ### SPECIFIC FOOD
        else:
            if (persistent.favefood == "sweets" and sweets_ran == "baked goods") or persistent.favefood == "baked goods":
                show itemframe i_pie at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a slice of pie.{p=0.2}{noalt}*{/noalt} It smells faintly of cinnamon and butterscotch."
                "There's something off about it,{w=0.2} but the presentation is rather appealing."

            elif (persistent.favefood == "sweets" and sweets_ran == "candy") or persistent.favefood == "candy":
                show itemframe i_candy at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a fruit-like piece of candy.{p=0.2}{noalt}*{/noalt} It smells faintly of marshmallows."
                "Something about it looks like it grew in an awkward spot,{w=0.2} but it doesn't look inedible."

            elif (persistent.favefood == "salty foods" and salty_ran == "fries") or persistent.favefood == "fries":
                show itemframe i_fries at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a paper dish of fries.{p=0.2}{noalt}*{/noalt} It smells faintly as if they've been freshly made, somehow."
                "The dish doesn't seem to be in the best condition,{w=0.2} but the food looks okay."

            elif (persistent.favefood == "salty foods" and salty_ran == "pretzels") or persistent.favefood == "pretzels":
                show itemframe i_pretzels at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a large, singular pretzel.{p=0.2}{noalt}*{/noalt} It smells faintly as if it's been freshly made, somehow."
                "Something seems funky about the salt,{w=0.2} but it otherwise looks appealing."

            elif (persistent.favefood == "bitter foods" and bitter_ran == "chocolate") or persistent.favefood == "chocolate":
                show itemframe i_chocolate at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a cracked red mug.{p=0.2}{noalt}*{/noalt} It smells faintly of chocolate."
                "The mug looks worse for wear,{w=0.2} but the drink itself looks alright."

            elif (persistent.favefood == "bitter foods" and bitter_ran == "coffee") or persistent.favefood == "coffee":
                show itemframe i_coffee at truecenter with easeinbottom
                pause 0.5
                "Tenna offered you a cracked yellow mug.{p=0.2}{noalt}*{/noalt} It smells faintly of coffee."
                "The mug looks worse for wear,{w=0.2} but the drink itself looks alright."
        
        hide itemframe with easeoutbottom
        show tenna upright chest smile at jump

        ### TENNA REACT (RANDOM FOOD)
        if persistent.favefood == "anything" or persistent.favefood == None:
            if persistent.favefood == "anything":
                tenna "I hope you like it!{p=0.2}{noalt}*{/noalt} You said you'd be okay with anything,{w=0.2} so..."
            else:
                tenna "I hope you like it!{p=0.2}{noalt}*{/noalt} You didn't specify what kind of food you preferred,{w=0.2} so..."
            if food_ran == "baked goods":
                show tenna upright chest neutral at jump
                tenna "Actually,{w=0.2} this type of pie is pretty important to me..."
                show tenna upright pressed smile at wiggle
                tenna "I hope I did the recipe justice, haha!"

        ### TENNA REACT (SPECIFIC FOOD)
        else:
            if persistent.favefood == "baked goods":
                tenna "."
                tenna "I hope you like it!{p=0.2}{noalt}*{/noalt} It should be your favorite,{w=0.2} right?"
                show tenna upright chest neutral at jump
                tenna "Admittedly,{w=0.2} this particular type of pie is important to me..."
                show tenna upright pressed smile at wiggle
                tenna "I hope I did the recipe justice, haha!"
            elif persistent.favefood in ["sweets", "salty foods", "bitter foods"]:
                tenna "I hope you like it!{p=0.2}{noalt}*{/noalt} You said you liked [persistent.favefood],{w=0.2} right?"
                if persistent.favefood == "sweets" and sweets_ran == "baked goods":
                    show tenna upright chest neutral at jump
                    tenna "Admittedly,{w=0.2} this specific kind of pie has some importance to me..."
                    show tenna upright pressed smile at wiggle
                    tenna "I hope I did the recipe justice, haha!"
            else:
                tenna "I hope you like it!{p=0.2}{noalt}*{/noalt} It should be your favorite,{w=0.2} right?"

        show tenna upright back neutral at yreset
        "You figured you might as well try it..."
        play sfx gulp
        pause 2.0
        "The texture coats your mouth with a thick,{w=0.2} viscous layer of...{w=0.5} something."
        play sfx defeat
        show sickoverlay with Dissolve(0.2)
        if persistent.glitches:
            pass
        else:
            with vpunch
        "Your tastebuds shrivel and recoil,{w=0.2} but you have no choice other than to swallow it down."
        hide sickoverlay
        show tenna upright pointing smile at jump
        tenna "So,{w=0.2} what do you think?"
        
        menu:
            rq "So, what do you think?"
            "It's terrible":
                "You couldn't even keep a straight face long enough to tell him it was palatable."
                show tenna panic panic at jump
                tenna "O-{w=0.1} oh-- {nw=0.2}"
                show tenna slouch claw panic at jump
                extend "is it really THAT bad?!"
                show tenna upright chest frown flipped at jump
                tenna "I'm so, so sorry, [persistent.mc]!!{p=0.2}{noalt}*{/noalt} Ahh,{w=0.2} I'll take the rest of that back!!"
                show tenna upright chest panic
                tenna "Don't worry!{p=0.2}{noalt}*{/noalt} I'll make something better later,{w=0.2} I promise!!"
                if date_lp > 0:
                    play sfx ding
                    show tenna upright chest awkward at jump
                    $ date_lp -= 10
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Despite your dissatisfaction,{w=0.2} Tenna really appreciates your honesty.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Despite your dissatisfaction,{w=0.2} Tenna really appreciates your honesty.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

            "Lie":
                $ p_foodkeep = True
                "You gave a strained thumbs up."
                show tenna slouch claw panic at droop
                tenna "Um--{w=0.2} [persistent.mc]?{p=0.5}{noalt}*{/noalt} Are you sure you're alright?"
                show tenna upright chest frown at yease
                tenna "It's okay if you don't like it,{w=0.2} you know..."
                "You shake your head frantically before stuffing the rest into your pocket."
                play sfx item
                if persistent.favefood == "anything" or persistent.favefood == None:
                    if food_ran == "baked goods":
                        $ inventory.append(itm_pie)
                    elif food_ran == "candy":
                        $ inventory.append(itm_candy)
                        $ p_candy == True
                    elif food_ran == "fries":
                        $ inventory.append(itm_fries)
                    elif food_ran == "pretzels":
                        $ inventory.append(itm_pretzel)
                    elif food_ran == "chocolate":
                        $ inventory.append(itm_cocoa)
                    elif food_ran == "coffee":
                        $ inventory.append(itm_coffee)
                else:
                    if (persistent.favefood == "sweets" and sweets_ran == "baked goods") or persistent.favefood == "baked goods":
                        $ inventory.append(itm_pie)
                    elif (persistent.favefood == "sweets" and sweets_ran == "candy") or persistent.favefood == "candy":
                        $ inventory.append(itm_candy)
                        $ p_candy == True
                    elif (persistent.favefood == "salty foods" and salty_ran == "fries") or persistent.favefood == "fries":
                        $ inventory.append(itm_fries)
                    elif (persistent.favefood == "salty foods" and salty_ran == "pretzels") or persistent.favefood == "pretzels":
                        $ inventory.append(itm_pretzel)
                    elif (persistent.favefood == "bitter foods" and bitter_ran == "chocolate") or persistent.favefood == "chocolate":
                        $ inventory.append(itm_cocoa)
                    elif (persistent.favefood == "bitter foods" and bitter_ran == "coffee") or persistent.favefood == "coffee":
                        $ inventory.append(itm_coffee)

                "Maybe you'll finish it later...?{p=0.2}{noalt}*{/noalt} It was added to your ITEMS."
                show tenna upright back frown at droop
                tenna "..."
                show tenna upright back blank flipped at jump
                tenna "Well,{w=0.2} okay.{p=0.2}{noalt}*{/noalt} If you say so."
                if date_lp > 0:
                    play sfx ding
                    show tenna upright chest neutral at jump
                    $ date_lp -= 2
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna sort of appreciates you not wanting to upset him.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna sort of appreciates you not wanting to upset him.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}LP{/color}."

    ### FIRST IMPRESSION
    elif turn == 12:
        $ menu_text = "Tenna seems to value your opinion rather highly..."
        show tenna upright chest neutral at yreset
        tenna "Oh, [persistent.mc].{p=0.5}{noalt}*{/noalt} Do you remember earlier when I asked you what springs to mind when you first meet someone?"
        show tenna upright back panic flipped at jump
        tenna "Not that it was very long ago,{w=0.2} but..."
        show tenna upright chest smile at jump
        if persistent.firstimpress == "nose":
            tenna "Anyway!{w=0.2} I just wanted to ask...{p=0.5}{noalt}*{/noalt} Since you said you thought about.{nw=0.2}"
            show tenna upright back awkward at jump
            extend " Nose sizes."
        elif persistent.firstimpress == None:
            tenna "Anyway!{w=0.2} I just wanted to ask,{w=0.2} since you didn't really give an answer..."
        else:
            tenna "Anyway!{w=0.2} I just wanted to ask,{w=0.2} since you said you prioritized how [persistent.firstimpress] someone is..."
        show tenna upright chest awkward at jump
        tenna "Is that.{w=0.2} Something very important to you,{w=0.2} or...?"

        menu:
            rq "Is that. Something very important to you, or...?"
            "Yes":
                show tenna upright back awkward at jump
                tenna "Oh!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} well, that's..."
                if not p_ten_date:
                    show tenna upright back frown at droop
                    tenna "(Though you...{w=0.2} still didn't...)"
                    show tenna upright back frown flipped at wiggle
                    tenna "(Maybe I'm just not...?)"
                    show tenna upright chest panic at jump
                    tenna "Huh?{p=0.2}{noalt}*{/noalt} N-{w=0.1} no,{w=0.2} I'm not mumbling about anything!!"
                    show tenna upright pressed smile at rise
                    tenna "I'm checked in!{w=0.2} I'm listening!{p=0.2}{noalt}*{/noalt} Don't you worry your pretty little head about a thing!"
                    if date_lp > 0:
                        play sfx ding
                        show tenna upright chest awkward at jump
                        $ date_lp -= 2
                        "Tenna looks like he remembered something.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_passion]}LP{/color}."
        
                else:
                    show tenna upright pressed smile at rise
                    tenna "That's just peachy!"
                    if date_lp > 0:
                        play sfx ding
                        show tenna upright chest awkward at jump
                        $ date_lp -= 10
                        "Tenna might be jumping to conclusions.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
        
            "No":
                show tenna slouch claw panic at jump
                tenna "You're kidding...!?"
                if not p_ten_date:
                    show tenna upright back frown flipped at wiggle
                    tenna "Ah.{p=0.2}{noalt}*{/noalt} Is that why you...?"
                    show tenna upright chest neutral at jump
                    tenna "No, no,{w=0.2} nevermind!{p=0.5}{noalt}*{/noalt} I'm just rambling to myself now!"
                    show tenna upright pointing oh
                    tenna "Hey,{w=0.2} whatever it is that you DO care about,{w=0.2} then..."
                    show tenna upright pointing weak
                    tenna "Um."
                    pause 1.0
                    show tenna upright back awkward at jump
                    tenna "Actually,{w=0.2} I forgot what I was saying, haha!{p=0.5}{noalt}*{/noalt} Oopsie daisy!"
                    if date_lp > 0:
                        play sfx ding
                        show tenna upright chest awkward at jump
                        $ date_lp -= 5
                        "Tenna looks like he remembered SOMETHING, anyway.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
                
                else:
                    show tenna upright back frown at droop
                    tenna "So, you...{w=0.2} hm."
                    show tenna upright back blank flipped at jump
                    tenna "(Maybe there's...{w=0.2} something else then...?)"
                    show tenna upright pressed smile flipped at rise
                    tenna "(Does that mean...?)"
                    show tenna upright chest panic at jump
                    tenna "Huh?{p=0.2}{noalt}*{/noalt} N-{w=0.1} no,{w=0.2} I'm not mumbling about anything!!"
                    show tenna upright pressed smile at rise
                    tenna "I'm checked in!{w=0.2} I'm listening!{p=0.2}{noalt}*{/noalt} Don't you worry your pretty little head about a thing!"
                    if date_lp > 0:
                        play sfx ding
                        show tenna upright chest awkward at jump
                        $ date_lp -= 10
                        "Tenna might be jumping to conclusions.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

    ### FAVORITE PROGRAMS
    elif turn == 16:
        show tenna upright pointing smile at jump
        if persistent.lovetv:
            tenna "[persistent.mc],{w=0.2} you love TV,{w=0.2} right?"
        else:
            tenna "[persistent.mc],{w=0.2} you like watching TV,{w=0.2} right?"
        show tenna upright back awkward at jump

        if persistent.programs:
            $ menu_text = "It almost seems like Tenna doesn't want to talk about himself."
            tenna "What I mean is--{p=0.5}{noalt}*{/noalt} You mentioned earlier you enjoy watching [persistent.programs]!"
            if persistent.programs == "cooking shows":
                show tenna upright pressed smile at rise
                tenna "Those have a special place in my boxy head,{w=0.2} too..."
                show tenna at wiggle
                tenna "All the different recipes Tori would learn to--{nw=0.5}"
                show tenna at yreset
                pause 1.0
            elif persistent.programs == "music videos":
                show tenna upright pressed smile at rise
                tenna "I have such fond memories with watching music videos myself!"
                show tenna at wiggle
                tenna "When the kids would turn off the parental controls when Tori wasn't home and--{nw=0.5}"
                show tenna at yreset
                pause 1.0
            elif persistent.programs == "anime":
                show tenna upright chest awkward at jump 
                tenna "I'm still a LITTLE unclear on what that is specifically, but,{w=0.2} ah..."
            elif persistent.programs == "romance shows":
                show tenna upright chest awkward at jump
                tenna "Provided you weren't just saying that to flirt with me and nothing else,{w=0.2} haha!"
            
            show tenna upright back frown
            pause 1.0
            show tenna upright chest neutral at jump
            tenna "Well,{w=0.2} I don't need to sidetrack things from your thoughts with my own interjections,{w=0.2} haha!"
            menu:
                rq "Well, I don't need to sidetrack things from your thoughts with my own interjections, haha!"
                "You can share your thoughts, too":
                    show tenna stretch shrug smile at jump
                    tenna "Oh,{w=0.2} pfft,{w=0.2} nah!{p=0.5}{noalt}*{/noalt} What kind of host would I be if I'm just rambling off about myself the whole time?"
                    show tenna upright pointing oh at jump
                    tenna "Let's just talk about something else!{p=0.5}{noalt}*{/noalt} Got any ideas, [persistent.mc]?"
                
                "We can talk about something else":
                    show tenna upright pointing oh at jump
                    tenna "Oh, sure!{p=0.5}{noalt}*{/noalt} Did you have any ideas?{p=0.5}{noalt}*{/noalt} Anything you wanna talk about,{w=0.2} I'm there!"
            
            if date_lp > 0:
                play sfx ding
                show tenna upright chest neutral at jump
                $ date_lp -= 10
                "Tenna just generally likes talking to you, it seems.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                
        ## if you didn't answer the programs question prior
        else:
            $ menu_text = "Tenna wishes you'd talk to him."
            tenna "Well,{w=0.2} what I mean is--{p=0.5}{noalt}*{/noalt} Surely there's some kind of programming you enjoy watching!"
            tenna "You said none of the answers I gave you before didn't suit you best,{w=0.2} but if I know TV--"
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            if persistent.glitches:
                tenna_funG "And trust me, I know TV."
            else:
                tenna_fun "And trust me, I know TV." # SELF VOICING FIX
            show tenna stretch raised cheer at jump
            tenna "-- then there's PLENTY of things you could be watching outside of those four answers!"
            show tenna upright chest smile at jump
            tenna "So!{p=0.2}{noalt}*{/noalt} Spill the beans, [persistent.mc]!{w=0.5} Tell me what your {nw}"
            play sfx ten_fave
            if persistent.glitches:
                extend "{image=txt_faveG}{alt}favorite{/alt} TV show is!"
            else:
                extend "{image=txt_fave}{alt}favorite{/alt} TV show is!"
            menu:
                rq "So!{p=0}{noalt}*{/noalt} Spill the beans, [persistent.mc]! Tell me what your {image=txt_fave}{alt}favorite{/alt} TV show is!"
                "Okay.":
                    pause 1.0
                    show tenna upright chest neutral
                    tenna_shh ".{w=0.2}.{w=0.2}."
                    show tenna slouch claw panic at droop
                    tenna "Is, uh.{p=0.5}{noalt}*{/noalt} This a joke?"
                    tenna "You aren't actually giving me an answer,{w=0.2} haha!"
                    show tenna upright chest frown at yreset
                    pause 1.0
                    show tenna stretch shrug smile flipped at jump
                    tenna "You're funny, [persistent.mc]!{p=0.5}{noalt}*{/noalt} Hahaha!{w=0.2} I love a good jape!!"

                "No, thanks.":
                    show tenna slouch claw panic at jump
                    tenna "Oh!{w=0.2} Well, uh..."
                    show tenna stretch shrug smile flipped at jump
                    tenna "Thaaaaaaat's okay, too{w=0.2} then!{p=0.5}{noalt}*{/noalt} Haha!"
                    if date_fp > 0:
                        play sfx ding
                        show tenna upright chest neutral at jump
                        $ date_fp -= 3
                        "Tenna appreciates your honesty, at least.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."

    ## HAPPY
    elif turn == 20:
        show tenna upright back neutral at jump
        tenna "Oh, by the way.{p=0.5}{noalt}*{/noalt} You're alright with this setup,{w=0.2} aren't you, [persistent.mc]?"
        show tenna upright back smile
        tenna "The park,{w=0.2} that is."
        show tenna upright back frown at droop
        if ten_moveboard:
            tenna "This Dark World isn't...{w=0.5} the best.{p=0.2}{noalt}*{/noalt} I know."
        elif q_dump > 0 or p_behind > 0 or vex_behind:
            tenna "You keep asking about the rest of the Dark World,{w=0.5} but, I promise you,{w=0.2} it's no good out there."
        else:
            tenna "It's nothing major, I know,{w=0.2} but it's important to me to make sure that you're happy with it."
        show tenna upright chest awkward at jump
        tenna "I'm determined to make this place somewhere you won't ever feel the need to leave from."
        show tenna upright pressed smile
        tenna "A place where you can always have someone to turn to,{w=0.2} whenever you want!"
        show tenna stretch shrug smile flipped at jump
        tenna "I can't do a WHOLE lot, haha.{p=0.5}{noalt}*{/noalt} I'm just a TV, after all!"
        tenna "Not much of a handyman{w=0.2} or an artist{w=0.2} or a chef or...{nw=0.5}"
        show tenna at droop
        extend "{p=0}{noalt}*{/noalt} Anything that might be more useful, really,{w=0.2} aha."
        show tenna stretch shrug weak flipped
        tenna "Just a giant,{w=0.2} inconvenient box,{w=0.2} reliant on electricity,{w=0.2} whose only purpose is to{w=0.2}.{w=0.2}.{w=0.2}."
        show tenna upright chest frown flipped
        pause 1.0
        show tenna upright pointing oh at jump
        tenna "I mean.{w=0.5} None of that stuff really matters!{p=0.5}{noalt}*{/noalt} Your life is numero uno!"
        show tenna upright chest neutral
        tenna "So...{w=0.5} are you happy?{w=0.2} Like this?"
        menu:
            rq "So... are you happy? Like this?"
            "Yes":
                show tenna upright chest awkward at rise
                tenna "You are?"
                show tenna upright pressed smile at wiggle
                tenna "Oh,{w=0.2} wonderful!{w=0.5} Absolutely SPLENDID, my dear [persistent.mc]!{p=0.5}{noalt}*{/noalt} Your happiness is my happiness!"
                show tenna upright pointing smile at jump
                tenna "So long as you've got a smile on your face,{w=0.2} there's not a single thing in this world that could EVER bring me down, haha!!"
                if date_lp > 0:
                    play sfx ding
                    show tenna upright chest awkward at jump
                    $ date_lp -= 10
                    "Tenna is thriving, for some reason.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
            
            "No":
                show tenna upright chest frown at droop
                tenna_shh ".{w=0.2}.{w=0.2}."
                show tenna upright back frown flipped at jump
                tenna "No,{w=0.2} no,{w=0.2} it's okay!{p=0.5}{noalt}*{/noalt} It's better that you tell me!"
                show tenna upright pointing oh at jump
                tenna "If there's something still upsetting you, just...{p=0.5}{noalt}*{/noalt} Say the {nw}"
                play sfx ten_favorite
                if persistent.glitches:
                    extend "{image=txt_wordG}{alt}word{/alt}!{w=0.5} I'll be there to fix it!!"
                else:
                    extend "{image=txt_word}{alt}word{/alt}!{w=0.5} I'll be there to fix it!!"
                menu:
                    rq "If there's something still upsetting you, just...{p=0}{noalt}*{/noalt} Say the {image=txt_word}{alt}word{/alt}! I'll be there to fix it!!"
                    "I want to know where we are.":
                        show tenna upright chest blank at jump
                        tenna "That..."
                        show tenna upright chest frown at droop
                        tenna "I..."
                        pause 1.0
                        show tenna stretch shrug smile flipped at wiggle
                        tenna "{cps=60}N-{w=0.1} next topic!!{/cps}"
                    
                    "It's something you can't fix.":
                        show tenna slouch claw panic at droop
                        tenna "C-{w=0.1} can't fix...?!"
                        show tenna upright pointing smile at jump
                        tenna "Haha,{w=0.2} aha,{w=0.5} that can't be right!{p=0.5}{noalt}*{/noalt} I've gotta be useful for SOMETHING..."
                        show tenna upright pointing weak at droop
                        if persistent.glitches:
                            tenna_shh "Please..."
                        else:
                            tenna_shh "{sc=3}Please...{/sc}"
                
                if date_lp > 0:
                    play sfx ding
                    show tenna upright chest awkward at jump
                    $ date_lp -= 5
                    "Tenna needs to know that you're okay.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

    $ turn += 1

label tendate_park_menu:
    show tenna upright chest smile at yreset
    show screen tendate_select
    $ quick_menu = True
    $ skipyes = False
    $ _skipping = False
    
    date "[menu_text]"

    $ renpy.pause(hard=True)
    $ renpy.choice_for_skipping()



############################################################################################################
################## INTERACTS

######################################################
##### TALK
label tendate_talk:
    $ skipyes = True
    $ _skipping = True
    hide screen tendate_select

    ### QUIZ DATE
    if currentdate == "quiz":
        menu:
            date "Talk"
            "Nice day!":
                $ niceday += 1
                if niceday == 1:
                    $ q_niceday = True
                    "You tell Tenna you think today is a nice day."
                    show tenna upright card confused
                    tenna "Huh?"
                    tenna "You do?"
                    pause 1.0
                    show tenna upright pressed smile at rise
                    tenna "Oh,{w=0.2} I get it!"
                    tenna "You're saying that because you got to meet ME today,{w=0.2} aren't you?"
                    show tenna at wiggle
                    tenna "Haha!{w=0.2} You're just the darndest,{w=0.2} [persistent.mc]!"
                    play sfx ding
                    show tenna upright card awkward at jump
                    $ date_lp -= 3
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna made up his own reason to be praised.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna made up his own reason to be praised.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}LP{/color}."

                elif niceday == 2:
                    "You once again told Tenna that you think today is a nice day."
                    show tenna upright card panic at jump
                    tenna "Haha,{w=0.2} yes,{w=0.2} you did say that!"
                    show tenna upright card panic flipped at jump
                    tenna "You don't need to keep repeating it,{w=0.2} I promise!"
                else:
                    "You once again told Tenna that you think today is a nice day."
                    show tenna upright card confused at jump
                    tenna "Haha...{w=0.2} yes,{w=0.2} I know!"
                    show tenna upright pointing oh at jump
                    tenna "Let's get back to the quiz for now!"

            "Stat Bars?" if q_stat == 0:
                $ q_stat += 1
                "You ask Tenna what the stat bars at the top of the board are for."
                show tenna upright card blank at jump
                tenna "Stat bars?"
                show tenna stretch shrug smile at jump
                tenna "I haven't the foggiest idea of what you're talking about,{w=0.2} haha!"

            "Heart meter?" if q_stat == 1:
                $ q_stat += 1
                "You further ask why there is a heart meter that has appeared beside you."
                show tenna upright chest confused at jump
                tenna "Boy,{w=0.2} [persistent.mc].{p=0.2}{noalt}*{/noalt} You really ask some strange questions,{w=0.2} hahaha..."
                show tenna upright pointing smile at jump
                tenna "Why don't you just{w=0.5} accept what's going on without question?"
                show tenna stretch shrug smile at jump
                tenna "It's REALLY easy!{p=0.2}{noalt}*{/noalt} And I promise it'll be just OODLES of fun!"

            "Antenna?" if check >= 1 and not q_bandage:
                $ q_bandage = True
                "You ask Tenna why his antenna has a bandage on it."
                show tenna slouch claw panic at jump
                tenna "Hey, now!{p=0.2}{noalt}*{/noalt} That's a bit rude,{w=0.2} don't you think?!"
                show tenna upright back panic at jump
                tenna "I'm not asking YOU why YOU look the way you do!!"
                "You...{w=0.2} suppose that's fair enough.{p=0.2}{noalt}*{/noalt} But it leaves you feeling a bit awkward..."
                play sfx awkwardS
                $ vess_hp -= 1
                "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

            "Escape...?" if q_escape:
                $ q_escape = False
                "You ask Tenna what was about the escape question."
                show tenna upright chest angry
                tenna "I said don't WORRY about it!"
                show tenna upright chest panic flipped
                tenna "B-{nw=0.1}"
                show tenna at droop
                extend " because there's no REASON to go anywhere!"
                show tenna upright pressed smile at jump
                tenna "Isn't this fun?{p=0.2}{noalt}*{/noalt} Just chatting and answering questions?"
                show tenna upright back panic at droop
                tenna "Haha..."

            "Where are we?" if q_dump == 0 and q_where:
                $ q_dump += 1
                $ q_where = False
                "You ask Tenna what's behind the board."
                show tenna upright card blank
                tenna "...{w=0.2} What?"
                if persistent.glitches:
                    show tenna upright card panic flipped
                else:
                    show tenna upright card panic flipped at shaking
                tenna "What do you mean?{w=0.2} I don't see anything!"
                tenna "It's just you,{w=0.2} me,{nw=0.5}"
                show tenna upright back panic
                extend " {cps=60}and this perfectly-designed{/cps}{nw}"
                play sfx ten_quizzes
                if persistent.glitches:
                    extend " {image=txt_quizshowG}{alt}quizshow{/alt}"
                else:
                    extend " {image=txt_quizshow}{alt}quizshow{/alt}"

            "Behind the board" if q_dump == 1:
                $ q_dump += 1
                "You tell Tenna you can see there's definitely something behind the board."
                show tenna upright card blank
                tenna "Huh?"
                pause 1.0
                show tenna upright back neutral flipped at jump
                tenna "Oh--{w=0.2} well--"
                show tenna stretch shrug smile at jump
                tenna "Don't look at that!{nw=0.2}"
                show tenna upright pressed smile at jump
                extend "{p=0}{noalt}*{/noalt} Isn't it more fun over here?"
                show tenna at wiggle
                tenna "Where there's someone you can talk to and interact with...!?"
                show tenna upright back panic
                tenna "Even if the situation is a bit,{w=0.2} well..."
                show tenna upright pressed smile flipped at wiggle
                tenna "Unique!{p=0.5}{noalt}*{/noalt} Yes,{w=0.2} very unique."

            "Return":
                jump tendate_quiz_menu

        jump tendate_quiz


    ### PARK DATE
    elif currentdate == "park":
        menu:
            date "Talk"
            "Nice day!":
                $ niceday += 1
                if (q_niceday or p_niceday) and niceday < 3:
                    if niceday == 1:
                        $ niceday += 1
                    "You tell Tenna you still think today is a nice day."
                    show tenna upright back frown at droop
                    tenna "You know...{w=0.2} we can have more in-depth conversations,{w=0.2} too!"
                    show tenna upright back neutral
                    tenna "After all,{w=0.2} it's just the two of us."
                    show tenna upright chest awkward at wiggle
                    tenna "Who knows how long we'll be stuck together..."
                    show tenna upright pointing smile at jump
                    tenna "Can't you spare me some of your other thoughts, too?"
                    show tenna upright back awkward at droop
                    tenna "I'm not really asking for a lot,{w=0.2} haha."
                    "You suppose that's fair enough...{w=0.2}?"
                    "Something about his comment doesn't sit right,{w=0.2} though..."
                    play sfx awkwardS
                    $ vess_hp -= 1
                    "{color=[c_passion]}You suddenly feel a little more awake...{/color}"

                elif niceday >= 3:
                    "You figure Tenna won't be content with this conversation topic."
                    jump tendate_park_menu
                
                else:
                    $ p_niceday = True
                    "You tell Tenna you think today is a nice day."
                    show tenna upright pressed smile at rise
                    tenna "It's a {nw}"
                    play sfx ten_aww
                    if persistent.glitches:
                        extend "{image=txt_lovelyG}{alt}lovely{/alt}{w=0.2} day,{w=0.2} isn't it?"
                    else:
                        extend "{image=txt_lovely}{alt}lovely{/alt}{w=0.2} day,{w=0.2} isn't it?"
                    show tenna at wiggle
                    tenna "The two of us got to meet,{w=0.5} and..."
                    tenna "..."
                    show tenna at yreset
                    pause 1.0
                    show tenna upright chest frown
                    pause 1.0
                    show tenna stretch shrug smile flipped at jump
                    tenna "Well,{w=0.2} not much else has happened,{nw=0.2}"
                    show tenna upright pointing oh at jump
                    extend " but hey--{w=0.2} that's alright, too!"
                    show tenna upright chest neutral at jump
                    tenna "Not every day needs to be packed to the gills!{p=0.2}{noalt}*{/noalt} It's important to take time to relax!"
                    if date_fp > 0:
                        play sfx ding
                        $ date_fp -= 2
                        show tenna upright back smile at jump
                        if not seenstats_fp:
                            $ seenstats_fp = True
                            "Tenna is just happy you're here.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}Frienship Points{/color}."
                        else:
                            "Tenna is just happy you're here.{p=0.2}{noalt}*{/noalt} He gained 2 {color=[c_kindness]}FP{/color}."
            
            "I Love TV":
                $ p_iltv += 1
                if p_iltv >= 7:
                    show tenna upright chest blank
                "You say, \"I Love TV.\""
                if p_iltv == 1:
                    show tenna panic flustered at jump
                    if date_lp > 0:
                        play sfx ding
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Tenna lights up with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Tenna lights up with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                    tenna "O-{nw=0.1}"
                    show tenna at jump
                    extend " oh!{p=0.2}{noalt}*{/noalt} You're saying that...{w=0.5} completely unprompted?!"
                    show tenna at wiggle
                    if not persistent.lovetv:
                        tenna "And even after refusing to earlier...!"
                    tenna "Ahh...{w=0.5} ahaha!"
                    tenna "Oh, [persistent.mc],{w=0.2} you're gonna make me blush!"
                
                elif p_iltv == 2:
                    show tenna upright back awkward at jump
                    if date_lp > 0:
                        play sfx ding
                        $ date_lp -= 5
                        "You could have sworn Tenna's screen flickered pink for a moment.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
                    show tenna at wiggle
                    tenna "You{w=0.5} really do love TV,{w=0.2} don't you?"
                    show tenna upright pressed smile
                    tenna "Haha..."
                
                elif p_iltv == 3:
                    show tenna upright chest awkward at jump
                    if date_lp > 0:
                        play sfx ding
                        $ date_lp -= 3
                        "Tenna seems a little out of it, for some reason...{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}LP{/color}."
                    show tenna upright back awkward at jump
                    tenna "Haha.{p=0.5}{noalt}*{/noalt} I love hearing you say that,{w=0.2} [persistent.mc]."
                    tenna "Can I be selfish and ask you keep doing it?"
                
                elif p_iltv == 4:
                    show tenna upright chest panic at jump
                    if date_lp > 0:
                        play sfx ding
                        $ date_lp -= 1
                        "Tenna taps his foot anxiously.{p=0.2}{noalt}*{/noalt} He gained 1 {color=[c_passion]}LP{/color}."
                    show tenna upright chest frown
                    tenna "..."
                    show tenna upright chest confused
                    tenna "Sorry...{w=0.5} could you say that again?"
                    show tenna upright back panic at jump
                    tenna "I'm not sure it's really...{w=0.5} sinking in,{w=0.2} haha."
                
                elif p_iltv == 5:
                    show tenna upright chest blank
                    "Tenna can't even bring himself to smile."
                    show tenna upright chest frown
                    tenna "...{nw=0.2}"
                    show tenna at droop
                    extend " do you really mean that?"
                    show tenna upright back confused
                    tenna "It's almost like...{p=0.5}{noalt}*{/noalt} The more you say it,{w=0.2} the less it means something."
                    show tenna upright back frown at droop
                    tenna "..."
                
                elif p_iltv == 6:
                    show tenna upright back blank
                    "Tenna deadpans."
                    show tenna upright back frown at droop
                    tenna "...{w=0.2} (why don't I feel anything when you say that anymore?)"
                    show tenna slouch panic panic at wiggle
                    tenna "(It's only been a few times,{w=0.2} haha...)"
                    show tenna upright back nosed at yreset
                    tenna "Say it again."
                
                elif p_iltv >= 7:
                    show tenna upright back nose
                    "Tenna looks visibly upset."
                    show tenna upright back nosed
                    tenna "Say it again."
                    tenna "Please,{w=0.5} say it again."

                if p_iltv >= 6:
                    $ p_turn = turn

            "Isn't much of a park" if not p_parkq:
                $ p_parkq = True
                "You tell Tenna you really don't know that you'd call this a \"park.\""
                show tenna upright pointing oh at jump
                tenna "What do you mean?{p=0.2}{noalt}*{/noalt} It's got all the qualities of a park!"
                show tenna upright pressed smile at rise
                tenna "There's a sky,{w=0.2} the ground,{w=0.2} some...{w=0.5} green grass substitute..."
                tenna "Everything every park needs!"
                show tenna upright chest panic at droop
                tenna "Not much room to take a walk in, though,{w=0.2} haha."
                show tenna upright chest frown
                pause 1.0
                show tenna upright pressed smile at wiggle
                tenna "Just think of it like a video game!{p=0.5}{noalt}*{/noalt} Where you sit on your butt and watch the TV as you pretend to walk around in a virtual space!"
                tenna "Let yourself get lost in the screen enough,{w=0.2} and you might just forget it's not real life!"
                show tenna upright pointing oh at jump
                tenna "That's what I'm here for!"
                show tenna upright pointing smile at jump
                tenna "The big,{w=0.2} bright screen in front of you to bring you to {nw}"
                play sfx ten_paradise
                extend "{image=txt_paradise}{alt}paradise{/alt}!"
                if date_lp > 0:
                    play sfx ding
                    show tenna upright back neutral at jump
                    $ date_lp -= 3
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna seems content with himself.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna seems content with himself.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_passion]}LP{/color}."

            "I don't want this" if not p_ten_date and not p_dateno:
                $ p_turn = turn
                $ p_dateno = True
                "You explain to Tenna that you really didn't want to go on a date with him."
                if q_flirt:
                    show tenna upright pointing oh at jump
                    tenna "Then why were you flirting with me earlier??"
                    show tenna upright back frown
                    tenna "You're not trying to toy with my heart,{w=0.2} are you?"
                    show tenna at droop
                    tenna "I'll have you know,{w=0.2} I'm really quite fragile when it comes down to it,{w=0.2} haha..."
                    show tenna stretch shrug weak flipped
                    tenna "But-- no,{w=0.2} no...{nw=0.5}"
                    show tenna at shrink
                    extend "{p=0}{noalt}*{/noalt} You're right!"
                else:
                    show tenna upright back frown
                    tenna "Oh..."
                    show tenna upright back frown flipped
                    tenna "I suppose...{nw=0.2}"
                    show tenna at droop
                    extend " I did spring this on you with no warning, haha."
                    show tenna stretch shrug weak flipped at shrink
                tenna "I can't just force you to do something you don't want."
                show tenna upright back nosed flipped
                tenna "As much as it pains me..."
                pause 1.0
                tenna "...{nw=0.2}"
                show tenna at zreset
                extend " although."
                show tenna upright pointing oh at jump
                tenna "Would you be against{w=0.5} just hanging out with a friend?"
                show tenna upright back smile at wiggle
                tenna "Surely that's the best compromise,{w=0.2} don't you think?"
                if date_fp > 0:
                    play sfx ding
                    show tenna upright chest neutral at jump
                    $ date_fp -= 3
                    if not seenstats_fp:
                        $ seenstats_fp = True
                        "Tenna makes the choice for you.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color}."
                    else:
                        "Tenna makes the choice for you.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."

            "Cute date" if p_ten_date and not p_dateyes:
                $ p_dateyes = True
                "You tell Tenna that it's cute how much effort he put in to make this date happen."
                show tenna panic flustered at jump
                if date_lp > 0:
                    play sfx ding
                    $ date_lp -= 10
                    "Tenna practically implodes.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                tenna "Y-{w=0.2} you really think so?!"
                show tenna upright chest panic at jump
                tenna "I-{w=0.1} I-{w=0.1} I-{nw=0.1}"
                show tenna upright back awkward at jump
                extend " I'm so honored!!"
                show tenna upright pressed smile at wiggle
                tenna "I really did my best to impress you, [persistent.mc]...!"

            "Behind the board" if p_behind == 0 and p_qu_here:
                $ p_behind += 1
                "You ask what the deal was with the landscape behind the board."
                if ten_moveboard:
                    if q_dump or vex_behind:
                        if persistent.glitches:
                            show tenna upright chest panic
                        else:
                            show tenna upright chest panic at shaking
                        tenna "Why do you keep asking??{p=0.2}{noalt}*{/noalt} You SAW what was back there!"
                    else:
                        show tenna upright chest panic at wiggle
                        tenna "You...{w=0.2} already saw it,{w=0.2} didn't you?"
                        tenna "Shouldn't it be self-explanitory...?"
                    show tenna upright back nose at yreset
                    tenna "It's awful.{p=0.5}{noalt}*{/noalt} It's awful, isn't it?"
                    show tenna upright back nosed
                
                elif q_dump or vex_behind:
                    show tenna upright chest frown
                    tenna "This again..."
                    tenna "I'm serious,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} You don't want to know what's back there."
                    show tenna upright back neutral
                    tenna "Just pay attention to me,{w=0.2} alright?"
                    show tenna upright pressed smile at rise
                    tenna "You need something to make you happy!{p=0.2}{noalt}*{/noalt} A {nw}"
                    play sfx ten_cheer
                    extend "{image=txt_fun}{alt}fun{/alt}{w=0.2} guy like me!"
                    show tenna upright back frown at droop
                    tenna "Not...{w=0.5} all of that."
                
                else:
                    show tenna upright chest frown
                    tenna "Oh."
                    show tenna upright back frown
                    tenna "You, uh.{nw=0.5}"
                    show tenna at droop
                    extend "{p=0}{noalt}*{/noalt} Saw that,{w=0.2} huh."
                    show tenna upright chest awkward at jump
                    tenna "Don't worry about it!{p=0.2}{noalt}*{/noalt} I promise it can't hurt you or anything!"
                    show tenna upright pointing oh at jump
                    tenna "Besides,{w=0.2} I'd be here for you if anything went wrong!"
                    show tenna stretch shrug smile
                    tenna "I'm not the strongest guy around, but...!"
                    show tenna stretch shrug weak at wiggle
                    tenna "Ahah..."
                    show tenna upright back frown at yreset
               
                pause 1.0
                tenna "Let's maybe...{nw=0.5}"
                show tenna at droop
                extend " NOT talk about this anymore."
            
            "Behind the board (again)" if p_behind == 1:
                $ p_behind += 1
                $ p_turn = turn
                "You tried to ask about the board again,{w=0.2} but...{nw=0.2}"
                if persistent.glitches:
                    show tenna slouch claw angry at jump
                else:
                    show tenna slouch claw angry at shock
                tenna "I said we're NOT talking about it!!"
                tenna "What part of that aren't you getting?!"
                show tenna upright chest smile at jump
                tenna "Just keep your eyes on me!{p=0.2}{noalt}*{/noalt} Look at this beautiful park I painted just for you!!"
                show tenna upright pointing smile at wiggle
                tenna "Everything will be {nw}"
                play sfx ten_perfect
                extend "{image=txt_perfect}{alt}perfect.{/alt}"
                show tenna upright pressed smile
                tenna "I know what you need.{p=0.5}{noalt}*{/noalt} You just have to focus on me,{w=0.2} okay?"

            "Return":
                jump tendate_park_menu

        jump tendate_park


######################################################
##### ACT
label tendate_act:
    $ skipyes = True
    $ _skipping = True
    hide screen tendate_select
    
    ### QUIZ DATE
    if currentdate == "quiz":
        menu:
            date "Act"
            "Check":
                $ check += 1
                if check == 1:
                    $ q_check = True
                    "Tenna - 50 FP  100 LP{p=0.2}{noalt}*{/noalt} It appears he has some damage on his antenna."
                    show tenna panic panic at jump
                    tenna "H-{w=0.1} hey now!{p=0.2}{noalt}*{/noalt} You don't need to stare at me so intensely,{w=0.2} haha!"
                    show tenna upright card awkward at jump
                    tenna "How's about we get back on track?{p=0.2}{noalt}*{/noalt} Tell me your answer, [persistent.mc]!"
                else:
                    "Tenna - 50 FP  100 LP{p=0.2}{noalt}*{/noalt} Seems a bit self-consious about you staring at him."
                    show tenna upright card awkward at wiggle
                    tenna "..."
                    jump tendate_quiz_menu

            "Flirt":
                $ flirt += 1
                if flirt == 1:
                    $ q_flirt = True
                    "You tell Tenna his outfit looks amazing."
                elif flirt == 2:
                    $ q_flirt2 = True
                    "You tell Tenna he looks particularly rectangular today."
                elif flirt == 3:
                    "You tell Tenna that his antennae are very cute."
                else:
                    "You flirted with Tenna."
                    show tenna upright card awkward flipped at wiggle
                    "...{w=0.2} But,{w=0.2} it seems he wants to move onto a different topic."
                    jump tendate_quiz

                play sfx ding
                show tenna upright card awkward at jump
                if flirt == 1:
                    $ date_lp -= 5
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna seems overjoyed by the unexpected affection.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna seems overjoyed by the unexpected affection.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
                else:
                    $ date_lp -= 1
                    "This time,{w=0.2} he seems less ecstatic.{p=0.2}{noalt}*{/noalt} Tenna only gained 1 {color=[c_passion]}LP{/color}."

                if flirt == 1:
                    tenna "Wow!{p=0.2}{noalt}*{/noalt} A bit forward today,{w=0.2} huh?"
                    show tenna slouch whisper smug
                    tenna "{nw=0.2}"
                    play sfx ten_sax
                    if persistent.glitches:
                        tenna_funG "Save it for later, would you?"
                    else:
                        tenna_fun "Save it for later, would you?" # SELF VOICING FIX
               
                elif flirt == 2:
                    tenna "Oh, wow.{p=0.2}{noalt}*{/noalt} You're really committing to this."
                    show tenna upright pointing oh at jump
                    tenna "At this rate,{w=0.2} you're gonna come off as more desperate than me!"
                    pause 1.0
                    show tenna upright card awkward at jump
                    tenna "Haha."
                    tenna "I'm kidding,{w=0.2} of course!{p=0.5}{noalt}*{/noalt} About both of those things!!"
                    $ q_turn = turn
               
                else:
                    tenna "Um."
                    show tenna upright chest awkward at jump
                    tenna "Listen,{w=0.2} you're very sweet and all, [persistent.mc]..."
                    show tenna upright chest awkward flipped at jump
                    tenna "But I would REALLY like to get to know you,{w=0.2} too...!"
                    show tenna upright pointing smile at jump
                    tenna "I'd appreciate it if you answered these questions!{p=0.2}{noalt}*{/noalt} I've made them {nw}"
                    play sfx ten_heyevery
                    if persistent.glitches:
                        extend "{image=txt_specialG}{alt}special{/alt}{w=0.2} , just for you!"
                    else:
                        extend "{image=txt_special}{alt}special{/alt}{w=0.2} , just for you!"
                    
            "Answer":
                if question == 8:
                    "This is the final question of the quiz.{p=0.5}{noalt}*{/noalt} Only answer it when you're sure you want to continue."
                    menu:
                        rq "(This is the final question of the quiz.\n{noalt}*{/noalt} Only answer it when you're sure you want to continue.)"
                        "Okay":
                            pass

                        "Go back":
                            jump tendate_quiz_menu

                menu:
                    date "Which answer will you choose?"
                    "[quiz_answer1]":
                        $ quiz_selected = 1
                        pause 0.5

                        ### Come here often?
                        if question == 1:
                            $ q_where = True
                            $ persistent.here = "yes"

                        ### First thing you notice?
                        elif question == 2:
                            $ persistent.firstimpress = "handsome"

                        ### Fave TV programming?
                        elif question == 5:
                            $ persistent.programs = "cooking shows"

                        ### What's your blood type?
                        elif question == 6:
                            $ persistent.blood = "A"

                        ### I LOVE TV
                        elif question == 8:
                            $ persistent.lovetv = True

                        jump tendate_quizreact

                    "[quiz_answer2]":
                        $ quiz_selected = 2
                        pause 0.5

                        ### Come here often?
                        if question == 1:
                            $ q_where = True
                            $ persistent.here = "no"

                        ### First thing you notice?
                        elif question == 2:
                            $ persistent.firstimpress = "charming"

                        ### Fave TV programming?
                        elif question == 5:
                            $ persistent.programs = "music videos"
                        
                        ### What's your blood type?
                        elif question == 6:
                            $ persistent.blood = "B"

                        ### I LOVE TV
                        elif question == 8:
                            $ persistent.lovetv = True

                    "[quiz_answer3]":
                        $ quiz_selected = 3
                        pause 0.5

                        ### Come here often?
                        if question == 1:
                            $ q_where = True
                            $ persistent.here = "maybe"

                        ### First thing you notice?
                        elif question == 2:
                            $ persistent.firstimpress = "nose"

                        ### Fave TV programming?
                        elif question == 5:
                            $ persistent.programs = "anime"
                        
                        ### Blood type?
                        elif question == 6:
                            $ persistent.blood = "AB"

                        ### I LOVE TV
                        elif question == 8:
                            $ persistent.lovetv = True

                    "[quiz_answer4]":
                        $ quiz_selected = 4
                        pause 0.5

                        ### COME HERE OFTEN
                        if question == 1:
                            $ q_where = True
                            $ persistent.here = "where"

                        ### FIRST IMPRESSIONS
                        elif question == 2:
                            $ persistent.firstimpress = "tall"

                        ### Fave TV programming?
                        elif question == 5:
                            $ persistent.programs = "romance shows"
                        
                        ### BLOOD
                        elif question == 6:
                            $ persistent.blood = "O"

                        ### I LOVE TV
                        elif question == 8:
                            $ persistent.lovetv = True

                    "None of these":
                        pause 0.5

                        ### Come here often?
                        if question == 1:
                            $ q_where = True
                            show tenna upright card panic at jump
                            tenna "...{w=0.2} [persistent.mc]..."
                            tenna "You DO know it's a \"yes\" or \"no\" question,{w=0.2} right?"
                            show tenna upright pointing oh at jump
                            tenna "There's only two answers!"
                            pause 1.0
                            show tenna upright card panic flipped
                            tenna "Or...{w=0.2} you can just stand there silently,{w=0.2} haha..."
                            show tenna stretch shrug smile
                            tenna "It's okay!{nw=0.2}"
                            show tenna stretch shrug weak at droop
                            extend "{p=0}{noalt}*{/noalt} It's FINE...!"

                        ### First thing you notice?
                        elif question == 2:
                            show tenna panic panic at jump
                            tenna "None of those?!"
                            pause 0.5
                            show tenna stretch shrug weak flipped
                            tenna "Ha{w=0.1}ha,{w=0.5} that's fine...!"
                            if persistent.glitches:
                                show tenna upright chest panic flipped
                            else:
                                show tenna upright chest panic flipped at shaking
                            tenna "That was presumptuous to ask,{w=0.2} wasn't it?!"
                            tenna "..."
                            pause 1.0

                        ### What's your favorite food?
                        elif question == 3:
                            show tenna panic panic at jump
                            tenna "You don't like FOOD?!"
                            show tenna upright chest confused at jump
                            tenna "That can't be right..."
                            show tenna upright pointing oh at jump
                            tenna "Do you just mean of the options here?"
                            show tenna upright chest panic at droop
                            tenna "I...{w=0.2} don't know that I can..."
                            pause 1.0
                            if not persistent.favefood:
                                show tenna upright back neutral at jump
                                tenna "Let's just move on!"
                            elif persistent.favefood == "anything":
                                show tenna upright pointing oh at jump
                                tenna "Oh!{w=0.2} I get it!"
                                show tenna upright pointing smile at jump
                                tenna "You just don't have any particular favorites,{w=0.2} right?"
                                show tenna stretch raised cheer at jump
                                tenna "Of course!{p=0.2}{noalt}*{/noalt} It makes perfect sense!"
                                tenna "You definitely weren't just...{nw=0.2}"
                                show tenna at droop
                                extend " refusing to participate or anything,{w=0.2} haha!"
                                show tenna upright chest frown flipped at droop
                                tenna "..."
                            else:
                                show tenna upright pointing oh at jump
                                tenna "Are you sure you don't like [persistent.favefood]?"
                                show tenna panic flustered at jump
                                tenna "Not for any particular reason,{w=0.2} haha!"
                                show tenna upright pointing oh
                                tenna "You just look like you'd really like [persistent.favefood]."
                                menu:
                                    rq "You just look like you'd really like [persistent.favefood]."
                                    "I do.":
                                        show tenna upright pointing smile at jump
                                        tenna "Ah-ha!{w=0.2} I knew it!"
                                        show tenna stretch shrug smile at jump
                                        tenna "C'mon!{p=0.2}{noalt}*{/noalt} Why didn't ya just say that in the first place, [persistent.mc]?!"
                                        show tenna upright pointing oh at jump
                                        tenna "You know communication is the most important thing in any relationship,{w=0.2} don't you?!"
                                        pause 1.0
                                        show tenna upright chest frown
                                        pause 0.5
                                        tenna "..."
                                        pause 1.0
                                        show tenna at droop
                                        pause 1.0
                                        show tenna stretch shrug weak flipped at jump
                                        tenna "ANYWAY!"
                                    "I don't.":
                                        show tenna slouch claw panic at droop
                                        tenna "O-{w=0.1} oh!"
                                        show tenna upright chest panic at wiggle
                                        tenna "Haha,{w=0.2} silly me!"
                                        tenna "Who am I to make such bold claims about a stranger,{w=0.2} am I right,{w=0.2} folks?"
                                        show tenna upright chest frown at yreset
                                        tenna "..."

                        ### What's your blood type?
                        elif question == 6:
                            show tenna upright card blank
                            tenna "Huh?"
                            show tenna upright card confused at jump
                            tenna "Um.{p=0.2}{noalt}*{/noalt} There's only four,{w=0.2} aren't there...?"
                            pause 1.0
                            show tenna stretch shrug smile flipped at jump
                            tenna "You know what?{p=0.2}{noalt}*{/noalt} Forget it!"
                            tenna "It was a silly question to begin with,{w=0.2} haha!"

                        ### I LOVE TV
                        elif question == 8:
                            $ persistent.lovetv = False
                            show tenna upright card panic
                            tenna_shh "...................................."
                            show tenna upright card panic flipped at jump
                            tenna "Haha."
                            tenna "Um.{p=0.5}{noalt}*{/noalt} Well."
                            show tenna at wiggle
                            pause 2.0

                        ### General
                        else:
                            $ q_none += 1
                            if q_none == 1:
                                show tenna slouch claw panic at jump
                                tenna "NONE?"
                                tenna "There's so many to choose from!{p=0.2}{noalt}*{/noalt} How can NONE of them suit you?!"
                                show tenna upright pointing oh at jump
                                tenna "I can't keep adding options infinitely,{w=0.2} y'know!"
                                show tenna upright chest panic at jump
                                tenna "That's..."
                                pause 0.5
                                show tenna upright back frown at droop
                                pause 1.0

                            elif q_none == 2:
                                show tenna upright card panic
                                tenna "Still nothing,{w=0.2} huh?"
                                show tenna stretch shrug smile at jump
                                tenna "Haha,{w=0.2} that's okay...!"
                                show tenna stretch shrug weak at droop
                                tenna "..."

                            elif q_none >= 3:
                                show tenna upright card confused
                                tenna "..."
                                show tenna upright back frown
                                tenna "I'm sorry.{p=0.2}{noalt}*{/noalt} This isn't working out very well."
                                show tenna upright back nosed at droop
                                tenna "I'm sorry."

                                ### HEARTBREAK
                                hide screen quiztext
                                hide screen datestats
                                call heartbreak_ani from _call_heartbreak_ani_10
                                show screen quiztext
                                show screen datestats
                        
                        $ question += 1

                    "Return":
                        jump tendate_quiz_menu

                if quiz_selected != 0:
                    jump tendate_quizreact

            "Attempt to move board" if q_dump >= 2:
                $ q_dump += 1
                if q_dump == 3:
                    $ q_turn = turn
                    "You reach out and try to move the board...{nw=0.2}"
                    $ renpy.music.set_volume(0.0, channel='music')
                    play sfx whip
                    show tenna slouch claw angry at jump
                    tenna "WHAT are you doing?!"
                    pause 1.0
                    show tenna upright card panic
                    pause 1.0
                    show tenna upright card panic flipped at jump
                    tenna "Haha,{w=0.5} oops!"
                    tenna "What I MEANT to say was...{nw=0.5}"
                    show tenna upright card smile at jump
                    extend "{p=0}{noalt}*{/noalt} Could you leave the board alone please?"
                    show tenna upright pressed smile at jump
                    tenna "Thank you!"
                    $ renpy.music.set_volume(1.0, channel='music')
                else:
                    "That might not be the best idea while Tenna's watching..."

            "Return":
                jump tendate_quiz_menu
        
        jump tendate_quiz


    ### PARK DATE
    elif currentdate == "park":
        menu:
            date "Act"
            "Check":
                $ check += 1
                if check == 1:
                    "Tenna - 50 FP 100 LP{p=0.2}{noalt}*{/noalt} He's close to breaking."
                    show tenna upright pointing oh at jump
                    if q_check:
                        tenna "There you go again,{w=0.2} staring at me so intently."
                    else:
                        tenna "Hey now,{w=0.2} what're you staring at me so intensely for?"
                    show tenna slouch whisper smug
                    tenna "Hm?{p=0.2}{noalt}*{/noalt} Checking me out,{w=0.2} maybe?"
                    pause 2.0
                    show tenna upright back nose
                    tenna "...{w=0.2} or you can go quiet and make that comment really awkward."
                    show tenna stretch shrug weak flipped at wiggle
                    tenna "Thaaaat's fine, too,{w=0.2} haha!"
                else:
                    "Tenna - 50 FP 100 LP{p=0.2}{noalt}*{/noalt} He's very close to breaking."
                    jump tendate_park_menu

            "Flirt":
                $ flirt += 1
                if flirt < 4:
                    if flirt == 1:
                        $ p_flirt = True
                        "You tell Tenna that he's a star."

                        if not p_ten_date and q_flirt:
                            show tenna upright pointing oh at jump
                            tenna "There you are,{w=0.2} flirting again even though you DIDN'T want a date!"
                            show tenna upright chest blank
                            tenna "Really,{w=0.2} you're yanking my chain around a bit too much."
                            tenna "Could you just...{nw=0.2}"
                            show tenna at droop
                            extend " be a LITTLE clearer with me?{p=0.5}{noalt}*{/noalt} Please?"
                            show tenna upright back nose at yease
                            tenna "It's..."
                            pause 1.0
                            show tenna stretch shrug weak flipped at jump
                            tenna "Actually,{w=0.2} nevermind!{p=0.2}{noalt}*{/noalt} Don't worry about it!"
                            show tenna upright chest neutral at jump
                            tenna "I'm not going to complain if you're going to sit here a shower me with compliments, haha!"
                            if date_lp > 0:
                                play sfx ding
                                show tenna upright chest awkward at jump
                                $ date_lp -= 3
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Tenna seems to be covering up something.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Tenna seems to be covering up something.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}LP{/color}."
                            jump tendate_park

                    elif flirt == 2:
                        "You mention how clear the colors on Tenna's screen are."
                    elif flirt == 3:
                        "You applaud all the hard work Tenna has been doing."

                    if date_lp > 0:
                        play sfx ding
                        show tenna upright chest awkward at jump
                        if flirt == 1:
                            $ date_lp -= 5
                            if not seenstats_lp:
                                $ seenstats_lp = True
                                "Tenna glimmers from the attention.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                            else:
                                "Tenna glimmers from the attention.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."
                        elif flirt == 2:
                            $ date_lp -= 3
                            "The way he beams with excitement seems a little lackluster.{p=0.2}{noalt}*{/noalt} But Tenna still gained 3 {color=[c_passion]}LP{/color}."
                        elif flirt == 3:
                            $ date_lp -= 1
                            "Tenna seems moderately moved.{p=0.2}{noalt}*{/noalt} He only gained 1 {color=[c_passion]}LP{/color}."

                    if flirt == 1:
                        if not p_ten_date:
                            show tenna upright back awkward at jump
                            tenna "Golly.{w=0.2} I thought you said you weren't interested in a date?"
                            show tenna upright chest awkward flipped at jump
                            tenna "You're.{w=0.2}.{w=0.2}.{w=0.2} so cute,{w=0.2} [persistent.mc]."
                            show tenna upright pointing oh at jump
                            tenna "Just tell me what you're thinking up front next time,{w=0.2} okay?"
                        elif q_flirt:
                            show tenna upright back awkward at jump
                            tenna "Golly,{w=0.2} [persistent.mc]!{p=0.5}{noalt}*{/noalt} You're just relentless,{w=0.2} aren't you?"
                            show tenna upright pressed smile at wiggle
                            tenna "Not that there's anything wrong with that, haha!{p=0.5}{noalt}*{/noalt} Keep doin' what you're doin'!"
                        else:
                            show tenna upright pressed smile at jump
                            tenna "Golly, [persistent.mc]!{p=0.2}{noalt}*{/noalt} Ya really think so?"
                            show tenna stretch raised cheer at jump
                            tenna "You're just a peach!"

                    elif flirt == 2:
                        show tenna upright back awkward flipped at jump
                        tenna "D-{w=0.1} do you really think that?"
                        show tenna upright chest panic at jump
                        tenna "I mean.{nw=0.5}"
                        show tenna upright pressed smile at wiggle
                        extend "{p=0}{noalt}*{/noalt} Haha,{w=0.2} I already knew that!{w=0.5} I've never had a spec of burn-in!!"

                    elif flirt == 3:
                        show tenna upright back neutral flipped at jump
                        tenna "Oh, of course!"
                        show tenna upright pointing smile at jump
                        tenna "Anything for you,{w=0.2} my dear viewer!"

                elif flirt >= 4:
                    "You flirted with Tenna."
                    show tenna upright chest frown
                    "However,{w=0.2} he doesn't seem particularly receptive towards your advances."
                    tenna "I appreciate all that you have to say, [persistent.mc]..."
                    show tenna upright pointing oh at jump
                    tenna "But you really don't need to flatter me the whole time!"
                    show tenna upright back awkward at wiggle
                    tenna "You're spoiling me too much, ahah..."
                    show tenna upright back smile at jump
                    tenna "How's about you let me have center stage for a minute or two?"
                    show tenna upright pointing oh at jump
                    $ p_ten_comment = renpy.random.choice(["Here's one for you!", "Oh, I've got it!", "Like this!", "For example..."])
                    tenna "[p_ten_comment]"
                    show tenna upright pointing smile at jump
                    $ p_ten_flirt = renpy.random.choice(["you're the sweetest thing I've ever met!", "lovely", "you're just the darndest!", "selflove"])
                    if p_ten_flirt == "lovely":
                        tenna "[persistent.mc],{w=0.2} you're the most{nw}"
                        play sfx ten_aww
                        if persistent.glitches:
                            extend " {image=txt_lovelyG}{alt}lovely{/alt}{w=0.2} person this Dark World's ever seen!"
                        else:
                            extend " {image=txt_lovely}{alt}lovely{/alt}{w=0.2} person this Dark World's ever seen!"
                    elif p_ten_flirt == "selflove":
                        if persistent.selflove == "kindness":
                            $ p_ten_flirt = "your kindness is unmatched!"
                        elif persistent.selflove == "passion":
                            $ p_ten_flirt = "your passion for life is inspiring!"
                        elif persistent.selflove == "determination":
                            $ p_ten_flirt = "your determination is wonderfully admirable!"
                        elif persistent.selflove == "hope":
                            $ p_ten_flirt = "your eyes are brimming with spectacular hope!"
                        tenna "[persistent.mc],{w=0.2} [p_ten_flirt]"
                    else:
                        tenna "[persistent.mc],{w=0.2} [p_ten_flirt]"
                    pause 1.0
                    show tenna upright back awkward at jump
                    tenna "Haha,{w=0.2} no reaction...?"
                    tenna "Well,{w=0.2} that's okay.{p=0.5}{noalt}*{/noalt} I suppose it wasn't my best material."
                    show tenna upright chest smile at jump
                    tenna "The important part is that I told you what I truly believe!"

                    if date_fp > 0 and not p_flirt2:
                        play sfx ding
                        show tenna upright chest neutral at jump
                        $ date_fp -= 3
                        if not seenstats_fp:
                            $ seenstats_fp = True
                            "Funnily enough,{w=0.2} Tenna felt closer to you after saying that.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color}."
                        else:
                            "Funnily enough,{w=0.2} Tenna felt closer to you after saying that.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."
                    $ p_flirt2 = True
                    $ p_turn = turn

            "Ask":
                if p_qu_here and p_qu_blood and p_qu_food and p_qu_me and p_qu_self:
                    "You can't think of any other questions to ask Tenna."
                    jump tendate_park_menu

                else:
                    menu:
                        date "What question will you ask?"
                        "Come here often?" if not p_qu_here:
                            $ p_qu_here = True
                            "You ask Tenna if he visits this place often."
                            show tenna upright back panic at rise
                            tenna "Ahaha!{p=0.5}{noalt}*{/noalt} Oh,{w=0.2} haha,{w=0.2} well,{w=0.2} that's{w=0.2}.{w=0.2}.{w=0.2}.{w=0.2}!"
                            show tenna upright back frown at droop
                            tenna "Let's maybe talk about something else.{p=0.5}{noalt}*{/noalt} Please?"

                        "Blood type?" if not p_qu_blood:
                            $ p_qu_blood = True
                            "You ask Tenna what his blood type was."
                            show tenna upright chest neutral
                            tenna "That's a{w=0.5} fascinating question...!"
                            show tenna upright pointing oh at jump
                            tenna "Hate to break it to ya, [persistent.mc],{w=0.2} but I'm just a TV!{p=0.5}{noalt}*{/noalt} TVs don't have blood!"
                            show tenna slouch whisper smug
                            tenna "If you were trying to figure out my personality from that,{w=0.2} you're unfortunately out of luck!{nw}"
                            play sfx2 ten_laughtrack
                            extend "{p=0}"
                            if date_fp > 0:
                                play sfx ding
                                show tenna upright chest neutral at jump
                                $ date_fp -= 3
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "That being said,{w=0.2} Tenna found the inquiry funny.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "That being said,{w=0.2} Tenna found the inquiry funny.{p=0.2}{noalt}*{/noalt} He gained 3 {color=[c_kindness]}FP{/color}."

                        "Favorite food?" if not p_qu_food:
                            $ p_qu_food = True
                            "You ask Tenna what his favorite food is."
                            show tenna upright pointing oh at jump
                            tenna "MY favorite?"
                            show tenna upright pressed smile at rise
                            tenna "How sweet of you to ask,{w=0.2} [persistent.mc]!"
                            if turn >= 4 and persistent.favefood == "baked goods":
                                show tenna upright chest awkward at jump
                                tenna "Though,{w=0.2} you might already have a solid idea..."
                            show tenna upright pressed smile at wiggle
                            tenna "I've never been able to eat it myself,{w=0.2} but the memories I have with a good ol' homemade cinnamon-butterscotch pie..."
                            tenna "It can't be beat!"
                            show tenna upright pointing smile at jump
                            tenna "That qualifies,{w=0.2} doesn't it?!"
                            if date_fp > 0:
                                play sfx ding
                                show tenna upright chest neutral at jump
                                $ date_fp -= 3
                                if not seenstats_fp:
                                    $ seenstats_fp = True
                                    "Strangely,{w=0.2} Tenna seems confused by the question.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_kindness]}Friendship Points{/color}."
                                else:
                                    "Strangely,{w=0.2} Tenna seems confused by the question.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_kindness]}FP{/color}."

                        "Opinion of me?" if not p_qu_me:
                            $ p_qu_me = True
                            "You ask Tenna what he thinks of you."
                            show tenna stretch raised cheer at rise
                            tenna "What a silly question!{p=0.5}{noalt}*{/noalt} Of course I {nw}"
                            play sfx ten_aww
                            if persistent.glitches:
                                extend "{image=txt_loveG}{alt}love{/alt}{w=0.2} you!"
                            else:
                                extend "{image=txt_love}{alt}love{/alt}{w=0.2} you!"
                            show tenna upright chest awkward at wiggle
                            if p_dateno:
                                tenna "...{w=0.2} As a friend, of course!{w=0.5} Haha!"
                            else:
                                tenna "...{w=0.2} I mean.{w=0.5} I know we haven't known each other long,{w=0.2} but..."
                            show tenna upright pressed smile
                            if persistent.selflove:
                                tenna "You've got so much [persistent.selflove] to share with the world!{p=0.5}{noalt}*{/noalt} How could I not appreciate you?"
                            else:
                                tenna "Point is--{w=0.2} I know destiny is at work here!"
                            if date_lp > 0:
                                play sfx ding
                                show tenna upright chest awkward at jump
                                $ date_lp -= 3
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Something feels a little insincere about his words.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Something feels a little insincere about his words.{p=0.2}{noalt}*{/noalt} But he gained 3 {color=[c_passion]}LP{/color}."

                        "Opinion of yourself?" if not p_qu_self:
                            $ p_qu_self = True
                            "You ask Tenna what he thinks of himself."
                            show tenna upright chest neutral
                            tenna "...{w=0.5} Myself?"
                            show tenna upright chest frown
                            tenna "I..."
                            pause 1.0
                            show tenna at droop
                            tenna "Haha.{p=0.5}{noalt}*{/noalt} Would it be strange to say I'm..."
                            show tenna upright chest panic flipped at jump
                            tenna "No-- actually!{p=0.5}{noalt}*{/noalt} What a ridiculous thing for me to suggest!"
                            show tenna stretch raised cheer at wiggle
                            tenna "I'm {nw}"
                            play sfx ten_heyevery
                            extend "{image=txt_tvtastic}{alt}TV-tastic{/alt}{p=1}{noalt}*{/noalt} The entertainment on your screen that makes you scream!"
                            show tenna stretch raised cheer flipped
                            tenna "I'm {nw}"
                            play sfx ten_sax
                            if persistent.glitches:
                                extend "{image=txt_groovyG}{alt}groovy{/alt}{w=0.5} and absolutely NEVER glooby!!"
                            else:
                                extend "{image=txt_groovy}{alt}groovy{/alt}{w=0.5} and absolutely NEVER glooby!!"
                            show tenna upright pointing smile at jump
                            tenna "I'LL never forget that,{w=0.2} so you shouldn't, either,{w=0.2} dearest [persistent.mc]!"
                            if date_lp > 0:
                                play sfx ding
                                show tenna upright chest awkward at jump
                                $ date_lp -= 5
                                if not seenstats_lp:
                                    $ seenstats_lp = True
                                    "Tenna had a boost of self-confidence.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}Love Points{/color}."
                                else:
                                    "Tenna had a boost of self-confidence.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_passion]}LP{/color}."

                        "Return":
                            jump tendate_park_menu

                    $ p_turn = turn
                            
            "Play the game" if p_lot:
                if p_played:
                    "You asked Tenna if you could play that game again."
                else:
                    $ p_played = True
                    "You told Tenna that you want to play the game now."
                    if date_lp > 0:
                        play sfx ding
                        show tenna upright back awkward at jump
                        $ date_lp -= 10
                        if not seenstats_lp:
                            $ seenstats_lp = True
                            "Tenna beams with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                        else:
                            "Tenna beams with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                show tenna upright pointing smile at jump
                tenna "You really want to?{p=0.2}{noalt}*{/noalt} Really-really?"
                show tenna upright pressed smile at jump
                tenna "Of course, [persistent.mc]!{w=0.2} Let's play it together!!"
                jump lot_intro

            "Attempt to move board" if p_behind >= 2:
                if p_board and turn >= 20:
                    if not persistent.playthru:
                        if not p_lot:
                            "You think you may have forgotten to give something to Tenna."
                            jump tendate_park_menu
                        elif not p_played:
                            "You think you should ask Tenna about that game he mentioned first."
                            jump tendate_park_menu
                        else:
                            pass
                    else:
                        pass

                    "This is likely to upset Tenna.{p=0.5}{noalt}*{/noalt} Only do it when you're sure you want to continue."
                    menu:
                        rq "This is likely to upset Tenna.{p=0.5}{noalt}*{/noalt} Only do it when you're sure you want to continue."
                        "Okay":
                            pass
                        
                        "Go back":
                            jump tendate_park_menu

                    "You one again reach out and try to move the board aside...{nw=0.2}"

                    ### TRANSITION TO END
                    jump tennaend

                else:
                    if not p_board:
                        $ p_board = True
                        if q_dump >= 3:
                            "You one again reach out and try to move the board aside...{nw=0.2}"
                        else:
                            "You reach out and try to move the board aside...{nw=0.2}"
                        play sfx plop
                        show tenna upright chest blank at rise
                        "Suddenly,{w=0.2} Tenna snatches your hand out of the air to stop you...!?"
                        show tenna upright chest panic at jump
                        tenna "O-{w=0.1} oh!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} OOPS!"
                        show tenna stretch shrug smile
                        tenna "Seems we just HAPPENED to touch hands by complete and utter accident!"
                        menu:
                            rq "Seems we just HAPPENED to touch hands by complete and utter accident!"
                            "Lean into it":
                                "You decided to squeeze Tenna's hand and give him a knowing smile."
                                play sfx plop
                                if persistent.glitches:
                                    show tenna panic flustered at jump
                                else:
                                    show tenna panic flustered at shock
                                "He drops your hand almost immediately."
                                show tenna upright back awkward flipped at wiggle
                                tenna "Pffffffpfft,{w=0.1} hahaha,{w=0.1} well, I,{w=0.1} that's{nw}"
                                show tenna stretch shrug weak flipped at jump
                                tenna "N-{w=0.1} nevermind!{p=0.5}{noalt}*{/noalt} Let's pretend that didn't happen!!"
                                if date_lp > 0:
                                    play sfx ding
                                    show tenna upright back awkward at jump
                                    $ date_lp -= 10
                                    if not seenstats_lp:
                                        $ seenstats_lp = True
                                        "Tenna's screen is undeniably pink.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                                    else:
                                        "Tenna's screen is undeniably pink.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

                            "Question him":
                                "You raised an eyebrow and just stared at him."
                                show tenna upright chest awkward at jump
                                pause 1.0
                                tenna "What?{p=0.5}{noalt}*{/noalt} Are you...{w=0.2} waiting for ME to do something?"
                                pause 1.0
                                play sfx plop
                                show tenna upright back awkward flipped at jump
                                "He drops your hand and looks away."
                                show tenna at wiggle
                                tenna "Ah,{w=0.2} just...{w=0.5} forget that happened!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} it was just a silly joke!{w=0.2} A prank!!"
                                if date_lp > 0:
                                    play sfx ding
                                    show tenna upright back awkward at jump
                                    $ date_lp -= 5
                                    if not seenstats_lp:
                                        $ seenstats_lp = True
                                        "Tenna's thoroughly embarrassed.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}Love Points{/color}."
                                    else:
                                        "Tenna's thoroughly embarrassed.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}LP{/color}."

                    else:
                        "You don't think it'll be helpful to try that again just yet."

            "Return":
                jump tendate_park_menu

        jump tendate_park


######################################################
##### ITEM
label tendate_item:
    hide screen tendate_select

    ### QUIZ DATE
    if currentdate == "quiz":
        $ skipyes = True
        $ _skipping = True

        $ q_item += 1
        if q_item == 1:
            "It felt like there was something in your pocket."
            "But when you went to check..."
            "...{w=0.2} nothing was there."
            $ persistent.itemheard = True
        elif q_item == 2:
            "There's nothing there."
        else:
            show tenna upright pointing oh at jump
            tenna "Hey, now!{p=0.2}{noalt}*{/noalt} What're you continually checking your pocket for?!"
            show tenna upright card awkward at jump
            tenna "Is what's happening here not entertaining enough??{nw=0.5}"
            show tenna upright back awkward at wiggle
            extend "{p=0}{noalt}*{/noalt} I can add more!!"
            show tenna upright pointing smile at jump
            tenna "Whatever you want!{p=0.2}{noalt}*{/noalt} Just say the {nw}"
            play sfx ten_favorite
            if persistent.glitches:
                extend "{image=txt_wordG}{alt}word{/alt}!"            
            else:
                extend "{image=txt_word}{alt}word{/alt}!"
            show tenna stretch raised cheer at jump
            play sfx badexplosion
            if persistent.glitches:
                $ _history = False
                tenna_shh "{image=txt_explosionsG}{alt}Explosions?!{/alt}{nw=0.8}"
                $ _history = True
                tenna "{image=txt_explosionsG}{alt}Explosions?!{/alt}{fast}\n{noalt}*{/noalt} Sure!!"
            else:
                $ _history = False
                tenna_shh "{image=txt_explosions}{alt}Explosions?!{/alt}{nw=0.8}"
                $ _history = True
                tenna "{image=txt_explosions}{alt}Explosions?!{/alt}{fast}\n{noalt}*{/noalt} Sure!!"
            show tenna stretch shrug weak
            play sfx splat
            $ _history = False
            tenna_shh "{image=txt_tears}{alt}Tears{/alt}?!{nw=0.8}"
            $ _history = True
            tenna "{image=txt_tears}{alt}Tears{/alt}?!{fast}\n{noalt}*{/noalt} Got those too!!!"
            show tenna upright card smile at jump
            tenna "Hahaha!{p=0.5}{noalt}*{/noalt} Just...{w=0.2} keep your eyes over here,{w=0.2} could you?"
            show tenna upright back panic at wiggle
            tenna "...{w=0.2} Because of the{nw}"
            play sfx ten_quizzes
            if persistent.glitches:
                extend " {image=txt_quizshowG}{alt}quizshow{/alt} ,{w=0.5} of course!"
            else:
                extend " {image=txt_quizshow}{alt}quizshow{/alt} ,{w=0.5} of course!"
        
        jump tendate_quiz


    ### PARK DATE
    elif currentdate == "park":
        $ date_item = True
        $ quick_menu = False
        call screen inv_view
        jump tendate_park_menu

### PARK DATE
label tendate_item_react:
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True

    ## PIPIS
    if which_item == itm_pipis:
        if not p_pipis:
            $ p_pipis = True
            if vex_pipisask:
                if not vex_natennuh:
                    "You brought out the same weird item you'd shown \"Not Tenna\" at the shop earlier."
                else:
                    "You brought out the same weird item you'd shown \"Mr. Natennuh\" at the shop earlier."
                show tenna slouch claw panic at jump  
                tenna "T-{w=0.1} this again??"
                show tenna panic panic at jump
                tenna "Where did you even FIND this?!"
            else:
                "You showed Tenna the weird item you found on the ground earlier."
                show tenna slouch claw panic at jump
                tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}--?!"
                show tenna panic panic at jump
                tenna "How'd THAT get here??"
            show tenna upright chest angry at droop
            tenna "That's not...!"
            "You tell Tenna that you found it laying on the ground,{w=0.2} not far from where you met him."
            show tenna slouch claw panic
            $ _history = False
            tenna "H-{nw=0.2}"
            $ _history = True
            play sfx beepSh
            if persistent.glitches:
                show tenna panic smpte at jump
            else:
                show tenna panic smpte at shock
            tenna_shh "H-{fast} HUH?"
            show tenna upright chest panic flipped at jump
            tenna "Don't be ridiculous, [persistent.mc].{p=0.2}{noalt}*{/noalt} I would have noticed that."
            tenna "...{nw=0.5}"
            show tenna upright chest angry at jump
            extend " You can keep that,{w=0.2} by the way."
            show tenna upright chest frown at droop
            tenna "..."
        else:
            "You tried offering the weird item to Tenna once more."
            show tenna upright chest angry at rise
            tenna "[persistent.mc].{p=0.5}{noalt}*{/noalt} I'm PRETTY SURE I expressed how I DON'T want that already."

    ## FLOWER
    elif which_item == itm_flower:
        $ inventory.remove(itm_flower)
        if vex_natennuh:
            "You offered Tenna the flower \"Mr. Natennuh\" \"sold\" you earlier."
        else:
            "You offered Tenna the flower \"Not Tenna\" \"sold\" you earlier."
        play sfx item
        show tenna upright chest awkward at jump
        "Tenna just about beams."
        show tenna upright pointing oh at jump
        tenna "Oh,{w=0.2} is that for me?"
        show tenna upright pressed smile at rise
        tenna "Ahaha!{w=0.2} How thoughtful of you, [persistent.mc]!"
        if persistent.favecolor:
            show tenna upright back awkward at jump
            tenna "Wow,{w=0.2} its color even reminds me of you--{w=0.2} for no reason in particular!"
        show tenna upright pressed smile at wiggle
        tenna "Aren't you such a charmer?"
        if date_lp > 0:
            play sfx ding
            show tenna upright back awkward at jump
            $ date_lp -= 10
            if not seenstats_lp:
                $ seenstats_lp = True
                "Tenna is somehow honored?{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
            else:
                "Tenna is somehow honored?{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."

    ## DVD / LEGEND OF TENNA
    elif which_item == itm_dvd:
        $ p_lot = True
        $ inventory.remove(itm_dvd)
        if vex_natennuh:
            "You offered Tenna the DVD box \"Mr. Natennuh\" \"sold\" you earlier."
        else:
            "You offered Tenna the DVD box \"Not Tenna\" \"sold\" you earlier."
        play sfx item
        show tenna upright chest awkward at rise
        "Immediately, he shimmers with excitement."
        show tenna upright chest smile at jump
        tenna "Wow,{w=0.2} what a gift you've got there, [persistent.mc]!"
        show tenna at wiggle
        tenna "I've definitely NEVER seen it before...{nw=0.2}"
        show tenna panic flustered at jump
        extend " oh!!"
        show tenna upright chest awkward
        tenna "Would you look at that!{p=0.5}{noalt}*{/noalt} There isn't actually a DVD inside at all!"
        show tenna upright pointing smile at jump
        tenna "It looks more like...{w=0.5} a game cartridge,{w=0.2} perhaps?"
        show tenna stretch raised cheer flipped at wiggle
        tenna "Haha, wow!{w=0.5} I didn't prepare for this at all...{nw=0.5}"
        show tenna upright pointing oh at jump
        extend " oh wait!!"
        show tenna stretch shrug smile at jump
        tenna "Turns out there just happens to be a game system right here!!{p=0.5}{noalt}*{/noalt} How convenient!!!"
        pause 1.0
        show tenna upright chest neutral at jump
        tenna "So, um."
        show tenna upright chest smile at jump
        tenna "Would you{w=0.5} want to play the game?{p=0.2}{noalt}*{/noalt} With me?"
        menu:
            rq "Would you want to play the game?{p=0}{noalt}*{/noalt} With me?"
            "Sure":
                $ p_played = True
                "You told Tenna that you would play it."
                if date_lp > 0:
                    play sfx ding
                    show tenna upright back awkward at jump
                    $ date_lp -= 10
                    if not seenstats_lp:
                        $ seenstats_lp = True
                        "Tenna beams with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}Love Points{/color}."
                    else:
                        "Tenna beams with excitement.{p=0.2}{noalt}*{/noalt} He gained 10 {color=[c_passion]}LP{/color}."
                show tenna stretch raised cheer at rise
                tenna "Great!!"
                jump lot_intro

            "No thanks":
                "You told Tenna that you'd rather not."
                show tenna slouch claw panic at droop
                tenna "O-{w=0.1} oh!"
                show tenna upright back panic flipped at wiggle
                tenna "That's okay, too,{w=0.2} I suppose..."
                show tenna stretch shrug smile flipped
                tenna "Gotta stay true to yourself and all that!"
                show tenna stretch shrug weak flipped at droop
                "...{w=0.5} Somehow,{w=0.2} you're feeling guilty for your choices."

    ## TENNA FIGURE
    elif which_item == itm_fighate or which_item == itm_figlove:
        if not p_figure:
            $ p_figure = True
            "You tried to offer Tenna the figure of himself."
            show tenna slouch claw panic at jump
            tenna "Oh, [persistent.mc],{w=0.2} you don't have to give me that!"
            show tenna upright pointing smile at jump
            tenna "That one's for you to keep!"
            tenna "Isn't it nice to have something that'll always remind you of your..."
            pause 1.0
            show tenna upright back awkward
            tenna "Your,{nw=0.2}"
            show tenna at droop
            extend " um...{p=0.2}{noalt}*{/noalt} Uh..."
            show tenna upright back awkward flipped
            tenna_shh "............................."
            pause 1.0
            show tenna stretch shrug weak
            tenna "Your, uh.{p=0.5}{noalt}*{/noalt} Friend?"
            if date_fp > 0:
                play sfx ding
                show tenna upright chest neutral at jump
                $ date_fp -= 5
                if not seenstats_fp:
                    $ seenstats_fp = True
                    "Tenna isn't sure how to address you.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
                else:
                    "Tenna isn't sure how to address you.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
        else:
            "You tried to offer Tenna the figure of himself again."
            show tenna upright chest frown at droop
            tenna "Haha,{w=0.2} seriously, [persistent.mc]!"
            show tenna upright pointing oh at jump
            tenna "That one's for YOU!"
            show tenna upright chest awkward at wiggle
            tenna "You don't have to be showering ME in all the gifts!"

    ## RED SHARD
    elif which_item == itm_redshard1:
        if not vex_rsh1ask:
            $ vex_rsh1ask = True
            if vex_natennuh:
                "You showed off the red shard you got from \"Mr. Natennuh\" earlier."
            else:
                "You showed off the red shard you got from \"Not Tenna\" earlier."
            show tenna upright chest neutral
            "You tried to explain the strange vision you had upon touching it."
            show tenna upright chest blank
            "You described a city,{w=0.2} where Tenna was talking with someone else before being approached by a stranger."
            show tenna upright chest frown at droop
            tenna "That's...{w=0.5} an odd sort of thing for you to bring up, [persistent.mc]!"
            show tenna upright chest awkward at yease
            tenna "I don't really know what you're talking about.{nw=0.5}"
            show tenna at wiggle
            extend "{p=0}{noalt}*{/noalt} Honest!{w=0.2} TV's honor!"
            show tenna upright back frown at droop
            tenna "...{w=0.2} but it is..."
        else:
            show tenna upright chest blank
            "You tried to ask about the red shard again,{w=0.2} to no avail."
            show tenna upright chest frown at droop
            tenna "I'm being honest, [persistent.mc].{p=0.5}{noalt}*{/noalt} I really don't know why that rock's so...{w=0.2} bizarre?"

    ## ALL OTHERS
    else:
        "You don't think Tenna would have anything to say about that."
        jump tendate_park_menu

    jump tendate_park



############################################################################################################
################## QUIZ ANSWER REACTS
label tendate_quizreact:
    $ skipyes = True
    $ _skipping = True
    
    ## Come here often?
    if question == 1:
        ## Yes
        if quiz_selected == 1:
            if persistent.playthru:
                show tenna upright chest confused at jump
                tenna "Huh..."
                show tenna upright pointing oh
                tenna "You know,{w=0.2} I thought you looked familiar!"
                show tenna upright chest panic at jump
                tenna "But I...{w=0.2} don't know why..."
                pause 1.0
                show tenna stretch shrug smile flipped at jump
                tenna "Eh.{w=0.2} It's probably nothing."
            else:
                show tenna upright card confused at jump
                tenna "Wait,{w=0.2} really?"
                show tenna slouch claw panic at jump
                tenna "Then where have you been this whole time?!"
                pause 0.5
                show tenna upright card panic
                pause 1.0
                tenna "I mean,{w=0.2} uh...{nw=0.2}"
                show tenna upright pointing smile at jump
                extend "{p=0}{noalt}*{/noalt} Let's move on, shall we?!"

        ## No
        elif quiz_selected == 2:
            if persistent.playthru:
                show tenna upright card frown
                tenna "..."
                pause 1.0
                show tenna upright pointing oh
                tenna "Are you sure...?"
                show tenna upright chest panic at jump
                tenna "It's just that--{p=0.5}{noalt}*{/noalt} You look awfully familiar??"
                pause 1.0
                show tenna stretch shrug smile flipped at jump
                tenna "Eh.{w=0.2} It's probably nothing."
            else:
                show tenna upright card confused
                tenna "Ah."
                show tenna stretch shrug smile at jump
                tenna "I've never seen you around before,{w=0.2} so that makes sense!"
                show tenna slouch claw panic at jump
                tenna "Not that--{nw=0.5}"
                show tenna at droop
                extend " I'm here all that much, either,{w=0.2} haha..."

        ## Maybe
        elif quiz_selected == 3:
            show tenna upright card confused at jump
            tenna "\"Maybe\"???????????"
            show tenna slouch claw panic at droop
            tenna "What do you mean,{w=0.2} \"Maybe\"????????????"

        ## Where are we?
        elif quiz_selected == 4:
            show tenna upright card frown
            tenna "Oh."
            show tenna at droop
            tenna "That's..."
            pause 1.0
            show tenna stretch shrug smile at jump
            tenna "Eh,{w=0.2} what does it matter,{w=0.2} really?!"
            show tenna upright pressed smile at wiggle
            tenna "\"Here\" is...{w=0.2} a place where you'll be happy forever,{w=0.2} right...?!"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna doesn't really know what answer he expected.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna doesn't really know what answer he expected.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
    
    ## First thing you notice?
    elif question == 2:
        ## Handsome / Charming
        if quiz_selected == 1 or quiz_selected == 2:
            show tenna upright pressed smile at rise
            tenna "Really?{p=0.2}{noalt}*{/noalt} Oh, you!"

        ## Big nose
        elif quiz_selected == 3:
            show tenna upright pointing smile at jump
            tenna "See?{p=0.2}{noalt}*{/noalt} You WERE thinking about it!"
            tenna "..."
            pause 1.0
            show tenna upright chest awkward at jump
            tenna "A-{w=0.2} anyway,{w=0.5} haha...!"

        ## Tall
        elif quiz_selected == 4:
            show tenna upright pressed smile at rise
            tenna "R-{w=0.2} really?{p=0.2}{noalt}*{/noalt} You think I'm tall?{p=0.5}{noalt}*{/noalt} Even though right now I'm--{nw=0.1}"
            show tenna upright chest awkward at jump
            tenna "I mean."

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna is flattered?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna is flattered?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    ## What's your favorite food?
    elif question == 3:
        ## Sweet
        if quiz_selected == 1:
            tenna "Sweets?"
            if not persistent.favefood:
                pass
            elif persistent.favefood not in ["baked goods", "candy", "sweets"]:
                show tenna upright card blank at jump
                tenna "Huh!{p=0.2}{noalt}*{/noalt} That wasn't really what I was expecting..."
                show tenna stretch shrug smile at jump
                tenna "Oh well!"
                show tenna upright card neutral at jump
                tenna "Anyway,{w=0.2} what kind of sweets?"

            show tenna upright pointing oh
            tenna "Like baked goods?{p=0.2}{noalt}*{/noalt} Or maybe candy??"
            menu:
                rq "Like baked goods?{p=0}{noalt}*{/noalt} Or maybe candy??"
                "Baked goods":
                    show tenna upright card smile at jump
                    tenna "Okay!"
                    if not persistent.favefood:
                        show tenna upright card blank flipped at wiggle
                        tenna "(Hm...{w=0.2} maybe I could try something that used to be on the cooking channel...)"
                    elif persistent.favefood != "baked goods":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "baked goods":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "baked goods"
                    
                "Candy":
                    show tenna upright card neutral at jump
                    tenna "I see!"
                    if not persistent.favefood:
                        show tenna upright card confused flipped at wiggle
                        tenna "(That...{w=0.2} might prove to be difficult...)"
                    elif persistent.favefood != "candy":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "candy":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "candy"

                "Neither":
                    show tenna upright chest frown at jump
                    tenna "Neither?!"
                    show tenna stretch shrug smile at jump
                    tenna "Well...{w=0.2} I'll just keep \"sweets\" in mind,{w=0.2} then!"
                    if not persistent.favefood:
                        pass
                    elif persistent.favefood != "sweets":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "sweets":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "sweets"

        ## Salty
        elif quiz_selected == 2:
            tenna "Salty foods?"
            if not persistent.favefood:
                pass
            elif persistent.favefood not in ["fries", "pretzels", "salty foods"]:
                show tenna upright card blank at jump
                tenna "Huh!{p=0.2}{noalt}*{/noalt} That wasn't really what I was expecting..."
                show tenna stretch shrug smile at jump
                tenna "Oh well!"
                show tenna upright card neutral at jump
                tenna "Anyway,{w=0.2} what kind of salty foods?"

            show tenna upright pointing oh
            tenna "Like fries?{p=0.2}{noalt}*{/noalt} Or maybe pretzels??"
            menu:
                rq "Like fries?{p=0}{noalt}*{/noalt} Or maybe pretzels??"
                "Fries":
                    show tenna upright card smile at jump
                    tenna "Okay!"
                    if not persistent.favefood:
                        show tenna upright card blank flipped at wiggle
                        tenna "(Hm...{w=0.2} maybe I could try something that used to be on the cooking channel...)"
                    elif persistent.favefood != "fries":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "fries":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "fries"
                    
                "Pretzels":
                    show tenna upright card neutral at jump
                    tenna "I see!"
                    if not persistent.favefood:
                        show tenna upright card confused flipped at wiggle
                        tenna "(That...{w=0.2} might prove to be difficult...)"
                    elif persistent.favefood != "candy":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "candy":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "candy"

                "Neither":
                    show tenna upright chest frown at jump
                    tenna "Neither?!"
                    show tenna stretch shrug smile at jump
                    tenna "Well...{w=0.2} I'll just keep \"salty foods\" in mind,{w=0.2} then!"
                    if not persistent.favefood:
                        pass
                    elif persistent.favefood != "salty foods":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "salty foods":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "salty foods"
            
            
        ## Bitter
        elif quiz_selected == 3:
            tenna "Bitter foods?"
            if not persistent.favefood:
                pass
            elif persistent.favefood not in ["coffee", "chocolate", "bitter foods"]:
                show tenna upright card blank at jump
                tenna "Huh!{p=0.2}{noalt}*{/noalt} That wasn't really what I was expecting..."
                show tenna stretch shrug smile at jump
                tenna "Oh well!"
                show tenna upright card neutral at jump
                tenna "Anyway,{w=0.2} what kind of bitter foods?"

            show tenna upright pointing oh
            tenna "Like chocolate?{p=0.2}{noalt}*{/noalt} Or maybe coffee??"
            menu:
                rq "Like chocolate?{p=0}{noalt}*{/noalt} Or maybe coffee??"
                "Chocolate":
                    show tenna upright card smile at jump
                    tenna "Okay!"
                    if not persistent.favefood:
                        show tenna upright card blank flipped at wiggle
                        tenna "(Hm...{w=0.2} maybe I could try something that used to be on the cooking channel...)"
                    elif persistent.favefood != "chocolate":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "chocolate":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "chocolate"
                    
                "Coffee":
                    show tenna upright card neutral at jump
                    tenna "I see!"
                    if not persistent.favefood:
                        show tenna upright card confused flipped at wiggle
                        tenna "(That...{w=0.2} might prove to be difficult...)"
                    elif persistent.favefood != "coffee":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "coffee":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "coffee"

                "Neither":
                    show tenna upright chest frown at jump
                    tenna "Neither?!"
                    show tenna stretch shrug smile at jump
                    tenna "Well...{w=0.2} I'll just keep \"bitter foods\" in mind,{w=0.2} then!"
                    if not persistent.favefood:
                        pass
                    elif persistent.favefood != "bitter foods":
                        show tenna upright card confused flipped at wiggle
                        tenna "(That REALLY wasn't what I thought you'd say...)"
                    elif persistent.favefood == "bitter foods":
                        show tenna upright pointing oh at jump
                        tenna "You know,{w=0.2} I had a feeling you'd answer that exact thing!"
                        play sfx ding
                        show tenna upright card neutral at jump
                        $ date_fp -= 5
                        "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."
                        $ question += 1
                        jump tendate_quiz
                    $ persistent.favefood = "bitter foods"

        ## Anything Tenna makes
        elif quiz_selected == 4:
            show tenna panic flustered at jump
            tenna "A-{w=0.1} anything?"
            if persistent.favefood in ["anything", None]:
                $ persistent.favefood = "anything"
                tenna "Do you mean...{w=0.2} so long as I'm the one making it,{w=0.2} or that you aren't picky?"
                pause 0.5
                show tenna upright card awkward flipped at jump
                tenna "Actually,{w=0.2} I don't want the answer to that."
                show tenna upright pointing smile at wiggle
                tenna "I'm just going to accept that answer as it is,{w=0.2} haha!"
                show tenna upright pressed smile
                tenna "Cooking food comes straight from the heart,{w=0.2} right?!"
                show tenna upright chest panic at jump
                tenna "I mean."
            else:
                tenna "..."
                show tenna upright chest frown
                tenna "That can't be right."
                show tenna upright pointing oh at jump
                tenna "You don't have to be coy about it,{w=0.2} you know!"
                show tenna upright pressed smile at wiggle
                tenna "I want to get to know you for {color=[c_passion]}YOU{/color}!"
                show tenna upright chest blank at yreset
                tenna "Hm.{nw=0.2}"
                show tenna upright chest smile at jump
                extend "{p=0}{noalt}*{/noalt} Guess I'll just have to go with my gut instinct, folks!"

            if quiz_selected == 4:
                pass
            else:
                show tenna upright chest neutral at jump
                tenna "Huh?{p=0.2}{noalt}*{/noalt} Oh,{w=0.2} don't listen to me!"
                show tenna stretch shrug smile at jump
                tenna "I'm just mumbling to myself,{w=0.2} haha!"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna definitely isn't planning anything.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    ## What's your favorite color?
    elif question == 4:
        show tenna upright card blank at jump
        if quiz_selected == 1:
            tenna "Red?"
        elif quiz_selected == 2:
            tenna "White?"
        elif quiz_selected == 3:
            tenna "Black?"
        elif quiz_selected == 4:
            tenna "Yellow?"

        show tenna upright card smile at jump
        tenna "Okay!"
        show tenna upright card neutral
        tenna "..."
        show tenna upright card confused flipped at jump

        if (quiz_selected == 1 and persistent.favecolor in ["white", "black", "yellow"]) or (quiz_selected == 2 and persistent.favecolor in ["red", "black", "yellow"]) or (quiz_selected == 3 and persistent.favecolor in ["red", "white", "yellow"]) or (quiz_selected == 4 and persistent.favecolor in ["red", "white", "black"]):
            tenna "That's... an interesting choice!"
            show tenna panic flustered at jump
            tenna "No,{w=0.2} no,{w=0.2} there's nothing wrong with it,{w=0.2} haha!"
        else:
            tenna "... Ah.{p=0.2}{noalt}*{/noalt} Guess there's not much else to add to that,{w=0.2} huh?"
            
        if quiz_selected == 1:
            $ persistent.favecolor = "red"
        elif quiz_selected == 2:
            $ persistent.favecolor = "white"
        elif quiz_selected == 3:
            $ persistent.favecolor = "black"
        elif quiz_selected == 4:
            $ persistent.favecolor = "yellow"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna's content with the answer,{w=0.2} he thinks?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna's content with the answer,{w=0.2} he thinks?{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."        

    ## Fave TV programming?
    elif question == 5:
        ## Cooking
        if quiz_selected == 1:
            show tenna upright card smile at jump
            tenna "Oh,{w=0.2} really?"
            show tenna upright pointing smile at jump
            tenna "Of course,{w=0.2} of course!{p=0.2}{noalt}*{/noalt} I can see it now...!"
            show tenna upright pressed smile at rise
            tenna "You'd watch them and take notes to prepare exquisite meals for your own family,{w=0.2} right?"
            pause 1.0
            show tenna upright chest panic at droop
            tenna "Ahah,{w=0.2} what's with that blank expression...?"

        ## Music videos
        elif quiz_selected == 2:
            show tenna upright card blank at jump
            tenna "Oh?"
            pause 0.5
            tenna "...{nw=0.5}"
            show tenna upright chest awkward at jump
            extend " Oh!"
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            play sfx ten_sax
            if persistent.glitches:
                tenna_funG "I'll keep that in mind."
            else:
                tenna_fun "I'll keep that in mind." # SELF VOICING FIX

        ## Anime
        elif quiz_selected == 3:
            show tenna upright pointing smile at jump
            tenna "You know,{w=0.2} I saw a DVD box marked--{nw}"
            show tenna upright chest confused at jump
            tenna "I mean."
            tenna "A show LISTED as that earlier."
            show tenna upright pointing oh at jump
            tenna "But it looked like a cartoon!"
            tenna "There's no reason to have two names for the same thing,{w=0.2} right?"
            pause 1.0
            show tenna upright back panic
            tenna "You don't have to stare at me so...{nw=0.5}"
            show tenna at droop
            extend " deadpan,{w=0.2} haha."

        ## Romance TV
        elif quiz_selected == 4:
            show tenna panic flustered at jump
            tenna "?!"
            show tenna upright pointing smile at jump
            tenna "Goodness!{p=0.5}{noalt}*{/noalt} You're bold,{w=0.2} aren't you?"
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            play sfx ten_sax
            if persistent.glitches:
                tenna_funG "But, hey, I'm not complaining."
            else:
                tenna_fun "But, hey, I'm not complaining." # SELF VOICING FIX

        play sfx ding
        if quiz_selected == 1 or quiz_selected == 3:
            show tenna upright card neutral at jump
            $ date_fp -= 5
            if not seenstats_fp:
                $ seenstats_fp = True
                "Tenna's feeling somewhat awkward...{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_kindness]}Friendship Points{/color}."
            else:
                "Tenna's feeling somewhat awkward...{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_kindness]}FP{/color}."
        else:
            play sfx ding
            show tenna upright card awkward at jump
            $ date_lp -= 5
            if not seenstats_lp:
                $ seenstats_lp = True
                "Tenna may have misinterpreted what you meant.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}Love Points{/color}."
            else:
                "Tenna may have misinterpreted what you meant.{p=0.2}{noalt}*{/noalt} But he still gained 5 {color=[c_passion]}LP{/color}."
    
    ## What's your blood type?
    elif question == 6:
        show tenna upright card blank at jump
        tenna "I see!"
        show tenna upright card confused flipped at wiggle
        tenna "(...{w=0.2} What...{w=0.2} do any of these say about someone's personality again?)"
        show tenna upright card angry flipped
        tenna "(Agh,{w=0.2} I shouldn't have made a question around something I read off of a piece of scrap!!)"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna is happy to get an answer,{w=0.2} anyway.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna is happy to get an answer,{w=0.2} anyway.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    ## Best self quality?
    elif question == 7:
        if quiz_selected == 1:
            tenna "Kindness?"
            show tenna upright pointing smile at jump
            tenna "So you're always kind to everyone you meet?"
            show tenna upright pressed smile at wiggle
            
        elif quiz_selected == 2:
            tenna "Passion?"
            show tenna upright pointing smile at jump
            tenna "So you have an unbridled love for what life has to offer?"
            show tenna upright back awkward at jump

        elif quiz_selected == 3:
            tenna "Determination?"
            show tenna upright pointing smile at jump
            tenna "So you have an insatiable desire to push onward?"
            show tenna upright card blank at jump
            
        elif quiz_selected == 4:
            tenna "Hope?"
            show tenna upright pointing smile at jump
            tenna "So you're certain that things will always end up alright,{w=0.2} despite everything?"
            show tenna upright back awkward at wiggle
            
        if not persistent.selflove:
            if quiz_selected == 1:
                tenna "Haha,{w=0.2} how sweet!"
            elif quiz_selected == 2:
                tenna "Haha,{w=0.2} how precious!"
            elif quiz_selected == 3:
                tenna "Haha,{w=0.2} how inspiring!"
            elif quiz_selected == 4:
                tenna "Haha,{w=0.2} must be nice!"
        elif (persistent.selflove != "kindness" and quiz_selected == 1) or (persistent.selflove != "passion" and quiz_selected == 2) or (persistent.selflove != "determination" and quiz_selected == 3) or (persistent.selflove != "hope" and quiz_selected == 4):
            tenna "That wasn't what I would have thought,{w=0.2} but I trust your self-judgement,{w=0.2} haha!"
        else:
            tenna "You know,{w=0.2} that suits you perfectly...!"

        if quiz_selected == 1:
            $ persistent.selflove = "kindness"
        elif quiz_selected == 2:
            $ persistent.selflove = "passion"
        elif quiz_selected == 3:
            $ persistent.selflove = "determination"
        elif quiz_selected == 4:
            $ persistent.selflove = "hope"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna is enjoying learning more about you...{w=0.2} maybe.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna is enjoying learning more about you...{w=0.2} maybe.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    ## I LOVE TV
    elif question == 8:
        "You said,{w=0.2} \"I Love TV.\""
        show tenna stretch raised cheer at jump
        tenna "Haha,{w=0.2} of course you do!"
        show tenna upright card smile at jump
        tenna "I just...{nw=0.5}"
        if persistent.glitches:
            show tenna upright back panic flipped
        else:
            show tenna upright back panic flipped at shaking
        extend " {cps=60}really needed to hear someone say that--{/cps}{nw=0.1}"
        show tenna stretch raised cheer at jump
        tenna "ANYWAY!"

        play sfx ding
        show tenna upright card neutral at jump
        $ date_fp -= 5
        if not seenstats_fp:
            $ seenstats_fp = True
            "Tenna doesn't seem wholly satisfied.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}Friendship Points{/color}."
        else:
            "Tenna doesn't seem wholly satisfied.{p=0.2}{noalt}*{/noalt} He gained 5 {color=[c_kindness]}FP{/color}."

    $ question += 1
    jump tendate_quiz