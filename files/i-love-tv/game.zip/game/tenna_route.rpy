############################################################################################################
################## ROUTE INTRO
label tennastart:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    ## creepy start
    $ quick_menu = False
    $ ten_rightclick = True
    $ ten_rightclick_op = True
    play ambiance wind fadein 1.0
    scene black
    show sadsit 1 at zoom0
    pause
    if persistent.playthru:
        $ quick_menu = True
    "You see someone in the distance."
    pause 1.0
    show sadsit 1 at zoom1
    play sfx step1
    pause 1.0
    play sfx2 step2
    pause 1.0
    play sfx step1
    pause 1.5
    "You take a few steps closer."
    pause 0.5
    show sadsit 1 at zoom2
    play sfx stepping
    pause 4.5
    stop sfx fadeout 0.5
    play sfx2 echo1
    pause 3.0
    "You heard a voice,{w=0.2} but couldn't make out what it said."
    pause 0.5
    show sadsit 1 at zoom3
    play sfx stepping
    pause 0.8
    play sfx2 echo2
    pause 4.2
    stop sfx fadeout 0.5
    stop ambiance
    show sadsit 2 at zoom3z
    pause 2.0
    "You were noticed."
    tenna "What's--"
    pause 3.0

    ## actual dialogue
    $ quick_menu = True
    $ ten_rightclick = False
    $ ten_rightclick_op = False
    scene black
    show junkyard
    show tenna panic smpte at tenpos_center
    pause 0.0
    show tenna at jump
    play sfx beepLo
    tenna "HOW THE WHAT THE{nw}"
    stop sfx
    show tenna upright chest awkward
    tenna "I mean."
    show tenna upright pressed smile at rise
    tenna "Oh,{w=0.2} finally!{p=0.2}{noalt}*{/noalt} A{nw}"
    play sfx ten_lightner
    extend " {image=txt_lightner1}{alt}Lightner{/alt}{w=0.2} appears to sweep me off my feet!"
    pause 1.0
    show tenna upright chest awkward
    tenna "You ARE a{nw}"
    play sfx ten_lightner
    extend " {image=txt_lightner1}{alt}Lightner{/alt}{w=0.5} , aren't you?"
    pause 1.0
    show tenna stretch shrug smile at jump
    tenna "Eh,{w=0.2} close enough."
    show tenna upright chest neutral
    hide tenna with easeoutleft
    pause 0.5
    show quizboard at dropin
    pause 0.35
    play sfx drop
    pause 0.3
    play sfx drop
    pause 1.0
    show tenna upright chest neutral at tenpos_center with easeinleft
    play music sponsors
    show tenna upright pressed smile at jump
    tenna "You don't know how long I've been waiting for someone like YOU to show up!"
    tenna "I can't remember the last time I was able to talk to--{nw=0.2}"
    show tenna upright chest awkward
    tenna "I mean."
    show tenna stretch raised cheer at jump
    tenna "The last time I was able to host{p=0}{image=txt_tvtime}{alt}TV Time!{/alt}"
    pause 2.0
    if persistent.glitches:
        show tenna upright chest panic flipped
    else:
        show tenna upright chest panic flipped at shaking
    tenna "{cps=60}Right, there's no audience anymore{/cps}{nw}"
    show tenna stretch raised cheer at jump
    tenna "THAT'S A-OKAY!{p=0.2}{noalt}*{/noalt} We don't need an audience to have fun of our own,{w=0.2} right?!"
    show tenna upright chest awkward at jump
    tenna "Perhaps it would even be BETTER if we were{w=0.5} alone?{nw=0.1}"
    show tenna stretch raised cheer flipped at jump
    tenna "HA HA HA!{p=0.2}{noalt}*{/noalt} Boy, I'm getting TOO ahead of myself now!!"
    show tenna slouch whisper smug at jump
    tenna "{nw=0.2}"
    play sfx ten_laughtrack
    if persistent.glitches:
        tenna_funG "Hell, I don't even know your name yet!"
    else:
        tenna_fun "Hell, I don't even know your name yet!" # SELF VOICING FIX
    show tenna upright pressed smile at jump
    tenna "So,{w=0.2} tell me!{p=0.5}{noalt}*{/noalt} What's your {nw}"
    play sfx ten_names
    extend "{image=txt_name}{alt}name{/alt} ,{w=0.2} huh??"
    tenna "For convenient reasons only and absolutely nothing else,{w=0.2} there's no censors limiting your input to three letters!"
    show tenna slouch whisper smug
    tenna "But feel free to put in as few as you want,{w=0.2} so long as it's more than none!"



############################################################################################################
################## NAMECHECK
label namecheck:
    show tenna upright chest neutral at yreset

    if not persistent.mc:
        $ persistent.mc = renpy.input("{noalt}*{/noalt} {color=[c_passion]}Your{/color} name, please!", allow="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ", length=15)
        $ persistent.mc = persistent.mc.capitalize()
        $ persistent.mc = persistent.mc.strip()

        if persistent.mc == prevname and persistent.mc != "":
            show tenna upright pointing oh at jump
            tenna "Hey, now..."
            show tenna upright pointing smile
            tenna "Isn't that the name you JUST said WASN'T your name?"
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            play sfx ten_laughtrack
            if persistent.glitches:
                tenna_funG "Seems we've got ourselves a jokester over here!"
            else:
                tenna_fun "Seems we've got ourselves a jokester over here!" # SELF VOICING FIX

        elif persistent.mc in ["Tenna", "Ant"]:
            $ ten_name = True
            show tenna slouch claw panic at jump
            tenna "Now wait just a second here--"
            show tenna upright chest awkward
            tenna "We can't both have the SAME name.{p=0.2}{noalt}*{/noalt} It'd be too confusing for the audience!"
            pause 2.0
            show tenna slouch panic static at wiggle
            tenna "Right,{w=0.2} there's still no audience--"
            show tenna stretch raised cheer flipped at jump
            tenna "FORGET {noalt}IT{/noalt}{alt}it{/alt}!{p=0.2}{noalt}*{/noalt} Just pick something else for now, PLEASE!!"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc == "Kris":
            show tenna slouch claw panic at jump
            tenna "Kris?!"
            pause 1.0
            show tenna upright chest angry at jump
            tenna "No, no.{w=0.2} I know Kris when I see them, haha!"
            pause 1.0
            if persistent.glitches:
                show tenna slouch panic static
            else:
                show tenna slouch panic static at shaking
            tenna "Even if...{w=0.2} I haven't seen them for a while, ha ha{nw}"
            show tenna stretch raised cheer flipped at jump
            tenna "ANYWAY!{w=0.2} Could you give me {color=[c_passion]}YOUR{/color} name, please?"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Susie", "Ralsei", "Pippins", "Ramb", "Zapper", "Shadowguy", "Shadow guy", "Lanino", "Elnina", "Toriel",
                            "Asgore", "December", "Dess", "Noelle", "Rudy", "Carol", "Asriel", "Queen", "Swatch", "King", "Spadeking",
                            "Chaosking", "Spade king", "Chaos king", "Addison"]:
            show tenna upright chest blank
            tenna "..."
            show tenna slouch claw panic at jump
            tenna "Are you yanking my chain?{p=0.5}{noalt}*{/noalt} What're the chances that's YOUR name,{w=0.2} too?"
            show tenna upright chest awkward at jump
            tenna "C'mon,{w=0.2} don't mess with me!{p=0.5}{noalt}*{/noalt} I want to get to know you for {color=[c_passion]}YOU{/color},{w=0.2} after all!"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Willo", "Chara", "Frisk", "Vess", "Lancer", "Rouxls", "Rouxlskaard", "Rouxls kaard", "Toby"]:
            show tenna upright chest frown
            tenna "..."
            show tenna upright chest neutral
            tenna "You know,{w=0.2} that somehow sounds familiar..."
            tenna "Even though I know I don't know anyone with that name!"
            show tenna stretch shrug smile at jump
            tenna "Oh well!{w=0.2} Let's just roll with it anyway!"

        elif persistent.mc in ["Spamton", "Mailman", "Themailman", "The mailman", "Spammy mailman", "Spammy", "Spammymailman"]:
            $ renpy.music.set_volume(0.0, channel='music')
            play sfx recordscratch
            show tenna slouch claw panic
            pause 3.0
            show tenna panic smpte at jump
            play sfx beepLo
            tenna "WHAT?!"
            pause 1.0
            $ renpy.music.set_volume(1.0, channel='music')
            if persistent.glitches:
                show tenna upright chest angry
            else:
                show tenna upright chest angry at shaking
            tenna "D-{w=0.1} Don't be ridiculous!{w=0.5} I'd recognize that skeevy mailman on sight!!"
            tenna "I mean."
            show tenna slouch claw panic flipped
            tenna "{cps=60}No actually I've never met this man in my life he can rot in hell for all I care{/cps}{nw=0.1}"
            if persistent.glitches:
                show tenna slouch claw angry at jump
            else:
                show tenna slouch claw angry at shock
            tenna "Just CHOOSE SOMETHING ELSE!!!"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Gaster", "Wd gaster", "Wdg", "Goner", "Theman", "The man", "Egg", "Knight", "The knight" "Theknight", "Roaring", "Roaringknight", "Roaring knight", "Man"]:
            $ renpy.music.set_volume(0.0, channel='music')
            show tenna upright chest frown
            tenna "..."
            pause 2.0
            $ renpy.music.set_volume(1.0, channel='music')
            show tenna upright chest neutral
            tenna "Nah, that can't be right!"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Dog", "Fox"]:
            tenna "..."
            show tenna upright chest confused at jump
            tenna "Just...{w=0.5} \"[persistent.mc]\"?"
            tenna "You mean like the animal,{w=0.2} right?"
            pause 2.0
            show tenna stretch shrug smile at jump
            tenna "Well,{w=0.2} what do I care?!{w=0.5} There's worse names to have out there!!!"

        elif persistent.mc == "Mike":
            show tenna upright chest frown
            tenna "...{w=0.2} Mike?"
            tenna "..."
            pause 1.0
            show tenna stretch shrug smile flipped at jump
            tenna "Well,{w=0.2} I suppose it's a common name, haha!"
            show tenna upright chest frown flipped
            tenna "..."
            pause 2.0
            if persistent.glitches:
                show tenna upright chest awkward
            else:
                show tenna upright chest awkward at shaking
            tenna "{cps=60}Actually I really don't think I'm comfortable with this can you pick something else thanks{/cps}{nw=0.2}"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc == "Michael":
            show tenna upright chest frown
            tenna "...{w=0.2} Michael?"
            tenna "..."
            pause 1.0
            show tenna stretch shrug smile flipped at jump
            tenna "Eh,{w=0.2} it's different enough."

        elif persistent.mc == "Pipis":
            $ renpy.music.set_volume(0.0, channel='music')
            play sfx recordscratch
            show tenna slouch claw panic
            pause 3.0
            show tenna upright chest awkward flipped at jump
            tenna "Um."
            pause 1.0
            $ renpy.music.set_volume(1.0, channel='music')
            if persistent.glitches:
                show tenna stretch raised cheer
            else:
                show tenna stretch raised cheer at shaking
            tenna "H-{w=0.1}haha...!{p=0.2}{noalt}*{/noalt} Good one,{w=0.2} pal!"
            show tenna upright chest panic
            tenna "How's about we try something else, though??"
            tenna "{nw=0.2}"
            if persistent.glitches:
                tenna_funG "Please."
            else:
                tenna_fun "Please." # SELF VOICING FIX
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Topher", "Tofu"]:
            show tenna upright chest blank
            tenna "...{w=0.2} [persistent.mc]..."
            show tenna upright chest frown
            tenna "You know,{w=0.2} that sounds strangely familiar."
            tenna "Have we met before,{w=0.2} by chance?{p=0.2}{noalt}*{/noalt} Or..."
            pause 1.0
            show tenna stretch shrug smile flipped at jump
            tenna "Eh,{w=0.2} it's probably nothing."

        elif persistent.mc in ["No", "Nope", "Noway", "Nothanks", "No way", "No thanks", "No thank you", "Nothank you", "No thankyou", "Nothankyou"]:
            show tenna slouch claw panic at jump
            tenna "Oh,{nw}"
            play sfx ten_laughtrack
            extend " c'mon, now!"
            if persistent.glitches:
                show tenna upright chest awkward
            else:
                show tenna upright chest awkward at shaking
            tenna "At least gimmie SOMETHING to work with here!!"
            show tenna stretch raised cheer flipped at jump
            tenna "Anything!{p=0.2}{noalt}*{/noalt} Anything at all!"
            tenna "Doesn't even have to be your actual name if you REALLY don't trust me,{w=0.2} haha!!"
            $ persistent.mc = ""
            jump namecheck

        elif persistent.mc in ["Yep", "Yes", "Yeppers", "Yesplease", "Yes please", "Yup", "Yessiree", "Whatsit", "Whatsittooya", "What zit tooya", "Whatzittooya"]:
            show tenna upright chest confused
            tenna "..."
            show tenna stretch raised cheer flipped at jump
            tenna "Haha,{w=0.2} well,{w=0.2} I personally wouldn't consider that much of a name..."
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            play sfx ten_laughtrack
            if persistent.glitches:
                tenna_funG "But what do I know? I'm just an old CRT!"
            else:
                tenna_fun "But what do I know? I'm just an old CRT!" # SELF VOICING FIX

        elif persistent.mc in ["Battat", "Pluey", "Jongler"]:
            show tenna upright chest confused
            tenna "[persistent.mc]?"
            show tenna upright chest frown
            tenna "Is that even a name??"
            show tenna stretch shrug smile at jump
            tenna "Can't say I've ever heard anything like it before,{w=0.2} but who am I to judge?!"

        elif persistent.mc in ["Ass","Anus","Anuses","Arse","Arses","Asses","Asshole","Assholes","Dumbass","Dumbasses","Jackass","Jackasses","Lmao","Lmfao",
                                "Assfuck","Bastard","Bastards","Shit",'Shits',"Shitty","Shitter","Shithead","Shitheads","Shithole","Shitholes","Sex",'Sexy',"Sexes",'Sexs',"Sexie",
                                'Sexys',"Sexting","Sext","Fuck",'Fucker',"Robotfucker",'Monsterfucker',"Motherfucker","Dumbfuck",'Buttfuck','Fucking','Fuckface','Kink','Kinky','Piss',
                                'Pisses','Pissing','Pisser','Pissed','Pissface','Pissboy',"Damn","Dammit","Goddamn","Goddamnit",'Bitch',"Bitches","No bitches",'Nobitches','Boner',
                                "Boners","Dildo","Dildos","Dick","Dicks",'Dickbag',"Jizz","Jizzy","Cock","Cocks","Ball","Balls",'Penis',"Penises","Peni","Bollocks","Slut","Sluts","Slutty",
                                "Douche","Douchebag","Boob","Boobs","Boobie","Boobies",'Booby','Boobys','Boober',"Boobers","Tit","Tits",'Titty',"Tittys",'Titties','Tiddy','Crackhead',
                                'Tiddys','Tiddies','Manboob','Manboobs','Mantit','Mantitty','Breast','Breasts','Bosom','Clit','Clitoris','Labia','Vagina','Vaginas','Fleshlight',
                                'Fleshlights','Cunt','Cunty','Pussy','Pussies','Pussys','Bepis','Toilet',"Poop","Poopie","Poopy","Pee",'Peepee','Toylet',"Pee pee", "Poo poo pee pee",
                                "Poopoo peepee", "Poopoopeepee","Poo poo peepee","Poopoo pee pee","Queer","Gay","Gayass"]:
            show tenna slouch claw panic at jump
            tenna "WOAH, there!"
            show tenna upright chest angry at jump
            tenna "I know I said there were no censors, but..."
            show tenna upright chest blank flipped
            pause 1.0
            show tenna upright chest angry
            tenna "Actually,{w=0.2} you know what?{nw=0.2}"
            show tenna stretch shrug smile at jump
            extend "{p=0}{noalt}*{/noalt} Fine!"
            show tenna slouch whisper smug
            tenna "{nw=0.2}"
            play sfx ten_laughtrack
            if persistent.glitches:
                tenna_funG "Just know you did this to yourself."
            else:
                tenna_fun "Just know you did this to yourself." # SELF VOICING FIX

        elif not persistent.mc:
            show tenna upright chest angry
            tenna "Uhh...{w=0.2} You gonna keep standing there and staring at me?"
            show tenna stretch shrug smile at jump
            tenna "It's just a name,{w=0.2} right?!{w=0.2} You can tell me anything!!"
            tenna "Literally any name!{w=0.2} I do not care whatsoever!!!"
            if persistent.glitches:
                show tenna slouch panic panic
            else:
                show tenna slouch panic panic at shaking
            tenna "Please"
            $ persistent.mc = ""
            jump namecheck

        else:
            tenna "[persistent.mc]?"
            show tenna stretch shrug smile at jump
            tenna "Works for me!"
        
        menu:
            rq "Is [persistent.mc] okay?"
            "Yes":
                pass
            
            "No":
                show tenna slouch claw panic at droop
                tenna "It's NOT [persistent.mc]?"
                show tenna stretch shrug smile at jump
                tenna "Whoopsies!{p=0.2}{noalt}*{/noalt} I must have misheard you!"
                show tenna upright pointing smile
                tenna "Let's roll that one back and try again."
                $ persistent.mc = ""
                jump namecheck

    else:
        show tenna slouch claw panic at jump
        tenna "Wait!{w=0.5} Don't tell me."
        show tenna upright card confused at jump
        tenna "Is it [persistent.mc]?"

        menu:
            rq "Is it [persistent.mc]?"
            "Yes":
                show tenna stretch raised cheer at jump
                tenna "Hahaha,{w=0.2} I knew it!!"
                tenna "You look like a [persistent.mc]!"
            
            "No":
                show tenna panic flustered at jump
                tenna "It's NOT?!"
                show tenna upright chest awkward at jump
                tenna "Well!{w=0.2} I guess I'm being a bit overzealous here, folks{nw}"
                play sfx ten_laughtrack
                extend "!"
                show tenna stretch raised cheer at jump
                tenna "Mind telling me what your name ACTUALLY is, then??"
                $ prevname = persistent.mc
                $ persistent.mc = ""
                jump namecheck



############################################################################################################
################## QUIZ START
label quizstart:
    ## AUTOSAVE
    $ renpy.save("mainfile")
    
    show tenna upright chest neutral at jump
    tenna "Anyway,{w=0.2} uh,{w=0.2} well,{w=0.2} you--"
    show tenna upright chest awkward at jump
    tenna "Do you{w=0.5} come here often?"
    stop music
    play sfx crickets
    pause 4.0
    show tenna slouch panic panic flipped
    tenna "Ahahahahaha{nw}"
    show tenna stretch raised cheer flipped at jump
    tenna "You know what?!{p=0.2}{noalt}*{/noalt} I have a better idea!"
    hide tenna with easeoutright
    pause 0.5
    show quizboard2 at dropin2
    pause 0.35
    play sfx drop
    pause 0.3
    play sfx drop
    pause 1.0
    show tenna upright chest neutral at tenpos_right with easeinright
    play music boardplz
    show tenna upright card neutral at jump
    tenna "A good old-fashioned{nw}"
    play sfx ten_quizzes
    if persistent.glitches:
        extend " {image=txt_quizshowG}{alt}quiz show!{/alt}"
    else:
        extend " {image=txt_quizshow}{alt}quiz show!{/alt}"
    tenna "What better way to get to know someone than a bunch of questions?!"
    menu:
        rq "What better way to get to know someone than a bunch of questions?!"
        "Like with one right answer?":
            show tenna upright chest angry at jump
            tenna "Wh--{w=0.2} No, of course not!"
            show tenna upright card blank at jump
            tenna "What good would that do for getting to know each other??"
        
        "Like a personality quiz?":
            show tenna stretch raised cheer flipped at jump
            tenna "You got it!"
            show tenna upright card neutral at jump
            tenna "Sort of."
        
        "Are you ever gonna tell me your name?":
            pass
            show tenna panic flustered at jump
            tenna "H-{w=0.1} huh?!"
            show tenna upright chest awkward
            tenna "D-{w=0.1} Did...{w=0.2} I not already tell you?"
            if persistent.playthru:
                show tenna stretch shrug weak at jump
                tenna "Haha...{p=0.2}{noalt}*{/noalt} Guess I'm just having some strange déjà vu today, folks!"
            elif ten_name:
                show tenna upright pointing oh at jump
                tenna "No-- WAIT!{p=0.5}{noalt}*{/noalt} I definitely did!"
                show tenna stretch shrug smile at jump
                tenna "It may have only been when you...{nw=0.2}"
                show tenna stretch shrug weak at droop
                extend " said you had the same name first, but..."
                show tenna at wiggle
                tenna "{cps=25}Haha...{/cps}"
                show tenna upright chest panic flipped
                tenna "..."
            else:
                tenna "I...{w=0.2} must not have,{w=0.2} huh?"

            if not ten_name:
                show tenna stretch shrug smile at jump
                tenna "Ha-ha!{p=0.2}{noalt}*{/noalt} Whoops!{p=0.2}{noalt}*{/noalt} Honest mistake!"
                tenna "Mike,{w=0.2} play the VHS!"
                $ renpy.music.set_volume(0.0, channel='music')
                pause 0.5
                play sfx crickets
                pause 3.0
                show tenna stretch shrug smile flipped at jump
                tenna "Hahaha,{w=0.2} that's okay."
                tenna "I can just...{w=0.2} introduce myself normally{w=0.5}???"
                show tenna upright chest blank flipped
                pause 1.0
                show tenna upright chest smile at jump
                tenna "It's Mr. Ant Tenna.{p=0.2}{noalt}*{/noalt} But you can just call me Tenna."
                $ renpy.music.set_volume(1.0, channel='music')

    show tenna stretch raised cheer flipped at jump
    tenna "ANYWAY!{nw=0.2}"
    show tenna upright pointing smile at jump
    extend "{p=0}{noalt}*{/noalt} Mike,{w=0.2} the board please!"
    stop music
    pause 1.0
    play sfx crickets
    pause 1.0
    stop sfx
    if persistent.glitches:
        show tenna upright chest panic flipped
    else:
        show tenna upright chest panic flipped at shaking
    tenna "Right Mike isn't here either--{nw=0.1}"
    show tenna stretch raised cheer at jump
    tenna "I'll just do it myself, then!!"
    show tenna upright card neutral at jump
    tenna "Ahem."

    ## TRANSITION TO QUIZ DATE
    call date_intro from _call_date_intro_1

    # STARTING VARIABLES
    $ date_fp = ten.fp
    $ date_maxfp = ten.maxfp
    $ date_lp = ten.lp
    $ date_hb = ten.hb
    $ date_maxlp = ten.maxlp
    $ date_name = ten.char

    # RESET VARIABLES (this is the first one but... for reference...)
    $ currentdate = "quiz"
    $ turn = 0
    $ flirt = 0
    $ check = 0
    $ niceday = 0
    $ vess_hp = 3

    show screen datestats
    pause 0.5
    jump tendate_quiz



############################################################################################################
################## AFTER QUIZ
label postquiz:
    if persistent.favecolor:
        $ flow_ran = persistent.favecolor
    if persistent.programs:
        $ dvd_ran = persistent.programs
    if persistent.favefood != "anything" or persistent.favefood != None:
        $ food_ran = persistent.favefood

    ## AUTOSAVE
    $ renpy.save("mainfile")
    
    hide screen datestats
    hide screen quiztext
    show tenna upright card smile at jump
    stop music fadeout 1.0
    tenna "Annnnd that's all my questions!"
    show tenna upright pressed smile at jump
    tenna "Thank you oh-so much for participating,{w=0.2} [persistent.mc]!"
    tenna "Doesn't it really feel like we got to know each other so well?!"
    menu:
        rq "Doesn't it really feel like we got to know each other so well?!"
        "Yeah":
            show tenna at rise
            tenna "Great!{p=0.5}{noalt}*{/noalt} Perfect, even!!!"
        
        "No":
            show tenna slouch claw panic at jump
            tenna "You're serious?!"
            pause 1.0
            show tenna upright pointing smile at jump
            tenna "Haha!{w=0.2} Oh, [persistent.mc]!{p=0.2}{noalt}*{/noalt} You're quite the kidder,{w=0.2} aren'tcha?!"
        
        "You didn't say anything about yourself?":
            show tenna slouch claw panic at droop
            tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}?"
            show tenna upright chest panic at jump
            tenna "Oh,{w=0.2} well,{w=0.2} uh...{nw=0.2}"
            show tenna stretch shrug smile flipped at jump
            extend "{p=0}{noalt}*{/noalt} Don't worry about that,{w=0.2} haha!!"

    show tenna upright back smile at jump
    tenna "Anyway..."
    tenna "If you'll excuse me for a second,{w=0.2} I have to..."
    show tenna upright back panic
    pause 1.0
    show tenna upright back panic flipped
    pause 1.0
    show tenna stretch shrug weak
    tenna "I have to go set up things for the...{nw=0.2}"
    show tenna upright pointing smile at jump
    tenna "For the next board!"
    pause 1.0
    show tenna upright back smile at wiggle
    tenna "Haha,{w=0.2} right!{p=0.5}{noalt}*{/noalt} Um."
    show tenna upright chest panic at jump
    tenna "Just...{p=0.5}{noalt}*{/noalt} Stay here,{w=0.2} would you?"
    show tenna upright pointing oh at jump
    tenna "Don't move an inch!{p=0.5}{noalt}*{/noalt} I'll be RIGHT back."
    show tenna upright back panic
    play sfx runaway
    hide tenna with easeoutleft
    pause 1.5
    "Tenna ran away."
    pause 2.0
    menu:
        "Move the board.":
            $ ten_moveboard = True
        
        "Move the board.":
            $ ten_moveboard = True
        
        "Move the board.":
            $ ten_moveboard = True
        
        "Move the board." if not persistent.playthru:
            $ ten_moveboard = True
        
        "Stay put." if persistent.playthru:
            "You don't move an inch."
            play ambiance wind fadein 3.0
            $ renpy.pause(10,hard=True)
            "Your eyes are starting to grow heavy."
            stop ambiance fadeout 7.0
            scene black with Dissolve(5.0)
            pause 10.0
            jump postquiz2

    pause 0.3
    play sfx slideaway
    pause 0.2
    show quizboard:
        xpos 0.1
    show quizboard2:
        xpos -0.2
    with move
    hide quizboard
    hide quizboard2
    with moveoutleft
    pause 1.0
    "You pushed the board away with ease."
    play music dump
    jump ex_postquiz 


######################################################
##### RETURN FROM EXPLORE
label postquiz2:
    if ten_moveboard == True:
        $ quick_menu = True
        stop music
        if persistent.glitches:
            show tenna cg zoom angry
            tenna "{cps=60}What are you doing?{/cps}"
        else:
            show tenna cg zoom angry at shakingcg
            tenna "{cps=60}{sc=3}What are you doing?{/sc}{/cps}" # SELF VOICING FIX
        show tenna at yreset
        pause 2.0
        hide tenna
        show tenna upright back panic at tenpos_center
        pause 2.0
        show tenna upright back panic flipped at jump
        pause 1.0
        tenna "Um."
        pause 2.0

        $ quick_menu = False
        scene black
        play sfx tech
        if persistent.glitches:
            show technicalSt at truecenter
            $ renpy.pause(6.0, hard=True)
        else:
            show technical at truecenter
            $ renpy.pause(1.8, hard=True)
            show technical
            $ renpy.pause(1.8, hard=True)
            show technical
            $ renpy.pause(2.4, hard=True)
        
    else:
        play sfx sfix
        pause 3.0
        "...{w=0.2} Something woke you up."

    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ quick_menu = True
    stop sfx
    scene black
    show junkyard
    show tenshop e_smile at center
    show tenshop at jump
    play music greenroom
    tenna "Wow!{p=0.2}{noalt}*{/noalt} A customer who just so happened to be right in front of where I opened up shop!"
    tenna "Good to meet you, stranger!{p=0.2}{noalt}*{/noalt} Got some freetime you wanna spend looking around?"
    tenna "Actually--{w=0.2} y'know what?"
    show tenshop e_blush
    tenna "Just 'cause you look so darn cute,{w=0.2} everything I've got available is totally free!{p=0.2}{noalt}*{/noalt} Doesn't cost a dime!"
    show tenshop -e_blush
    tenna "Consider it a gift from me to you!"
    $ persistent.itemheard = True
    jump shop_nmt


######################################################
##### RETURN FROM SHOP
label parkstart:
    ## FOR ITEMS (DEBUG)
    if debugtesting == True:
        if persistent.favecolor:
            $ flow_ran = persistent.favecolor
        if persistent.programs:
            $ dvd_ran = persistent.programs
        if persistent.favefood != "anything" or persistent.favefood != None:
            $ food_ran = persistent.favefood
            
    ## AUTOSAVE
    $ renpy.save("mainfile")

    stop music
    scene black
    play sfx sfix
    pause 4.0
    show junkyard
    pause 2.0
    show tenna upright pressed smile at tenpos_center with easeinleft
    tenna "I'm{nw}"
    play sfx ten_heyevery
    show tenna at rise
    if persistent.glitches:
        extend " {image=txt_backG}{alt}back!{/alt}!"
    else:
        extend " {image=txt_back}{alt}back!{/alt}!"
    show tenna upright pointing smile at jump
    tenna "Did ya miss me?"
    show tenna upright chest panic at jump
    tenna "Oh,{w=0.2} wait a moment--{nw=0.2}"
    show tenna stretch shrug smile at jump
    extend "{p=0}{noalt}*{/noalt} I forgot something!"
    hide tenna with easeoutleft
    pause 0.5
    show parkboard at dropin
    pause 0.35
    play sfx drop
    pause 0.3
    play sfx drop
    pause 1.0
    show tenna upright chest neutral at tenpos_center with easeinleft
    show tenna upright chest smile at jump
    tenna "There we go!{p=0.2}{noalt}*{/noalt} That's better!"
    show tenna stretch raised cheer at jump
    tenna "Sorry for SUCH a long wait, folks,{w=0.2} ahaha!"
    show tenna upright pressed smile at rise
    tenna "Anyway,{w=0.2} now that the board is ready..."

    ## TRANSITION TO TENNA PARK DATE
    call date_intro from _call_date_intro_2

    # DATE VARIABLES
    if not date_fp:
        $ date_fp = ten.fp
    if not date_maxfp:
        $ date_maxfp = ten.maxfp
    if not date_lp:
        $ date_lp = ten.lp
    if not date_maxlp:
        $ date_maxlp = ten.maxlp
    if not date_name:
        $ date_name = ten.char

    # RESET VARIABLES
    $ currentdate = "park"
    $ turn = 0
    $ flirt = 0
    $ check = 0
    $ niceday = 0
    $ vess_hp = 3

    show screen datestats
    jump tendate_park



############################################################################################################
################## ROUTE END
label tennaend:
    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ ten_rightclick = True

    stop music
    hide screen datestats
    play sfx whipcrack
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "Would you STOP it?"
    show tenna upright pressed smile
    tenna "Keep.{w=0.2} Your eyes.{w=0.2} On me."
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "It's REALLY not that hard!"
    show tenna upright back panic at wiggle
    tenna "Don't worry about what's going on back there!!{p=0.2}{noalt}*{/noalt} Don't even think about it!!"
    show tenna upright back frown
    tenna "Just stay focused on this{nw}"
    play sfx ten_aww
    if persistent.glitches:
        extend " {image=txt_lovelyG}{alt}lovely{/alt}{w=0.2} corner I've made,{w=0.2} won't you...?"
    else:
        extend " {image=txt_lovely}{alt}lovely{/alt}{w=0.2} corner I've made,{w=0.2} won't you...?"
    show tenna upright back nosed at yreset
    tenna "Please."
    show tenna at wiggle
    tenna "{cps=60}It's better this way.{/cps}"
    if persistent.glitches:
        show tenna slouch panic panic
    else:
        show tenna slouch panic panic at shaking
    tenna "Things are meant to be happy,{w=0.2} aren't they...?{p=0.5}{noalt}*{/noalt} Even in the WORST of times...!"
    show tenna upright pointing oh at wiggle
    tenna "Please--{w=0.2} let me make sure everything is perfect for you.{p=0.2}{noalt}*{/noalt} For {noalt}US{/noalt}{alt}us{/alt}."
    show tenna upright pointing smile
    tenna "A little corner of the world where Nothing Is Wrong."
    show tenna upright pointing weak
    tenna "I want that for you...{nw=0.2}"
    show tenna at droop
    extend "{p=0}{noalt}*{/noalt} Don't you want that,{w=0.2} too?"

    menu:
        "Please stop.":
            show tenna slouch claw panic at droop
            tenna "H...{w=0.5} huh?"
            tenna "But--{nw=0.2}"
            if persistent.glitches:
                show tenna slouch claw angry at jump
                tenna "Stop WHAT?"
                show tenna upright pointing weak
            else:
                show tenna slouch claw angry at shock
                tenna "Stop WHAT?"
                show tenna upright pointing weak at shaking
            tenna "I haven't DONE anything WRONG!"
        
        "You're scaring me.":
            show tenna slouch claw panic at droop
            tenna "H...{w=0.5} huh?"
            tenna "But I--{nw=0.2}"
            tenna "But you--{nw=0.2}"
            if persistent.glitches:
                show tenna slouch claw angry flipped at jump
            else:
                show tenna slouch claw angry flipped at shock
            tenna "But-- out THERE is scary?!"

    show tenna slouch claw angry at yreset
    tenna "What do you{nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend " MEAN?"
    show tenna slouch panic panic at wiggle
    tenna "Out there is--{w=0.2} is--{w=0.2} it's{w=0.2}.{w=0.2}.{w=0.2}."
    if persistent.glitches:
        show tenna slouch panic static
    else:
        show tenna slouch panic static at shaking
    tenna "Please,{w=0.2} why won't you...?!"
    show tenna slouch panic static flipped
    tenna "{cps=60}Not you, too, I--{/cps}"
    show tenna upright pointing smile
    tenna "Please.{w=0.2} Please.{p=0.2}{cps=60}{noalt}*{/noalt} I know you need this.{/cps}"
    show tenna upright pointing weak
    if persistent.glitches:
        tenna "I need this."
    else:
        tenna "{sc=3}I{/sc} need this." # SELF VOICING FIX
    show tenna upright back awkward
    tenna "{cps=60}I'll do better, I promise!{/cps}"
    show tenna slouch panic panic flipped
    if persistent.glitches:
        tenna "I just--{p=0.2}{noalt}*{/noalt} {cps=25}I just...!{/cps}"
    else:
        tenna "I just--{p=0.2}{noalt}*{/noalt} {cps=25}{sc=3}I just...!{/sc}{/cps}" # SELF VOICING FIX
    show tenna at yreset
    play ambiance wind fadein 0.5
    pause 3.0
    show tenna upright back black flipped
    pause 3.0
    tenna "I just want to be watched."
    show tenna at wiggle
    tenna "I just want someone to look at me."
    show tenna slouch panic panic at wiggle
    tenna "Someone to look at me and...{w=0.5} really see someone!"
    if persistent.glitches:
        show tenna slouch panic panic flipped
    else:
        show tenna slouch panic panic flipped at shaking
    tenna "I used to have that...!"
    show tenna upright back black flipped
    tenna "But that was...{w=0.5} years ago."
    pause 0.5
    show tenna at yreset
    pause 1.0
    show tenna at droop
    pause 3.0
    tenna "You know,"
    tenna "I met this real sweet girl once."
    tenna "She was kinder to me than anyone had been in years."
    show tenna upright chest panic flipped
    tenna "She told me that somebody out there would want me.{p=0.5}{noalt}*{/noalt} Somebody out there would want an old-fashioned TV like me."
    show tenna upright pressed smile at rise
    tenna "And I really believed her!"
    tenna "I felt electric!{p=0.2}{noalt}*{/noalt} I felt like a million bucks!"
    show tenna at wiggle
    tenna "I felt real{nw}"
    play sfx ten_hope
    extend " {image=txt_hope}{alt}hope!{/alt}...!"
    pause 1.0
    show tenna at yreset
    pause 1.0
    show tenna upright chest frown
    pause 1.0
    show tenna upright back panic
    tenna "...{w=0.2} only to wind up in a dump next I woke up,{w=0.2} haha."
    tenna "..."
    show tenna upright back frown
    pause 2.0
    tenna "That...{nw=0.5}"
    show tenna at droop
    extend " hurt more than anything."
    show tenna upright back panic
    tenna "She sounded so sincere."
    tenna "Like she really meant it!"
    show tenna slouch panic panic at wiggle
    if persistent.glitches:
        tenna "Only for her, too..."
    else:
        tenna "{sc=3}Only for her, too...{/sc}" # SELF VOICING FIX
    show tenna at yreset
    pause 2.0
    show tenna upright chest frown
    pause 1.0
    show tenna upright back frown flipped at jump
    tenna "Have you ever...{w=0.5} been left behind?"
    tenna "Just...{nw=0.5}"
    show tenna stretch shrug weak at jump
    extend " by everyone!{p=0.5}{noalt}*{/noalt} Everyone you ever knew and ever loved!!"
    tenna "They just left you for dead,{w=0.2} haha...!"
    show tenna upright back frown
    pause 1.0
    show tenna stretch shrug weak at wiggle
    tenna "Nobody sticks around if you aren't good enough for them,{w=0.2} haha..."
    show tenna upright back frown flipped
    tenna "It must have been something I did,{w=0.5} right?"
    if persistent.glitches:
        show tenna slouch panic panic flipped
    else:
        show tenna slouch panic panic flipped at shaking
    tenna "Right??{p=0.5}{noalt}*{/noalt} Why else would they leave me?!"
    tenna "All alone?!{p=0.2}{noalt}*{/noalt} Just to die by myself?!"
    show tenna at yreset
    pause 2.0
    show tenna upright back nosed flipped
    pause 1.0
    tenna "I thought{w=0.5} having friends and family meant{p=0.5}{noalt}*{/noalt} we'd always be together."
    tenna "That the people I loved would be there no matter what..."
    show tenna upright back nose flipped
    tenna "But before I knew it--{p=0.5}{noalt}*{/noalt} when I needed them the most--"
    stop ambiance
    if persistent.glitches:
        show tenna upright back panic
        tenna "...{w=0.2} nobody was there."
    else:
        show tenna upright back panic at shaking
        tenna "...{w=0.2} {sc=3}nobody was there.{/sc}" # SELF VOICING FIX
    show tenna upright back nosed at droop
    pause 2.0

    menu:
        "I've never had an experience like that.":
            $ ten_symp = False
            show tenna upright back nose
            tenna "Oh...?"
            pause 1.0
            show tenna stretch shrug weak flipped at jump
            tenna "Ahahaha!{w=0.2} Of course not!"
            tenna "I mean,{w=0.2} why would you?{p=0.2}{noalt}*{/noalt} You're practically perfect in every way!"
            show tenna at wiggle
            tenna "Who would ever want to leave you behind...?"
            show tenna upright chest panic flipped at jump

        "I know what you mean.":
            if ten.lp > 0 or ten.fp > 0:
                $ renpy.notify("+♡")
                if ten.lp > 0:
                    $ ten.lp -= 5
                if ten.fp > 0:
                    $ ten.fp -= 5
            play sfx hypnosis
            $ ten_symp = True
            show tenna slouch claw panic at jump
            tenna "R-{w=0.1} really?!{p=0.5}{noalt}*{/noalt} You do?!"
            show tenna panic flustered at jump
            tenna "I mean, you're so...{w=0.2} considerate!{p=0.2}{noalt}*{/noalt} You've been putting up with me this whole time!"
            tenna "Who would ever want to leave YOU behind?!"
            show tenna upright chest panic flipped
            tenna "Th...{w=0.2} that's..."
            show tenna stretch shrug weak flipped at jump

    show tenna upright chest frown
    tenna "Ah,{w=0.2} forget about all of that.{nw=0.5}"
    show tenna upright back panic at jump
    extend "{p=0}{noalt}*{/noalt} I shouldn't bring down the mood by talking about depressing things!"
    pause 1.0
    menu:
        "You deserve to have an outlet, too.":
            if ten.lp > 0 or ten.fp > 0:
                $ renpy.notify("+♡")
                if ten.lp > 0:
                    $ ten.lp -= 5
                if ten.fp > 0:
                    $ ten.fp -= 5
            play sfx hypnosis
            $ ten_outlet = True
            show tenna upright back confused
            tenna_shh ".{w=0.2}.{w=0.2}."
            pause 0.5
            show tenna upright chest panic at droop
            tenna "I..."
            pause 1.0
            show tenna stretch shrug weak flipped at jump
            tenna "Haha,{w=0.2} I don't know about that."
            tenna "It's, um.{p=0.5}{noalt}*{/noalt} Complicated?{p=0.5}{noalt}*{/noalt} Complicated."
            show tenna upright back smile at wiggle
            tenna "After all,{w=0.2} I'm supposed to be the one putting a smile on YOUR face,{w=0.2} aren't I?"
            tenna "Not...{w=0.5} the other way around."
            show tenna upright back frown flipped at droop
            pause 2.0
            show tenna upright back nose at yease
            pause 1.0
            show tenna upright back panic at jump
            tenna "Don't give me that look!"
            show tenna upright pointing oh at jump
            tenna "Yes, THAT one!{p=0.2}{noalt}*{/noalt} That cutesy, puppy-dog look of sympathy!"
        
        "...":
            $ ten_outlet = False
            pause 1.0
            show tenna slouch claw panic
            tenna "Don't...{nw=0.5}"
            show tenna at droop
            extend " give me THAT look...!"
    
    show tenna upright chest smile
    tenna "C'mon, now!{p=0.2}{noalt}*{/noalt} Wouldn't it be better if we just..."
    show tenna upright chest panic
    tenna "Decided the past never happened?"
    show tenna stretch raised cheer flipped at jump
    tenna "It's not like you knew me before today,{w=0.2} anyway!"
    show tenna slouch panic panic flipped at droop
    tenna "I just{w=0.5} don't want to think about it anymore."
    show tenna upright pointing smile at jump
    tenna "So,{w=0.2} I'll be a new me,{w=0.2} and you can...{p=0.5}{noalt}*{/noalt} Do whatever you want to,{w=0.2} I guess!"
    show tenna stretch raised cheer at jump
    tenna "Then it'll just be the two of us--{w=0.2} [persistent.mc] and Mr. Ant Tenna!"
    show tenna at wiggle
    tenna "Forget about everything!{p=0.2}{noalt}*{/noalt} The past is dead to us,{w=0.2} ahahaha!!"
    show tenna upright pointing smile at jump
    tenna "From now on,{w=0.2} we'll ONLY do what makes us happy."
    tenna "It's better that way,{w=0.2} right?"
    if persistent.glitches:
        tenna "Right?!"
    else:
        show tenna at shaking
        tenna "{sc=3}Right?!{/sc}" # SELF VOICING FIX
    menu:
        rq "{color=[c_goner]}Right?!{/color}" # SELF VOICING FIX
        "I think that's a bit extreme...":
            show tenna slouch claw panic at droop
            tenna "Wh-{w=0.1} what?"
            if persistent.glitches:
                show tenna slouch claw angry at jump
            else:
                show tenna slouch claw angry at shock
            tenna "What are you TALKING about?"
            tenna "Surely you don't WANT to be SAD??"
        
        "...":
            show tenna at yreset
            pause 1.0
            tenna "..."
            pause 1.0
            tenna "...{nw=0.2}"
            show tenna upright back smile at jump
            extend " ahah."
            show tenna upright pointing oh at jump
            tenna "Why{w=0.5} aren't you saying anything?"
            pause 2.0
            play sfx whipcrack
            if persistent.glitches:
                show tenna slouch claw angry at jump
            else:
                show tenna slouch claw angry at shock
            tenna "SAY SOMETHING GODDAMMIT!"

    show tenna upright chest frown flipped at droop
    tenna "I had a whole itinerary planned and everything..."
    show tenna upright pressed smile at wiggle
    tenna "You know--{w=0.2} dates exactly to your liking!{p=0.2}{noalt}*{/noalt} Meals prepped just the way you want!"
    show tenna at zoom_in1
    tenna "We'll just have fun.{p=0.5}{noalt}*{/noalt} Just the two of us.{p=0.5}{noalt}*{/noalt} Forever."
    show tenna at zoom_in2
    if persistent.glitches:
        tenna "{cps=25}I promise I'll never,{w=0.2} EVER leave you.{/cps}"
    else:
        tenna "{cps=25}I promise I'll never,{w=0.2} {sc=3}EVER{/sc} leave you.{/cps}"
    show tenna at zoom_in3
    tenna "Really!{p=0.2}{noalt}*{/noalt} I can be whatever you need me to be!"
    show tenna at zoom_in4
    tenna "I want you to be happy!{p=0.2}{noalt}*{/noalt} More than anything else in the world!"
    hide tenna
    if persistent.glitches:
        show tenna cg zoom blush
        tenna "I promise...!"
    else:
        show tenna cg zoom blush at shakingcg
        tenna "{sc=3}I promise...!{/sc}" # SELF VOICING FIX
    pause 1.0
    show tenna at yreset
    pause 3.0
    show tenna cg zoom panic at zoomout1_st
    pause 2.0
    show tenna at zoomout1
    pause 3.0
    hide tenna
    show tenna slouch claw panic at tenpos_center
    pause 1.0
    show tenna at shrink
    tenna "I..."
    pause 1.0
    show tenna slouch panic static at wiggle
    tenna "I did it again,{w=0.5} didn't I?"
    show parkboard at center
    show tenna at yreset
    pause 2.0
    show tenna upright back black
    pause 2.0
    show parkboard at fallaway
    play sfx click
    pause 1.8
    play sfx falling
    pause 1.0
    play sfx drop
    if persistent.glitches:
        pass
    else:
        with vpunch
    pause 1.0
    play music dump
    tenna "Haha."
    hide parkboard
    pause 1.0
    tenna "It's pointless."
    tenna "It's really all just pointless,{w=0.2} isn't it?"
    pause 1.0
    show tenna slouch panic panic flipped at wiggle
    tenna "Why experience happiness at all{p=0.5}{noalt}*{/noalt} if it's just going to be taken away?"
    pause 2.0
    show tenna slouch panic static
    tenna "Everything changed too fast..."
    tenna "What made people happy yesterday...{w=0.5} doesn't anymore."
    if persistent.glitches:
        show tenna slouch panic static
        pause 1.0
        tenna "Nothing I can do is{w=0.2} fun for ANYONE anymore!"
    else:
        show tenna slouch panic static at shaking
        pause 1.0
        tenna "Nothing I can do is{w=0.2} fun for {sc=3}ANYONE{/sc} anymore!"
    show tenna stretch shrug weak
    tenna "Haha,{w=0.2} I'm just an irrelevant,{w=0.2} broken sack of junk!!"
    tenna "A trash heap who thought that someone could still care about me,{w=0.2} after everything I've done!!"
    if persistent.glitches:
        show tenna slouch panic panic flipped
    else:
        show tenna slouch panic panic flipped at shaking
    tenna "Haha...!{p=0.2}{noalt}*{/noalt} Hahaha...!!"
    show tenna upright chest panic at jump
    tenna "You know,{w=0.2} maybe this isn't a good idea."
    show tenna stretch shrug weak at jump
    tenna "Turns out,{w=0.2} I haven't changed at all!"
    tenna "Who even ARE {color=[c_passion]}you{/color}, really?!"
    show tenna upright pointing oh
    tenna "You've gotta be a Lightner,{w=0.2} right?"
    show tenna slouch claw panic
    tenna "Then why do you..."
    show tenna slouch panic panic at shrinks
    tenna "...{w=0.2} feel so far away?"
    pause 1.0
    show tenna stretch raised cheer flipped at zreset
    tenna "Ahah,{w=0.5} it's real comedic!"
    if persistent.glitches:
        show tenna slouch claw angry flipped at jump
    else:
        show tenna slouch claw angry flipped at shock
    tenna "Some desperate,{w=0.2} washed-up TV,{w=0.2} stuck in this loop of playing pretend--"
    tenna "--while trying to court a stranger when he doesn't even know{nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend " WHAT they are?!"
    show tenna stretch raised cheer flipped
    tenna "Funniest joke in the universe, folks!"
    tenna "I should've taken up being a JESTER instead,{w=0.2} am I right?!"
    show tenna upright chest frown flipped
    pause 2.0
    show tenna upright back nosed
    tenna "...{w=0.2} You...{nw=0.5}"
    show tenna at shrink
    extend " deserve better than that."
    tenna "And right now,"
    show tenna upright back black at shrinks
    tenna "I don't think I can give that to you."
    pause 1.0
    show tenna panic flustered at zreset
    tenna "Don't be sad, [persistent.mc]!"
    show tenna upright pointing smile at jump
    tenna "We may not have known each other long, but..."
    show tenna upright chest smile
    tenna "I feel connected to you,{w=0.2} somehow."
    show tenna upright pointing oh at jump
    tenna "But I know what you need--{w=0.2} and that's somebody who's going to bring you joy!"
    pause 1.0
    show tenna upright back black flipped at droop
    tenna "I don't want to be left alone anymore,{w=0.2} no,{w=0.2} but..."
    show tenna upright back frown flipped
    tenna "If I can't figure out how to find happiness for myself, then,{w=0.2} how am I supposed to help YOU find YOURS?"
    pause 1.0
    show tenna slouch panic panic flipped
    tenna "{cps=60}Though I don't really know how I'm going to do that either{/cps}{nw=0.1}"
    show tenna stretch raised cheer at jump
    tenna "Whatever!!{p=0.5}{noalt}*{/noalt} I'll figure it out!!"
    show tenna upright chest smile at jump
    tenna "I promise--{w=0.2} next time you see me?{p=0.5}{noalt}*{/noalt} I'll be a brand-new man."
    tenna "Same old TV,{w=0.2} though."
    show tenna slouch whisper smug at jump
    tenna "{nw=0.2}"
    play sfx ten_laughtrack
    if persistent.glitches:
        tenna_funG "You'll have to get used to that."
    else:
        tenna_fun "You'll have to get used to that." # SELF VOICING FIX
    pause 1.0
    show tenna upright back blank
    pause 2.0
    show tenna upright back frown
    tenna "...{w=0.2} Haha..."
    show tenna upright back confused at wiggle
    tenna "That...{w=0.2} was a joke,{w=0.2} you know!"
    $ _history = False
    tenna "You don't have to be...{nw=1}"
    $ _history = True
    show tenna upright back nose at droop
    stop music
    if persistent.glitches:
        tenna_shh "You don't have to be...{fast}{p=0}{noalt}*{/noalt} Dead silent."
    else:
        tenna_shh "You don't have to be...{fast}{p=0}{noalt}*{/noalt} {sc=3}Dead silent.{/sc}"

    ## GASTER MOMENT
    $ quick_menu = False
    scene black
    $ renpy.pause(3.0, hard=True)
    play music faintcourageSl
    $ renpy.pause(6.0, hard=True)
    show soul_sketchy at soulbop with Dissolve(4.0)
    $ renpy.pause(3.0, hard=True)
    show text _("And in exchange...") at truecenter with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (1.0, hard=True)
    show text _("This world may not be as you expect.") with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (1.0, hard=True)
    show text _("Your existence here is pointless.") with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (1.0, hard=True)
    show text _("It will not add anything...") with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (1.0, hard=True)
    show text _("Nor will you likely gain anything.") with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (2.0, hard=True)
    show text _("After all,") with dissolve
    pause
    hide text with dissolve
    $ renpy.pause (1.0, hard=True)
    hide soul_sketchy with dissolve
    $ renpy.pause (2.0, hard=True)
    show vess cg at truecenter with dissolve
    $ renpy.pause (2.0, hard=True)
    show text _("You are nothing more than a discarded project.") with dissolve
    pause
    scene black
    stop music fadeout 3.0
    $ renpy.pause (5.0, hard=True)
    "It felt as though you were waking up from a bad dream."
    "Inexplicably,{w=0.2} you're reminded of that note you saw..."
    "\"If it seems you have reached [[The End.]{p=0.2}{noalt}*{/noalt} Go back to sleep.\""
    pause 1.0
    "Your eyes opened,{w=0.2} and..."

    ## SAVE DATE INFO
    $ ten.fp = date_fp
    $ ten.lp = date_lp
    $ ten.hb = date_hb

    ## AUTOSAVE
    $ renpy.save("mainfile")

    ## FAKE CRASH TO MAKE DEAL
    if persistent.route != "Spamton":
        $ persistent.tenroute_fin = True
        $ renpy.pause(1.0, hard=True)
        $ renpy.quit()
    
    ## TRANSITION TO SPAMTON ROUTE
    else:
        jump spamroutestart