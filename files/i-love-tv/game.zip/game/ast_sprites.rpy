############################################################################################################
################## SPRITES
image starwalkerIm = "images/sprites/starwalker.png"

image frame_menu = "gui/frame_menu.png"
transform gameovertext:
    "gui/gameover.png"

image tn_talk_idle = "images/sprites/buttons/tn talk idle.png"
image tn_talk_hover = "images/sprites/buttons/tn talk hover.png"
image tn_act_idle = "images/sprites/buttons/tn act idle.png"
image tn_act_hover = "images/sprites/buttons/tn act hover.png"
image tn_item_idle = "images/sprites/buttons/tn items idle.png"
image tn_item_hover = "images/sprites/buttons/tn items hover.png"
image tn_menu_idle = "images/sprites/buttons/tn menu idle.png"
image tn_menu_hover = "images/sprites/buttons/tn menu hover.png"

image sp_talk_idle = "images/sprites/buttons/sp talk idle.png"
image sp_talk_hover = "images/sprites/buttons/sp talk hover.png"
image sp_act_idle = "images/sprites/buttons/sp act idle.png"
image sp_act_hover = "images/sprites/buttons/sp act hover.png"
image sp_item_idle = "images/sprites/buttons/sp items idle.png"
image sp_item_hover = "images/sprites/buttons/sp items hover.png"
image sp_menu_idle = "images/sprites/buttons/sp menu idle.png"
image sp_menu_hover = "images/sprites/buttons/sp menu hover.png"

image gp_talk_idle = "images/sprites/buttons/gp talk idle.png"
image gp_talk_hover = "images/sprites/buttons/gp talk hover.png"
image gp_act_idle = "images/sprites/buttons/gp act idle.png"
image gp_act_hover = "images/sprites/buttons/gp act hover.png"
image gp_item_idle = "images/sprites/buttons/gp items idle.png"
image gp_item_hover = "images/sprites/buttons/gp items hover.png"
image gp_menu_idle = "images/sprites/buttons/gp menu idle.png"
image gp_menu_hover = "images/sprites/buttons/gp menu hover.png"

image date_ten = "images/sprites/tenna/tenna date.png"
image date_spam = "images/sprites/spamton/spamton date.png"
image date_mke = "images/sprites/mike/mike date.png"


######################################################
##### SOULS
image soul_sketchy = "images/sprites/souls/soul sketchy lg.png"
image soul_sketchyW = "images/sprites/souls/soul sketchy white lg.png"
image soul_sketchyS = "images/sprites/souls/soul sketchy sm.png"
image soul_sketchyWS = "images/sprites/souls/soul sketchy white sm.png"

image arrow_left = "images/sprites/souls/arrow left.png"
image arrow_leftW = "images/sprites/souls/arrow left white.png"
image arrow_right = "images/sprites/souls/arrow right.png"
image arrow_rightW = "images/sprites/souls/arrow right white.png"
image arrow_up = "images/sprites/souls/arrow up.png"
image arrow_upW = "images/sprites/souls/arrow up white.png"
image arrow_down = "images/sprites/souls/arrow down.png"
image arrow_downW = "images/sprites/souls/arrow down white.png"

image secret_button1 = "images/sprites/souls/secret button1.png"
image secret_button2 = "images/sprites/souls/secret button2.png"

transform soul:
    "images/sprites/souls/soul lg.png" 
    zoom 0.18

image soul_im:
    "images/sprites/souls/soul lg.png" 
    zoom 0.12

image soul_hover:
    "images/sprites/souls/soul sm.png"
    xpos -20
    yalign 0.5
    yoffset 1.5

image soul_im datestart:
    "images/sprites/souls/soul lg.png"
    zoom 0.12
    pause 0.07
    "images/nothing.png"
    pause 0.08
    repeat

### TENNA HP / HEARTBREAK
image soultv_whole:
    "images/sprites/souls/tv lg.png"
    zoom 0.25
image soultv_cracked:
    "images/sprites/souls/tv cracked lg.png"
    zoom 0.25
image soultv_cracked2:
    "images/sprites/souls/tv cracked2 lg.png"
    zoom 0.25
image soultv_broken:
    "images/sprites/souls/tv broken lg.png"
    zoom 0.25

image heartbreak soultv_crack1:
    "soultv_whole"
    pause 0.5
    "soultv_cracked"
image heartbreak soultv_crack2:
    "soultv_cracked"
    pause 0.5
    "soultv_cracked2"
image heartbreak soultv_crack3:
    "soultv_cracked2"
    pause 0.5
    "soultv_broken"

image heartbreak soultv_restore1:
    "soultv_cracked"
    pause 0.5
    "soultv_whole"
image heartbreak soultv_restore2:
    "soultv_cracked2"
    pause 0.5
    "soultv_cracked"

### SPAMTON HP / HEARTBREAK
image soulgrn_whole:
    "images/sprites/souls/soul green lg.png"
    zoom 0.12
image soulgrn_cracked:
    "images/sprites/souls/soul cracked green lg.png"
    zoom 0.12
image soulgrn_cracked2:
    "images/sprites/souls/soul cracked2 green lg.png"
    zoom 0.12
image soulgrn_broken:
    "images/sprites/souls/soul broken green lg.png"
    zoom 0.12 

image heartbreak soulgrn_crack1:
    "soulgrn_whole"
    pause 0.5
    "soulgrn_cracked"
image heartbreak soulgrn_crack2:
    "soulgrn_cracked"
    pause 0.5
    "soulgrn_cracked2"
image heartbreak soulgrn_crack3:
    "soulgrn_cracked2"
    pause 0.5
    "soulgrn_broken"

image heartbreak soulgrn_restore1:
    "soulgrn_cracked"
    pause 0.5
    "soulgrn_whole"
image heartbreak soulgrn_restore2:
    "soulgrn_cracked2"
    pause 0.5
    "soulgrn_cracked"

### MIKE HP / HEARTBREAK
image souldice_whole:
    "images/sprites/souls/dice lg.png"
    zoom 0.15
image souldice_cracked:
    "images/sprites/souls/dice cracked lg.png"
    zoom 0.15
image souldice_cracked2:
    "images/sprites/souls/dice cracked2 lg.png"
    zoom 0.15
image souldice_broken:
    "images/sprites/souls/dice broken lg.png"
    zoom 0.15

image heartbreak souldice_crack1:
    "souldice_whole"
    pause 0.5
    "souldice_cracked"
image heartbreak souldice_crack2:
    "souldice_cracked"
    pause 0.5
    "souldice_cracked2"
image heartbreak souldice_crack3:
    "souldice_cracked2"
    pause 0.5
    "souldice_broken"

image heartbreak souldice_restore1:
    "souldice_cracked"
    pause 0.5
    "souldice_whole"
image heartbreak souldice_restore2:
    "souldice_cracked2"
    pause 0.5
    "souldice_cracked"

### HEARTBREAK COUNTERS
transform hb_red_full:
    "images/sprites/souls/circle red full xs.png"
transform hb_red_empty:
    "images/sprites/souls/circle red empty xs.png"
transform hb_green_full:
    "images/sprites/souls/soul green full xs.png"
transform hb_green_empty:
    "images/sprites/souls/soul green empty xs.png"
transform hb_blue_full:
    "images/sprites/souls/circle blue full xs.png"
transform hb_blue_empty:
    "images/sprites/souls/circle blue empty xs.png"


######################################################
##### TENNA
### panic pose
image tenna panic flustered = "images/sprites/tenna/tenna panic flustered.png"
image tenna panic flustered flipped = Transform("images/sprites/tenna/tenna panic flustered.png", xzoom=-1.0)
image tenna panic panic = "images/sprites/tenna/tenna panic panic.png"
image tenna panic panic flipped = Transform("images/sprites/tenna/tenna panic panic.png", xzoom=-1.0)
image tenna panic smpte = "images/sprites/tenna/tenna panic smpte.png"
image tenna panic smpte flipped = Transform("images/sprites/tenna/tenna panic smpte.png", xzoom=-1.0)

### slouch pose
# claw
image tenna slouch claw angry = "images/sprites/tenna/tenna slouch claw angry.png"
image tenna slouch claw angry flipped = Transform("images/sprites/tenna/tenna slouch claw angry.png", xzoom=-1.0)
image tenna slouch claw panic = "images/sprites/tenna/tenna slouch claw panic.png"
image tenna slouch claw panic flipped = Transform("images/sprites/tenna/tenna slouch claw panic.png", xzoom=-1.0)

# panic
image tenna slouch panic panic = "images/sprites/tenna/tenna slouch panic panic.png"
image tenna slouch panic panic flipped = Transform("images/sprites/tenna/tenna slouch panic panic.png", xzoom=-1.0)
image tenna slouch panic static = "images/sprites/tenna/tenna slouch panic static.png"
image tenna slouch panic static flipped = Transform("images/sprites/tenna/tenna slouch panic static.png", xzoom=-1.0)
image tenna slouch panic smpte = "images/sprites/tenna/tenna slouch panic smpte.png"
image tenna slouch panic smpte flipped = Transform("images/sprites/tenna/tenna slouch panic smpte.png", xzoom=-1.0)

# whisper
image tenna slouch whisper smug = "images/sprites/tenna/tenna slouch whisper smug.png"
image tenna slouch whisper smug flipped = Transform("images/sprites/tenna/tenna slouch whisper smug.png", xzoom=-1.0)

### stretch pose
# raised
image tenna stretch raised cheer = "images/sprites/tenna/tenna stretch raised cheer.png"
image tenna stretch raised cheer flipped = Transform("images/sprites/tenna/tenna stretch raised cheer.png", xzoom=-1.0)

# shrug
image tenna stretch shrug smile = "images/sprites/tenna/tenna stretch shrug smile.png"
image tenna stretch shrug smile flipped = Transform("images/sprites/tenna/tenna stretch shrug smile.png", xzoom=-1.0)
image tenna stretch shrug weak = "images/sprites/tenna/tenna stretch shrug weak.png"
image tenna stretch shrug weak flipped = Transform("images/sprites/tenna/tenna stretch shrug weak.png", xzoom=-1.0)

### upright
# card
image tenna upright card angry = "images/sprites/tenna/tenna upright card angry.png"
image tenna upright card angry flipped = Transform("images/sprites/tenna/tenna upright card angry.png", xzoom=-1.0)
image tenna upright card awkward = "images/sprites/tenna/tenna upright card awkward.png"
image tenna upright card awkward flipped = Transform("images/sprites/tenna/tenna upright card awkward.png", xzoom=-1.0)
image tenna upright card blank = "images/sprites/tenna/tenna upright card blank.png"
image tenna upright card blank flipped = Transform("images/sprites/tenna/tenna upright card blank.png", xzoom=-1.0)
image tenna upright card confused = "images/sprites/tenna/tenna upright card confused.png"
image tenna upright card confused flipped = Transform("images/sprites/tenna/tenna upright card confused.png", xzoom=-1.0)
image tenna upright card frown = "images/sprites/tenna/tenna upright card frown.png"
image tenna upright card frown flipped = Transform("images/sprites/tenna/tenna upright card frown.png", xzoom=-1.0)
image tenna upright card neutral = "images/sprites/tenna/tenna upright card neutral.png"
image tenna upright card neutral flipped = Transform("images/sprites/tenna/tenna upright card neutral.png", xzoom=-1.0)
image tenna upright card panic = "images/sprites/tenna/tenna upright card panic.png"
image tenna upright card panic flipped = Transform("images/sprites/tenna/tenna upright card panic.png", xzoom=-1.0)
image tenna upright card smile = "images/sprites/tenna/tenna upright card smile.png"
image tenna upright card smile flipped = Transform("images/sprites/tenna/tenna upright card smile.png", xzoom=-1.0)

# chest
image tenna upright chest angry = "images/sprites/tenna/tenna upright chest angry.png"
image tenna upright chest angry flipped = Transform("images/sprites/tenna/tenna upright chest angry.png", xzoom=-1.0)
image tenna upright chest awkward = "images/sprites/tenna/tenna upright chest awkward.png"
image tenna upright chest awkward flipped = Transform("images/sprites/tenna/tenna upright chest awkward.png", xzoom=-1.0)
image tenna upright chest blank = "images/sprites/tenna/tenna upright chest blank.png"
image tenna upright chest blank flipped = Transform("images/sprites/tenna/tenna upright chest blank.png", xzoom=-1.0)
image tenna upright chest confused = "images/sprites/tenna/tenna upright chest confused.png"
image tenna upright chest confused flipped = Transform("images/sprites/tenna/tenna upright chest confused.png", xzoom=-1.0)
image tenna upright chest frown = "images/sprites/tenna/tenna upright chest frown.png"
image tenna upright chest frown flipped = Transform("images/sprites/tenna/tenna upright chest frown.png", xzoom=-1.0)
image tenna upright chest neutral = "images/sprites/tenna/tenna upright chest neutral.png"
image tenna upright chest neutral flipped = Transform("images/sprites/tenna/tenna upright chest neutral.png", xzoom=-1.0)
image tenna upright chest panic = "images/sprites/tenna/tenna upright chest panic.png"
image tenna upright chest panic flipped = Transform("images/sprites/tenna/tenna upright chest panic.png", xzoom=-1.0)
image tenna upright chest smile = "images/sprites/tenna/tenna upright chest smile.png"
image tenna upright chest smile flipped = Transform("images/sprites/tenna/tenna upright chest smile.png", xzoom=-1.0)

# pressed
image tenna upright pressed smile = "images/sprites/tenna/tenna upright pressed smile.png"
image tenna upright pressed smile flipped = Transform("images/sprites/tenna/tenna upright pressed smile.png", xzoom=-1.0)

# pointing
image tenna upright pointing oh = "images/sprites/tenna/tenna upright pointing oh.png"
image tenna upright pointing oh flipped = Transform("images/sprites/tenna/tenna upright pointing oh.png", xzoom=-1.0)
image tenna upright pointing smile = "images/sprites/tenna/tenna upright pointing smile.png"
image tenna upright pointing smile flipped = Transform("images/sprites/tenna/tenna upright pointing smile.png", xzoom=-1.0)
image tenna upright pointing weak = "images/sprites/tenna/tenna upright pointing weak.png"
image tenna upright pointing weak flipped = Transform("images/sprites/tenna/tenna upright pointing weak.png", xzoom=-1.0)

# back
image tenna upright back angry = "images/sprites/tenna/tenna upright behind angry.png"
image tenna upright back angry flipped = Transform("images/sprites/tenna/tenna upright behind angry.png", xzoom=-1.0)
image tenna upright back awkward = "images/sprites/tenna/tenna upright behind awkward.png"
image tenna upright back awkward flipped = Transform("images/sprites/tenna/tenna upright behind awkward.png", xzoom=-1.0)
image tenna upright back black = "images/sprites/tenna/tenna upright behind black.png"
image tenna upright back black flipped = Transform("images/sprites/tenna/tenna upright behind black.png", xzoom=-1.0)
image tenna upright back blank = "images/sprites/tenna/tenna upright behind blank.png"
image tenna upright back blank flipped = Transform("images/sprites/tenna/tenna upright behind blank.png", xzoom=-1.0)
image tenna upright back confused = "images/sprites/tenna/tenna upright behind confused.png"
image tenna upright back confused flipped = Transform("images/sprites/tenna/tenna upright behind confused.png", xzoom=-1.0)
image tenna upright back frown = "images/sprites/tenna/tenna upright behind frown.png"
image tenna upright back frown flipped = Transform("images/sprites/tenna/tenna upright behind frown.png", xzoom=-1.0)
image tenna upright back neutral = "images/sprites/tenna/tenna upright behind neutral.png"
image tenna upright back neutral flipped = Transform("images/sprites/tenna/tenna upright behind neutral.png", xzoom=-1.0)
image tenna upright back nose = "images/sprites/tenna/tenna upright behind nose.png"
image tenna upright back nose flipped = Transform("images/sprites/tenna/tenna upright behind nose.png", xzoom=-1.0)
image tenna upright back nosed = "images/sprites/tenna/tenna upright behind nosed.png"
image tenna upright back nosed flipped = Transform("images/sprites/tenna/tenna upright behind nosed.png", xzoom=-1.0)
image tenna upright back panic = "images/sprites/tenna/tenna upright behind panic.png"
image tenna upright back panic flipped = Transform("images/sprites/tenna/tenna upright behind panic.png", xzoom=-1.0)
image tenna upright back smile = "images/sprites/tenna/tenna upright behind smile.png"
image tenna upright back smile flipped = Transform("images/sprites/tenna/tenna upright behind smile.png", xzoom=-1.0)

### LoT overlay
image tenna lotoverlay = "images/sprites/tenna/lot tenna overlay.png"

### overworld button
image ten_button:
    "images/sprites/tenna/ten button.png"
    zoom 1.1
image ten_buttonH:
    "images/sprites/tenna/ten button h.png"
    zoom 1.1

image ten_button_sm:
    "images/sprites/tenna/ten button.png"
    zoom 0.8
image ten_button_smH:
    "images/sprites/tenna/ten button h.png"
    zoom 0.8


######################################################
##### TENNA TEXT

### movement
image txt_tvtime:
    ypos -1.0
    "images/sprites/text/tv time1.png"
    pause 0.2
    "images/sprites/text/tv time2.png"
    pause 0.2
    repeat

image txt_lightner1:
    "images/sprites/text/lightner1.png"
    pause 0.2
    "images/sprites/text/lightner2.png"
    pause 0.2
    repeat

image txt_quizshow:
    ypos -0.2
    "images/sprites/text/quizshow.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_charmer:
    ypos 0.1
    "images/sprites/text/charmer1.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer2.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer3.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer4.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer5.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer6.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer7.png" with Dissolve(0.2)
    pause 0.1
    "images/sprites/text/charmer8.png" with Dissolve(0.2)
    pause 0.1
    repeat

image txt_name:
    "images/sprites/text/names1.png"
    pause 0.3
    "images/sprites/text/names2.png"
    pause 0.3
    repeat

image txt_tears:
    ypos 0.1
    "images/sprites/text/tears1.png"
    pause 0.05
    "images/sprites/text/tears2.png"
    pause 0.05
    "images/sprites/text/tears3.png"
    pause 0.05
    "images/sprites/text/tears4.png"
    pause 0.05
    "images/sprites/text/tears5.png"
    pause 0.05
    "images/sprites/text/tears6.png"
    pause 0.05
    "images/sprites/text/tears7.png"
    pause 0.05
    "images/sprites/text/tears8.png"
    pause 0.05
    "images/sprites/text/tears9.png"
    pause 0.05
    "images/sprites/text/tears10.png"
    pause 0.05
    "images/sprites/text/tears11.png"
    pause 0.05
    "images/sprites/text/tears12.png"
    pause 0.05
    "images/sprites/text/tears13.png"
    pause 0.05
    "images/sprites/text/tears14.png"
    pause 0.05
    "images/sprites/text/tears15.png"
    pause 0.05
    "images/sprites/text/tears16.png"
    pause 0.05
    "images/sprites/text/tears17.png"
    pause 0.05
    "images/sprites/text/tears18.png"
    pause 0.05
    "images/sprites/text/tears19.png"
    pause 0.05
    repeat

image txt_word:
    ypos 0.1
    "images/sprites/text/word.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_star:
    "images/sprites/text/star.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_heartwarming:
    "images/sprites/text/heartwarming reunion.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_special:
    ypos -0.1
    "images/sprites/text/special.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_fun:
    ypos 0.1
    "images/sprites/text/fun1.png"
    pause 0.05
    "images/sprites/text/fun2.png"
    pause 0.05
    "images/sprites/text/fun3.png"
    pause 0.05
    "images/sprites/text/fun4.png"
    pause 0.05
    "images/sprites/text/fun5.png"
    pause 0.05
    "images/sprites/text/fun6.png"
    pause 0.05
    "images/sprites/text/fun7.png"
    pause 0.05
    "images/sprites/text/fun8.png"
    pause 0.05
    "images/sprites/text/fun9.png"
    pause 0.05
    "images/sprites/text/fun10.png"
    pause 0.05
    "images/sprites/text/fun11.png"
    pause 0.05
    "images/sprites/text/fun12.png"
    pause 0.05
    "images/sprites/text/fun13.png"
    pause 0.05
    "images/sprites/text/fun14.png"
    pause 0.05
    "images/sprites/text/fun15.png"
    pause 0.05
    repeat

image txt_explosions:
    ypos 0.1
    "images/sprites/text/explosions1.png"
    pause 0.1
    "images/sprites/text/explosions2.png"
    pause 0.1
    "images/sprites/text/explosions3.png"
    pause 0.1
    "images/sprites/text/explosions4.png"
    pause 0.1
    "images/sprites/text/explosions5.png"
    pause 0.1
    "images/sprites/text/explosions6.png"
    pause 0.1
    "images/sprites/text/explosions7.png"
    pause 0.1
    "images/sprites/text/explosions8.png"
    pause 0.1
    "images/sprites/text/explosions9.png"
    pause 0.1
    "images/sprites/text/explosions10.png"
    pause 0.1
    repeat

image txt_lovely:
    ypos 0.1
    "images/sprites/text/lovely.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_love:
    ypos 0.1
    "images/sprites/text/love.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_jealous:
    ypos 0.1
    "images/sprites/text/jealous.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_gameover:
    ypos -0.2
    "images/sprites/text/gameover.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_hope:
    ypos -0.3
    "images/sprites/text/hope1.png"
    pause 0.05
    "images/sprites/text/hope2.png"
    pause 0.05
    "images/sprites/text/hope3.png"
    pause 0.05
    "images/sprites/text/hope4.png"
    pause 0.05
    "images/sprites/text/hope5.png"
    pause 0.05
    "images/sprites/text/hope6.png"
    pause 0.05
    "images/sprites/text/hope7.png"
    pause 0.05
    "images/sprites/text/hope8.png"
    pause 0.05
    "images/sprites/text/hope9.png"
    pause 0.05
    "images/sprites/text/hope10.png"
    pause 0.05
    "images/sprites/text/hope11.png"
    pause 0.05
    "images/sprites/text/hope12.png"
    pause 0.05
    "images/sprites/text/hope13.png"
    pause 0.05
    "images/sprites/text/hope14.png"
    pause 0.05
    "images/sprites/text/hope15.png"
    pause 0.05
    "images/sprites/text/hope16.png"
    pause 0.05
    "images/sprites/text/hope17.png"
    pause 0.05
    "images/sprites/text/hope18.png"
    pause 0.05
    "images/sprites/text/hope19.png"
    pause 0.05
    "images/sprites/text/hope20.png"
    pause 0.05
    "images/sprites/text/hope21.png"
    pause 0.05
    "images/sprites/text/hope22.png"
    pause 0.05
    "images/sprites/text/hope23.png"
    pause 0.05
    "images/sprites/text/hope24.png"
    pause 0.05
    "images/sprites/text/hope25.png"
    pause 0.05
    "images/sprites/text/hope26.png"
    pause 0.05
    "images/sprites/text/hope27.png"
    pause 0.05
    "images/sprites/text/hope28.png"
    pause 0.05
    "images/sprites/text/hope29.png"
    pause 0.05
    "images/sprites/text/hope30.png"
    pause 0.05
    "images/sprites/text/hope31.png"
    pause 0.05
    "images/sprites/text/hope32.png"
    pause 0.05
    "images/sprites/text/hope33.png"
    pause 0.05
    "images/sprites/text/hope34.png"
    pause 0.05
    "images/sprites/text/hope35.png"
    pause 0.3
    repeat

image txt_back:
    ypos 0.1
    "images/sprites/text/back.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_groovy:
    ypos 0.1
    "images/sprites/text/groovy.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_paradise:
    ypos 0.15
    zoom 1.2
    "images/sprites/text/paradise1.png"
    pause 0.1
    "images/sprites/text/paradise2.png"
    pause 0.1
    "images/sprites/text/paradise3.png"
    pause 0.1
    "images/sprites/text/paradise4.png"
    pause 0.1
    "images/sprites/text/paradise5.png"
    pause 0.1
    "images/sprites/text/paradise6.png"
    pause 0.1
    "images/sprites/text/paradise7.png"
    pause 0.1
    "images/sprites/text/paradise8.png"
    pause 0.1
    "images/sprites/text/paradise9.png"
    pause 0.1
    "images/sprites/text/paradise10.png"
    pause 0.1
    repeat

image txt_perfect:
    ypos 0.15
    zoom 1.2
    "images/sprites/text/perfect1.png"
    pause 0.1
    "images/sprites/text/perfect2.png"
    pause 0.1
    "images/sprites/text/perfect3.png"
    pause 0.1
    "images/sprites/text/perfect4.png"
    pause 0.1
    "images/sprites/text/perfect5.png"
    pause 0.1
    "images/sprites/text/perfect6.png"
    pause 0.1
    "images/sprites/text/perfect7.png"
    pause 0.1
    "images/sprites/text/perfect8.png"
    pause 0.1
    "images/sprites/text/perfect9.png"
    pause 0.1
    "images/sprites/text/perfect10.png"
    pause 0.1
    repeat

image txt_fave:
    ypos 0.1
    "images/sprites/text/favorite.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_first:
    ypos 0.1
    "images/sprites/text/first.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_great:
    ypos 0.1
    "images/sprites/text/great.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_surprise:
    ypos 0.1
    "images/sprites/text/surprise.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

image txt_dream:
    ypos 0.2
    "images/sprites/text/dream.png"
    xoffset -.5
    pause 0.03
    yoffset -.5
    pause 0.03
    xoffset .5
    pause 0.03
    yoffset .5
    pause 0.03
    xoffset 0
    pause 0.03
    yoffset 0
    pause 0.03
    repeat

### still
image txt_tvtastic:
    ypos -0.1
    "images/sprites/text/tv tastic.png"

image txt_explosionsG:
    ypos 0.1
    "images/sprites/text/explosions.png"

image txt_wordG:
    ypos 0.1
    "images/sprites/text/word.png"

image txt_quizshowG:
    ypos -0.2
    "images/sprites/text/quizshow.png"

image txt_specialG:
    ypos -0.1
    "images/sprites/text/special.png"

image txt_loveG:
    ypos 0.1
    "images/sprites/text/love.png"

image txt_lovelyG:
    ypos 0.1
    "images/sprites/text/lovely.png"

image txt_jealousG:
    ypos 0.1
    "images/sprites/text/jealous.png"

image txt_gameoverG:
    ypos -0.2
    "images/sprites/text/gameover.png"

image txt_backG:
    ypos 0.1
    "images/sprites/text/back.png"

image txt_groovyG:
    ypos 0.1
    "images/sprites/text/groovy.png"

image txt_faveG:
    ypos 0.1
    "images/sprites/text/favorite.png"

image txt_firstG:
    ypos 0.1
    "images/sprites/text/first.png"

image txt_greatG:
    ypos 0.1
    "images/sprites/text/great.png"

image txt_surpriseG:
    ypos 0.1
    "images/sprites/text/surprise.png"

image txt_dreamG:
    ypos 0.2
    "images/sprites/text/dream.png"

image txt_heartwarmingG = "images/sprites/text/heartwarming reunion.png"
image txt_starG = "images/sprites/text/star.png"


######################################################
##### SPAMTON
### crazy
image spamton crazy angry = "images/sprites/spamton/spam crazy anger.png"
image spamton crazy angry flipped = Transform("images/sprites/spamton/spam crazy anger.png", xzoom=-1.0)
image spamton crazy avert = "images/sprites/spamton/spam crazy avert.png"
image spamton crazy avert flipped = Transform("images/sprites/spamton/spam crazy avert.png", xzoom=-1.0)
image spamton crazy frantic = "images/sprites/spamton/spam crazy frantic.png"
image spamton crazy frantic flipped = Transform("images/sprites/spamton/spam crazy frantic.png", xzoom=-1.0)
image spamton crazy laugh = "images/sprites/spamton/spam crazy laugh.png"
image spamton crazy laugh flipped = Transform("images/sprites/spamton/spam crazy laugh.png", xzoom=-1.0)
image spamton crazy smirk = "images/sprites/spamton/spam crazy smirk.png"
image spamton crazy smirk flipped = Transform("images/sprites/spamton/spam crazy smirk.png", xzoom=-1.0)

### panic
image spamton panic up scream = "images/sprites/spamton/spam panic up scream.png"
image spamton panic up scream flipped = Transform("images/sprites/spamton/spam panic up scream.png", xzoom=-1.0)
image spamton panic up screame = "images/sprites/spamton/spam panic up screame.png"
image spamton panic up screame flipped = Transform("images/sprites/spamton/spam panic up screame.png", xzoom=-1.0)

### slouch
image spamton slouch down frown = "images/sprites/spamton/spam slouch down frown.png"
image spamton slouch down frown flipped = Transform("images/sprites/spamton/spam slouch down frown.png", xzoom=-1.0)
image spamton slouch down panic = "images/sprites/spamton/spam slouch down panic.png"
image spamton slouch down panic flipped = Transform("images/sprites/spamton/spam slouch down panic.png", xzoom=-1.0)
image spamton slouch down smile = "images/sprites/spamton/spam slouch down smile.png"
image spamton slouch down smile flipped = Transform("images/sprites/spamton/spam slouch down smile.png", xzoom=-1.0)
image spamton slouch down static 1 = "images/sprites/spamton/spam slouch down static 1.png"
image spamton slouch down static 1 flipped = Transform("images/sprites/spamton/spam slouch down static 1.png", xzoom=-1.0)
image spamton slouch down static 2 = "images/sprites/spamton/spam slouch down static 2.png"
image spamton slouch down static 2 flipped = Transform("images/sprites/spamton/spam slouch down static 2.png", xzoom=-1.0)
image spamton slouch down static:
    "spamton slouch down static 1"
    pause 0.2
    "spamton slouch down static 2"
    pause 0.2
    repeat
image spamton slouch down static flipped:
    "spamton slouch down static 1 flipped"
    pause 0.2
    "spamton slouch down static 2 flipped"
    pause 0.2
    repeat

### standing
image spamton standing down frown = "images/sprites/spamton/spam standing down frown.png"
image spamton standing down frown flipped = Transform("images/sprites/spamton/spam standing down frown.png", xzoom=-1.0)
image spamton standing down panic = "images/sprites/spamton/spam standing down panic.png"
image spamton standing down panic flipped = Transform("images/sprites/spamton/spam standing down panic.png", xzoom=-1.0)
image spamton standing down smile = "images/sprites/spamton/spam standing down smile.png"
image spamton standing down smile flipped = Transform("images/sprites/spamton/spam standing down smile.png", xzoom=-1.0)
image spamton standing down static 1 = "images/sprites/spamton/spam standing down static 1.png"
image spamton standing down static 1 flipped = Transform("images/sprites/spamton/spam standing down static 1.png", xzoom=-1.0)
image spamton standing down static 2 = "images/sprites/spamton/spam standing down static 2.png"
image spamton standing down static 2 flipped = Transform("images/sprites/spamton/spam standing down static 2.png", xzoom=-1.0)
image spamton standing tilt laugh = "images/sprites/spamton/spam standing tilt laugh.png"
image spamton standing tilt laugh flipped = Transform("images/sprites/spamton/spam standing tilt laugh.png", xzoom=-1.0)
image spamton standing tilt stare = "images/sprites/spamton/spam standing tilt stare.png"
image spamton standing tilt stare flipped = Transform("images/sprites/spamton/spam standing tilt stare.png", xzoom=-1.0)
image spamton standing up frown = "images/sprites/spamton/spam standing up frown.png"
image spamton standing up frown flipped = Transform("images/sprites/spamton/spam standing up frown.png", xzoom=-1.0)
image spamton standing up frowne = "images/sprites/spamton/spam standing up frowne.png"
image spamton standing up frowne flipped = Transform("images/sprites/spamton/spam standing up frowne.png", xzoom=-1.0)
image spamton standing up smile = "images/sprites/spamton/spam standing up smile.png"
image spamton standing up smile flipped = Transform("images/sprites/spamton/spam standing up smile.png", xzoom=-1.0)
image spamton standing up stare = "images/sprites/spamton/spam standing up stare.png"
image spamton standing up stare flipped = Transform("images/sprites/spamton/spam standing up stare.png", xzoom=-1.0)
image spamton standing up glare = "images/sprites/spamton/spam standing up glare.png"
image spamton standing up glare flipped = Transform("images/sprites/spamton/spam standing up glare.png", xzoom=-1.0)
image spamton standing up glaree = "images/sprites/spamton/spam standing up glaree.png"
image spamton standing up glaree flipped = Transform("images/sprites/spamton/spam standing up glaree.png", xzoom=-1.0)
image spamton standing up smirk = "images/sprites/spamton/spam standing up smirk.png"
image spamton standing up smirk flipped = Transform("images/sprites/spamton/spam standing up smirk.png", xzoom=-1.0)
image spamton standing up smirke = "images/sprites/spamton/spam standing up smirke.png"
image spamton standing up smirke flipped = Transform("images/sprites/spamton/spam standing up smirke.png", xzoom=-1.0)
image spamton standing down static:
    "spamton standing down static 1"
    pause 0.2
    "spamton standing down static 2"
    pause 0.2
    repeat
image spamton standing down static flipped:
    "spamton standing down static 1 flipped"
    pause 0.2
    "spamton standing down static 2 flipped"
    pause 0.2
    repeat

### glitched
image spamton crazy laugh glitch:
    animated_glitch("spamton crazy laugh", chroma=False, timeout_vanilla=0.5)

image spamton crazy laugh flipped glitch:
    animated_glitch("spamton crazy laugh flipped", chroma=False, timeout_vanilla=0.5)

image spamton crazy frantic flipped glitch:
    animated_glitch("spamton crazy frantic flipped", chroma=False, timeout_vanilla=0.5)

image spamton slouch down static glitch:
    animated_glitch("spamton slouch down static", chroma=False)

image spamton slouch down static flipped glitch:
    animated_glitch("spamton slouch down static flipped", chroma=False)

image spamton slouch down panic flipped glitch:
    animated_glitch("spamton slouch down panic flipped", chroma=False)
    
image spamton panic up screame glitch:
    animated_glitch("spamton panic up screame", chroma=False, timeout_vanilla=0.5)

image spamton standing tilt stare glitch:
    animated_glitch("spamton standing tilt stare", chroma=False, timeout_vanilla=0.5)

image spamton standing tilt stare flipped glitch:
    animated_glitch("spamton standing tilt stare flipped", chroma=False, timeout_vanilla=0.5)

image spamton crazy angry flipped glitch:
    animated_glitch("spamton crazy angry flipped", chroma=False, timeout_vanilla=0.5)

image spamton crazy frantic glitch:
    animated_glitch("spamton crazy frantic", chroma=False, timeout_vanilla=0.5)

image spamton standing tilt laugh flipped glitch:
    animated_glitch("spamton standing tilt laugh flipped", chroma=False, timeout_vanilla=0.5)

image spamton standing tilt laugh glitch:
    "spamton standing tilt laugh"
    pause 0.1
    glitch("spamton standing tilt laugh", chroma=False, randomkey=None)
    pause 0.2
    glitch("spamton standing tilt laugh flipped", chroma=False, randomkey=None)
    pause 0.2
    repeat

image spamton slouch down smile glitch:
    animated_glitch("spamton slouch down smile", chroma=False)

image spamton slouch down smile flipped glitch:
    animated_glitch("spamton slouch down smile flipped", chroma=False)

image spamton slouch down frown glitch:
    animated_glitch("spamton slouch down frown", chroma=False)
    
image spamton standing down panic glitch:
    animated_glitch("spamton slouch down panic", chroma=False)

image spamton slouch down panic flipped glitch:
    animated_glitch("spamton slouch down panic flipped", chroma=False)


### spamton spam ad
image clickhere:
    "images/sprites/buttons/click here for your free prize 1.png"
    pause 0.5
    "images/sprites/buttons/click here for your free prize 2.png"
    pause 0.5
    repeat

image clickhereH:
    "images/sprites/buttons/click here for your free prize 1 h.png"
    pause 0.5
    "images/sprites/buttons/click here for your free prize 2 h.png"
    pause 0.5
    repeat

screen s_clickhere:
    modal True
    imagebutton:
        xpos 200
        ypos 100
        idle "clickhere"
        hover "clickhereH"
        action Jump("rewardrecieved")

### overworld button
image spam_button = "images/sprites/spamton/spam button.png"
image spam_buttonH = "images/sprites/spamton/spam button h.png"

### angel spammy
image angel idle = "images/sprites/spamton/angel still.png"
image angel up = "images/sprites/spamton/angel up.png"
image angel down = "images/sprites/spamton/angel down.png"
image angel patpat:
    "angel up"
    pause 0.05
    "angel down"
    pause 0.05
    repeat

image angel patpatS:
    "angel up"
    pause 0.1
    "angel down"
    pause 0.1
    repeat

image angel green1 = "images/sprites/spamton/angel green1.png"
image angel green2 = "images/sprites/spamton/angel green2.png"
image angel green3 = "images/sprites/spamton/angel green3.png"
image angel green4 = "images/sprites/spamton/angel green4.png"
image angel green:
    "angel green1"
    pause 0.1
    "angel green2"
    pause 0.1
    "angel green3"
    pause 0.1
    "angel green4"

### other
image strings = "images/sprites/spamton/strings.png"
image strings_Fl = Transform("images/sprites/spamton/strings.png", xzoom=-1.0)


######################################################
##### MIKE
### GP arms
image mike arms avert = "images/sprites/mike/mike arms avert.png"
image mike arms freakout = "images/sprites/mike/mike arms freakout.png"

### GP standing
image mike standing angry = "images/sprites/mike/mike standing angry.png"
image mike standing awkward = "images/sprites/mike/mike standing awkward.png"
image mike standing indifferent = "images/sprites/mike/mike standing indifferent.png"
image mike standing nervous = "images/sprites/mike/mike standing nervous.png"
image mike standing sigh = "images/sprites/mike/mike standing sigh.png"
image mike standing wink = "images/sprites/mike/mike standing wink.png"
image mike standing conflicted = "images/sprites/mike/mike standing conflicted.png"
image mike standing pout = "images/sprites/mike/mike standing pout.png"
image mike standing smile = "images/sprites/mike/mike standing smile.png"

### GP tie
image mike tie anime = "images/sprites/mike/mike tie anime.png"
image mike tie anime flipped = Transform("images/sprites/mike/mike tie anime.png", xzoom=-1.0)
image mike tie awkward = "images/sprites/mike/mike tie awkward.png"
image mike tie awkward flipped = Transform("images/sprites/mike/mike tie awkward.png", xzoom=-1.0)
image mike tie nervous = "images/sprites/mike/mike tie nervous.png"
image mike tie nervous flipped = Transform("images/sprites/mike/mike tie nervous.png", xzoom=-1.0)
image mike tie blush = "images/sprites/mike/mike tie blush.png"
image mike tie blush flipped = Transform("images/sprites/mike/mike tie blush.png", xzoom=-1.0)
image mike tie avert = "images/sprites/mike/mike tie avert.png"
image mike tie avert flipped = Transform("images/sprites/mike/mike tie avert.png", xzoom=-1.0)

### costume down
image costume down annoyed = "images/sprites/mike/costume down annoyed.png"
image costume down annoyed flipped = Transform("images/sprites/mike/costume down annoyed.png", xzoom=-1.0)
image costume down frown = "images/sprites/mike/costume down frown.png"
image costume down frown flipped = Transform("images/sprites/mike/costume down frown.png", xzoom=-1.0)
image costume down smile = "images/sprites/mike/costume down smile.png"
image costume down smile flipped = Transform("images/sprites/mike/costume down smile.png", xzoom=-1.0)
image costume down nervous = "images/sprites/mike/costume down nervous.png"
image costume down nervous flipped = Transform("images/sprites/mike/costume down nervous.png", xzoom=-1.0)
image costume down angry = "images/sprites/mike/costume down anger.png"
image costume down angry flipped = Transform("images/sprites/mike/costume down anger.png", xzoom=-1.0)

### costume pointing
image costume pointing angry = "images/sprites/mike/costume pointing anger.png"
image costume pointing angry flipped = Transform("images/sprites/mike/costume pointing anger.png", xzoom=-1.0)
image costume pointing frown = "images/sprites/mike/costume pointing frown.png"
image costume pointing frown flipped = Transform("images/sprites/mike/costume pointing frown.png", xzoom=-1.0)
image costume pointing nervous = "images/sprites/mike/costume pointing nervous.png"
image costume pointing nervous flipped = Transform("images/sprites/mike/costume pointing nervous.png", xzoom=-1.0)
image costume pointing smile = "images/sprites/mike/costume pointing smile.png"
image costume pointing smile flipped = Transform("images/sprites/mike/costume pointing smile.png", xzoom=-1.0)

### costume tie
image costume tie awkward = "images/sprites/mike/costume tie awkward.png"
image costume tie awkward flipped = Transform("images/sprites/mike/costume tie awkward.png", xzoom=-1.0)
image costume tie blush = "images/sprites/mike/costume tie blush.png"
image costume tie blush flipped = Transform("images/sprites/mike/costume tie blush.png", xzoom=-1.0)
image costume tie nervous = "images/sprites/mike/costume tie nervous.png"
image costume tie nervous flipped = Transform("images/sprites/mike/costume tie nervous.png", xzoom=-1.0)
image costume tie smile = "images/sprites/mike/costume tie smile.png"
image costume tie smile flipped = Transform("images/sprites/mike/costume tie smile.png", xzoom=-1.0)
image costume tie frown = "images/sprites/mike/costume tie frown.png"
image costume tie frown flipped = Transform("images/sprites/mike/costume tie frown.png", xzoom=-1.0)

### costume face
image costume smile = "images/sprites/mike/costume smile.png"
image costume angry = "images/sprites/mike/costume anger.png"

### overworld button
image mike_button = "images/sprites/mike/mike button.png"
image mike_buttonH = "images/sprites/mike/mike button h.png"


######################################################
##### GASTER
image gaster frown = "images/sprites/gaster/gaster frown.png"
image gaster frowne = "images/sprites/gaster/gaster frowne.png"
image gaster frowns = "images/sprites/gaster/gaster frowns.png"
image gaster frownse = "images/sprites/gaster/gaster frownse.png"
image gaster laugh = "images/sprites/gaster/gaster laugh.png"
image gaster neutral = "images/sprites/gaster/gaster neutral.png"
image gaster neutrale = "images/sprites/gaster/gaster neutrale.png"
image gaster side = "images/sprites/gaster/gaster side.png"
image gaster smile = "images/sprites/gaster/gaster smile.png"
image gaster smilee = "images/sprites/gaster/gaster smilee.png"


######################################################
##### SIDE IMAGES
image side tenside = "images/sprites/tenna/tenna side.png"
image side spamside = "images/sprites/spamton/spamton side.png"
image side spamglassside = "images/sprites/spamton/spamglass side.png"
image side spamaddside = "images/sprites/spamton/spamadd side.png"
image side mikeside = "images/sprites/mike/mike side.png"
image side pipside = "images/sprites/mike/pip side.png"


######################################################
##### ITEMS
layeredimage itemframe:
    always:
        "gui/item pickup.png"

    group items:
        ### actual items
        attribute i_pipis:
            pos(155,95)
            "pipis"

        attribute i_pie:
            pos(155,95)
            "baked goods"

        attribute i_candy:
            pos(155,95)
            "candy"

        attribute i_fries:
            pos(155,95)
            "fries"

        attribute i_pretzels:
            pos(155,95)
            "pretzels"

        attribute i_chocolate:
            pos(155,95)
            "chocolate"

        attribute i_coffee:
            pos(155,95)
            "coffee"

        attribute i_nes:
            pos(155,95)
            "nes"

        attribute i_shovel:
            pos(155,95)
            "shovel"

        attribute i_shovel2:
            pos(155,95)
            "shovel2"

        attribute i_redshard1:
            pos(155,95)
            "redshard1"

        attribute i_redshard2:
            pos(155,95)
            "redshard2"
        
        attribute i_redshard3:
            pos(155,95)
            "redshard3"

        attribute i_fighate:
            pos(155,95)
            "fighate"

        attribute i_cartridge1:
            pos(155,95)
            "cartridge1"

        attribute i_cartridge2:
            pos(155,95)
            "cartridge2"

        attribute i_freecard:
            pos(155,95)
            "freecard"

        attribute i_debit:
            pos(155,95)
            "debit"
            
        attribute i_flower:
            pos(155,95)
            "flower"

        attribute i_ring:
            pos(155,95)
            "ring"

        attribute i_greenshard2:
            pos(155,95)
            "greenshard2"

        attribute i_greenshard3:
            pos(155,95)
            "greenshard3"

        attribute i_blueshard:
            pos(155,95)
            "blueshard"

        attribute i_shadow:
            pos(155,95)
            "shadow"

        attribute i_notes:
            pos(155,95)
            "notes"

        ### illustrations
        attribute i_dump:
            pos(10,20)
            "images/sprites/items/dump zoom.png"

        attribute i_shovpile:
            pos(10,20)
            "images/sprites/items/shovel zoom.png"

        attribute i_matt:
            pos(10,20)
            "images/sprites/items/matt zoom.png"

        attribute i_tv:
            pos(10,20)
            "images/sprites/items/tv zoom.png"

        attribute i_hand:
            pos(10,20)
            "images/sprites/items/hand zoom.png"

        attribute i_garbage:
            pos(10,20)
            "images/sprites/items/garbage zoom.png"

        attribute i_lump1:
            pos(10,20)
            "images/sprites/items/lump zoom1.png"

        attribute i_lump2:
            pos(10,20)
            "images/sprites/items/lump zoom2.png"

        attribute i_lump3:
            pos(10,20)
            "images/sprites/items/lump zoom3.png"

        attribute i_eye:
            pos(10,20)
            "images/sprites/items/eye zoom.png"

        attribute i_blanket:
            pos(10,20)
            "images/sprites/items/blanket zoom.png"

        attribute i_blanket2:
            pos(10,20)
            "images/sprites/items/blanket2 zoom.png"

        ### memoryshards connected
        attribute i_redmem:
            pos(155,95)
            "images/sprites/items/red memoryshard.png"

        attribute i_greenmem:
            pos(155,95)
            "images/sprites/items/green memoryshard.png"

        ## shaking vers
        attribute i_redmemS:
            pos(155,95)
            "redmemSh"
        
        attribute i_redmemSh:
            pos(135,75)
            "images/sprites/items/red memoryshard shatter.png"

        attribute i_greenmemS:
            pos(155,95)
            "greenmemSh"
        
        attribute i_greenmemSh:
            pos(145,85)
            "images/sprites/items/green memoryshard shatter.png"

### item failsafes for when they dont have things chosen
default flow_ran = renpy.random.choice(["red", "black", "yellow", "white"])
default dvd_ran = renpy.random.choice(["cooking shows", "music videos", "anime", "romance shows"])
default sweets_ran = renpy.random.choice(["baked goods", "candy"])
default salty_ran = renpy.random.choice(["fries", "pretzels"])
default bitter_ran = renpy.random.choice(["chocolate", "coffee"])
default food_ran = renpy.random.choice(["baked goods", "candy", "fries", "pretzels", "chocolate", "coffee"])

image shadow = "images/sprites/items/shadow.png"
image shadowH = "images/sprites/items/shadow h.png"
image pipis = "images/sprites/items/pipis.png"
image pipisH = "images/sprites/items/pipis h.png"
image notes = "images/sprites/items/notes.png"
image notesH = "images/sprites/items/notes h.png"

image endingguide = "images/sprites/items/endings guide.png"

image nes = "images/sprites/items/nes.png"
image nesH = "images/sprites/items/nes h.png"
image cartridge1 = "images/sprites/items/cartridge1.png"
image cartridge1H = "images/sprites/items/cartridge1 h.png"
image cartridge2 = "images/sprites/items/cartridge2.png"
image cartridge2H = "images/sprites/items/cartridge2 h.png"

image figlove = "images/sprites/items/figure love.png"
image figloveH = "images/sprites/items/figure love h.png"
image fighate = "images/sprites/items/figure hate.png"
image fighateH = "images/sprites/items/figure hate h.png"
image flower = "images/sprites/items/flower [flow_ran].png"
image flowerH = "images/sprites/items/flower [flow_ran] h.png"
image dvd = "images/sprites/items/dvd [dvd_ran].png"
image dvdH = "images/sprites/items/dvd [dvd_ran] h.png"

image baked goods = "images/sprites/items/baked goods.png"
image baked goodsH = "images/sprites/items/baked goods h.png"
image candy = "images/sprites/items/candy.png"
image candyH = "images/sprites/items/candy h.png"
image fries = "images/sprites/items/fries.png"
image friesH = "images/sprites/items/fries h.png"
image pretzels = "images/sprites/items/pretzels.png"
image pretzelsH = "images/sprites/items/pretzels h.png"
image chocolate = "images/sprites/items/chocolate.png"
image chocolateH = "images/sprites/items/chocolate h.png"
image coffee = "images/sprites/items/coffee.png"
image coffeeH = "images/sprites/items/coffee h.png"

image loveletter = "images/sprites/items/loveletter.png"
image loveletterH = "images/sprites/items/loveletter h.png"
image shovel = "images/sprites/items/shovel.png"
image shovelH = "images/sprites/items/shovel h.png"
image shovel2 = "images/sprites/items/shovel2.png"
image shovel2H = "images/sprites/items/shovel2 h.png"
image ring = "images/sprites/items/ring.png"
image ringH = "images/sprites/items/ring h.png"
image freecard = "images/sprites/items/freecard.png"
image freecardH = "images/sprites/items/freecard h.png"
image debit = "images/sprites/items/debit.png"
image debitH = "images/sprites/items/debit h.png"

### memoryshards
image redshard1 = "images/sprites/items/red shard 1.png"
image redshard1H = "images/sprites/items/red shard 1 h.png"
image redshard2 = "images/sprites/items/red shard 2.png"
image redshard2H = "images/sprites/items/red shard 2 h.png"
image redshard3 = "images/sprites/items/red shard 3.png"
image redshard3H = "images/sprites/items/red shard 3 h.png"

image greenshard1 = "images/sprites/items/green shard 1.png"
image greenshard1H = "images/sprites/items/green shard 1 h.png"
image greenshard2 = "images/sprites/items/green shard 2.png"
image greenshard2H = "images/sprites/items/green shard 2 h.png"
image greenshard3 = "images/sprites/items/green shard 3.png"
image greenshard3H = "images/sprites/items/green shard 3 h.png"

image blueshard = "images/sprites/items/blue shard.png"
image blueshardH = "images/sprites/items/blue shard h.png"

image redmemSh:
    "images/sprites/items/red memoryshard.png"
    xoffset 1
    pause 0.05
    yoffset 1
    pause 0.05
    xoffset -1
    pause 0.05
    yoffset -1
    pause 0.05
    xoffset 0
    pause 0.05
    yoffset 0
    pause 0.05
    repeat

image greenmemSh:
    "images/sprites/items/green memoryshard.png"
    xoffset 1
    pause 0.05
    yoffset 1
    pause 0.05
    xoffset -1
    pause 0.05
    yoffset -1
    pause 0.05
    xoffset 0
    pause 0.05
    yoffset 0
    pause 0.05
    repeat