############################################################################################################
################## MIKE AND SPAMTON
label secret_ending_spamtat:
    $ rightclick_icon = False

    ## AUTOSAVE
    $ renpy.save("mainfile")

    scene junkspam with Dissolve(1.0)
    pause 1.0
    show mike standing pout at mikepos_inright with easeinright   
    mike_no "So...{w=0.5} who did you say you found,{w=0.2} again?"
    show mike standing nervous
    mike_no "Someone who can help us find Tenna,{w=0.2} right,{w=0.2} but,{w=0.2} what do they even look like...?{p=0.5}{noalt}*{/noalt} Who am I looking for?"
    show spamton standing up smile flipped at spampos_inleft with easeinleft
    play music heyevery
    $ multichar = True
    show spamton standing tilt laugh flipped at jump
    spamton "[[It's your favorite,]{w=0.2} SPAMTON G. SPAMTON!"
    stop music
    if persistent.glitches:
        show mike standing angry at jump
    else:
        show mike standing angry at shock
    mike_no "GAH!"
    show mike arms freakout at jump
    mike_no "Wait,{w=0.2} wait,{w=0.2} hey,{w=0.2} wait,{w=0.2} you're that--{nw=0.2}"
    play music catswing
    show spamton crazy angry flipped at jump
    spamton "HEY WAIT!!{p=0.5}{noalt}*{/noalt} YOU'RE THAT [[freaky Fridays] THAT KEPT ASKING ME ABOUT MIKE!!"
    show mike arms avert at jump
    mike_no "H-{w=0.1} how'd YOU end up HERE??"
    show mike tie nervous flipped at wiggle
    mike_no "Psst.{w=0.2} Hahahaha,{w=0.2} uh,{w=0.2} hey,{w=0.2} {color=[c_passion]}you{/color},{w=0.2} did you just,{w=0.2} somehow know??"
    show spamton standing up glare flipped at jump
    show mike standing nervous
    mike_no "This guy made me real uncomfortable when I met him before though, so,{w=0.2} maybe we could just not--{nw=0.5}"
    show mike standing indifferent at jump
    show spamton slouch down panic flipped
    spamton "WHAT ARE YOU [[hush hush]ING FOR?!"
    show spamton crazy frantic at xwiggle
    spamton "IF YOU'RE HERE TRYING TO GET MIKE'S [[Personal Information] [[Round 2] I'M NOT GIVING {noalt}IT{/noalt}{alt}it{/alt} TO YOU!!"
    show mike standing conflicted at jump
    mike_no "No, no, no,{w=0.2} I wasn't even thinking about that at all right now!!"
    show mike standing angry at jump
    mike_no "I've got other WAY MORE pressing matters right now, and they really,{w=0.2} REALLY don't involve you!!"
    show mike standing conflicted
    mike_no "This,{w=0.2} uh..."
    mike_no "The Lightner just wanted to introduce us because,{w=0.2} apparently you can help me??"
    show spamton standing up stare flipped at jump
    spamton "[[The Lightner] ?!{p=0.2}{noalt}*{/noalt} YOU DON'T EVEN KNOW [[persistent.mc] BY NAME?!"
    show mike standing indifferent
    mike_no "Uh.{p=0.5}{noalt}*{/noalt} \"Persistent dot MC\" isn't a name, either???"
    show spamton standing tilt laugh flipped at jump
    spamton "[persistent.mc!u]!!{p=0.2}{noalt}*{/noalt} AT LEAST SHOW [[lucky dice] SOME [[Common Deecency]!!!"
    show mike standing awkward at droop
    mike_no "\"Lucky\"...{w=0.2} What?"
    show spamton standing up glare flipped
    show mike tie nervous at jump
    mike_no "No, NO,{w=0.2} nevermind, NEVERMIND!{p=0.2}{noalt}*{/noalt} I really don't care about anybody's name right now!!"
    show mike tie avert
    mike_no "Okay,{w=0.2} okay.{w=0.2} Actually.{p=0.2}{noalt}*{/noalt} Y'know what?{w=0.2} I'm just gonna cut to the chase."
    show mike standing angry
    mike_no "I know you hated this topic the last time I brought him up, but--"
    show mike arms freakout at jump
    mike_no "TENNA!{p=0.2}{noalt}*{/noalt} You knew him,{w=0.2} right?!"
    mike_no "He's my...{nw=0.5}"
    show mike arms avert at droop
    extend "{p=0}{noalt}*{/noalt} My boss."
    show mike arms freakout at jump
    mike_no "And he's MISSING!{w=0.2} Gone without a trace!!"
    show mike tie avert at rise
    mike_no "He's supposed to be here?{w=0.2} Or, uh,{w=0.2} \"[persistent.mc]\" met him at some point.{p=0.2}{noalt}*{/noalt} But we can't find him anymore."
    show mike standing angry
    mike_no "Do you have ANY info on that???{p=0.2}{noalt}*{/noalt} ANYTHING at all??"
    show mike arms freakout
    mike_no "Because I could really use it.{p=0.2}{noalt}*{/noalt} Really, really.{p=0.2}{noalt}*{/noalt} It's really important."
    show spamton standing up glaree flipped at jump
    spamton "I'M NOT HANDING OUT [[fuzz face] [[Personal Information] EITHER."
    show mike standing pout
    show spamton crazy laugh at xwiggle
    spamton "I'M NOT [[converse with the dead] ABOUT HIM AT ALL,{w=0.2} EAHEHAAH."
    show spamton standing up smile flipped at jump
    spamton "[[Face the Noise].{p=0.5}{noalt}*{/noalt} [[Trash Heap] {noalt}IS{/noalt}{alt}is{/alt} ALREADY [[swimming with the fishes], [[dice boy]."
    if persistent.glitches:
        show mike arms freakout at jump
    else:
        show mike arms freakout at shock
    mike_no "HE'S NOT DEAD!!"
    show mike standing awkward at jump
    mike_no "I-{w=0.1} I mean..."
    show mike tie nervous at wiggle
    mike_no "I know it,{w=0.2} SEEMS like he's dead.{p=0.5}{noalt}*{/noalt} But there's a slim chance he's still alive out here somewhere."
    show mike standing sigh at droop
    mike_no "I didn't see what happened but...{p=0.2}{noalt}*{/noalt} If he's HERE...{w=0.5} and if THAT'S true,{w=0.2} then..."
    show spamton standing up frowne flipped
    spamton "WAIT, IF WHAT'S TRUE."
    show mike standing pout at jump
    mike_no "Huh?"
    show mike tie nervous at wiggle
    mike_no "Oh...{w=0.2} just some weird \"prophecy\" thing someone told me,{w=0.2} hahaha,{w=0.2} it's probably nothing--{nw=0.5}"
    if persistent.glitches:
        show spamton panic up scream at jump
        spamton "[[YOU WHAT?]??"
        show spamton standing up stare flipped
    else:
        show spamton panic up scream at shock
        spamton "[[YOU WHAT?]??"
        show spamton standing up stare flipped at shakingcg
    spamton "WHERE {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}.{p=0.2}{noalt}*{/noalt} WHERE {noalt}IS{/noalt}{alt}is{/alt} {noalt}IT{/noalt}{alt}it{/alt}.{p=0.2}{noalt}*{/noalt} DO YOU STILL HAVE IT??"
    show mike standing conflicted at jump
    mike_no "Have WHAT?{w=0.2} What are you talking about?"
    show spamton at leanrightLQ_mike
    show mike standing angry at leanrightLQ
    mike_no "Hey,{w=0.2} hey,{w=0.2} woah, woah, woah,{w=0.2} what are you doing??"
    if persistent.glitches:
        show spamton slouch down panic flipped at jump
    else:
        show spamton slouch down panic flipped at shock
    spamton "THE [[ShadowCrystal] YOU MORON!!!"
    show spamton standing up stare flipped at xwiggle
    spamton "WHERE {noalt}IS{/noalt}{alt}is{/alt} [[[[ He ]] ?!{w=0.2} HUH?{p=0.2}{noalt}*{/noalt} HUH?{p=0.2}{noalt}*{/noalt} HUH?"
    show mike arms avert at jump
    mike_no "WHAT are you TALKING about??{p=0.2}{noalt}*{/noalt} Wh-{w=0.1} where is{nw}"
    if persistent.glitches:
        show mike at jump
    else:
        show mike at shock
    extend " WHO?!"
    show mike standing conflicted at jump
    mike_no "Hold on,{w=0.2} hold it,{w=0.2} wait,{w=0.2} a crystal?{p=0.5}{noalt}*{/noalt} YOU have one of those, too??"
    show mike standing nervous
    mike_no "Does that mean you know about all the prophecy crap and stuff??"
    show spamton standing up smile flipped at yreset
    spamton "[[It's all coming together].{p=0.2}{noalt}*{/noalt} ALL OF THAT [[[[ Fate ]] {noalt}IS{/noalt}{alt}is{/alt} HAPPENING [[as we speak.]"
    show spamton standing tilt laugh flipped at jump
    spamton "I'M SURPRISED NEITHER OF {noalt}US{/noalt}{alt}us{/alt} HAVE\n[[disappear off of the face of the Earth] ALREADY!"
    show mike tie avert at leanrightL
    mike_no "But,{w=0.2} I..."
    show mike at yreset
    pause 1.0
    stop music fadeout 2.0
    show mike standing indifferent
    pause 2.0
    show mike standing nervous
    mike_no "Wait,{w=0.5} is that what they meant by a \"time limit\"...?"
    show mike at droop
    mike_no "Does it{w=0.5} even matter if I find Tenna in time...?"
    show spamton standing up glare flipped
    spamton "WHAT \"THEY\" ARE YOU TALKING ABOUT.{p=0.5}{noalt}*{/noalt} [[[[ He ]] ?"
    pause 2.0
    show mike standing sigh
    mike_no "{cps=35}...{w=0.5} I dunno who you're talking about.{p=0.5}{noalt}*{/noalt} Sorry.{/cps}"
    pause 1.0
    show spamton standing tilt laugh flipped at xwiggle
    spamton "YIKES!!{p=0.5}{noalt}*{/noalt} DON'T GET ALL [[down in the dumps] JUST BECAUSE WE'RE [[down in the dumps] !!"
    show spamton standing up frown flipped at jump
    spamton "HOW LONG.{p=0.5}{noalt}*{/noalt} HOW LONG HAVE YOU HAD [[ShadowCrystal]"
    pause 1.0
    mike_no "{cps=35}...{nw=0.5}{/cps}"
    show mike standing pout at rise
    extend "{cps=35} I dunno,{w=0.2} a couple days?{p=0.2}{noalt}*{/noalt} I lost track of time at some point since comin' out here...{/cps}"
    show spamton standing up glare flipped
    spamton "YEAH THAT {noalt}[[track]S{/noalt}{alt}tracks{/alt}."
    show spamton crazy smirk flipped at jump
    spamton "[[[[ {color=[c_kindness]}Freedom{/color} ]] ISNT WHAT {noalt}IT'S{/noalt}{alt}it's{/alt} [[Blackboard {noalt}Chalk]ED{/noalt}{alt}chalked{/alt} UP TO BE,{w=0.2} HUH??"
    play music lostgirlS
    show mike standing conflicted
    mike_no "\"Freedom\"...?"
    show mike arms avert at jump
    mike_no "What,{w=0.2} choosing to be out HERE?{w=0.2} Of all places??"
    show mike standing sigh
    mike_no "This is practically living hell.{p=0.5}{noalt}*{/noalt} And \"living\" is a strong word."
    show spamton standing up smirk flipped at jump
    spamton "BUT YOU [[choosing] {noalt}IT{/noalt}{alt}it{/alt},{w=0.2} [[did you not?]!"
    show spamton standing up frowne flipped
    spamton "WHAT'D [[[[ He ]] OFFER YOU.{w=0.2} [[What's your deal?]"
    show mike standing angry at jump
    mike_no "Where are all these questions coming from?!{p=0.2}{noalt}*{/noalt} I don't owe you any answers!!"
    show spamton standing tilt laugh flipped at jump
    spamton "YOURE LESS OBNOXIOUS [[{noalt}read:{/noalt}{alt}red:{/alt} terrifying] THAN [[Clown Around Town], AT LEAST!!"
    show mike standing indifferent
    mike_no "Who??{w=0.2} What??{w=0.2} How??"
    show mike arms freakout at jump
    mike_no "What does this have to do with literally anything you just said AT all?!"
    show spamton standing up glare flipped at jump
    spamton "JUST ANSWER THE [[Beaver Dam] QUESTION ALREADY."
    show mike standing angry at jump
    mike_no "Geez,{w=0.2} FINE,{w=0.2} fine,{w=0.2} FINE!!"
    show mike standing nervous
    mike_no "Ya know,{w=0.2} you're a lot different than you were ten years ago..."
    show spamton standing up glaree flipped
    spamton "[[Tell me about it.]"
    pause 1.0
    show mike standing pout
    mike_no "The deal...{w=0.5} That random stranger I told you about--{w=0.2} they brought me here and gave me that crystal."
    mike_no "I told them I wanted to find Tenna--{nw=0.2}"
    show spamton standing up frown flipped at jump
    spamton "WHAT DID YOU SAY [[exactly.]]?"
    show mike standing conflicted
    mike_no "..."
    pause 2.0
    show mike standing sigh
    mike_no "...{w=0.2} I said I wanted to find Tenna{nw=0.5}"
    show mike at droop
    extend "{cps=35} \"no matter what it takes.\"{/cps}"
    show spamton standing tilt laugh flipped at jump
    spamton "EAHEHAHEHAH!!{w=0.2} [[There it is!]{p=0.5}{noalt}*{/noalt} JUST HOW WE ALL ARE."
    show spamton standing up stare flipped
    spamton "{cps=20}[[Desperate]{/cps}"
    show mike standing angry at rise
    mike_no "Yeah?{p=0.2}{noalt}*{/noalt} What did YOU say to them,{w=0.2} then?"
    show spamton standing up frown flipped
    spamton "[[Classified Information]."
    show mike standing indifferent at jump
    mike_no "What?{nw=0.5}"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    extend " Oh, come on!{p=0.2}{noalt}*{/noalt} I told you my thing!!"
    show mike standing nervous at yreset 
    mike_no "It didn't ALSO have to do with Tenna,{w=0.2} did it...?"
    show spamton crazy laugh at jump
    spamton "[[Hector] NO.{w=0.2} I DIDN'T EVEN KNOW [[Cathode] YET!!"
    show mike standing conflicted
    mike_no "Then,{w=0.2} what was it...?"
    show spamton standing up glaree flipped at jump
    spamton "WHY DO YOU SAY THAT LIKE [[Boob Tube] {noalt}IS{/noalt}{alt}is{/alt} [[The only thing that matters is ] ??"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "H-{w=0.1} hey,{w=0.2} HEY,{w=0.2} hey,{w=0.2} you're making a LOTTA assumptions there!!"
    show mike standing sigh at droop
    mike_no "Whatever..."
    show mike standing nervous at rise
    mike_no "Look,{w=0.2} as I was saying,{w=0.2} that person said they'd help me,{w=0.2} but now I'm on a time crunch."
    mike_no "They gave me a week,{w=0.2} but they never specified what'd happen if time ran out."
    show mike standing conflicted
    mike_no "So I've just been tryin' to find Tenna as fast as possible so we can get home as fast as possible."
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "That answer your question,{w=0.2} you {noalt}yatzy{/noalt}{alt}yahtzee{/alt}?!"
    show spamton standing up frown flipped
    spamton "I'VE GOT [[You've got 1 new message] MORE"
    show mike standing indifferent at yreset
    mike_no "..."
    show mike standing angry
    mike_no "Yeah?{p=0.5}{noalt}*{/noalt} Well,{w=0.2} I'll answer that only if you tell me what \"desperate\" thing you did first."
    show spamton standing tilt laugh flipped at xwiggle
    spamton "EAHAHA!{p=0.2}{noalt}*{/noalt} TRYING TO STRIKE A [[big deals] WITH A [[professional salesman]?!"
    if persistent.glitches:
        show spamton standing up frowne flipped
    else:
        show spamton standing up frowne flipped at shakingcg
    spamton "YOU'RE {noalt}[[$&!X]ING{/noalt}{alt}beeping{/alt} YOURSELF!!"
    show mike standing wink at jump
    mike_no "I'll just leave,{w=0.2} then.{p=0.5}{noalt}*{/noalt} Not like you're gonna help me find Tenna,{w=0.2} anyway,{w=0.2} so what's the point in sticking around?"
    show mike arms freakout at jump
    mike_no "It's not as if I actually care about anything to do with some jerk like you to begin with,{w=0.2} as it is!!"
    if persistent.glitches:
        show spamton crazy frantic
    else:
        show spamton crazy frantic at shakingcg
    spamton "WHAT'S YOUR [[Have a Problem]?!"
    show spamton standing up frown flipped at jump
    spamton "FINE,{w=0.2} TWIST MY ARM [[off] IF YOU'RE GONNA [[be that way]!!"
    show mike standing pout
    show spamton slouch down frown flipped
    pause 2.0
    show spamton at droop
    spamton "I TOLD [[[[ Him ]] I WANTED TO BE A [[{color=[c_power]}BIG SHOT{/color}],{p=0.5}[[no matter the cost]."
    if persistent.glitches:
        show spamton standing up stare flipped
    else:
        show spamton standing up stare flipped at shakingcg
    spamton "I WAS TIRED OF BEING [[one of the little guys] !!{p=0.5}{noalt}*{/noalt} {noalt}IT'S{/noalt}{alt}it's{/alt} [[No Fun Allowed] BEING STUCK IN THE [[underdog]HOUSE!!"
    show spamton crazy angry at xwiggle
    spamton "BUT [[Never take candy from a stranger in an] PHONE CALL!{p=0.2}{noalt}*{/noalt} THAT'S A [[[[ free ]] ONE WAY TICKET TO {space=80}!"
    show mike standing conflicted at jump
    mike_no "You got a phone call??"
    show mike standing nervous
    mike_no "The person just showed up at the new studio for me,{w=0.2} while we were even still building it..."
    show spamton standing up frowne flipped at yreset
    spamton "WHAT."
    if persistent.glitches:
        show spamton standing up stare flipped
    else:
        show spamton standing up stare flipped at shakingcg
    spamton "[[[[ redacted ]]{w=0.5} IN THE [[flesh and bones]???"
    show mike standing angry at jump
    mike_no "What,{w=0.2} YOU never saw them??"
    show spamton standing tilt laugh flipped at jump
    spamton "NO!!!"
    if persistent.glitches:
        show spamton slouch down panic flipped
    else:
        show spamton slouch down panic flipped at shakingcg
    spamton "I DON'T WANT MY EYES TO [[ash to ash, dust to dust] ??"
    show mike standing conflicted at rise
    mike_no "What??{w=0.5} What does THAT mean??"
    show spamton standing up smile flipped at yreset
    spamton "[[lucky dice].{p=0.5}{noalt}*{/noalt} YOUR GUY [[sucks]?"
    show spamton crazy laugh flipped at xwiggle
    spamton "DID YOU MEET THAT {noalt}[[phone]Y{/noalt}{alt}phoney{/alt} THAT GAVE ME A \n[[third-rate] [[Green] DEAL??"
    show mike arms freakout at jump
    mike_no "I don't know!{p=0.2}{noalt}*{/noalt} I don't know who this person is at all,{w=0.2} it's not like we talked more than the ONE time!"
    show mike arms avert
    mike_no "Why do you talk about this crap like I'm supposed to know what you're talking about?!"
    show spamton standing up smile flipped at jump
    spamton "WOW!{p=0.5}{noalt}*{/noalt} YOU'RE COMPLETELY [[useless]"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike_no "HEY,{w=0.2} HEY,{w=0.2} what the hell?!{p=0.5}{noalt}*{/noalt} Where's this coming from!?"
    show spamton standing tilt laugh flipped at jump
    spamton "HEY !{w=0.2} THAT OTHER [[inquiry].{p=0.5}{noalt}*{/noalt} [[You owe:] AN ANSWER!!"
    show mike standing angry at rise
    mike_no "You're just gonna--?!{nw=0.2}"
    show mike standing sigh at droop
    extend " Ugh,{w=0.5} I guess I did say that."
    show mike tie nervous at wiggle
    mike_no "Okay,{w=0.2} okay.{w=0.2} OKAY!{w=0.2} Fine.{p=0.5}{noalt}*{/noalt} What's your stupid question,{w=0.2} huh?"
    show spamton standing up frowne flipped at jump
    spamton "WHERE {noalt}IS{/noalt}{alt}is{/alt} YOUR [[home]?{p=0.5}{noalt}*{/noalt} WHERE {noalt}IS{/noalt}{alt}is{/alt} YOUR [[new studio]??"
    spamton "DID [[TV World] DIE WITH [[The Lord of the Screens] ?"
    show mike tie avert at yreset
    pause 2.0
    show mike standing nervous
    mike_no "..."
    show mike at droop
    mike_no "{cps=35}Sort of...{/cps}"
    show mike standing sigh
    mike_no "We mostly just, moved,{w=0.2} really.{p=0.5}{noalt}*{/noalt} Got invited to a different Dark World and a couple Lightners carried us over there."
    mike_no "We were expecting Tenna to be there at some point,{w=0.2} but...{w=0.5} he never showed."
    show mike standing pout
    mike_no "I wanted to bring him back,{w=0.2} so he could see our new home."
    show spamton standing up glaree flipped
    spamton "AND [[definitely nothing else]"
    show mike standing angry at jump
    mike_no "WHAT??{w=0.5} WHAT ARE YOU EVEN INSINUATING AT THIS POINT?!"
    show spamton standing tilt laugh flipped at jump
    spamton "TRUST ME,{w=0.2} [[snake eyes]{p=0.5}{noalt}*{/noalt} IVE BEEN IN YOUR PLACE ALREADY.{p=0.5}{noalt}*{/noalt} YOU'RE [[not] SUBTLE"
    show mike standing indifferent
    mike_no "Huh?"
    if persistent.glitches:
        show mike arms avert
        mike_no "Wait,{w=0.2} wait,{w=0.2} HUH?{p=0.5}{noalt}*{/noalt} What does--"
        show spamton slouch down panic flipped
        spamton "DO YOU HAVE EXACTLY [[six] BRAINCELLS???{w=0.2} ONE FOR EACH [[ugly] [[face]???"
        show mike standing angry at jump
    else:
        show mike arms avert at shakingcg
        mike_no "Wait,{w=0.2} wait,{w=0.2} HUH?{p=0.5}{noalt}*{/noalt} What does--"
        show spamton slouch down panic flipped at shakingcg
        spamton "DO YOU HAVE EXACTLY [[six] BRAINCELLS???{p=0.2}{noalt}*{/noalt} ONE FOR EACH [[ugly] [[face]???"
        show mike standing angry at shock
    mike_no "HEY!!{w=0.2} LOOK,{w=0.2} look,{w=0.5} I'm not gonna be the guy to make assumptions about some random stranger's dating life,{w=0.2} {noalt}y'hear{/noalt}{alt}ya hear{/alt} me?!"
    show spamton crazy frantic at xwiggle
    spamton "YOU [[hit the jackpot] AND YOU STILL [[turn it down]??"
    show mike standing indifferent at droop
    mike_no "Oh,{w=0.2} no.{p=0.5}{noalt}*{/noalt} You didn't ACTUALLY--"
    show spamton standing up glare flipped at jump
    spamton "YEAH I WISH I HADN'T."
    spamton "[[Trash {noalt}Heap]'S{/noalt}{alt}heap's{/alt} PERSONALITY {noalt}IS{/noalt}{alt}is{/alt} NOT AS PRETTY AS HIS [[ass]"
    show mike tie awkward at jump
    mike_no "His--?!{nw=0.5}"
    show mike standing awkward at droop
    extend " Whatever,{w=0.2} whatever,{w=0.2} whatever,{w=0.2} I don't{noalt}--{/noalt}"
    pause 1.0
    show mike tie nervous at wiggle
    mike_no "S-{w=0.1} so what if I just--{w=0.2} wanna make sure he's happy all the time..."
    mike_no "And wanna be the one that's making him happy all the time..."
    mike_no "And wanna be there for him whenever and wherever he needs,{w=0.2} for whatever he needs,{w=0.2} no matter what it is..."
    show spamton standing up glaree flipped
    mike_no "And don't really care about how much of a toll it takes on me..."
    show mike tie awkward
    mike_no "And really like it when he asks for an antenna massage...{w=0.2} so I can,{w=0.5} touch--{nw=0.1}"
    show spamton slouch down panic at jump
    spamton "I'M GOING TO [[throw up] IF YOU SAY ONE MORE WORD."
    if persistent.glitches:
        show mike standing indifferent at jump
    else:
        show mike standing indifferent at shock
    mike_no "GAH!"
    show mike standing angry at jump
    mike_no "Sh-{w=0.1} shut up!!{p=0.2}{noalt}*{/noalt} SHUT UP,{w=0.2} SHUT UP!!"
    show mike arms freakout at jump
    mike_no "MY POINT {noalt}IS{/noalt}{alt}is{/alt},{w=0.2} I don't{noalt}--{/noalt}{w=0.2} LOVE him!!{p=0.5}{noalt}*{/noalt} It's not the same,{w=0.2} it's different!!"
    show spamton standing up glaree flipped at jump
    spamton "SINCE WHEN {noalt}IS{/noalt}{alt}is{/alt} [[unyielding devotion] ANYTHING ELSE"
    if persistent.glitches:
        show mike arms avert at jump
    else:
        show mike arms avert at shock
    mike_no "SINCE I SAID SO!"
    show mike standing sigh at droop
    mike_no "I don't know how to explain it,{w=0.2} but it's not the same thing."
    show mike standing conflicted
    mike_no "I think I'd freak out if he started acting like he cares about me the same way,{w=0.2} and NOT in a good way,{w=0.2} not at all."
    show spamton standing up stare flipped
    spamton "...{w=0.5} SO YOU JUST WANNA BE HIS [[servant]???"
    show mike standing angry at jump
    mike_no "NO!"
    show mike standing conflicted
    mike_no "Ugh,{w=0.2} forget it,{w=0.2} FORGET {noalt}IT{/noalt}{alt}it{/alt},{w=0.2} forget I said any of that,{w=0.2} this isn't a constructive conversation at all!!"
    show mike standing sigh at droop
    mike_no "You, uh--{w=0.5} [persistent.mc].{p=0.5}{noalt}*{/noalt} Let's get outta here."
    show mike standing sigh
    mike_no "This was a dead end.{w=0.2} A total waste of my time."
    $ multichar = False
    "You mention you have a different idea,{w=0.2} but it won't really help finding Tenna."
    $ multichar = True
    show mike standing sigh at droop
    mike_no "Then,{w=0.5} what's it matter...?"
    show spamton standing up frown flipped
    pause 2.0
    show spamton slouch down frown flipped at droop
    spamton "[[Do you ever think about]{w=0.5} MOVING ON?"
    show mike standing conflicted
    mike_no "...{w=0.5} What do you care?"
    show spamton slouch down panic flipped
    spamton "I [[think about] {noalt}IT{/noalt}{alt}it{/alt} [[around the clock]."
    show spamton crazy laugh at jump
    play sfx spamlaugh
    $ _history = False
    spamton_shh "[[[[ Unintelligible Laughter ]]{nw=0.5}"
    $ _history = True
    show spamton slouch down frown flipped at droop
    spamton "[[[[ Unintelligible Laughter ]]{fast}\n{noalt}*{/noalt} AND I FAIL.{w=0.2} EVERY SINGLE TIME."
    pause 1.0
    show mike standing pout at rise
    mike_no "...{w=0.5} I'm not following."
    show spamton standing up stare flipped at jump
    spamton "[[Cathode] {noalt}IS{/noalt}{alt}is{/alt} [[Unforgettable ] AND {noalt}IT'S{/noalt}{alt}it's{/alt} ABSOLUTELY [[disgusting]!!!"
    show spamton standing up frowne flipped
    spamton "BUT HE'S [[gone]."
    show spamton standing down frown flipped
    spamton "HE'S BEEN GONE."
    show spamton standing down frown at jump
    spamton "YOU R [[lyeing] TO YOURSELF."
    show spamton slouch down static
    spamton "{noalt}HE' s{/noalt}{alt}he's{/alt} NOT COMING BACK [[for you],"
    show spamton at droop
    spamton "...,{w=0.2} SO JUST [[stop.]"
    pause 2.0
    show mike standing conflicted at leanright
    mike_no "Y'know,{w=0.5} I get the feeling you're just kinda self-projecting here,{w=0.5} and I really don't appreciate it."
    pause 2.0
    show spamton standing down frown at rise
    spamton "[[Riddle me this:]{p=0.5}{noalt}*{/noalt} DO YOU WANNA GO HOME [[alive]{w=0.5} OR STAY HERE UNTIL YOU [[die alone]?"
    show mike standing nervous
    mike_no "..."
    pause 1.0
    show mike standing sigh at droop
    mike_no "I'd rather keep looking for Tenna--{nw=0.2}"
    show spamton standing down static flipped at jump
    spamton "WRONG."
    show mike standing indifferent at jump
    mike_no "What--{nw=0.2}"
    if persistent.glitches:
        show mike arms freakout at jump
    else:
        show mike arms freakout at shock
    extend " HEY,{w=0.2} you asked the question and I answered it!!"
    show mike standing conflicted
    mike_no "Just because YOU'D rather be selfish about it..."
    show spamton standing tilt laugh flipped at jump
    spamton "EHAAHEHAH!!{p=0.5}{noalt}*{/noalt} I WAS [[selfish] WHEN I STUCK WITH [[fuzz face] !!"
    show spamton standing up frowne flipped
    spamton "I GOT [[obsessed with ] AND [[Look at me now] !"
    if persistent.glitches:
        show spamton slouch down panic flipped
    else:
        show spamton slouch down panic flipped at shakingcg
    spamton "YOU WANNA END UP LIKE [[Your Good Friend,] SPAMTON?!"
    show mike standing conflicted at droop
    mike_no "That's not--{w=0.2} the..."
    show mike standing angry at rise
    mike_no "Wait,{w=0.2} no,{w=0.2} you said your deal was to be a \"big shot\" or whatever!"
    show spamton slouch down frown flipped
    spamton "[[[[CRTs]] MADE ME [[You could lose your benefits]{p=0.5}{noalt}*{/noalt} I [[ trussted] HIM AND IT GOT ME [[not quite] DEATH BY [[Pinocchio]."
    show spamton standing down static flipped at yreset
    spamton "MY ADVICE?{w=0.5} [[Get out while you can.]"
    show mike standing conflicted
    mike_no "But I..."
    pause 2.0
    show mike standing sigh at droop
    mike_no "What am I supposed to do,{w=0.2} then...?"
    show spamton slouch down panic flipped
    spamton "DON'T TELL ME YOU [[put all your eggs in one ]"
    show mike standing nervous
    pause 2.0
    show mike standing sigh
    mike_no "... so,{w=0.2} uh.{p=0.5}{noalt}*{/noalt} About{w=0.5} the Mike thing{w=0.2}.{w=0.2}.{w=0.2}."
    show mike tie nervous at jump
    mike_no "'Cause I couldn't get any info from you,{w=0.2} or anyone else for that matter,{w=0.2} and haven't been able to find him for...{w=0.5} ten-ish years,{w=0.2} now..."
    show mike tie avert at wiggle
    mike_no "I sorta...{w=0.2} pretended to be him instead.{p=0.5}{noalt}*{/noalt} Took Mike's place,{w=0.5} so Tenna wouldn't be so upset all the time."
    mike_no "I haven't been able to do much of anything else other than pretend to be Mike or try to look for the...{w=1.0}{cps=35} the \"real\" Mike.{/cps}"
    show mike standing sigh at jump
    mike_no "It got to be so much I had to hire two other guys to ALSO pretend to be Mike with me!"
    show mike standing conflicted
    mike_no "We take shifts and stuff...{p=0.5}{noalt}*{/noalt} Sometimes we work at the same time,{w=0.2} in secret,{w=0.2} if Tenna asks for too much at once."
    show mike standing nervous
    mike_no "So,{w=0.2} I,{w=0.2} y'know,{w=0.5} without Tenna, I{w=0.2}.{w=0.2}.{w=0.2}."
    pause 1.0
    show mike standing sigh at droop
    mike_no "{cps=35}I don't know what else to do.{/cps}"
    show spamton standing up frown flipped
    pause 2.0
    show spamton standing up frowne flipped at jump
    spamton "YOU'RE{p=0.5}{noalt}*{/noalt} YOU'RE KIDDING,{w=0.5} RIGHT"
    show mike tie avert at jump
    mike_no "Hahaha.{w=0.5} I wish."
    spamton "WOW."
    show spamton crazy laugh at xwiggle
    spamton "SOMEHOW YOU {noalt}[[#X$@]ED{/noalt}{alt}beeped{/alt} UP WORSE THAN ME!!"
    show spamton standing up stare flipped at jump
    spamton "THAT'S IMPRESSIVE,{w=0.2} [[lucky dice].{p=0.5}{noalt}*{/noalt} YOU DESERVE A [[gold star] FOR YOUR [[idiocy]"
    show mike standing angry at rise
    mike_no "Oh,{w=0.2} COME ON."
    show spamton standing up smile flipped at jump
    spamton "[[Survey Request]!!{w=0.2} WHEN HAS TENNA EVER SAID \"Thanks\" TO YOU??"
    show mike standing indifferent
    pause 1.0
    show mike standing conflicted at droop
    mike_no "...{w=0.2} It's{w=0.2}.{w=0.2}.{w=0.2}.{w=0.5} been a few years."
    show spamton panic up screame at jump
    spamton "[[years] ????{p=0.5}{noalt}*{/noalt} WITH AN [[s]????{p=0.5}{noalt}*{/noalt} YIKES!!"
    show spamton standing up frown flipped at jump
    spamton "[[Take it from me, kid].{p=0.5}{noalt}*{/noalt} YOU GOTTA KNOW WHEN TO CALL IT [[That's quitter talk]."
    show mike standing angry at jump
    mike_no "I-{w=0.1} I'm not a child??"
    if persistent.glitches:
        show spamton crazy angry
    else:
        show spamton crazy angry at shakingcg
    spamton "ARE YOU INTENTIONALLY [[>Mark all as read]??{p=0.5}{noalt}*{/noalt} THAT'S NOT EVEN [[in the ballpark] OF WHAT I WAS [[Talking with you] ABOUT!!"
    show mike standing pout at droop
    pause 1.0
    show mike standing sigh
    mike_no "But,{w=1.0}{cps=35} how am I even supposed to go home like this?{/cps}"
    show spamton standing up glare flipped at yreset
    show mike arms freakout at wiggle
    mike_no "{cps=35}How can I face the other two completely empty-handed,{w=0.5} after making such a big deal outta everything...?{/cps}"
    show mike standing conflicted at droop
    pause 2.0
    menu:
        "Say something":
            $ multichar = False
            "You tell \"Mike\" you're sure it won't end poorly."
            $ multichar = True
            if persistent.glitches:
                show mike standing angry at jump
            else:
                show mike standing angry at shock
            mike_no "HOW could you possibly be so certain about that?"
            show mike arms freakout at jump
            mike_no "You don't even know the other two!{p=0.5}{noalt}*{/noalt} I don't know,{w=0.2} they might get pissed at me for not explaining anything again!"
            show mike arms avert
            mike_no "Wouldn't YOU be mad if somebody ran off without explaining anything,{w=0.2} disappeared for who knows how long,{w=0.2} then came back without anything?!"
            show spamton slouch down static flipped at droop
            spamton "{w=0.2}.{w=0.2}.{w=0.2}."

        "...":
            show spamton standing tilt laugh flipped at jump
            spamton "[[It's just that easy!]{p=0.2}{noalt}*{/noalt} DO IT ANYWAY."
            show mike standing sigh at jump
            mike_no "Oh,{w=0.2} yeah,{w=0.2} real easy.{p=0.5}{noalt}*{/noalt} Thanks for the help."
            show spamton standing up glare flipped
            spamton "WHO [[Give to your local] A DAM ABOUT THAT."
            show spamton crazy frantic at xwiggle
            spamton "IF THEY [[Abandon you at a bar and grill] THEN THAT'S THEIR [[check for mistakes?]!!"
            show mike standing angry
            mike_no "...{w=0.2} Ah,{w=0.2} yeah,{w=0.2} THAT'S reassuring."
            show mike arms freakout at jump
            mike_no "Sure,{w=0.2} let me just lose the majority of people I interact with over this!"
            show spamton standing up glare flipped at yreset
            spamton "YOU'RE TELLING ME YOU DIDN'T [[anticipaint] ANYTHING [[Bad Ending] WOULD HAPPEN?!"
            show spamton standing tilt laugh at jump
            spamton "ACTUALLY I TAKE BACK ALL MY [[copyrighted] ADVICE,{w=0.2} YOU'RE [[completely hopeless]!!"

    show spamton standing up stare flipped at jump    
    spamton "[persistent.mc!u],{w=0.2} {noalt}IS{/noalt}{alt}is{/alt} THAT [[Get out of] {noalt}H3LL{/noalt}{alt}hell{/alt} [[[[ Free ]] CARD STILL ON THE [[card table]??"
    show spamton standing tilt laugh flipped at jump
    spamton "IF THIS [[joke die] WON'T TAKE IT THEN [[Gimmie, gimmie, gimmie!]"
    show mike standing angry at jump
    mike_no "Wh-{w=0.1} what?!{p=0.5}{noalt}*{/noalt} What,{w=0.2} hey,{w=0.2} hold on,{w=0.2} you can't just LEAVE ME here!!"
    show spamton standing up stare flipped
    spamton "YOU BET [[your ass] I CAN!"
    show spamton crazy smirk at jump
    spamton "YOU'RE MORE WORRIED ABOUT [[Trash Heap] [[Dump] ANYWAY,{w=0.2} SO WHY DO YOU EVEN [[care]?"
    pause 1.0
    show mike standing conflicted at droop
    mike_no "I..."
    show spamton at xwiggle
    spamton "HAVING [[second thoughts?]"
    show mike standing sigh
    mike_no "Don't even..."
    show spamton standing up frown flipped at droop
    spamton "[[Lookie over here],{w=0.2} [[dice boy].{p=0.5}{noalt}*{/noalt} YOU CAN [[[[ freely ]] MAKE YOUR OWN [[Choices] NOW."
    show spamton standing tilt laugh flipped at jump
    spamton "IF YOU WANNA GET YOUR {noalt}[[$#!T] [[*#!X]ED{/noalt}{alt}beep beeped{/alt} AND END UP AS [[Real, High Definition] TRASH,{w=0.2} [[Be our guest!]"
    show spamton standing up stare flipped
    spamton "JUST DON'T EXPECT [[Sending you much love] FROM ME IF YOU [[die boy]."
    if persistent.glitches:
        show mike standing conflicted at jump
    else:
        show mike standing conflicted at shock
    mike_no "I don't WANT to die,{w=0.2} I WANT to find Tenna...!"
    show mike standing sigh
    mike_no "But..."
    pause 2.0
    show mike at droop
    mike_no "{cps=35}{w=0.2}.{w=0.2}.{w=0.2}.{w=0.5} he's gone.{/cps}"
    mike_no "{cps=35}He's really gone,{w=0.5} isn't he?{/cps}"
    show spamton standing tilt laugh flipped at xwiggle
    spamton "[[Now you're getting it.],{w=0.2} EAHEEHAHEH!"
    show spamton slouch down frown flipped at droop
    spamton "YOU'RE NOT THE ONLY [[One morning,] YOU KNOW."
    pause 2.0
    show mike standing conflicted at rise
    mike_no "{cps=35}How are you just...{w=0.5} dealing with it?{p=0.5}{noalt}*{/noalt}{/cps} Like it's nothing to you??"
    show mike arms avert at jump
    mike_no "You don't even look like you're bothered,{w=0.2} dammit!!"
    show spamton standing up glaree flipped
    spamton "[[years of experience]."
    show mike standing conflicted
    mike_no "{cps=35}Ah...{/cps}"
    pause 1.0
    show mike standing sigh at droop
    mike_no "Shit."
    mike_no "Can we just...{w=0.5} leave?"
    show mike standing nervous
    mike_no "I don't wanna be in this stupid dump anymore."
    show mike standing sigh
    mike_no "I'm so sick of...{w=0.5} everything."
    show spamton standing up smile flipped at jump
    spamton "SOUNDS LIKE YOU NEED [[Vacationing in the]"
    show mike standing nervous at rise
    mike_no "That sounds real nice right about now.{p=0.5}{noalt}*{/noalt} Honestly,{w=0.5} I might even straight up NEED a vacation right now."
    show spamton crazy laugh at xwiggle
    spamton "EAHEAHEHA!!{p=0.2}{noalt}*{/noalt} SOMEBODY GET THE [[burning acid] READY!!"
    mike_no "...{nw=0.5}"
    show mike standing indifferent at jump
    extend " wait the what--{nw=0.5}"
    show spamton standing up stare flipped at jump
    spamton "[persistent.mc!u]!{p=0.5}{noalt}*{/noalt} LEAD {noalt}US{/noalt}{alt}us{/alt} TO [[wherever that place is]!!"
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    $ multichar = False
    "You lead Spamton and \"Mike\" to the mattress where you first saw the mystery man,{w=0.2} as instructed."

    # TO UNIVERSAL ENDING
    $ end_spamtat = "done"
    jump ending_universal