############################################################################################################
################## MIKE, TENNA, AND SPAMTON
label secret_ending_triple:
    $ currentend = "triple"

    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ multichar = True
    show junkyard with Dissolve(1.0)
    pause 1.0
    show tenna upright chest neutral at tenpos_center
    show spamton standing up frown flipped at spampos_left
    with Dissolve(0.2)
    pause 0.5
    show tenna upright pointing oh flipped at tenpos_offcen
    show tenna at jump
    tenna "Oh,{w=0.2} [persistent.mc]!{p=0.5}{noalt}*{/noalt} You're back!"
    show tenna upright back panic flipped at wiggle
    tenna "You were gone so long that I was getting a little worried,{w=0.2} haha..."
    show spamton standing up glare flipped at jump
    spamton "{noalt}IT{/noalt}{alt}it{/alt} WAS [[cook for 5 minutes] ???"
    show tenna upright chest angry at tenpos_center
    show tenna at jump
    tenna "That's besides the point!!"
    show tenna upright chest neutral flipped at tenpos_offcen
    show tenna at jump
    show spamton standing up frown flipped
    tenna "Anyway!{w=0.5} [persistent.mc],{w=0.2} who's this mystery person you found?"
    show costume tie frown at cospos_right with easeinright
    pause 0.5
    show costume pointing nervous
    mike_no_img "H-{w=0.1} Hey,{nw=0.2}"
    play music volumeadjustment
    show tenna slouch claw panic flipped at jump
    tenna "MIKE?!{p=0.5}{noalt}*{/noalt} You ARE here?!"
    show tenna upright chest confused flipped at leanrightL
    tenna "Where have you been?!{p=0.5}{noalt}*{/noalt} I've been alone for AGES!!"
    show tenna upright chest angry flipped at jump
    tenna "I looked for you!{p=0.5}{noalt}*{/noalt} I called out to you!!"
    show costume tie nervous at leanright
    mike_no_img "I..."
    show spamton standing up glare flipped at jump
    spamton "THaT'S NOT [[[[Mike.]]"
    show tenna upright chest panic at jump
    tenna "Huh?{nw=0.5}"
    show tenna slouch claw angry at jump
    extend "{p=0}{noalt}*{/noalt} What the hell do YOU know?"
    show spamton standing up smirk flipped
    spamton "MIKE."
    show costume pointing angry at jump
    mike_no_img "H-{w=0.1} hey!{p=0.5}{noalt}*{/noalt} I'm definitely Mike!{w=0.2} Totally Mike!"
    show costume pointing smile
    mike_no_img "Mi-hi-yai-yi-yi-yike!"
    show spamton crazy smirk flipped
    spamton "MORE LIKE [[yikes.]"
    show costume pointing nervous at jump
    mike_no_img "HEY!!!"
    show spamton standing up glare flipped at yreset
    show tenna upright back frown
    pause 1.0
    show tenna upright back frown flipped at droop
    pause 1.0
    tenna "Is he right?"
    show costume tie nervous at leanleftQ
    mike_no_img "What?!{p=0.5}{noalt}*{/noalt} Tenna,{w=0.2} you're gonna trust THIS guy over ME?!"
    show costume at jump
    mike_no_img "ME,{w=0.2} Mike?!{p=0.5}{noalt}*{/noalt} Your buddy,{w=0.2} your pal???"
    show tenna upright back confused flipped
    tenna "{cps=15}...{/cps}"
    show tenna upright back panic flipped
    tenna "{cps=15}\"This guy\"?{/cps}"
    show costume pointing frown at jump
    mike_no_img "Wh--{p=0.5}{noalt}*{/noalt} Don't tell me this freak I've... definitely never seen before is somebody you care about!!"
    show tenna upright back confused flipped at leanleftL
    tenna "{cps=15}...{/cps}"
    pause 2.0
    show tenna upright back confused at jump
    pause 1.0
    show spamton standing up frown flipped
    pause 0.5
    show spamton panic up scream at leanleftQ
    spamton "DON'T {noalt}[[L@@K]{/noalt}{alt}look{/alt} AT ME!!"
    show spamton crazy avert flipped at jump
    spamton "I ALREADY TOLD YOU."
    show spamton standing up glare flipped
    show costume pointing angry at jump
    mike_no_img "Don't listen to that loser,{w=0.2} Tenna!{p=0.5}{noalt}*{/noalt} Don't do it!!"
    show tenna upright back confused flipped at jump
    show costume pointing nervous
    mike_no_img "I'm Mike!{w=0.5} I've always been Mike!!"
    tenna "...{nw=0.5}"
    show tenna upright chest panic at jump
    extend " Well,{w=0.2} I guess I also didn't recognize you like this at first."
    show spamton crazy avert flipped at jump
    spamton "OH GIMMIE A [[government mandated break]!!{p=0.5}{noalt}*{/noalt} THaAT'S YOUR [[Take a Vacation] AWAY ?!?!?!"
    show spamton crazy laugh flipped at xwiggle
    spamton "YOU WERE IN [[Request Denied] ABOUT THAT!!"
    show spamton crazy frantic flipped at jump
    spamton "THIS GUY DOESN'T EVEN [[Look! Look!] LIKE MIKE YOU [[Worms for] [[empty box] !!!!!{p=0.5}{noalt}*{/noalt} ARE YOU [[Request Denied]ING THAT TOO?!?!"
    show tenna upright back panic at droop
    tenna "..."
    pause 1.0
    show tenna upright back confused flipped at jump
    tenna "He always just said he had different costumes he liked wearing."
    show spamton crazy frantic at xwiggle
    spamton "AND YOU [[Believe it!] {noalt}?!?!1?!!?!??!!?1?!{/noalt}"
    show spamton standing up frown flipped at jump
    show costume pointing nervous at wiggle
    mike_no_img "Because it's TRUE!{w=0.2} The TRUTH!{w=0.2} Absolutely AND positively!!"
    show tenna upright back panic at jump
    tenna "And he said he liked talking differently from time to time...{p=0.5}{noalt}*{/noalt} Or just.{w=0.2} Not at all."
    show costume tie nervous
    mike_no_img "Yyyep!{p=0.5}{noalt}*{/noalt} Hahahaha,{w=0.2} gotta rest and train the vocal chords,{w=0.2} y'know?{w=0.2} {noalt}Y'feel?{w=0.2} Y'see?{w=0.2} Y'hear?{/noalt}{alt}ya feel? ya see? ya hear?{/alt}"
    show spamton standing up glaree flipped
    spamton "..."
    show spamton crazy angry flipped at jump
    spamton "[[Cathode],{w=0.5} YOU'RE THE DUMBEST \n[[Funniest Home Videos] {noalt}[[[[&!+X#]]{/noalt}{alt}beep{/alt} IN THE WHOLE\n[[World History Lesson]"
    show tenna panic panic at jump
    tenna "Wha--{nw=0.5}"
    show tenna slouch claw angry at jump
    extend " HEY,{w=0.2} that's{nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend " SEVERELY uncalled for!?"
    show costume pointing angry at yreset
    show costume at leanleftL
    mike_no_img "Heya--{w=0.2} Ouch!{w=0.2} Rude!{p=0.5}{noalt}*{/noalt} Even I felt that burn!!"
    show costume pointing frown
    mike_no_img "This weirdo sounds like way more of a \"yikes\" than me,{w=0.2} don'cha think, huh?"
    show costume pointing smile at jump
    mike_no_img "How's about we skedaddle on outta here and leave him behind?{p=0.5}{noalt}*{/noalt} Go somewhere far,{w=0.2} far away?"
    show costume tie frown
    mike_no_img "And never see him again."
    show tenna upright chest angry at rise
    tenna "I can't say that doesn't sound UN-appealing..." 
    show tenna upright back frown flipped at jump
    tenna "But,{w=0.2} Mike--{w=0.5} don't you remember.{w=0.2}.{w=0.2}.{nw=1.0}"
    show tenna at droop
    extend " Spamton?"
    show spamton standing up frown flipped
    pause 2.0
    show costume tie nervous at droop
    mike_no_img "Who?"
    pause 2.0
    show tenna upright back confused at jump
    pause 1.0
    show spamton standing up glaree flipped at jump
    spamton "I ALREADY [[Told you so] [[Trash Heap]"
    show costume pointing nervous at wiggle
    mike_no_img "Huh--{w=0.2} oh, uh--{w=0.2} this guy?{p=0.5}{noalt}*{/noalt} THIS guy!"
    show costume tie nervous
    mike_no_img "Yeah,{w=0.2} pfft,{w=0.5} of course I remember him!"
    show tenna upright back confused flipped at jump
    show costume pointing nervous
    mike_no_img "He's.{w=0.5} Definitely memorable!!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} completely!{w=0.2} I was yankin' your chain!!"
    show spamton crazy angry at jump
    spamton "THIS {noalt}IS{/noalt}{alt}is{/alt} [[[[Drive Our {noalt}Cungadero{/noalt}{alt}cun gah dero{/alt} Around Town]]ING\nME NUTS."
    show spamton standing up smile flipped 
    show tenna upright back panic flipped 
    show costume tie nervous at yreset
    mike_no_img "What?{w=0.2} Huh?"
    show costume tie nervous at leanrightLQ_mike
    show spamton at leanrightLQ
    mike_no_img "HEY, hey, Hey WAIT--{p=0.2}{noalt}*{/noalt} Don't come after me, what'd I do?!"
    play sfx leap
    hide spamton
    hide costume
    with easeoutright
    pause 0.2
    stop music
    play sfx beatup
    pause 0.2
    show tenna slouch claw panic flipped at jump
    pause 1.0
    show tenna panic panic flipped at jump
    pause 0.8
    show tenna upright chest panic flipped at jump
    pause 1.0
    show tenna panic flustered flipped at jump
    pause 1.0
    show tenna slouch claw panic flipped at jump
    pause 0.2
    stop sfx fadeout 0.2
    pause 1.0
    show tenna at tenpos_left with ease
    pause 0.5
    show spamton standing up glare at spampos_center with easeinright
    show spamton standing up glare flipped
    pause 1.0
    show mike standing nervous at mikepos_offsceenright
    show mike at mikepos_right with MoveTransition(1.5,time_warp=_warper.ease)
    pause 1.0
    mike_no "{cps=25}...{/cps}"
    show tenna at droop
    tenna "{cps=25}...{/cps}"
    show mike standing sigh at droop
    mike_no "Okay."
    mike_no "Maybe I'm not really Mike."
    play music sneaking
    show mike arms freakout at rise
    mike_no "But I--{w=0.5} Tenna,{w=0.2} ya gotta understand--{p=0.5}{noalt}*{/noalt} Nobody liked seeing you so upset just because \"Mike\" wasn't around!"
    if persistent.glitches:
        show mike arms avert at jump
    else:
        show mike arms avert at shock
    mike_no "So me and a couple other guys--{w=0.2} we were just--"
    if persistent.glitches:
        show mike standing sigh
    else:
        show mike standing sigh at shakingcg
    mike_no "You always ask for way more than just one guy can do,{w=0.2} so I got more \"Mikes\"--"
    show mike arms avert
    mike_no "We all kept pretending to be Mike so you wouldn't be so agitated all the time!"
    show mike arms freakout
    mike_no "I couldn't just tell you NO,{w=0.2} then you'd just be miserable and take it out on everyone else again!"
    show mike arms avert at jump
    mike_no "Look--{w=0.2} I don't even know who Mike is!{w=0.2} I don't!!"
    show mike tie nervous at wiggle
    mike_no "It just seemed like such a soft spot--{w=0.2} and that one day you seemed so..."
    show mike arms freakout at jump
    mike_no "I mean--{w=0.2} it also doesn't even make sense that you believed me?!"
    if persistent.glitches:
        show mike arms freakout at jump
    else:
        show mike arms freakout at shock
    mike_no "And--{w=0.2} this guy??{p=0.5}{noalt}*{/noalt} Is this the \"other guy\" you mentioned??{w=0.2} That Mike was \"different after he left\"?!"
    show spamton standing up frown flipped
    show tenna upright chest angry flipped at rise
    show mike standing sigh
    mike_no "So,{w=0.2} uh.{w=0.2}.{w=0.2}."
    show mike at droop
    mike_no "Ah,{w=0.2} forget it."
    show mike tie avert
    mike_no "I'm sorry,{w=0.2} Tenna.{p=0.5}{noalt}*{/noalt} I just didn't wanna..."
    show mike standing conflicted at droop
    mike_no "I mean--{w=0.2} Nobody wanted you to be depressed all the time! So I thought it'd cheer you up!"
    show mike standing sigh
    mike_no "But I, uh...{w=0.5} just went ahead and made everything worse,{w=0.2} didn't I?"
    show mike standing nervous at leanright
    mike_no "I...{w=0.2} I'll just.{w=0.5} You probably want me to leave.{w=0.2} Why wouldn't you?"
    show mike standing sigh at leanrightL
    mike_no "Yeah,{w=0.2} I'll just--"
    show tenna upright chest frown flipped at jump
    tenna "Wait."
    show mike standing indifferent at jump
    pause 1.0
    show tenna upright back frown flipped
    tenna "...{w=0.5} So."
    show tenna upright back confused flipped
    tenna "This is a lot."
    show spamton crazy smirk
    spamton "ONLY BECAUSE YOUR [[Stupid {noalt}dumb@$$]{/noalt}{alt}dumb beep{/alt}--{nw=0.1}"
    show tenna slouch claw angry flipped
    tenna "Shut it,{w=0.2} I wasn't {nw}"
    if persistent.glitches:
        show tenna at jump
    else:
        show tenna at shock
    extend "TALKING to you!"
    show spamton standing up glare
    show tenna upright chest frown flipped at rise
    tenna "Mike-- or.{p=0.5}{noalt}*{/noalt} Pippins?"
    show mike tie avert at jump
    gp "...{w=0.2} that's.{w=0.5} Uh."
    show mike standing nervous
    gp "Y'know,{w=0.2} now that you say THAT name out loud,{w=0.5} I'm realizing I haven't been called anything but Mike in years."
    show tenna upright chest blank flipped at jump
    tenna "Okay,{w=0.2} then we'll stick with that."
    show mike standing awkward at droop
    mike "..."
    show tenna upright chest confused flipped zorder 10
    tenna "You've been doing this for--{w=0.5} YEARS?"
    show mike tie blush at wiggle
    mike "...{w=0.5} {noalt}yyyyyyep.{/noalt}{alt}yep.{/alt}"
    show tenna upright back confused flipped at jump
    tenna "Out of your own free will??"
    show spamton standing up glare flipped
    show mike standing awkward at jump
    mike "Uh.{w=0.2} Yeah."
    show spamton standing up glare at spampos_offscreenleft
    show tenna upright back frown flipped
    tenna "...{w=0.2} Okay.{p=0.5}{noalt}*{/noalt} Okay."
    hide spamton
    show tenna upright back panic flipped at droop
    tenna "This is.{w=0.5} Still a lot."
    show tenna upright back confused flipped
    tenna "Why are you even HERE,{w=0.2} of all places?"
    show tenna upright chest panic flipped at jump
    tenna "Did they also...?"
    show mike tie nervous at jump
    mike "Oh, THAT.{p=0.5}{noalt}*{/noalt} That.{p=0.5}{noalt}*{/noalt} That's{nw=0.5}"
    show mike tie awkward at droop
    extend "{cps=15}...{/cps}"
    show mike tie avert
    pause 1.0
    show mike standing sigh at yreset
    mike "I didn't know where you went,{w=0.2} so I went looking for you."
    show mike standing nervous at mikepos_offcenease
    mike "The Lightners said you weren't in the Dark World when everybody else got there."
    mike "Sure enough--{w=0.2} the room with your name on it was empty."
    show tenna panic flustered flipped at jump
    tenna "A room for--??"
    show mike tie nervous
    mike "I was tryin' not to think about it,{w=0.2} but it was bothering me a lot."
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "I mean-- a reasonable amount."
    show mike standing sigh at yreset
    mike "And I ended up here.{p=0.2}{noalt}*{/noalt} {noalt}S{w=0.5}sssssssssssssomehow.{/noalt}{alt}somehow.{/alt}"
    show tenna slouch claw panic flipped at jump
    tenna "Just--{w=0.2} SOMEHOW?{p=0.5}{noalt}*{/noalt} Mike,{w=0.2} how long have you BEEN here?"
    show mike tie avert
    mike "I {w=0.2} don't know.{w=0.5} A few days, maybe??{p=0.5}{noalt}*{/noalt} I got lost...!"
    show tenna panic flustered flipped at jump
    tenna "You've been looking for me for...!?"
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "HEY,{w=0.2} don't think about it too deeply!!"
    show mike tie blush at jump
    mike "W-{w=0.1} we're all worried about ya!!{w=0.5} In some capacity!!"
    show tenna upright chest awkward flipped at rise
    tenna "But you cared enough to try and find me...?"
    show mike tie awkward at wiggle
    mike "That's--{w=0.2} neither--{w=0.2} here nor there...!"
    show mike arms avert at jump
    mike "I told everybody else not to worry about it!!{p=0.5}{noalt}*{/noalt} The other Mikes could handle stuff without me!!"
    show tenna upright pressed smile flipped at wiggle
    tenna "You...{w=0.2} ah..." # blushy
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "H-{w=0.1} hey!{w=0.2} What's THAT expression for?!"
    show tenna at yreset
    show tenna at leanrightL
    tenna "I thought everybody left me for dead!{p=0.5}{noalt}*{/noalt} I thought nobody cared about me anymore!"
    show tenna at wiggle
    tenna "Haha,{w=0.2} I should have known that YOU still cared,{w=0.2} Mike!" # wiggle
    show mike standing conflicted at leanrightLQ
    mike "Wha-HEY,{w=0.2} hey!!{p=0.5}{noalt}*{/noalt} Don't gimmie that kind of credit!!"
    show mike arms avert at jump
    mike "I'm not even the guy you thought I was!!"
    show tenna upright back frown flipped at yreset
    tenna "No, you're not.{w=0.2} And I'm still not happy about that."
    show tenna upright chest neutral flipped at jump
    tenna "But YOU stayed when the Mike I DID know didn't."
    show mike standing awkward at droop
    mike "I..."
    show mike arms freakout at jump
    mike "N-{w=0.1} nevermind all of that!!{w=0.2} Agh!!{p=0.5}{noalt}*{/noalt} Let's just get outta here!!"
    show mike standing wink at leanright
    mike "C'mon,{w=0.2} everybody's waitin' for you back at our new home."
    spamton "CAN'T."
    show mike standing indifferent zorder 11
    mike "Huh--"
    show mike at mikepos_right
    show tenna upright chest blank at tenpos_offcen2
    with ease
    pause 0.2
    show spamton standing up glare flipped at spampos_left with easeinleft
    pause 0.2
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "Hey,{w=0.2} who even ASKED you?!"
    show mike standing pout at yreset
    show spamton crazy angry flipped at jump
    spamton "THERE'S [[No way...] OUT."
    show spamton standing up frown flipped at jump
    spamton "I'VE [[tried and true] ALREADY."
    show tenna upright pointing oh at jump
    tenna "Now, hold on--{w=0.2} that can't be right!{p=0.5}{noalt}*{/noalt} If Mike here came from a Dark World where the Lightners are..."
    show tenna upright pointing smile at jump
    tenna "That MUST mean there's an exit.{w=0.2} We'd just have to go out the same way he entered!"
    show mike tie nervous at jump
    mike "Y-{w=0.1} yeah!{w=0.5} You heard him!"
    show mike tie avert
    mike "Just,{w=0.2} uh...{nw=0.5}"
    show mike at droop
    extend "{p=0}{noalt}*{/noalt} I might have completely forgotten which direction I came from."
    show tenna upright chest blank flipped at tenpos_offcen
    show spamton standing up glare flipped
    pause 2.0
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "Don't look at me like I'M some kind of jerk!!"
    show mike arms avert
    mike "I said I got LOST once already,{w=0.2} didn't you hear me?!"
    show spamton standing tilt laugh flipped glitch
    spamton "YOU'RE ONE [[useless] SON OF A [[beach paradise], YOU KNOW THAT?"
    show spamton standing up smirk flipped
    if persistent.glitches:
        show mike arms freakout at jump
    else:
        show mike arms freakout at shock
    mike "HEY!"
    show tenna upright chest angry at tenpos_offcen2
    show tenna at jump
    tenna "Would you quit targeting Mike like that?"
    show spamton crazy frantic flipped at xwiggle
    spamton "HE'S NOT EVEN MIKE ???"
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "Who cares what name he's using?!"
    show tenna upright chest angry
    tenna "Geez,{w=0.2} you'd think YOU would know about that,{w=0.2} of ALL people!"
    if persistent.glitches:
        show spamton slouch down panic flipped
    else:
        show spamton slouch down panic flipped glitch at shakingcg
    spamton "THAT WAS [[make a difference] AND YOU KNOW {noalt}IT{/noalt}{alt}it{/alt}!!"
    show tenna upright pointing oh at jump
    tenna "That's not the point!"
    show mike tie avert
    mike "I mean, he's...{w=0.2} kind of got a point."
    show tenna upright pointing weak flipped at tenpos_offcen
    show tenna at jump
    tenna "NO,{w=0.2} he does not."
    show spamton standing up frown flipped at yreset
    show tenna upright chest frown flipped at droop
    tenna "Look,{w=0.2} Mike.{w=0.5} I'm REALLY not happy about the fact that you lied to me for years.{p=0.5}{noalt}*{/noalt} I'm not going to pretend I'm not."
    show tenna upright back frown flipped
    tenna "I'm sick of pretending all the time..."
    show tenna upright pressed smile flipped at jump
    tenna "BUT!{w=0.5} I'm also ELATED that you came looking for me!"
    show tenna upright chest panic flipped at jump
    tenna "I suppose I really haven't been all that nice to you...{p=0.5}{noalt}*{/noalt} YOU-you,{w=0.2} that is."
    show tenna upright back angry flipped at wiggle
    tenna "Pippinses...{w=0.5} were never really my,{w=0.2} uh...{p=0.8}{noalt}*{/noalt} Haha,{w=0.5} how do I put this..."
    show mike standing sigh at droop
    mike "You hate Pippinses."
    show tenna upright pointing weak flipped at jump
    tenna "W-{w=0.1} well,{w=0.2} I wouldn't go THAT far...!"
    show mike arms freakout at jump
    mike "YOU MADE A QUIZ QUESTION THAT WAS JUST \"What's the name of this awful guy?\" WITH A PIPPINS?"
    show tenna at droop
    tenna "Pff,{w=0.2} I mean,{w=0.2} on-stage banter is one thing--"
    if not persistent.glitches:
        show mike at shakingcg
    mike "ONE OF THE ANSWERS WAS \"TOYLET\"??"
    show tenna upright chest panic flipped at wiggle
    if persistent.mc == "Toylet":
        tenna "Th-{w=0.1} that's the same name of our good friend [persistent.mc], you know!"
    else:
        tenna "T-{w=0.1} this this was before I knew YOU were Mike, you know!"
    if persistent.glitches:
        show mike arms avert at jump
    else:
        show mike arms avert at shock
    mike "WHAT DOES THAT MATTER??"
    show tenna upright back nose flipped at droop
    show mike standing sigh
    mike "Look,{w=0.2} Tenna.{p=0.5}{noalt}*{/noalt} I know you're not a bad guy."
    mike "I...{w=0.5} know that better than a lotta people."
    show mike standing nervous at droop
    mike "...{w=0.2} but you were never really all that good to \"Mike,\"{w=0.5} either."
    show tenna upright back nosed flipped
    show mike arms freakout at jump
    mike "I had to hire TWO other guys just to keep up with all you were askin' for!{p=0.2}{noalt}*{/noalt} TWO!!"
    show mike standing sigh
    mike "I thought about quitting more than once."
    mike "When you started hunting the Lightners down over nothing...{w=0.5} that really hit the nail in the coffin."
    show mike standing conflicted
    mike "I knew something was wrong,{w=0.5} but I also knew I wouldn't be able to help."
    show mike at droop
    mike "The only thing I could do was just...{w=0.5} leave."
    show mike standing sigh
    mike "I'm...{w=0.5} sorry I did that.{p=0.2}{noalt}*{/noalt} I don't think there's anything else I coulda done,{w=0.2} but I know it still probably hurt...{w=0.5} right?"
    show mike standing conflicted
    mike "You did a lotta stuff that upset me AND a lot of other folks,{w=0.2} and I'm really not over that."
    show mike standing nervous
    mike "But I still..."
    show mike tie avert at wiggle
    mike "You're still..."
    show mike at yreset
    show tenna upright back nose flipped at jump
    pause 1.0
    show mike tie nervous
    mike "...{w=0.2} I still care about you.{p=0.5}{noalt}*{/noalt} And I know you're not a bad person."
    show spamton standing up glare flipped
    if persistent.glitches:
        show mike arms freakout
    else:
        show mike arms freakout at shakingcg
    mike "ALRIGHT?{p=0.5}{noalt}*{/noalt} THERE,{w=0.2} I SAID {noalt}IT{/noalt}{alt}it{/alt}!!"
    show mike tie avert at droop
    show tenna upright chest blank flipped at rise
    tenna "Mike,{w=0.2} you...?"
    show tenna slouch claw panic flipped at jump
    show mike standing pout at jump
    show spamton standing tilt laugh flipped at xwiggle
    spamton "ENOUGH OF THE [[Buy Water Works For] OVER THERE!!"
    show tenna upright pointing weak at tenpos_offcen2
    show tenna at jump
    show mike tie awkward
    tenna "What's your problem?!{p=0.5}{noalt}*{/noalt} Can't you tell there's something going on here?!"
    show spamton standing up glare flipped at jump
    spamton "YEAH THAaT'S THE POINT."
    show tenna upright chest angry at rise
    tenna "Are you {nw}"
    play sfx splat
    if persistent.glitches:
        extend "{image=txt_jealousG}{alt}jealous{/alt}{w=0.1} or something?!"
    else:
        extend "{image=txt_jealous}{alt}jealous{/alt}{w=0.1} or something?!"
    show mike tie avert at droop
    show spamton crazy laugh at jump
    spamton "[[hockey sticks] NO."
    show spamton standing up glaree flipped
    spamton "I'M JUST SICK OF PLAYING [[And get the third wheel free!] WHILE YOU TWO HAVE A [[Schmoozefest] !!"
    show spamton standing up stare flipped at jump
    spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} AREN'T YOU [[Sick of dried-on grease?] STANDING AROUND LIKE A [[limp noodle] ??"
    $ multichar = False
    menu:
        rq "[persistent.mc!u].\n{noalt}*{/noalt} AREN'T YOU [[Sick of dried-on grease?] STANDING AROUND LIKE A [[limp noodle] ??"
        "I wasn't bothered.":
            "You say you weren't all that bothered."
            $ multichar = True
            show tenna upright pointing oh at jump
            show spamton standing up frown flipped
            tenna "See,{w=0.2} [persistent.mc] knows how to be respectful when other people are having a conversation!"

        "It's a little awkward...":
            "You say you're feeling slightly awkward."
            $ multichar = True
            show spamton standing tilt laugh flipped at jump
            show tenna upright chest frown 
            spamton "SEE??{p=0.5}{noalt}*{/noalt} YOU JUST WANT ME TO BE [[Wrong.] ABOUT EVERYTHING!"
        
        "...":
            $ multichar = True

    show spamton standing up smile flipped
    show tenna upright chest blank
    show mike tie nervous at jump
    mike "Actually,{w=0.5} maybe we SHOULD save this for another time..."
    show tenna upright back blank flipped at tenpos_offcen
    show tenna at jump
    show mike standing conflicted
    mike "Look, y'know,{w=0.2} I'm happy to see ya and everything, Tenna,{w=0.5} but if we're actually STUCK here..."
    show mike tie avert at wiggle
    mike "I'm...{w=0.2} I don't really wanna...{w=0.2} I don't think it'd be...{p=0.5}{noalt}*{/noalt} Haa..."
    show mike at droop
    mike "I'm gonna need some time to adjust to that,{w=0.2} y-{w=0.1} y'know?{p=0.5}{noalt}*{/noalt} Hahahaha..."
    show tenna upright back nose flipped
    pause 1.0
    $ _history = False
    tenna_shh ".{w=0.2}.{w=0.2}.{nw=0.5}"
    $ _history = True
    show tenna upright back nosed flipped at droop
    tenna "...{fast} Fine."
    show tenna upright chest blank at tenpos_offcen2
    show tenna at jump
    tenna "[persistent.mc],{w=0.2} if you need me,{w=0.2} I'm going to sit by my house for a bit."
    hide tenna with easeoutleft
    pause 1.0
    show spamton standing up glare flipped at jump
    spamton "OK????"
    show spamton standing up glaree flipped at xwiggle
    spamton "WHAT'S HIS [[irreparable damage]"
    show spamton standing up frown flipped at jump
    spamton "I'LL BE BY MY [[homemade] STORE [[Made with Love] I GUESS."
    show mike standing pout
    hide spamton with easeoutright
    stop music fadeout 2.0
    pause 1.0
    show mike at mikepos_center with ease
    mike "...{w=0.2} Uh."
    show mike tie nervous at jump
    mike "I'm gonna leave,{w=0.2} too.{p=0.5}{noalt}*{/noalt} I mean,{w=0.2} everyone else did."
    show mike standing wink
    mike "I'll be back over by that TV set again.{p=0.5}{noalt}*{/noalt} If you need me."
    show mike standing conflicted
    mike "Yeah.{w=0.5} Uh..."
    show mike standing sigh at droop
    mike "Oh,{w=0.2} forget it."

    ## AUTOSAVE
    $ renpy.save("mainfile")

    $ multichar = False
    $ end_triple = "done"
    show mike standing wink
    hide mike with easeoutright
    pause 1.0
    "Maybe you should go talk to them..."
    play music dump
    jump ex_ogroom