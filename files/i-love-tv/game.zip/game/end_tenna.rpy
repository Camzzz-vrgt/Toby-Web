############################################################################################################
################## TENNA ENDINGS
label ending_tenna:
    $ currentend = "tenna"

    ## AUTOSAVE
    $ renpy.save("mainfile")

    ## intro transition
    $ ten_seen = True
    show tenna upright chest blank flipped at tenpos_center with Dissolve(0.5)
    pause 1.0
    show tenna upright chest blank at jump
    pause 1.0
    show tenna slouch claw panic at jump

    ## actual dialogue
    $ quick_menu = True
    $ skipyes = True
    $ _skipping = True
    tenna "O-{w=0.1} oh,{w=0.2} [persistent.mc]!{p=0.5}{noalt}*{/noalt} When did you get here?!"
    show tenna upright pointing weak at rise
    tenna "Or, better yet--{w=0.2} I'm glad to see you're okay!"
    show tenna upright back frown at droop
    tenna "Last I saw you,{w=0.2} you'd passed out on the ground..."
    show tenna upright chest frown
    tenna "I tried to wake you up,{w=0.5} but you just vanished!"
    show tenna stretch shrug weak at wiggle
    tenna "I was worried you left for good,{w=0.2} haha..."
    tenna "...{nw=0.5}"
    show tenna upright chest frown flipped at droop
    extend " Though,{w=0.2} I suppose I WAS the one who said I was leaving first..."
    show tenna upright back panic at jump
    tenna "I'm still...{w=0.5} working on all that,{w=0.2} by the way."
    tenna "On being less selfish,{w=0.2} that is.{nw=0.5}"
    show tenna at droop
    extend "{p=0}{noalt}*{/noalt} Haha."
    show tenna stretch shrug smile at wiggle
    tenna "Which I'm stiiiiiiill failing at,{w=0.2} APPARENTLY,{w=0.5} since I can't seem to shut up about myself for even two seconds!"
    tenna "Ahaha...{w=0.2} ha!!"
    show tenna stretch shrug weak at droop
    pause 2.0
    show tenna upright back panic at jump
    tenna "So.{p=0.5}{noalt}*{/noalt} How{w=0.5} have{w=0.1} you{w=0.1} been?"

    menu:
        rq "So.{p}{noalt}*{/noalt} How have you been?"
        "Tell him you learned about his past":
            pass
        
        "...":
            tenna_shh "...{nw=0.5}"
            show tenna upright chest panic at droop
            tenna "...{fast} um?"
            show tenna upright pointing smile at rise
            tenna "Hey,{w=0.2} [persistent.mc]!{p=0.5}{noalt}*{/noalt} You're not still mad at me,{w=0.2} are you?"
            show tenna upright back smile at wiggle
            tenna "Haha, I mean,{w=0.2} I know it probably seemed like I was running away and everything!"
            show tenna upright pointing smile 
            tenna "But--{w=0.2} you're such a {nw}"
            play sfx ten_aww
            if persistent.glitches:
                extend "{image=txt_lovelyG}{alt}lovely{/alt}{w=0.2} person!{p=0.5}{noalt}*{/noalt} I didn't want to let you down again..."
            else:
                extend "{image=txt_lovely}{alt}lovely{/alt}{w=0.2} person!{p=0.5}{noalt}*{/noalt} I didn't want to let you down again..."
            show tenna stretch shrug weak
            tenna "I can't keep doing what I've always done and pretend it's going to change something,{w=0.2} haha...!"
            menu:
                "Tell him you learned about his past":
                    pass
    
    stop music fadeout 1.0
    pause 2.0
    "You tell Tenna everything.{p=0.5}{noalt}*{/noalt} No point in covering it up, you figure."
    show tenna upright back blank at yreset
    "Everything you learned from the MemoryShards,{w=0.5} everything Spamton explained to you..."
    show tenna upright back nose
    pause 1.0
    play music flashback fadein 2.0
    pause 2.0
    tenna "You.{w=0.2}.{w=0.2}."
    show tenna at droop
    tenna "How did you...{w=0.5} find that out?"
    pause 2.0
    show tenna upright back nosed
    tenna "I..."
    pause 2.0
    show tenna slouch panic panic
    tenna "The family I lived with was watching TV less and less,{w=0.2} so I..."
    show tenna at wiggle
    if persistent.glitches:
        tenna "I had to do SOMETHING!!{p=0.5}{noalt}*{/noalt} I couldn't be without them,{w=0.2} I just COULDN'T!"
        show tenna slouch panic static
    else:
        tenna "{sc=2}I had to do SOMETHING!!{/sc}{p=0.5}{noalt}*{/noalt} {sc=2}I couldn't be without them,{w=0.2} I just COULDN'T!{/sc}" # SELF VOICING FIX
        show tenna slouch panic static at shaking
    tenna "He was popular! He was beloved!{p=0.2}{noalt}*{/noalt} I couldn't STAND him,{w=0.2} but it..."
    show tenna at yreset
    pause 2.0
    show tenna upright back black
    tenna "So I...{w=0.5} wanted to use that.{p=1}{noalt}*{/noalt} So nobody would forget me."
    if persistent.glitches:
        show tenna slouch claw angry at jump
    else:
        show tenna slouch claw angry at shock
    tenna "Alright?!{w=0.2} I admit it!{p=0.5}{noalt}*{/noalt} I messed up!"
    show tenna slouch panic panic
    tenna "But I really started to care about him!{p=0.2}{noalt}*{/noalt} Really,{w=0.2} I did!!"
    show tenna at droop
    tenna "It didn't start out right,{w=0.2} but--{p=0.5}{noalt}*{/noalt} We could have really BEEN something--"
    if persistent.glitches:
        show tenna slouch claw angry flipped at jump
    else:
        show tenna slouch claw angry flipped at shock
    tenna "If he just hadn't LEFT ME--"
    if persistent.glitches:
        show tenna slouch panic static
    else:
        show tenna slouch panic static at shaking
    tenna "things could have turned out so much better!!"
    tenna "I'm...{nw=0.5}"
    show tenna at shrink
    extend " I'm nothing on my own,{w=0.2} am I?"
    show tenna slouch panic panic
    tenna "The whole family left me behind once he was gone."
    show tenna at wiggle
    tenna "The whole family,{w=0.2} one by one..."
    tenna "It really is all just my..."
    show tenna stretch shrug smile flipped
    tenna "Haha,{w=0.2} I'm just an object!{p=0.5}{noalt}*{/noalt} Right?{w=0.2} Just the same as anybody else in the Dark World!"
    show tenna stretch shrug weak flipped
    tenna "I'm something to be used for a task and then just..."
    tenna "And then just.{w=0.2}.{w=0.2}.{nw=0.5}"
    show tenna at shrinks
    extend " thrown away."
    show tenna slouch panic static at wiggle
    tenna "Now I'm{w=0.5} obsolete."
    pause 1.0
    if persistent.glitches:
        show tenna slouch panic smpte at jump
    else:
        show tenna slouch panic smpte at shock
    play loop beepLo
    tenna_shh "I'm sorry I'm sorry I'm sorry I'm sorry I'm sorry{nw}"
    show tenna slouch panic smpte flipped
    tenna_shh "{cps=25}I'm making it worse{/cps}{nw}"
    tenna_shh "{cps=25}I'm making you upset{/cps}{nw}"
    tenna_shh "{cps=25}I wish I'd never woken up{/cps}{nw}"
    stop loop

    ## DEBUG ONLY
    if debugtesting:
        $ ten.fp = 0
        $ ten.lp = 0

    ## if "won" route 
    if ten.fp <= 0 and ten.lp <= 0:
        menu:
            "{size=-10}{color=#aaaaaa}(This may affect your ending.){/color}{/size}\nComfort him":
                $ ten_success = True
                jump ending_tenna_good
            "Do not":
                $ ten_failed = True
                jump ending_tenna_bad

    ## if "failed" route
    else:
        $ ten_failed = True
        jump ending_tenna_bad


######################################################
##### TENNA GOOD END
label ending_tenna_good:
    play sfx plop
    stop music
    scene black
    if persistent.glitches:
        pass
    else:
        with vpunch
    pause 1.0
    tenna "{cps=25}H-{w=0.2} huh?!{/cps}"
    tenna "What're you..."
    play music faintcourageSo
    show tennaend 1 with Dissolve(2.0)
    pause 3.0
    show tennaend 2 down nose with Dissolve(1.0)
    pause 1.0
    tenna "...{w=0.5} Thank you,{w=0.2} [persistent.mc]."
    show tennaend 2 side nose with Dissolve(0.2)
    tenna "I...{w=0.5} really needed this."
    tenna "I'm"
    pause 2.0
    show tennaend 2 down nose with Dissolve(0.2)
    pause 0.5
    tenna "{cps=25}I'm not a very good person,{w=0.5} am I?{/cps}"
    pause 2.0
    show tennaend 2 down panic with Dissolve(0.2)
    tenna "It's funny,{w=0.2} haha..."
    tenna "Being watched was the only thing that made me feel valuable."
    show tennaend 2 down nose with Dissolve(0.2)
    tenna "It's the only thing I knew for so long,{w=0.2} that..."
    tenna "Losing it felt like losing everything."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "I was willing to do ANYTHING.{p=0.5}{noalt}*{/noalt} Even if that was..."
    pause 1.0
    show tennaend 2 down nose with Dissolve(0.5)
    pause 2.0
    show tennaend 2 side nose with Dissolve(0.5)
    tenna "...{w=0.2} I never told you,{w=0.2} but..."
    show tennaend 2 down nose with Dissolve(0.2)
    tenna "Before I got here,{w=0.5} I{w=0.5} nearly died."
    tenna "At least,{w=0.5} I think so?"
    show tennaend 2 down frown with Dissolve(0.2)
    tenna "I only remember...{p=0.5}{noalt}*{/noalt} I could feel so much pain up my arms and then suddenly--{w=0.5} I couldn't."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "And then--{w=0.5} I couldn't feel anything,{w=0.2} haha...!"
    pause 1.0
    show tennaend 2 down nose with Dissolve(0.5)
    pause 1.0
    show tennaend 2 side panic with Dissolve(0.2)
    tenna "I'm sorry.{p=0.5}{noalt}*{/noalt} You didn't need to hear all that."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "I'm saying too much,{w=0.2} aren't I?"

    menu:
        rq "I'm saying too much, aren't I?"
        "Say what you need to":
            pause 0.5
            show tennaend 2 side confused with Dissolve(0.2)
            tenna "What I need to...?"
            show tennaend 2 side panic with Dissolve(0.2)
            tenna "Oh,{w=0.2} you don't want that.{p=0.5}{noalt}*{/noalt} We'd be here for years!"
            show tennaend 2 down smile with Dissolve(0.2)
            tenna "I appreciate your open ears, though,{w=0.2} haha."
            tenna "It means so much more than I know how to say,{w=0.2} [persistent.mc]."

        "I want to listen to you":
            pause 0.5
            show tennaend 2 side nose with Dissolve(0.5)
            pause 0.5
            tenna "You do?"
            pause 1.0
            show tennaend 2 down nose with Dissolve(0.2)
            tenna "Well,{w=0.2} okay.{p=0.5}{noalt}*{/noalt} Only if you're certain."

        "It's a bit much for me":
            $ ten_noexplain = True
            pause 0.5
            show tennaend 2 down panic with Dissolve(0.5)
            tenna "Haha.{w=0.5} Okay."
            tenna "I'm sorry.{p=0.5}{noalt}*{/noalt} I should have asked first."
            show tennaend 2 side smile with Dissolve(0.2)
            tenna "But I'm glad you told me..."
            show tennaend 2 side panic with Dissolve(0.2)
            tenna "...{w=0.2} instead of assuming I'd figure it out."
            jump ending_tenna_good_you

    tenna "Then..."
    show tennaend 2 down frown with Dissolve(0.5)
    pause 1.0
    tenna "I never wanted things to turn out this way."
    tenna "I didn't actually want to hurt anyone."
    show tennaend 2 down nose with Dissolve(0.2)
    tenna "I just wanted to go back to the way things used to be."
    tenna "There's no way I could have let them just walk away..."
    tenna "They were my family."
    show tennaend 2 down panic with Dissolve(0.2)
    tenna "I wanted more than ANYTHING to keep them in my life."
    tenna "The world was changing so fast.{p=0.2}{noalt}*{/noalt} Between school and work and all sorts of outside life..."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "There wasn't time for TV anymore,{w=0.2} haha..."
    show tennaend 2 down frown with Dissolve(0.2)
    tenna "I thought,{w=0.2} if I could become more up-to-date,{w=0.2} have some more relevant shows,{w=0.2} get some of the hip, new tech down..."
    pause 1.0
    show tennaend 2 down nose with Dissolve(0.5)
    tenna "...{w=0.2} My old partner...{p=0.5}{noalt}*{/noalt} He'd promised to teach me about all of that."
    show tennaend 2 down panic with Dissolve(0.2)
    tenna "He always said we'd make it big--{w=0.2} TOGETHER.{p=0.5}{noalt}*{/noalt} We'd never have to worry again!"
    tenna "Then,{w=0.2} the Lightners would finally look up from their laptops or phone calls and watch me."
    tenna "The family could have been together for more than just the holidays."
    show tennaend 2 down nose with Dissolve(0.2)
    pause 2.0
    tenna "But he lied to me."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "He left me to rot."
    tenna "Because of that,{w=0.2} my family just left me behind,{w=0.2} haha!{w=0.5} Every last one of them!"
    tenna "Even Tori..."
    show tennaend 2 down angry with Dissolve(0.2)
    tenna "One by one,{w=0.2} everything just...{w=0.5} fell apart,{w=0.2} haha...!"
    pause 1.0
    show tennaend 2 down confused with Dissolve(0.2)
    tenna "I don't want to be forgotten.{p=0.5}{noalt}*{/noalt} I don't want to be obsolete.{w=0.2}.{w=0.2}."
    show tennaend 2 down frown with Dissolve(0.2)
    tenna "...{w=0.5} but it happened anyway."
    tenna "I got so focused on it..."
    show tennaend 2 down panic with Dissolve(0.2)
    pause 0.5
    tenna "...{w=0.5} that must've been what he meant when he said I was a \"walking red flag,\"{w=0.2} ahah...!"
    tenna "I shouldn't have trusted him..."   
    pause 1.0
    show tennaend 2 down nose with Dissolve(0.2)
    tenna "I put everything into our friendship.{p=0.5}{noalt}*{/noalt} Our relationship."
    tenna "With everything I possibly could...{w=0.5} I always put him first."
    show tennaend 2 down angry with Dissolve(0.2)
    tenna "Yes,{w=0.2} even when I...{w=0.5} DIDN'T care all that much about him."
    show tennaend 2 down panic with Dissolve(0.2)
    tenna "I was so convinced that the further I pushed things,{w=0.2} the longer we stayed together,{w=0.5} it'd be alright in the end!"
    tenna "Then,{w=0.2} when everyone thought of a big shot like him,{w=0.5} they'd think of me right by his side!"
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "I'd be watched for as long as I wanted!{p=0.5}{noalt}*{/noalt} I'd be hip and relevant,{w=0.2} just like he was."
    pause 1.0
    show tennaend 2 down frown with Dissolve(0.2)
    tenna "It turned out okay,{w=0.2} for a while..."
    tenna "He was actually kind of a sweet guy, for a bit.{p=0.5}{noalt}*{/noalt} Despite my frustration,{w=0.2} I actually started to CARE..."
    show tennaend 2 down panic with Dissolve(0.2)
    tenna "I thought it could only go up from there, haha!{p=0.5}{noalt}*{/noalt} ... and that's exactly when I let my guard down."
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "But now--{w=0.2} now that he's GONE--{w=0.2} I can't--{w=0.2} I can't stop..."
    show tennaend 2 down angry with Dissolve(0.2)
    tenna "I can't stop thinking about him!!"
    tenna "It's like he's haunting my very existence,{w=0.2} ahah..."
    tenna "It doesn't make sense,{w=0.2} does it?!"
    show tennaend 2 down pained with Dissolve(0.2)
    tenna "I can't STAND HIM!{p=0.5}{noalt}*{/noalt} But I also can't stand the thought of being WITHOUT him...!?"
    pause 1.0
    show tennaend 2 side panic with Dissolve(0.2)
    tenna "Oh, I'm sorry...{p=0.5}{noalt}*{/noalt} He really takes up...{w=0.5} so much of the space in my hollow box,{w=0.2} haha!"
    show tennaend 2 side confused with Dissolve(0.2)
    pause 1.0
    show tennaend 2 side nose with Dissolve(0.2)
    tenna "This is really not the best conversation to be having with someone I was trying to court earlier,{w=0.2} is it?"
    show tennaend 2 side confused with Dissolve(0.2)
    tenna "Haha.{p=0.5}{noalt}*{/noalt} Um.{p=1}{noalt}*{/noalt} Sorry..."
    show tennaend 2 side panic with Dissolve(0.2)
    tenna "L-{w=0.1} like I said, I'm not{w=0.5} in a good place to be with you right now."
    tenna "I've got way too much baggage!{p=0.5}{noalt}*{/noalt} More than any one CRT should be carrying!"
    tenna "I'm already heavy enough,{w=0.2} aren't I?!"
    tenna "Ha...{w=0.5} ha."
    show tennaend 2 side frown with Dissolve(0.2)
    pause 1.0
    
    menu:
        "You don't have to carry it alone.":
            pause 0.5
            show tennaend 2 side panic with Dissolve(0.2)
            tenna "Wh--{w=0.1} huh?!"
            tenna "But it's...{w=0.2} barely been..."
            tenna "And it's..."

        "I don't think a relationship is going to work out.":
            $ ten_care = False
            pause 1.0
            show tennaend 2 side panic with Dissolve(0.2)
            tenna "I can't really be mad at you for thinking that,{w=0.2} haha."
            tenna "But...{w=0.5} then why haven't you left already?"

    tenna "Knowing everything I've done,{w=0.2} yet you still...?"
    pause 1.0
    show tennaend 2 side frown with Dissolve(0.2)
    tenna "This feels...{w=0.5} off."
    pause 1.0

    menu:
        "You deserve an outlet, too":
            pause 1.0
            show tennaend 2 side panic with Dissolve(0.2)
            if ten_outlet:
                tenna "Ahaha..."
                tenna "This again?"
            else:
                tenna "You... {w=0.5}don't really think that,{w=0.2} do you?"
            show tennaend 2 side nose with Dissolve(0.2)
            
        "You'll find someone who'll love you as you are" if not ten_care:
            pause 1.0
            show tennaend 2 side nose with Dissolve(0.2)
            pause 1.0
            tenna "...{w=0.2} Do you really think so?"
            tenna "It becomes harder to believe that every day."

        "You deserve love as much as anyone else" if ten_care:
            pause 1.0
            show tennaend 2 side nose with Dissolve(0.2)
            tenna "I..."
        
        "...":
            jump ending_tenna_good_you

    pause 2.0
    show tennaend 2 down nose with Dissolve(0.2)
    if ten_care:
        tenna "[persistent.mc]..."
        tenna "I{w=0.5} can't BEGIN to understand..."
        show tennaend 2 down smile with Dissolve(0.2)
        tenna "But I'm so thankful to have met you."
        show tennaend 2 side smile with Dissolve(0.2)
        tenna "You've given me a new sense of purpose."
        pause 1.0
        show tennaend 2 down panic with Dissolve(0.2)
        tenna "Haha,{w=0.2} why do I feel so guilty having these kinds of thoughts?"
        tenna "It's...{w=0.5} reminding me of SOMETHING..."
        show tennaend 2 down frown with Dissolve(0.2)
        tenna "But I don't really understand why it..."

    elif not ten_care:
        tenna "You're sickeningly sweet,{w=0.2} you know that?"
        show tennaend 2 down panic with Dissolve(0.2)
        tenna "I...{w=0.5} don't want to leave you."
        show tennaend 2 side panic with Dissolve(0.2)
        tenna "But if you don't want to..."
        tenna "...{w=0.2} stay{w=0.2}.{w=0.2}.{w=0.2}."
        tenna "Then{w=0.1}.{w=0.1}.{w=0.1}."
        pause 1.0
        show tennaend 2 side frown with Dissolve(0.2)
        tenna "I'll{w=0.5} just have to"
        pause 2.0
        if persistent.glitches:
            show tennaend 3 with Dissolve(0.2)
            tenna "Augh,{w=0.2} I don't want to do it,{w=0.2} [persistent.mc]!"
        else:
            show tennaend 3 at shakingcg with Dissolve(0.2)
            tenna "{sc=2}Augh,{w=0.2} I don't want to do it,{w=0.2} [persistent.mc]!{/sc}" # SELF VOICING FIX
        tenna "But if I just{w=0.5} forced you..."
        pause 2.0
        show tennaend 2 side nose at yreset with Dissolve(0.5)
        pause 1.0
        tenna "Then you wouldn't be happy,{w=0.2} either...{w=0.5} would you?"

label ending_tenna_good_you:
    scene black with Dissolve(2.0)
    pause 2.0
    scene tennahouse with Dissolve(2.0)
    pause 1.0
    show tenna upright back frown at tenpos_center with Dissolve(1.0)
    tenna "Hey, [persistent.mc]..."
    show tenna upright back confused
    tenna "Why are {color=[c_passion]}you{/color} here?"
    if ten_symp:
        show tenna upright back frown flipped at jump
        tenna "You said you understood what I went through..."
        tenna "Have you been through similar...?"
        show tenna upright back blank flipped
        tenna "And, well...{w=0.2} The obvious."
    show tenna upright back panic at wiggle
    tenna "I don't know why anyone would WANT to be here."
    show tenna stretch shrug weak at jump
    tenna "I mean--{w=0.2} it's a dump!{p=0.2}{noalt}*{/noalt} Literally!"
    show tenna upright pointing weak
    tenna "Haha,{w=0.2} if there's a hell for {noalt}Darkners{/noalt}{alt}dark nurs{/alt}...{nw=0.5}"
    show tenna at droop
    extend "{p=0}{noalt}*{/noalt} This would be it."
    show tenna upright back black
    tenna "No one else here is alive."
    tenna "Lightners just throw all their...{nw=0.5}"
    show tenna at shrink
    extend " useless junk here."
    tenna "All the {noalt}Darkners{/noalt}{alt}dark nurs{/alt} they don't need anymore."
    tenna "But...{nw=0.5}"
    show tenna upright back frown at zreset
    extend " you're a Lightner,{w=0.2} right?"
    show tenna upright back confused
    tenna "Why are {color=[c_passion]}YOU{/color} here?"

    menu:
        rq "Why are {color=[c_passion]}YOU{/color} here?"
        "My life isn't worth it":
            show tenna slouch claw panic at jump
            tenna "H-{w=0.1} huh?!"
            show tenna panic panic at jump
            tenna "[persistent.mc],{w=0.2} don't say things like that...!"
            show tenna upright chest panic
            tenna "Didn't I just tell you how much you helped me?"
            if persistent.glitches:
                show tenna slouch claw angry at jump
            else:
                show tenna slouch claw angry at shock
            tenna "That alone makes what you said completely bogus!"
            show tenna upright back frown flipped at droop
            tenna "If..."
            show tenna upright pointing smile at jump
            tenna "If I can hang in there,{w=0.2} you can too!"

            menu: 
                "Thank you.":
                    tenna "...{nw=0.5}"
                    show tenna upright back panic
                    extend " Haha,{w=0.5} I can't tell if you mean that or not."
                    show tenna upright back frown at droop
                    tenna "Just...{w=0.5} promise me you won't go anywhere,{w=0.2} okay?{p=1}{noalt}*{/noalt} Not like THAT."
                    show tenna upright pointing oh at jump
                    tenna "You can always remember good ol' Mr. Tenna is cheering you on!"
                    show tenna upright chest panic at wiggle
                    tenna "I'm not going anywhere anytime soon,{w=0.2} after all..."

                "You're not real":
                    show tenna slouch claw panic at droop
                    pause 1.0
                    tenna "...{w=0.5} I..."
                    show tenna upright back confused flipped at yreset
                    pause 1.0
                    tenna "That...{w=0.2} may be..."
                    show tenna at droop
                    pause 2.0
                    show tenna upright chest angry at jump
                    tenna "Well, I--{p=0.5}{noalt}*{/noalt} What does it matter??"
                    if persistent.glitches:
                        show tenna slouch claw angry at jump
                    else:
                        show tenna slouch claw angry at shock
                    tenna "If I'm real or not--{w=0.2} who cares?!"
                    show tenna upright pointing oh at jump
                    tenna "You still FEEL something right now,{w=0.2} right?"
                    show tenna upright chest confused
                    tenna "I know I do.{p=0.2}{noalt}*{/noalt} Somehow.{w=0.5} In some way..."
                    show tenna upright back frown
                    tenna "...{w=0.5} so if a dumb, old CRT has the capacity to live and feel,{w=0.2} even though that's supposed to be impossible,"
                    show tenna upright pointing oh
                    tenna "Then you can keep going,{w=0.2} too."
                    show tenna upright pointing smile at jump
                    tenna "Okay?{p=0.5}{noalt}*{/noalt} Promise me that,{w=0.2} [persistent.mc]."

        "I feel so alone":
            show tenna panic panic at droop
            tenna "Oh, no,{w=0.2} [persistent.mc]..."
            show tenna upright chest frown
            tenna "That's no reason to throw yourself in the dump!"
            show tenna upright chest confused
            tenna "Well,{w=0.5} I suppose I don't know that you CHOSE to be here."
            pause 0.5
            show tenna upright pointing oh at jump
            tenna "If I can be a LITTLE selfish,{w=0.2} though--"
            show tenna upright chest awkward
            tenna "I'm{w=0.2} glad you managed to make your way here."

            menu:
                "I'm glad I found you, too.":
                    show tenna panic flustered at jump
                    tenna "You--"
                    show tenna upright chest awkward flipped at jump
                    tenna "You're{nw=0.5}"
                    show tenna slouch panic panic flipped at wiggle
                    extend " way too sweet for one person,{w=0.2} [persistent.mc]!"
                    show tenna upright pointing smile at jump
                    tenna "It's getting a little ridiculous,{w=0.2} haha."
                    show tenna upright back awkward at wiggle
                    tenna "But it also makes me{w=0.5} so happy to hear you say that..."
                    tenna "And with such sincerity.{w=0.2}.{w=0.2}."

                "You're not real":
                    show tenna slouch claw panic at jump
                    tenna "Huh?"
                    show tenna upright back confused
                    tenna "...{nw=0.5}"
                    show tenna stretch shrug weak at jump
                    extend " haha,{w=0.5} where's this coming from...?"
                    show tenna upright back frown flipped
                    pause 1.0
                    show tenna upright back confused at droop
                    tenna "W-{w=0.1} whether or not that may be true,{w=0.2} I..."
                    pause 1.0
                    if persistent.glitches:
                        show tenna slouch claw angry at jump
                    else:
                        show tenna slouch claw angry at shock
                    tenna "Does it really matter?"
                    show tenna upright pointing oh at jump
                    tenna "You still feel SOMETHING right now,{w=0.5} don't you?"
                    show tenna upright pointing weak at wiggle
                    tenna "If that's true,{w=0.2} then..."
                    show tenna stretch shrug weak at jump
                    tenna "Just go with your gut, I say!"
                    show tenna upright chest panic flipped at wiggle
                    tenna "Haha...{w=0.5} does that even make sense?"

        "I just needed a break":
            show tenna panic flustered at jump
            tenna "A break?{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} you chose the DUMP for that...?"
            show tenna upright chest frown at droop
            tenna "Well,{w=0.2} I suppose I don't know that you CHOSE to be here."
            show tenna upright pointing smile at jump
            tenna "But I can think of about a dozen or so other places you could have better spent your time,{w=0.2} haha!"
            show tenna upright chest awkward flipped at jump
            tenna "I hope I'm at least not making things worse,{w=0.2} haha."
            show tenna upright back confused flipped at wiggle
            tenna "I'm not as fun as I used to be..."

            menu:
                "I feel a bit better here.":
                    show tenna upright back awkward at jump
                    tenna "That's good...!"
                    show tenna upright back frown
                    tenna "It's...{w=0.2} hard to tell if you're just saying that or are serious."
                    show tenna upright chest neutral at jump
                    tenna "But,{w=0.2} I'll trust that you're being honest with me."
    
                "You're not real":
                    show tenna panic panic at jump
                    tenna "I--"
                    pause 1.0
                    show tenna upright back panic flipped at wiggle
                    tenna "Why{w=0.5} would you say that,{w=0.2} haha...?"
                    tenna "It's..."
                    show tenna upright back frown flipped
                    tenna "...{w=0.5} not wrong,{w=0.2} I suppose."
                    show tenna upright back black flipped at shrink
                    tenna "To you,{w=0.2} I'm just..."
                    pause 1.0
                    show tenna upright back confused flipped at yreset
                    show tenna at zreset
                    tenna "But {w=0.2}why does that matter...?"
                    show tenna upright pointing oh at jump
                    tenna "You still FEEL something right now,{w=0.2} don't you?"
                    show tenna upright pointing smile at jump
                    tenna "Isn't that more important...?"
                    show tenna upright pointing weak
                    tenna "Even if I'm just..."

        "I was curious":
            show tenna panic panic at jump
            tenna "Just curious?!{p=0.2}{noalt}*{/noalt} About a DUMP?!"
            show tenna upright back panic flipped at wiggle
            tenna "Haha,{w=0.2} does that have a different context for Lightners...?"
            show tenna upright back frown flipped
            tenna "Because it sounds...{w=0.5} morbid to me."
            show tenna panic panic at jump
            tenna "Sorry,{w=0.2} I didn't mean it like that--"
            show tenna upright chest confused
            tenna "It's just..."

            menu:
                "I was curious about you":
                    show tenna panic flustered at jump
                    tenna "Wh-{w=0.1} what's that supposed to mean??"
                    show tenna at wiggle
                    tenna "Saying it with such a deadpanned expression doesn't really help,{w=0.2} you know!"
                    show tenna upright pointing weak
                    tenna "A-{w=0.1} are you flirting with me again?!"
                    show tenna stretch shrug weak flipped
                    tenna "Geez, [persistent.mc]!{p=0.5}{noalt}*{/noalt} Your boldness is{w=0.5}.{w=0.2}.{w=0.2}.{nw=0.5}"
                    show tenna upright back awkward flipped at jump
                    extend " really precious."

                "I was curious about your ex":
                    show tenna upright chest blank
                    pause 1.0
                    tenna_shh ".{w=0.2}.{w=0.2}."
                    pause 1.0
                    show tenna upright chest confused
                    tenna "Sorry.{p=0.5}{noalt}*{/noalt} What?"
                    pause 2.0
                    show tenna stretch shrug smile at jump
                    tenna "Haha,{w=0.5} surely you're kidding,{w=0.2} right?"
                    show tenna stretch shrug weak
                    tenna "He..."
                    show tenna upright chest frown
                    pause 2.0
                    show tenna upright back frown flipped at jump
                    tenna "He's not{w=0.2} here.{w=1}.{w=0.2}.{w=0.5} is he?"
                    show tenna panic flustered at jump
                    tenna "SORRY sorry Sorry!!!"
                    show tenna slouch panic panic flipped at wiggle
                    tenna "AUGH! I'm a mess!!"
                    show tenna stretch shrug weak flipped
                    tenna "I don't{w=0.5} want to deal with him anymore!"
                    show tenna slouch panic panic flipped
                    tenna "Sorry, I'm sorry--{p=0.2}{noalt}*{/noalt} Can we talk about{nw=0.5}"
                    if persistent.glitches:
                        show tenna slouch panic static flipped
                    else:
                        show tenna slouch panic static flipped at shaking
                    extend " {cps=60} Literally Anything Else, please.{/cps}{nw=0.1}"
                    show tenna upright back frown at jump
                    tenna "Um."

        "I don't want to talk about it":
            show tenna slouch claw panic at jump
            tenna "O-{w=0.1} oh!{p=0.2}{noalt}*{/noalt} I'm sorry,{w=0.2} I didn't mean to come off like you HAD to say something..."
            show tenna upright back frown
            tenna "Though,{w=0.5} I was kind of hoping you'd..."
            pause 1.0
            show tenna stretch shrug weak flipped at jump
            tenna "Haha,{w=0.2} nevermind!!{p=0.5}{noalt}*{/noalt} Forget I said anything!"
            show tenna upright pointing oh at jump
            tenna "Don't...{w=0.2} force yourself on my account..."
            show tenna upright pointing weak at droop
            tenna "Haha..."

    show tenna upright chest frown at jump
    pause 2.0
    show tenna upright back frown
    tenna "Actually...{p=0.5}{noalt}*{/noalt} I had one more thing I wanted to say."
    show tenna at droop
    if ten_care:
        tenna "[persistent.mc],{w=0.2} I know this might not be what you want to hear..."
        show tenna upright chest panic flipped at wiggle
        tenna "Well.{w=0.2} Maybe it is.{p=0.5}{noalt}*{/noalt} We actually haven't truly known each other for that long,{w=0.2} have we...?"
        show tenna upright chest frown at jump
        tenna "But, anyway..."
    else:
        tenna "[persistent.mc],{w=0.2} I know you already said you wanted to go separate ways,{w=0.2} but..."
        show tenna upright chest panic at droop
        tenna "I need to get this off my chest, too.{p=0.5}{noalt}*{/noalt} If that's alright with you."
        show tenna upright chest frown at jump
        tenna "It's just that..."
    pause 1.0
    show tenna upright back confused
    tenna "I don't know that I actually...{nw=0.5}"
    show tenna at droop
    extend " want to jump head-first into a whole relationship thing anytime soon."
    show tenna stretch shrug weak flipped at jump
    tenna "Haha, I know,{w=0.2} it's ironic!{nw=0.5}"
    if p_ten_date:
        extend "{p=0}{noalt}*{/noalt} I'm the one who asked you on a date in the first place."
    else:
        extend "{p=0}{noalt}*{/noalt} I'm the one who pushed you into a date in the first place."
    show tenna upright chest frown flipped at droop
    tenna "But I did some thinking,{w=0.2} after we split...{w=0.5} and I decided I'm not REALLY ready for that kind of a leap yet."
    if ten_care:
        show tenna panic flustered at jump
        tenna "I appreciate your companionship, though,{w=0.2} don't get me wrong!{p=0.5}{noalt}*{/noalt} It's not that I want you to LEAVE..."
        show tenna upright chest neutral
        tenna "It just might be a bit better if we let the love grow a little more naturally,{w=0.2} don't you agree?"
        show tenna upright back frown
        tenna "Not...{w=0.2} y'know.{p=0.5}{noalt}*{/noalt} Me trying to push something along to fill the gap of being alone."
        show tenna upright back panic at droop
        tenna "Haha."
    else:
        show tenna panic flustered at jump
        tenna "I-{w=0.1} I know,{w=0.2} like I said,{w=0.2} you made it clear you don't want this either!"
        show tenna upright back frown
        tenna "That makes the feeling mutual,{w=0.2} right?{p=0.5}{noalt}*{/noalt} But...{w=0.5} it seems wrong to say out loud somehow.{w=0.5} Haha."
        show tenna at wiggle
        tenna "I guess I've just been so ALONE for so LONG that I...{w=0.5} feel like I should keep any scrap of attention I get."
        show tenna upright back panic
        tenna "Haha...{w=0.5} that probably sounds strange."
        show tenna at yreset
    pause 1.0
    show tenna upright back nosed
    tenna "I'm so sorry.{p=0.5}{noalt}*{/noalt} For using you. {w=0.5}And for keeping so much from you..."
    show tenna upright chest panic at jump
    tenna "I was certain that if you'd heard about what I'd done before--{w=0.5} you'd just turn away running like everyone else,{w=0.2} haha..."
    show tenna upright chest frown flipped at jump
    tenna "It was selfish,{w=0.2} to say the least.{w=0.5} I should have known better."
    show tenna stretch shrug weak flipped at droop
    tenna "I've already hurt enough people by trying to force them to stay close to me..."
    show tenna slouch panic panic flipped at wiggle
    tenna "The thought of letting go,{w=0.2} though..."
    show tenna slouch panic static flipped
    tenna "It hurts.{p=0.5}{noalt}*{/noalt} It hurts so,{w=0.2} so much."
    pause 1.0
    menu:
        "Letting go doesn't mean you'll be abandoned.":
            show tenna upright chest blank at jump
            tenna "...{w=0.2} huh?"
            show tenna upright back nosed
            tenna "I..."
            show tenna upright back panic at jump
            tenna "That doesn't make much sense to me,{w=0.2} haha."
            show tenna upright chest frown
            tenna "No matter if I let go or not...{w=0.2} everyone always runs away."

            menu:
                rq "No matter if I let go or not... everyone always runs away."
                "You're holding on too tight.":
                    show tenna upright chest confused at droop
                    tenna "Too tight...?"
                    show tenna upright chest panic at wiggle
                    tenna "Haha,{w=0.2} what,{w=0.2} do you mean...{w=0.5} it's suffocating?"
                    show tenna slouch claw panic
                    tenna "I...{w=0.2} I'm suffocating those around me,{w=0.2} so they don't want to be near me?"
                    show tenna slouch panic panic flipped
                    tenna "I'm...{w=0.2} I'm really always the problem,{w=0.2} aren't I?"

                "You aren't going to be alone forever.":
                    show tenna upright pointing weak at wiggle
                    tenna "Oh, [persistent.mc],{w=0.2} you have no idea how much I want to believe that."
                    show tenna stretch shrug weak
                    tenna "But every single time I have that hope,{w=0.5} it seems the world just decides to take it away."
                    show tenna stretch shrug weak flipped
                    tenna "As if I'm bound to this reality by fate or something,{w=0.2} haha!"

        "It's important to be able to forgive yourself.":
            show tenna upright chest confused at jump
            pause 1.0
            show tenna upright chest neutral
            tenna "Haha,{w=0.2} what?"
            show tenna upright chest frown
            tenna "That's...{w=0.5} not going to help anything."
            show tenna upright pointing oh at jump
            tenna "If I did that,{w=0.2} I'd never learn from my mistakes."
            menu:
                rq "If I did that, I'd never learn from my mistakes."
                "Actually, it'll let you grow.":
                    show tenna slouch claw panic at droop
                    tenna "How?!"
                    show tenna upright chest angry at rise
                    tenna "I'd just be accepting these terrible things I've done and brushing them aside!"
                    if persistent.glitches:
                        show tenna slouch claw angry at jump
                    else:
                        show tenna slouch claw angry at shock
                    tenna "I've hurt people!{p=0.5}{noalt}*{/noalt} I've hurt people I CARE about...!"
                    show tenna slouch panic panic flipped at wiggle
                    tenna "There's absolutely NO way I can live comfortably with that until I{w=0.5}.{w=0.2}.{w=0.2}."
                    show tenna stretch shrug weak flipped
                    tenna "I don't know what!{w=0.5} But it's{w=0.2} unacceptable!!"

                "That's not what I meant.":
                    show tenna upright chest angry at rise
                    tenna "Then WHAT?"
                    if persistent.glitches:
                        show tenna slouch claw angry at jump
                    else:
                        show tenna slouch claw angry at shock
                    tenna "It's not WRONG!{p=0.5}{noalt}*{/noalt} I've hurt everyone!{w=0.5} They all abandoned me BECAUSE I hurt them!"
                    show tenna upright pointing weak at wiggle
                    tenna "I even hurt YOU,{w=0.2} someone who was a total stranger to me not too long ago."
                    show tenna slouch panic panic
                    tenna "Just because I didn't want to let go."

        "...":
            pass

    show tenna upright back panic flipped at jump
    tenna "Forget it!{p=0.5}{noalt}*{/noalt} I don't want to talk about this right now."
    if persistent.glitches:
        show tenna stretch shrug weak
    else:
        show tenna stretch shrug weak at shaking
    tenna "Last thing I need to be doing is saddling YOU with MORE of MY problems,{w=0.2} haha..."

    ## AUTOSAVE
    $ renpy.save("mainfile")
    
    ### TO SPAMTENNA OR BATTENNA OR TRIPLE ENDING
    if itm_ring in inventory:
        show tenna upright back frown at jump
        tenna "Anyway, [persistent.mc]..."
        show tenna upright back nose
        stop music fadeout 1.0
        tenna_shh ".{w=0.2}.{w=0.2}."
        play ambiance cricketsA fadein 1.0
        pause 1.0
        tenna "Wait.{p=0.5}{noalt}*{/noalt} [persistent.mc]."
        show tenna upright chest panic at jump
        tenna "That, um.{p=0.5}{noalt}*{/noalt} Ring you're wearing.{w=0.2}.{w=0.2}."
        show tenna upright back panic at wiggle
        tenna "Where, haha...{w=0.5} where did you get that...?"
        show tenna upright back smile
        tenna "There's only..."
        pause 1.0
        show tenna stretch shrug weak flipped at jump
        tenna "Haha,{w=0.2} um...{p=0.5}{noalt}*{/noalt} Don't take this the wrong way,{w=0.2} but--"
        show tenna upright back panic at wiggle
        tenna "You weren't...{w=0.2} seeing someone else while I was gone,{w=0.2} were you...?"
        show tenna stretch shrug smile flipped at jump
        tenna "Haha, oh,{w=0.2} nevermind!{p=0.5}{noalt}*{/noalt} What a ridiculous thing for me to suggest!"
        show tenna stretch shrug weak flipped
        tenna "It's a stupid ring!{w=0.2} We're in a dump!{p=0.5}{noalt}*{/noalt} You could have found that ANYWHERE..."
        show tenna at wiggle
        tenna "And I wasn't even gone THAT long--{nw=0.2}"
        show tenna upright chest panic at jump
        extend " well,{w=0.2} I.{nw=0.5}"
        show tenna upright back panic at wiggle
        extend "{p=0}{noalt}*{/noalt} I know I'm the one who{w=0.2} called things off and all."
        if persistent.glitches:
            show tenna upright pointing weak
        else:
            show tenna upright pointing weak at shaking
        tenna "But I promised I'd be back!"
        if ten_care:
            show tenna upright back frown
            tenna "Was I really not good enough...?"
            show tenna upright back nosed flipped
            tenna "{cps=60}Maybe I wasn't fast enough--{p=0.2}{noalt}*{/noalt} I'm sorry, I really should have done all this sooner...{/cps}"
            show tenna upright pointing weak
            tenna "{cps=60}Self-improvement takes time,{w=0.2} you know?{p=0.2}{noalt}*{/noalt} Even now, I'm still...{/cps}"
        else:
            show tenna upright back panic
            tenna "Ah,{w=0.2} but...{p=0.5}{noalt}*{/noalt} You...{w=0.2} wanted to call things off now,{w=0.2} right?"
            show tenna stretch shrug smile
            tenna "I...{w=0.2} haha,{w=0.2} so it's really POINTLESS for me to be thinking these kinds of things...!"
            show tenna stretch shrug weak flipped
            tenna "{cps=60}Didn't I just say a relationship wasn't a good idea, anyway?{/cps}"
            show tenna upright chest panic
            tenna "{cps=60}Haha...{w=0.2} hahaha...{w=0.2} no,{w=0.2} no!{p=0.5}{noalt}*{/noalt} I'm fine,{w=0.2} really!!{/cps}"

        menu tenend_choice:
            rq "This may decide your ending.\n{noalt}*{/noalt} Proceed with caution."
            "Lie\n{size=-10}{color=#aaaaaa}(stick with Tenna){/color}{/size}":
                "If you choose this option,{w=0.2} you will lock into the ending with only Tenna."
                menu:
                    rq "(If you choose this option, you will lock into the ending with only Tenna.)"
                    "Yes":
                        pass
                    "No":
                        jump tenend_choice

                "You tell Tenna it's nothing,{w=0.2} just something you found while looking for him."
                show tenna upright back nose at yreset
                tenna "Oh...{nw=0.5}"
                show tenna panic flustered at jump
                stop ambiance
                extend "{p=0}{noalt}*{/noalt} O-{w=0.1} oh!{w=0.2} Of course!"
                if persistent.glitches:
                    show tenna stretch shrug weak
                else:
                    show tenna stretch shrug weak at shaking
                tenna "Haha,{w=0.2} and here I am,{w=0.5} jumping to unnecessary conclusions!"
                show tenna upright back frown at droop
                tenna "Sorry about that...{w=0.5} I should have known I can trust you to be honest with me."

            "Confess\n{size=-10}{color=#aaaaaa}(stick with Spamton){/color}{/size}":
                "If you choose this option,{w=0.2} you will lock out of all endings with Tenna."
                menu:
                    rq "(If you choose this option, you will lock out of all endings with Tenna.)"
                    "Yes":
                        pass
                    "No":
                        jump tenend_choice

                $ ten_success = False
                $ ten_failed = True
                "You admit you ended up stumbling upon someone else while Tenna was gone."
                show tenna upright back nose at yreset
                tenna_shh ".{w=0.5}.{w=0.5}."
                show tenna upright back panic
                tenna "Ah."
                tenna "Ahaha."
                show tenna upright back neutral flipped at jump
                tenna "Okay.{w=0.5} Sure.{w=0.5} That's fine."
                show tenna upright back angry flipped at rise
                tenna "That's...{w=0.5} FINE...!"
                if ten_care:
                    show tenna stretch shrug smile flipped at jump
                    tenna "It's perfectly normal to want to interact with other people!{p=0.5}{noalt}*{/noalt} I'd do it too,{w=0.2} if I was ABLE to."
                    show tenna upright back angry flipped at wiggle
                    tenna "Even if they are people who think a good gift for a FRIEND is a...{w=0.5} RING, of ALL things,{w=0.2} hahaha!!"
                    show tenna upright pointing smile at jump
                    tenna "That's all this is,{w=0.5} right?"
                    show tenna upright chest smile
                    tenna "You just made a new FRIEND while waiting for me,{w=0.5} right?"
                    show tenna upright pressed smile at rise
                    tenna "Haha,{w=0.2} of course it is!{p=0.5}{noalt}*{/noalt} I don't know why I'm worrying otherwise!"
                    show tenna upright back panic
                    tenna_shh ".{w=0.2}.{w=0.2}."
                    show tenna upright pointing weak at droop
                    tenna "Oh,{w=0.2} don't give me THAT look.{p=0.5}{noalt}*{/noalt} PLEASE not THAT look."
                    pause 1.0                    
                else:
                    show tenna upright chest angry at jump
                    tenna "You didn't wanna stick with me anyway,{w=0.2} right?"
                    show tenna stretch shrug smile
                    tenna "You just said we should go our separate ways."
                    show tenna stretch shrug smile flipped at jump
                    tenna "Guess that's on me for expecting something else at some point,{w=0.2} haha!{p=0.5}{noalt}*{/noalt} Hahaha!"
                    show tenna upright chest angry flipped
                show tenna upright chest angry at jump
                tenna "You know what?{nw=0.2}"
                if persistent.glitches:
                    show tenna slouch claw angry at jump
                    extend " FINE!{nw=0.5}"
                    show tenna at jump
                else:
                    show tenna slouch claw angry at shock
                    extend " FINE!{nw=0.5}"
                    show tenna at shock
                extend "{p=0}{noalt}*{/noalt} NEVERMIND!"
                show tenna upright chest angry
                tenna "Just leave me alone to die by myself like{nw}"
                if persistent.glitches:
                    show tenna slouch claw angry at jump
                else:
                    show tenna slouch claw angry at shock
                extend " EVERYONE ELSE ALREADY HAS!"
                if persistent.glitches:
                    show tenna upright pointing weak
                else:
                    show tenna upright pointing weak at shaking
                tenna "See if I care!!"

                ### TRIPLE HEARTBREAK
                $ renpy.music.set_volume(0.0, channel='ambiance')
                call heartbreak_triple_ani from _call_heartbreak_triple_ani
                $ renpy.music.set_volume(1.0, channel='ambiance')

                show tenna stretch shrug smile flipped at jump
                tenna "I don't know why I even bothered TRYING!"
                stop ambiance fadeout 2.0
                play sfx runaway
                hide tenna with easeoutright
                pause 2.0
                "Tenna ran away."
                "Seems he might not ever come back this time..."
                pause 1.0
                play music dump
                jump ex_tenhouse

            "Bring Spamton here":
                "If you choose this option,{w=0.2} you may get the ending with Tenna and Spamton or another ending."
                menu:
                    rq "(If you choose this option, you may get the ending with Tenna and Spamton or another ending.)"
                    "Yes":
                        $ end_spamtenna = "started"

                        "You told Tenna to wait here."
                        call tenna_waiting from _call_tenna_waiting
                        "You trudged off back to the side of the Dark World where you met Spamton."
                        pause 1.0
                        scene junkspam with Dissolve(1.0)
                        play music dump
                        pause 1.0
                        jump spam_interact

                    "No":
                        jump tenend_choice

            "Lead to \"Mike\"" if mke_success:
                "If you choose this option,{w=0.2} you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\""
                menu:
                    rq "(If you choose this option, you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\")"
                    "Yes":
                        $ end_battenna = "started"

                        "You told Tenna to follow you."
                        call tenna_waiting from _call_tenna_waiting_1
                        "You led Tenna back to the side of the Dark World where you met \"Mike,\"{w=0.2} but told Tenna to wait out of sight for a bit."
                        pause 1.0
                        scene junkyard5 with Dissolve(1.0)
                        play music dump
                        pause 1.0
                        jump mike_interact

                    "No":
                        jump tenend_choice

    ### TO BATTENNA ENDING
    elif mke_success:
        "You belatedly remembered that there was somebody else you found in the Dark World."
        show tenna upright chest neutral at jump
        tenna "Oh,{w=0.2} [persistent.mc]?{p=0.5}{noalt}*{/noalt} Did you want to tell me something?"
        
        menu tenend_choice2:
            rq "Oh,{w=0.2} [persistent.mc]?\n{noalt}*{/noalt} Did you want to tell me something?"
            "Lead him to \"Mike\"":
                "If you choose this option,{w=0.2} you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\""
                menu:
                    rq "(If you choose this option, you may get the ending with Tenna and \"Mike\" or pivot to the ending with only \"Mike.\")"
                    "Yes":
                        $ end_battenna = "started"

                        "You told Tenna to follow you."
                        call tenna_waiting from _call_tenna_waiting_2
                        "You led Tenna back to the side of the Dark World where you met \"Mike,\"{w=0.2} but told Tenna to wait out of sight for a bit."
                        pause 1.0
                        scene junkyard5 with Dissolve(1.0)
                        play music dump
                        pause 1.0
                        jump mike_interact

                    "No":
                        jump tenend_choice2

            "Do not":
                "If you choose this option,{w=0.2} you will lock into the ending with only Tenna."
                menu:
                    rq "(If you choose this option, you will lock into the ending with only Tenna.)"
                    "Yes":
                        "You decided things are fine as they are."

                    "No":
                        jump tenend_choice2


######################################################
##### TRANSITION TO TENNA ONLY ENDING
label ending_tenna_only:
    show tenna upright back frown at yreset
    pause 1.0
    if ten_cancel:
        play music faintcourageSo
    show tenna at droop
    tenna "Well.{p=0.5}{noalt}*{/noalt} [persistent.mc]?{w=0.2} If nothing else...{w=0.5} can I at least make it up to you?"
    if ten_cancel:
        tenna "About,{w=0.2} you know.{p=0.5}{noalt}*{/noalt} Lying to you before,{w=0.2} and everything."
    show tenna upright chest confused at jump
    tenna "Or--{w=0.2} try my best to, anyway,{w=0.2} haha!{p=0.5}{noalt}*{/noalt} Can't promise it'll be any good."
    show tenna upright pointing smile at jump
    tenna "Just forget about..."
    pause 1.0
    show tenna upright pointing weak at droop
    tenna "Oh,{w=0.2} wait.{nw=0.5}"
    show tenna upright chest frown
    extend "{p=0}{noalt}*{/noalt} Telling you to forget what I did earlier would just be repeating the same problem."
    show tenna stretch shrug smile at jump
    tenna "Whoopsie daisy,{w=0.2} haha!{p=0.2}{noalt}*{/noalt} I'm getting there,{w=0.2} I promise!"
    show tenna upright pointing weak at jump
    tenna "See,{w=0.2} I even noticed where I screwed up this time...!{p=0.5}{noalt}*{/noalt} Haha..."
    show tenna upright chest frown
    pause 1.0
    show tenna upright back frown at droop
    tenna "I'm not really sure HOW I'll make it up to you..."
    show tenna upright pointing oh at jump
    tenna "Hey,{w=0.2} how's about since you're the one I'm doing something for,{w=0.2} YOU should be in charge of that decision!"
    show tenna upright chest neutral
    tenna "If we're going to be stuck here for a while,{w=0.2} then we might as well do something to get comfy with each other."
    "An idea springs to mind..."
    show tenna upright pointing oh at jump
    tenna "Hm-hmm?{w=0.2} What's that look?{p=0.2}{noalt}*{/noalt} Did you already come up with something?"
    play sfx sparkleglock
    show tenna upright pressed smile at jump
    $ _history = False
    if persistent.glitches:
        tenna_shh "{image=txt_greatG}{alt}Great!{/alt}{nw=0.5}"
    else:
        tenna_shh "{image=txt_great}{alt}Great!{/alt}{nw=0.5}"
    $ _history = True
    if persistent.glitches:
        tenna "{image=txt_greatG}{alt}Great!{/alt}{fast}{p=0}{noalt}*{/noalt} You're really something else,{w=0.2} you know that?"
    else:
        tenna "{image=txt_great}{alt}Great!{/alt}{fast}{p=0}{noalt}*{/noalt} You're really something else,{w=0.2} you know that?"
    show tenna upright pointing smile at jump
    tenna "Alrighty, then!{w=0.5} What say you,{w=0.2} [persistent.mc]?"
    "You suggest that Tenna follows you to the other side of the Dark World, first."
    show tenna panic flustered at jump
    tenna "Oh!{w=0.2} You're keeping it a surprise...?"
    show tenna stretch shrug smile at jump
    tenna "Well,{w=0.2} that's fine by me!{w=0.2} I, for one, happen to LOVE{nw}"
    play sfx ten_surprise
    if persistent.glitches:
        extend " {image=txt_surpriseG}{alt}surprise{/alt}s!"
    else:
        extend " {image=txt_surprise}{alt}surprise{/alt}s!"
    show tenna upright pointing oh at jump
    tenna "Lead the way,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} I trust you."
    stop music fadeout 2.0
    scene black with Dissolve(2.0)
    play sfx waterwalk
    pause 1.0
    "You guide Tenna through the darkness to the other side of the dump, where you found that mattress."

    ### TRANSITION TO UNIVERSAL ENDING 
    $ end_tenna = True
    jump ending_universal

    
######################################################
##### call this for transitioning to the other ends
label tenna_waiting:
    stop ambiance
    show tenna slouch claw panic at jump
    tenna "Huh?"
    show tenna upright chest confused at rise
    tenna "Um.{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} sure, [persistent.mc]."
    show tenna upright chest neutral
    "You explain how you met someone he might want to see."
    show tenna slouch claw panic at jump
    tenna "What--{w=0.5} so you DID meet someone?"
    show tenna upright chest frown
    tenna "I...{w=0.2} How is that even possible?{p=0.5}{noalt}*{/noalt} I haven't seen another person besides you since I got here!"
    show tenna upright back panic
    tenna "Well,{w=0.2} not...{p=0.5}{noalt}*{/noalt} Not anyone LIVING,{w=0.5} anyway."
    show tenna upright back frown at droop
    tenna "..."
    pause 1.0
    show tenna upright pointing weak at jump
    if end_battenna == "started":
        tenna "A-{w=0.1} anyway!{p=0.5}{noalt}*{/noalt} Lead the way,{w=0.2} [persistent.mc]!"
        stop music fadeout 1.0
    else:
        tenna "Don't, ah...{w=0.5} Don't take too long,{w=0.2} okay?"
    play sfx waterwalk
    scene black with Dissolve(2.0)
    $ rightclick_icon = False
    return


######################################################
##### TENNA BAD END
label ending_tenna_bad:
    tenna "{cps=25}I'm...{/cps}{nw=0.1}"
    tenna "{cps=25}I'll just...{/cps}{nw=0.2}"
    pause 1.0
    show tenna upright back nosed flipped
    pause 1.0

    ### TRIPLE HEARTBREAK
    call heartbreak_triple_ani from _call_heartbreak_triple_ani_1

    tenna "I'm leaving."
    show tenna upright back nosed at tenpos_left with ease
    pause 1.0
    tenna "You're a good person, [persistent.mc].{nw=0.5}"
    show tenna upright back nose
    extend "{p=0}{noalt}*{/noalt} I'm not."
    show tenna upright back nosed
    tenna "Find someone who makes you happy that isn't going to hurt you."
    tenna "Please."
    tenna "You deserve the best."
    show tenna slouch claw panic flipped at jump
    tenna "I'm not saying this because I don't care about you...!"
    show tenna upright back nosed flipped
    if persistent.selflove:
        tenna "But your [persistent.selflove] would be better off with someone else."
    else:
        tenna "But you'll be better off with someone else."
    show tenna upright back nosed
    tenna "So...{w=0.5} this is goodbye."
    tenna "Don't come find me."
    show tenna upright back black
    tenna "Instead...{nw=0.5}"
    show tenna at shrinkss
    extend " I hope you find someone who can give you real love."
    stop music fadeout 2.0
    play sfx runaway
    hide tenna with easeoutleft
    pause 2.0
    "Tenna ran away."
    "Seems he might not ever come back this time..."
    pause 1.0

    if spam_failed and not mke_success:
        jump ending_none
    else:
        play music dump
        jump ex_tenhouse