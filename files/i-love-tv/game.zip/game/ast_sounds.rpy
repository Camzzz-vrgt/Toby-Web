############################################################################################################
################## SFX
define silence = "audio/sfx/sfx_silent.wav" # literally nothing (for main menu)

define bark = "audio/sfx/sfx_bark.wav" # test sound (normal)
define weird = "audio/sfx/sfx_weird.wav" # test sound ([weird])
define select = "audio/sfx/sfx_select.wav"
define menuhover = "audio/sfx/sfx_menuhover.wav"
define ding = "audio/sfx/sfx_ding.wav" # gained lp/fp
define item = "audio/sfx/sfx_item.wav" # general collect sfx
define hypnosis = "audio/sfx/sfx_hypnosis.wav" # sfx for strange item/otherwise
define click = "audio/sfx/sfx_click.wav"
define ssave = "audio/sfx/sfx_save.wav"
define datestart = "audio/sfx/sfx_datestart.wav"
define soulcrack = "audio/sfx/sfx_crack.wav"
define soulrestore = "audio/sfx/sfx_restore.wav"
define hpdrop = "audio/sfx/sfx_damage.wav"

define lot_enter = "audio/sfx/sfx_lot_enter.wav"
define lot_ouch = "audio/sfx/sfx_lot_ouch.wav"
define lot_sparkle = "audio/sfx/sfx_lot_sparkle.wav"
define lot_defeatrun = "audio/sfx/sfx_lot_defeatrun.wav"
define lot_lift = "audio/sfx/sfx_lot_lift.wav"
define lot_escape = "audio/sfx/sfx_lot_escaped.wav"
define lot_doorS = "audio/sfx/sfx_lot_door.wav"
define tvstatic = "audio/sfx/sfx_tvstatic.wav"
define tvturnoff1 = "audio/sfx/sfx_tvturnoff.wav"
define tvturnoff2 = "audio/sfx/sfx_tvturnoff2.wav"

define bwaa = "audio/sfx/sfx_bwaa.wav" # soul animation in intro
define step1 = "audio/sfx/sfx_step1.wav"
define step2 = "audio/sfx/sfx_step2.wav"
define stepping = "audio/sfx/sfx_stepping.wav" # multiple steps
define drop = "audio/sfx/sfx_drop.wav"
define recordscratch = "audio/sfx/sfx_recordscratch.wav"
define plop = "audio/sfx/sfx_plop.wav" # og "snd_wing"
define falling = "audio/sfx/sfx_fall.wav"
define crickets = "audio/sfx/sfx_crickets.wav"
define whip = "audio/sfx/sfx_whip.wav"
define whipcrack = "audio/sfx/sfx_whip_hard.wav"
define swish = "audio/sfx/sfx_whip_swing.wav"
define badexplosion = "audio/sfx/sfx_badexplosion.wav"
define splat = "audio/sfx/sfx_splat.wav"
define runaway = "audio/sfx/sfx_run.wav" # undertale run sfx
define slideaway = "audio/sfx/sfx_slide.wav"
define tech = "audio/sfx/sfx_technical.wav"
define sfix = "audio/sfx/sfx_fix.wav"
define ringring = "audio/sfx/sfx_rotaryring.wav"
define pickup = "audio/sfx/sfx_pickup.wav"
define hangup = "audio/sfx/sfx_hangup.wav"
define cloth = "audio/sfx/sfx_shuffle.wav" # clothing moving
define stardrop = "audio/sfx/sfx_stardrop.wav" # for starwalker disappear
define doorclose = "audio/sfx/sfx_doorclose.wav"
define dooropen = "audio/sfx/sfx_dooropen.wav"
define waterwalk = "audio/sfx/sfx_waterwalk.wav"
define defeat = "audio/sfx/sfx_defeat.wav"
define sparkleglock = "audio/sfx/sfx_sparkle.wav"
define sparklegem = "audio/sfx/sfx_sparkle2.wav"
define sparklehelp = "audio/sfx/sfx_sparkle_help.wav"
define gulp = "audio/sfx/sfx_gulp.wav"
define digging = "audio/sfx/sfx_dig.wav"
define dighit = "audio/sfx/sfx_dighit.wav"
define awkwardS = "audio/sfx/sfx_awkward.wav"
define glass1 = "audio/sfx/sfx_glassbreak.wav"
define glass2 = "audio/sfx/sfx_glassshatter.wav"
define rip1 = "audio/sfx/sfx_rip1.wav"
define rip2 = "audio/sfx/sfx_rip2.wav"
define rip3 = "audio/sfx/sfx_rip3.wav"
define weirdeffect = "audio/sfx/sfx_weirdeffect.wav"
define pipisS = "audio/sfx/sfx_pipis.wav"
define slam = "audio/sfx/sfx_slam.wav"
define beatup = "audio/sfx/sfx_beatup.wav"
define leap = "audio/sfx/sfx_leap.wav"
define knock = "audio/sfx/sfx_knock.wav"
define bump = "audio/sfx/sfx_bump.wav"
define rumble = "audio/sfx/sfx_rumble.wav"
define cymbal = "audio/sfx/sfx_cymbal.wav"
define disappear = "audio/sfx/sfx_disappear.wav"


######################################################
##### AMBIANCE
define wind = "audio/sfx/amb_wind.wav"
define city = "audio/sfx/amb_city.wav"
define cityQ = "audio/sfx/amb_city_quiet.wav"
define ocean = "audio/sfx/amb_ocean.wav"
define cricketsA = "audio/sfx/amb_crickets.wav"
define lightamb = "audio/sfx/amb_lightworld.wav"


######################################################
##### TENNA-SPECIFIC
### voice
define echo1 = "audio/sfx/sfx_echo_ten.wav" # intro echos
define echo2 = "audio/sfx/sfx_echo_ten2.wav"

### tenna shriek
define beep = "audio/sfx/sfx_beep.wav"
define beepSh = "audio/sfx/sfx_beep_short.wav"
define beepLo = "audio/sfx/sfx_beep_loud.wav"

### text
define ten_lightner = "audio/sfx/ten_lightner.wav" # sparkle ; og "snd_magicsprinkle_ch1"
define ten_quizzes = "audio/sfx/ten_quizzes.wav" # vibraphone ; og "snd_ftext_vibraphones"
define ten_laughtrack = "audio/sfx/ten_laughtrack.wav" # og "snd_laughtrack_short_bc_temp"
define ten_names = "audio/sfx/ten_names.wav" # the muffled voice ; og "snd_ftext_names"
define ten_fave = "audio/sfx/ten_favorite.wav" # cha-ching ; og "snd_ftext_prize"
define ten_first = "audio/sfx/ten_first.wav" # bling ; og "snd_coin"
define ten_heyevery = "audio/sfx/ten_heyevery.wav" # hey every leitmotif ; og "snd_ftext_enter"
define ten_aww = "audio/sfx/ten_aww.wav" # crowd says "aww" ; og "snd_audience_aww"
define ten_sax = "audio/sfx/ten_sax.wav" # shadowguy sfx ; og "snd_shadowman_sax_long"
define ten_hope = "audio/sfx/ten_hope.wav" # his theme ; og "snd_ftext_brother"
define ten_cheer = "audio/sfx/ten_cheer.wav" # cheering/clapping crowd ; og "snd_crowd_cheer_single"
define ten_rock = "audio/sfx/ten_rock.wav" # rock sfx ; og "snd_cd_bagel_susie"
define ten_paradise = "audio/sfx/ten_paradise.wav" # paradise, paradise sfx ; i edited this one
define ten_perfect = "audio/sfx/ten_perfect.wav" # paradise, paradise sfx ; i edited this one
define ten_surprise = "audio/sfx/ten_surprise.wav" # birthday noisemaker


######################################################
##### SPAMTON-SPECIFIC
define spamlaugh = "audio/sfx/voice_spamlaugh.wav"
define spamlaughL = "audio/sfx/voice_spamlaugh_long.wav"


############################################################################################################
################## MUSIC
### everyone
define dump = "audio/music/dump.wav"

### gaster
define anotherhim = "audio/music/anotherhim.wav"
define gasterwaltz = "audio/music/gasterwaltz.wav"
define drone = "audio/music/drone.wav"

### tenna
define sponsors = "audio/music/sponsors.wav"
define boardplz = "audio/music/boardplz.wav"
define quiz = "audio/music/quiz.wav"
define quizL = "audio/music/quiz_lofi.wav"
define greenroom = "audio/music/greenroom.wav"
define faintcourage = "audio/music/faintcourage.wav"
define faintcourageSo = "audio/music/faintcourage_soft.wav"
define faintcourageSl = "audio/music/faintcourage_slow.wav"
define bigcityboard = "audio/music/bigcityboard.wav"
define southoftheborder = "audio/music/southoftheborder.wav"
define pushingbuddies = "audio/music/pushingbuddies.wav"
define paradise = "audio/music/paradise.wav"

### spamton
define spamtonO = "audio/music/spamton.wav"
define spamtonL = "audio/music/spamton_lofi.wav"
define digitalroots = "audio/music/digitalroots.wav"
define dialtone = "audio/music/dialtone.wav"
define dialtoneS = "audio/music/dialtone_slow.wav"
define heyevery = "audio/music/heyevery.ogg"
define nowsyourchance = "audio/music/nowsyourchancetobea.wav"
define bigshotL = "audio/music/bigshot_lofi.wav"

### mike
define airwavesL = "audio/music/airwaves_lofi.wav"
define volumeadjustment = "audio/music/volumeadjustment.wav"
define sneaking = "audio/music/sneaking.wav"
define lostgirl = "audio/music/lostgirl.wav"
define lostgirlS = "audio/music/lostgirl_slow.wav"
define catswing = "audio/music/catswing.wav"

### memoryshards
define cyberworldM = "audio/music/cyberworld_midi.wav"
define flashback = "audio/music/flashback.wav"
define flashbackS = "audio/music/flashback_slow.wav"
define spamtonS = "audio/music/spamton_slow.wav"
define glowingsnow = "audio/music/glowingsnow.wav"
define glowingsnowS = "audio/music/glowingsnow_slow.wav"
define greenroomB = "audio/music/greenroom_box.wav"
define dumpS = "audio/music/dump_slow.wav"

### main menu
init python:
    def replace_music(filename):
        if not persistent.playthru:
            if filename == config.main_menu_music and persistent.mainskip and persistent.route == "Tenna":
                return tvworld
            elif filename == config.main_menu_music and persistent.mainskip and persistent.route == "Spamton":
                return dealgonewrong
        else:
            if filename == config.main_menu_music and persistent.mainscreen == "Tenna":
                return tvworld
            elif filename == config.main_menu_music and persistent.mainscreen == "Spamton":
                return dealgonewrong
        return filename

define config.audio_filename_callback = replace_music

define tvworld = "audio/music/tvworld.wav"
define dealgonewrong = "audio/music/dealgonewrong.wav"