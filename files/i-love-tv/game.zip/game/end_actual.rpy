############################################################################################################
################## UNIVERSAL ENDING
label ending_universal:
    pause 1.0
    scene junkyard4 with Dissolve(1.0)
    pause 1.0

    ### TRIPLE END
    if end_triple_mke and end_triple_spam and end_triple_ten:
        $ multichar = True
        show tenna upright back blank flipped at tenpos_right
        show mike standing pout at mikepos_left
        with Dissolve(1.0)
        pause 1.0
        show tenna upright back blank at jump
        pause 1.0
        show tenna upright pointing oh at jump
        tenna "Oh, [persistent.mc]!{p=0.2}{noalt}*{/noalt} You're here!"
        show tenna upright back neutral at jump
        tenna "Haha,{w=0.2} I didn't realize..."
        $ multichar = False
        "You explained you invited all three of them to come meet you here."
        $ multichar = True
        show tenna upright chest frown
        tenna "...{w=0.2} Is...{w=0.5} Spamton not coming?"
        $ multichar = False
        "You told Tenna that Spamton said he had to do something first."
        $ multichar = True
        show tenna upright back frown at droop
        tenna "Oh."
        show tenna upright back neutral at jump
        tenna "Then,{w=0.2} we'll just have to wait for him!"
        show tenna upright back blank flipped at jump
        pause 2.0
        show mike standing conflicted
        mike_shh "{w=0.2}.{w=0.2}.{w=0.2}."
        pause 1.0
        play music lostgirlS
        show mike standing sigh
        mike "Tenna?"
        pause 2.0
        show tenna upright chest blank flipped at jump
        tenna "What is it,{w=0.2} Mike?"
        pause 1.0
        show mike standing conflicted at droop
        mike "I'm,{w=0.5} sorry about earlier."
        show mike standing nervous
        mike "You, ah,{w=0.2} could tell I was talkin' outta my ass,{w=0.5} couldn't ya?"
        pause 1.0
        show tenna upright back frown flipped at droop
        tenna "It WAS pretty obvious."
        show tenna stretch shrug weak flipped at wiggle
        tenna "Haha, it was written all over your face!"
        show tenna upright back blank flipped at jump
        show mike tie nervous at wiggle
        mike "...{w=0.2} hahaha, that.{w=0.5} Makes sense."
        show mike standing sigh at jump
        mike "Look,{w=0.2} I...{w=0.5} I didn't really tell you everything before...{p=0.5}{noalt}*{/noalt} About how I got here."
        pause 1.0
        show tenna upright chest blank flipped at jump
        tenna "Does that have to do with anything?"
        show mike standing nervous
        mike "A lot,{w=0.2} actually."
        pause 2.0
        show mike standing sigh
        mike "I didn't actually have any idea where you were.{w=0.5} Somebody else had to tell me where you ended up,{w=0.2} and they're the one who led me here to begin with."
        show mike standing conflicted
        mike "But they told me I had a week to find you AND get back home...{p=0.5}{noalt}*{/noalt} If I didn't do that in time,{w=0.2} well..."
        show mike standing nervous
        mike "...{w=0.2} That,{w=0.2} they never explained to me."
        show mike standing sigh
        mike "So, if we were going to be STUCK here, I was worried..."
        pause 1.0
        show mike at droop
        mike "I was worried I wasn't going to make it{w=0.5} and I didn't know how to explain that to you.{p=0.5}{noalt}*{/noalt} Not now."
        show mike tie avert at wiggle
        mike "It'll probably be okay now,{w=0.2} since we're going home,{w=0.2} but..."
        show mike standing nervous at jump
        mike "Sorry,{w=0.2} for not being clear about it upfront.{p=0.5}{noalt}*{/noalt} I was tryin' to avoid making you mad,{w=0.2} but..."
        show mike standing sigh at droop
        mike "Ah,{w=0.2} forget it."
        pause 2.0
        show tenna upright back confused at jump
        pause 1.0
        show tenna upright chest frown at jump
        tenna "Mike."
        mike "...{w=0.5} What?"
        pause 1.0
        show tenna upright back frown at jump
        tenna "It's okay."
        show tenna upright back confused at wiggle
        tenna "I apologize for getting snippy and running away."
        show tenna stretch shrug smile at jump
        tenna "In a way,{w=0.2} I didn't want to upset YOU more,{w=0.2} either...{p=0.5}{noalt}*{/noalt} I've already lashed out at you enough over the years,{w=0.2} haven't I?"
        show tenna stretch shrug weak at wiggle
        tenna "Haha.{w=0.5} I should have learned that clarity helps significantly more by now..."
        show mike standing angry at jump
        mike "Oh,{w=0.2} don't even with that."
        show tenna upright chest panic at jump
        show mike tie awkward at wiggle
        mike "I mean--{w=0.2} look,{w=0.2} you've got every right to be mad at me.{p=0.5}{noalt}*{/noalt} I'm the guy who wasn't clear to start off with."
        mike "What...{nw=0.5}"
        show mike standing wink at jump
        extend " what matters most is that we figured it out now,{w=0.2} right?"
        show tenna upright chest neutral at jump
        pause 2.0
        show tenna slouch claw panic at jump
        show mike standing indifferent at jump
        spamton "HEY EVERY{space=150}!{p=0.5}{noalt}*{/noalt} DID I MISS ANY [[important plot points] ?!"
        show mike standing pout at mikepos_center with ease
        pause 0.5
        show spamton standing up smile flipped at spampos_left with easeinleft
        pause 1.0
        show spamton standing up glare flipped
        spamton "WOW,{w=0.2} YOU TWO LOOK [[pissed] TO SEE ME."
        show tenna upright back angry at wiggle
        tenna "Your timing is...{w=0.5} IMPECCABLE, you know."
        show tenna upright pointing oh at jump
        tenna "Sometimes people like to have serious conversations in PRIVATE?"
        show mike standing conflicted at leanright
        mike "T-{w=0.1} Tenna,{w=0.2} ya don't have to..."
        if persistent.glitches:
            show spamton standing up stare flipped
        else:
            show spamton standing up stare flipped at shakingcg
        spamton "YOU KNOW [[CRTs],{w=0.2} IF YOU WANT ME [[evicted from this location] YOU COULD JUST SAY SO!!"
        show tenna slouch claw panic at jump
        tenna "Wait, no,{w=0.2} Spammy-- uh,{w=0.2} Spamton!{p=0.5}{noalt}*{/noalt} That isn't what I meant!"
        show spamton standing up frowne flipped at jump
        spamton "THEN [[Explain yourself] ?"
        show spamton crazy frantic at xwiggle
        spamton "SEEMS LIKE YOU'D RATHER BE WITH [[Get Help With Your Gambling Addiction] THAN ME!"
        show tenna slouch panic panic at jump
        tenna "No,{w=0.2} no!{p=0.5}{noalt}*{/noalt} I'm sorry,{w=0.2} that REALLY wasn't my intention!"
        show tenna upright back panic at jump
        show spamton standing up glare flipped at jump
        tenna "I just didn't appreciate you interrupting the mood like that...{w=0.5} Mike and I were having a nice conversation."
        show tenna upright pointing weak at wiggle
        tenna "But,{w=0.2} please,{w=0.5} I want more than anything for all of us to get along!"
        show tenna upright back frown
        tenna "If I can consider you ALL even just my closest friends, if nothing else,{w=0.5} that'd make me the happiest TV alive."
        show tenna upright back awkward
        tenna "Not that I'd turn down an offer for anything more-- BUT it's not required at all, haha!!"
        show tenna upright pointing weak at jump
        tenna "Am I making sense?{w=0.5} Should I say it some other way?"
        pause 1.0
        show spamton slouch down frown flipped at droop
        pause 1.0
        spamton "No.{p=0.5}{noalt}*{/noalt} You're fine."
        show spamton slouch down static flipped
        spamton "[[ Sorry.{w=0.5} For snapping at you. ]"
        show spamton standing tilt stare flipped at rise
        spamton "I'M [[Too used to ] EXPECTING [[the absolute worst] OUTTA PEOPLE."
        show tenna upright back frown at jump
        show mike standing nervous
        pause 1.0
        show spamton standing up frown flipped at jump
        spamton "BUT THAT'S ON ME."
        show spamton crazy laugh at xwiggle
        spamton "[[After all,] ALL OF {noalt}US{/noalt}{alt}us{/alt} ARE IN {noalt}[[H3LL]{/noalt}{alt}hell{/alt},{w=0.2} EAHEHA!!"
        show tenna upright chest angry at rise
        tenna "Oh,{w=0.2} come on, now!"
        show tenna upright chest blank at jump
        show mike standing sigh at droop
        mike "No, wait,{w=0.2} he's kind of got a point.{p=0.5}{noalt}*{/noalt} At least for the three of us."
        show tenna upright pointing weak at jump
        show spamton standing up frown flipped at jump
        tenna "Mike!{p=0.2}{noalt}*{/noalt} Why are you siding with him on THIS?"
        show mike tie nervous at jump
        mike "I mean--{w=0.2} think about it!"
        show mike standing angry at jump
        mike "We all suck in our own ways!!"
        mike "I'm a jerk who does things without thinking and says a lotta words that don't mean anything--"
        show mike arms avert
        mike "He's just generally an asshole--"
        show spamton standing up glaree flipped
        spamton "MEAN?"
        show mike arms freakout at jump
        mike "And, Tenna,{w=0.2} you--!"
        show mike standing nervous at rise
        mike "You're...{w=0.2} really, REALLY bad at thinking outside of yourself."
        show tenna upright back nose at jump
        show mike arms freakout at jump
        mike "Look, I know that's mean to say,{w=0.2} but it's true...!"
        show mike standing nervous
        mike "So,{w=0.2} I...{w=0.5} I'm sorry that you got stuck out here."
        show mike standing sigh at droop
        mike "But it's not my fault!"
        show mike standing conflicted
        mike "Tenna, when we get back...{p=0.5}{noalt}*{/noalt} I wanna do things differently.{w=0.2} I don't wanna follow your every whim."
        show mike standing angry at jump
        mike "And I'm TAKING A BREAK!"
        show tenna panic panic at shrink
        tenna "D-{w=0.1} didn't you already quit...?{p=0.2}{noalt}*{/noalt} Haha..."
        show mike standing nervous
        mike "Oh,{w=0.2} right.{p=0.5}{noalt}*{/noalt} I forgot about that."
        show mike standing angry at jump
        mike "WHATEVER!{p=0.5}{noalt}*{/noalt} My point is,{w=0.2} that guy's got a point and you should listen to him instead of arguing about it!"
        show mike standing pout
        mike "Can't believe you're making me side with this creepy jerk just to get that through your plastic skull."
        show tenna upright back nose at jump
        show spamton standing up frowne flipped
        pause 2.0
        show mike standing conflicted at droop
        mike "Uh.{p=0.5}{noalt}*{/noalt} Did I take it too far,{w=0.2} or...?"
        show tenna upright chest awkward flipped at jump
        tenna "No,{w=0.2} not that!"
        show tenna upright back frown flipped at shrinks
        tenna "It's just, haha,{w=0.5} everything's starting to sink in..."
        show spamton standing up glaree flipped at jump
        spamton "ONLY TOOK YOU [[Ten years]."
        show tenna slouch claw angry at jump
        tenna "Says the one holding a ten-year grudge!!"
        show spamton crazy smirk at xwiggle
        spamton "AS IF YOU WEREN'T??"
        show tenna upright chest frown at jump
        pause 2.0
        tenna "Okay.{p=0.5}{noalt}*{/noalt} I'll...{w=0.2} do my best.{w=0.5} For all of you."
        show tenna slouch claw angry at zreset # check transform
        tenna "So long as{nw}"
        if persistent.glitches:
            show tenna at jump
            show spamton standing up frowne flipped at jump
            show mike standing indifferent at jump
            extend " YOU TWO learn to be{nw}"
            show tenna at jump
            extend " HONEST WITH ME,{w=0.2} without having to go through fifty-some-odd{nw}"
            show tenna at jump
        else:
            show tenna at shock
            show spamton standing up frowne flipped at jump
            show mike standing indifferent at jump
            extend " YOU TWO learn to be{nw}"
            show tenna at shock
            extend " HONEST WITH ME,{w=0.2} without having to go through fifty-some-odd{nw}"
            show tenna at shock
        show mike at droop
        show spamton at droop
        extend " LOOPS!"
        show mike standing conflicted at leanleft
        mike "Y-{w=0.1} you got it,{w=0.2} boss."
        show spamton standing up glare flipped at jump
        spamton "UGH.{w=0.5} FINE,{w=0.2} [[ I suppose. ]"
        show tenna upright pressed smile at rise
        tenna "Yay!"
        show tenna at wiggle
        tenna "Now, [persistent.mc],{w=0.2} let's get this show on the road!"
        scene black with Dissolve(2.0)
        play sfx cloth
        pause 3.0
        mike "Hey,{w=0.2} watch it,{w=0.2} you {noalt}yatzy{/noalt}{alt}yahtzee{/alt}!"
        play sfx cloth
        spamton "NOT MY FAULT YOU [[smacked me] AND [[thwacked me] IN THE FACE!!"
        play sfx cloth
        tenna "Would you two quit it already?!{p=0.5}{noalt}*{/noalt} You're going to hurt [persistent.mc] if you keep fighting!!"
        alt "The three of you lay down on the mattress."
        pause 3.0
        scene uniend triple with Dissolve(2.0)
        pause 1.0
        tenna "[persistent.mc],{w=0.2} this isn't too much,{w=0.2} is it?"
        spamton "ASKING FOR [[forgiveness] NOT [[permission] ??"
        tenna "What?!{w=0.2} That's not what I..."
        tenna "[persistent.mc],{w=0.2} I can move,{w=0.2} if you'd prefer!"
        $ multichar = False
        "You tell Tenna not to worry about it."
        $ multichar = True
        tenna "Okay,{w=0.2} so long as you're certain."
        mike "This is,{w=0.2} uh,{w=0.2} okay,{w=0.2} too,{w=0.5} right?"
        $ multichar = False
        "You tell Mike that if he's comfortable,{w=0.2} it's fine with you."
        $ multichar = True
        mike "Got it."
        mike "It's not...{w=0.5} the most comfortable ever,{w=0.2} but that's mostly 'cause of the mattress,{w=0.2} so it'll have to do."
        pause 1.0
        tenna "By the way,{w=0.2} [persistent.mc]..."
        tenna "You never told us what the next part of your plan is,{w=0.2} haha."
        $ multichar = False
        "You say it's not much.{p=0.2}{noalt}*{/noalt} You'll figure it out when you get to the Light World."
        $ multichar = True
        spamton "YOU'RE REALLY [[testing my faith], [persistent.mc!u]!!"
        mike "Do we really have any other choice, anyway?"
        mike "Not like I can remember where to go outside of the Fountain..."
        tenna "It'll be fine!{p=0.5}{noalt}*{/noalt} [persistent.mc] hasn't let me down yet!"
        mike "Yeah...{w=0.5} If nothing else,{w=0.2} it'll be better than the dump."
        spamton "A REAL [[vote of confidence]!"
        scene black with Dissolve(2.0)
        pause 1.0
        spamton "JUST...{w=0.5} Don't screw this up."
        mike "We'll see ya in a little bit,{w=0.2} right, [persistent.mc]?"
        tenna "Haha,{w=0.2} please...{p=1.0}{noalt}*{/noalt} Let's go home."

    ### TENNA ONLY
    elif end_tenna:
        show tenna upright chest confused flipped at tenpos_farleft with easeinleft
        play music glowingsnow
        tenna "So...{w=0.5} What is it we're doing, exactly?"
        show tenna stretch shrug smile flipped at jump
        tenna "You still haven't told me.{p=0.5}{noalt}*{/noalt} I'm left in suspense,{w=0.2} [persistent.mc]!"
        "You point."
        show tenna upright chest neutral flipped
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        show tenna panic flustered flipped at jump
        tenna "O-{w=0.1} oh!"
        show tenna slouch whisper smug flipped
        tenna "[persistent.mc],{w=0.2} I didn't expect you to be so forward..."
        hide itemframe with easeoutbottom
        "You explain that this is his ticket out of here."
        show tenna upright chest panic flipped at jump
        tenna "Huh?"
        tenna "Ticket out of here...?"
        pause 1.0
        show tenna upright back awkward flipped at jump
        tenna "Golly, [persistent.mc],{w=0.2} are you flirting with me again?{p=0.5}{noalt}*{/noalt} I swear,{w=0.2} it's getting more vague every time!"
        "You firmly explain that you're being literal,{w=0.2} not coy."
        show tenna upright back nose flipped
        tenna "Oh."
        show tenna stretch shrug weak flipped at jump
        tenna "Oh,{w=0.2} haha,{w=0.2} of course!{w=0.5} I knew that!"
        show tenna upright back panic flipped at jump
        tenna "Though..."
        show tenna at tenpos_center with ease
        show tenna upright chest panic at jump
        tenna "If it's not too much to ask...{w=0.5} What in the WORLD are you talking about?"
        "You describe the plan as best you can,{w=0.2} telling Tenna that you'll lay down for a rest..."
        show tenna upright chest blank
        "... and you'll need physical contact from him when you fall asleep,{w=0.2} otherwise you won't be able to find him when you wake up in the Light World."
        show tenna slouch claw panic at jump
        tenna "{noalt}Wh-huh{/noalt}{alt}whuh huh{/alt}?"
        show tenna panic panic at jump
        tenna "I mean,{w=0.2} I understand your instructions just fine, but...{p=0.5}{noalt}*{/noalt} Are you sure?"
        show tenna upright back confused at jump
        tenna "With you being asleep and all,{w=0.2} it just feels a little off-kilter..."
        "You tell Tenna he could lay with you,{w=0.2} if that would make it more comfortable."
        show tenna panic flustered at jump
        tenna "[persistent.mc]!{w=0.5} You're being VERY forward right now!"
        "...{w=0.5} You meant,{w=0.2} literally lay down."
        show tenna upright back nose
        tenna_shh "..."
        show tenna stretch shrug weak at jump
        tenna "Haha,{w=0.5} maybe somebody oughta turn my parental controls back on."
        show tenna upright back confused at jump
        pause 1.0
        show tenna upright chest confused
        tenna "But,{w=0.5} you're serious about this?{p=0.5}{noalt}*{/noalt} This will help me leave this place...?"
        "You nod."
        show tenna upright back frown at jump
        pause 1.0
        tenna "Well,{w=0.2} if that's the case, I...{nw=0.5}"
        show tenna upright chest neutral at jump
        extend " I wouldn't mind doing that in the slightest,{w=0.2} [persistent.mc]."
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and Tenna follows suit."
        pause 3.0
        scene uniend tenna with Dissolve(2.0)
        pause 1.0
        tenna "Comfortable?{w=0.2} I hope so!"
        tenna "The ground here is...{w=0.2} not great, haha,{w=0.2} but I'm okay!"
        tenna "I'm really putting all my trust in you,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} I don't want to be here any more than I already have been..."
        pause 1.0
        tenna "One more thing,{w=0.2} [persistent.mc]..."
        tenna "I...{w=0.2} just wanted to say,{w=0.5} thank you.{w=0.2} Again."
        tenna "I don't know where I would be right now if it weren't for you,{w=0.2} haha."
        tenna "Everything you've done,{w=0.2} just for me...{p=0.5}{noalt}*{/noalt} It means more than all the Worlds combined."
        scene black with Dissolve(2.0)
        pause 1.0
        tenna "I just hope I'll be able to see you again."

    ### SPAMTON ONLY
    elif end_spamton:
        show spamton standing up smile flipped at spampos_left with easeinleft
        show spamton standing tilt laugh flipped at jump
        play music glowingsnow
        spamton "HERE WE ARE AT"
        show spamton standing up frowne flipped
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        pause 0.5
        show spamton at jump
        spamton "[[ Mattress Sale ] ?!"
        hide itemframe with easeoutbottom
        show spamton at spampos_center with ease
        show spamton crazy frantic at xwiggle
        spamton "[persistent.mc!u]!{p=0.2}{noalt}*{/noalt} WHATS THE [[ Big Deals on ] ?!"
        show spamton standing up frown at yreset
        "You explain how you're going to lay down on the mattress,{w=0.2} and when you wake up in the Light World,{w=0.2} you'll be able to bring him somewhere else..."
        show spamton standing glare
        "... but he will have to touch you,{w=0.2} or you'll lose him.{p=0.5}{noalt}*{/noalt} It doesn't have to be much if it makes him uncomfortable, though."
        show spamton crazy angry at xwiggle
        spamton "[persistent.mc!u],{w=0.2} YOU {noalt}SHOUOLD{/noalt}{alt}should{/alt} HAVE MENTIONED THIS [[in our Terms and Conditions]!!"
        show spamton standing up glaree at jump
        spamton "BUT [[fine].{p=0.5}{noalt}*{/noalt} [[Whatever doesn't kill] ME."
        show spamton standing tilt laugh at xwiggle
        spamton "I'M KEEPING THIS [[at an absolute minimum!!]"
        show spamton standing up glare at yreset
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and Spamton follows suit."
        pause 3.0
        scene uniend spamton with Dissolve(2.0)
        pause 1.0
        spamton "HEY [persistent.mc!u]?{p=0.5}{noalt}*{/noalt} WHATS THE [[plan B]"
        spamton "{noalt}WHAat's{/noalt}{alt}what's{/alt} [[the next part look like?]"
        "You explained that once you wake up in the Light World,{w=0.2} you'll figure something out."
        spamton "JUST [[figure something out]?!{p=0.5}{noalt}*{/noalt} YOU DIDN'T [[Always Plan Ahead] ?"
        spamton "WELL IT'S A GOOD THING I'M [[definitely] [[putting my life in your hands] !"
        spamton "NOT THAT I'VE EVER [[Scheduled] ANYTHING EITHER."
        spamton "SO I GUESS [[I'll let it slide] [[,{w=0.2} just this once.]"
        scene black with Dissolve(2.0)
        pause 1.0
        spamton "I'M REALLY [[ trusting you, ]{w=0.5} [persistent.mc!u]."
        spamton "DON'T [[Abandoned me ], TOO,{w=1.0} {cps=25}alright...?{/cps}"

    ### MIKE ONLY
    elif end_mike:
        show mike standing pout at mikepos_left with easeinleft
        play music glowingsnow
        mike_no "Hey,{w=0.2} y'know..."
        show mike standing conflicted
        mike_no "When you said you could help me leave..."
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        if persistent.glitches:
            show mike arms freakout at jump
        else:
            show mike arms freakout at shock
        mike_no "I didn't think you were gonna drag me over to a MATTRESS?!"
        hide itemframe with easeoutbottom
        show mike standing angry at mikepos_center with ease
        mike_no "You've gotta have some kind of plan,{w=0.2} right?{p=0.5}{noalt}*{/noalt} DO you have a plan??"
        if persistent.glitches:
            show mike arms avert at jump
        else:
            show mike arms avert at shock
        mike_no "You BETTER have one!!{p=0.5}{noalt}*{/noalt} Because otherwise this is a big N-O from me!!{w=0.2} Absolutely NOT!!"
        "You explain to \"Mike\" the plan,{w=0.2} wherein which you'll lay down to rest..."
        "... but he will have to be touching you when you do so,{w=0.2} or you won't be able to find him to take him home."
        show mike standing indifferent
        mike_no "..."
        show mike tie awkward at jump
        mike_no "Th-{w=0.1} that's..."
        show mike tie avert
        pause 2.0
        show mike standing nervous at jump
        mike_no "O-{w=0.1} okay.{p=0.5}{noalt}*{/noalt} If that's what I've gotta do,{w=0.2} I'll do it."
        show mike tie nervous
        mike_no "It's not like it's weird or anything,{w=0.2} it's just, uh...{w=0.5} kinda awkward."
        show mike tie awkward at jump
        mike_no "N-{w=0.1} not that,{w=0.2} I think you're doing anything to make it awkward!{w=0.2} Or that--"
        show mike tie avert
        pause 1.0
        show mike standing sigh
        mike_no "... oh,{w=0.2} forget it."
        show mike standing angry at jump
        mike_no "Whatever.{p=0.5}{noalt}*{/noalt} You--{w=0.2} lay down first,{w=0.2} and I'll just...{w=0.5} figure something out."
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and \"Mike\" follows suit."
        pause 3.0
        scene uniend mike with Dissolve(2.0)
        pause 1.0
        mike_no "Uh...{w=0.2} how's this?"
        mike_no "Fine??{w=0.2} I hope??"
        mike_no "...{w=0.5} Was that a nod?"
        mike_no "I can't see that,{w=0.2} y'know,{w=0.2} I'm not facing you!!"
        mike_no "Ah,{w=0.2} whatever.{w=0.5} It doesn't really matter.{p=0.5}{noalt}*{/noalt} You can just kick me off if you've got a real problem,{w=0.2} then."
        pause 1.0
        mike_no "So...{w=0.5} how exactly is this whole thing gonna work,{w=0.2} again?"
        "You explain that you only half-know,{w=0.2} but you're sure you'll figure it out when you wake up in the Light World."
        mike_no "Geez...{w=0.5} Real reassuring."
        mike_no "No,{w=0.2} it's alright.{w=0.2} Really.{p=0.5}{noalt}*{/noalt} I don't really have anything else I can do, anyway,{w=0.2} so...{w=0.5} I trust you."
        scene black with Dissolve(2.0)
        pause 1.0
        mike_no "Hope I'll see ya in a bit,{w=0.2} then."

    ### BATTENNA
    elif end_battenna == "done":
        $ multichar = False
        show tenna upright chest neutral flipped at tenpos_farleft with easeinleft
        show tenna upright chest confused flipped at jump
        play music glowingsnow
        tenna "Well,{w=0.2} [persistent.mc]?{w=0.5} Where's that mattress you were talking about?"
        "You point."
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        show tenna upright back smile flipped at jump
        tenna "Okay!"
        hide itemframe with easeoutbottom
        pause 1.0
        show tenna upright chest neutral flipped at tenpos_inright with ease
        show tenna upright chest confused flipped at jump
        pause 1.0
        show tenna upright pointing oh at jump
        tenna "Mike,{w=0.2} are you coming?"
        $ multichar = True
        show mike standing nervous at mikepos_inleft with easeinleft
        mike "Yeah,{w=0.2} I'm comin',{w=0.2} it's just..."
        show mike tie avert at wiggle
        mike "Is this REALLY the only way to get back?"
        show tenna upright chest confused at jump
        tenna "Is something wrong?{nw=0.5}"
        show tenna upright pointing smile at jump
        extend " I can always hold your hand,{w=0.2} if that'll make it easier!"
        if persistent.glitches:
            show mike arms freakout at jump
        else:
            show mike arms freakout at shock
        mike "Pfpfpffpppfpfft???"
        show mike arms avert at jump
        mike "NO!{w=0.2} I don't need THAT!!{p=0.2}{noalt}*{/noalt} What are we,{w=0.2} four?!"
        show tenna upright chest confused at droop
        tenna "Haha..."
        show tenna upright back confused at jump
        tenna "Well,{w=0.2} I meant it as more of a romantic gesture,{w=0.2} but if you don't want to we don't have to!"
        if persistent.glitches:
            show mike standing angry at jump
        else:
            show mike standing angry at shock
        mike "A--?!"
        show mike tie awkward at jump
        mike "N-{w=0.1} no!{w=0.2} I don't want to!"
        show tenna panic panic at jump
        show mike standing sigh at wiggle
        mike "Ah,{w=0.2} I mean..."
        show tenna upright back panic at jump
        show mike standing nervous at droop
        mike "Sorry,{w=0.2} sorry,{w=0.5} I don't mean to be so aggressive..."
        show mike tie nervous
        mike "I'll be fine.{w=0.2} I can handle it."
        show mike standing awkward
        mike "So long as we get home...{w=0.5} I don't really care how it happens at this point."
        show tenna upright back smile at jump
        tenna "Okay.{p=0.5}{noalt}*{/noalt} So long as you're happy,{w=0.2} I can work with that."
        show mike tie awkward at wiggle
        mike "...{w=0.2} uh-huh..."
        show tenna upright pointing smile at jump
        tenna "[persistent.mc],{w=0.2} lead the way,{w=0.2} then!"
        $ multichar = False
        show mike standing awkward at jump
        "You nod,{w=0.2} heading over to lay down on the mattress."
        $ multichar = True
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and the other two follow suit."
        pause 3.0
        scene uniend battenna with Dissolve(2.0)
        pause 1.0
        tenna "Is this okay,{w=0.2} [persistent.mc]?{p=0.5}{noalt}*{/noalt} It's not too much,{w=0.2} is it?"
        $ multichar = False
        "You assure Tenna that he's just fine."
        $ multichar = True
        tenna "Okay,{w=0.2} good."
        mike "This is,{w=0.2} uh,{w=0.2} okay,{w=0.2} too,{w=0.5} right?"
        $ multichar = False
        "You tell Mike that if he's comfortable,{w=0.2} it's fine with you."
        $ multichar = True
        mike "Got it."
        mike "It's not...{w=0.5} the most comfortable ever,{w=0.2} but that's mostly 'cause of the mattress,{w=0.2} so it'll have to do."
        pause 1.0
        tenna "[persistent.mc]?{w=0.5} How is this happening,{w=0.2} again?"
        $ multichar = False
        "You tell Tenna that you'll figure out the rest once you wake up in the Light World."
        $ multichar = True
        tenna "Oh!{w=0.5} Taking things one step at a time, I see,{w=0.2} haha!"
        tenna "Sure,{w=0.2} [persistent.mc].{p=0.5}{noalt}*{/noalt} Whatever works for you."
        tenna "Just...{w=0.5} don't take too long figuring it out,{w=0.2} okay?"
        mike "Yeah,{w=0.2} I don't wanna be stuck here any longer than I've gotta be,{w=0.2} either."
        scene black with Dissolve(2.0)
        pause 1.0
        mike "See ya in a bit, right,{w=0.2} uh,{w=0.2} \"[persistent.mc]\"?"
        tenna "Yes,{w=0.2} please!{p=0.5}{noalt}*{/noalt} I already can't wait,{w=0.2} haha."

    ### SPAMTAT
    elif end_spamtat == "done":
        $ multichar = False
        show mike standing pout at mikepos_left with easeinleft
        play music glowingsnow
        mike_no "Hey,{w=0.2} y'know..."
        show mike standing conflicted
        mike_no "When you said you could help me leave..."
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        if persistent.glitches:
            show mike arms freakout at jump
        else:
            show mike arms freakout at shock
        mike_no "I didn't think you were gonna drag me over to a MATTRESS?!"
        hide itemframe with easeoutbottom
        show mike standing pout
        $ multichar = True
        show spamton standing up smile flipped at spampos_center with easeinleft
        show spamton standing tilt laugh at jump
        spamton "DON'T GET SO [[panties in a twist] ABOUT IT."
        show spamton standing up stare at jump
        spamton "BUT. BUT.{w=0.5} ACE?"
        show spamton standing up frowne
        spamton "WHAT THE [[bleep] ARE WE DOING HERE?"
        $ multichar = False
        "You explained that,{w=0.2} in order to get them out of here,{w=0.2} you'll need to bring them through the Light World."
        show spamton at spampos_right with ease
        "In order to do that,{w=0.2} you'll first need to lay down here.{w=0.5} They'll both need to be touching you, however,{w=0.2} or you'll lose sight of them."
        $ multichar = True
        show mike standing indifferent at jump
        show spamton standing up stare at jump
        pause 1.0
        show spamton standing up tilt laugh at jump
        spamton "EAHEHAHAH!{p=0.2}{noalt}*{/noalt} YOU DIDN'T THINK TO MENTION THIS [[Sooner Rather than Later] ??"
        show spamton standing up frowne at jump
        spamton "I THOUGHT I SAID I'M [[not a [[Touchy-Feely Guy]] !"
        show mike standing nervous at droop
        mike_no "I'm not exactly jumping at the idea, either, but..."
        show mike tie awkward at jump
        mike_no "If,{w=0.2} I've gotta do it in order to leave,{w=0.2} then,{w=0.2} I can do it."
        show spamton crazy laugh at xwiggle
        spamton "DON'T EVEN!{p=0.5}{noalt}*{/noalt} YOU'RE BASICALLY [[ jumping ] FOR JOY!"
        show mike standing angry at jump
        mike_no "I-{w=0.1} I am NOT!{p=0.2}{noalt}*{/noalt} You think I'm a cuddly guy, either?!"
        show mike arms avert at wiggle
        mike_no "I can just,{w=0.2} tolerate it when necessary!"
        show spamton standing up glaree at jump
        spamton "UH-HUH."
        show spamton standing up stare
        spamton "IS THAT WHAT YOU SAY TO [[Static Picture],{w=0.2} TOO?"
        if persistent.glitches:
            show mike arms freakout
        else:
            show mike arms freakout at shakingcg
        mike_no "UGH!{p=0.5}{noalt}*{/noalt} Why did I choose to come here with YOU?"
        show mike tie avert at wiggle
        mike_no "Hey, uh,{w=0.2} [persistent.mc]?{w=0.2} Can we get this over with before I DO actually decide I'd rather die out here?"
        $ multichar = False
        "You nod,{w=0.2} walking over to lay down on the mattress."
        $ multichar = True
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and the other two follow suit."
        pause 3.0
        mike_no "Th-{w=0.1} this is okay, right?"
        spamton "NOT [[ a cuddly guy, either ] HE SAYS..."
        mike_no "Hey,{w=0.2} SHUT UP?"
        scene uniend spamtat with Dissolve(2.0)
        pause 1.0
        mike_no "So long as it's okay I'll,{w=0.2} just stay like this?"
        mike_no "I didn't know what else to do!"
        spamton "LITERALLY ANYTHING??{w=0.2} I JUST [[hold hands] !!"
        $ multichar = False
        "You tell \"Mike\" it's really not that big of a deal."
        $ multichar = True
        mike_no "Alright, alright!"
        mike_no "Then,{w=0.2} I won't worry about it."
        pause 1.0
        spamton "YOU KNOW.{w=0.2} [persistent.mc!u]."
        spamton "HOW {noalt}IS{/noalt}{alt}is{/alt} THIS GOING TO [[offer your assistance to] ?" # ALT TEXT
        "You explain that you'll \"sleep\" here in order to wake up in the Light World..."
        "... and that'll you'll figure the rest of it out when you get that far."
        spamton "WELL ISN'T THAT [[unsettling]!"
        mike_no "You'd rather stay here than at least take the chance to get out?"
        spamton "I'M NOT A BIG FAN OF [[ gambling my life away ], [[dice boy] !!{w=0.5} IT NEVER ENDS [[ favorable results ] !"
        spamton "BUT.{w=0.2} [persistent.mc!u].{p=0.5}{noalt}*{/noalt} I [[[[ trust ]] you."
        spamton "SO DON'T {noalt}[[$#!@]{/noalt}{alt}beep{/alt} THIS UP!!"
        mike_no "Sheesh.{w=0.2} No pressure or anything."
        mike_no "But...{w=0.2} guess I'm kinda in the same boat."
        scene black with Dissolve(2.0)
        pause 1.0
        mike_no "I guess we'll see ya later...?"
        spamton "YOU BETTER [[see ya later],{w=0.2} [persistent.mc!u]!{p=0.5}{noalt}*{/noalt} [[ Or else! ]"
    
    ### SPAMTENNA
    elif end_spamtenna == "done":
        show spamton standing up smile flipped at spampos_left with easeinleft # check pos
        play music glowingsnow
        play sfx sparkleglock
        show itemframe i_matt at truecenter with easeinbottom
        show spamton standing tilt laugh flipped at jump
        spamton "HERE WE ARE AT [[mattress]!"
        show spamton standing up glare flipped at jump
        spamton "NOW WHAT?"
        hide itemframe with easeoutbottom
        show tenna upright chest neutral flipped at tenpos_inright with easeinleft
        show tenna upright pointing oh at jump
        tenna "He's got a point."
        show tenna upright pointing weak
        tenna "You still haven't told us the plan,{w=0.2} [persistent.mc]."
        show tenna upright back blank
        $ multichar = False
        show spamton at spampos_inleft with ease
        "You explained how you're going to lay down on the mattress and \"fall asleep.\""
        "What you'll actually be doing is waking up in the Light World,{w=0.2} but in order to find the two of them there, you'll have to be touching them."
        $ multichar = True
        show spamton standing up glaree flipped
        show tenna upright back nose
        tenna "...{w=0.2} Oh."
        show spamton crazy frantic at xwiggle
        spamton "WHY DO YOU SOUND SO [[Tired of boring, ] ??"
        show tenna panic panic at jump
        tenna "What?!{p=0.5}{noalt}*{/noalt} I'm not BORED,{w=0.2} haha!!"
        show tenna upright chest awkward at jump
        tenna "It's just not what I expected,{w=0.2} is all!"
        show spamton slouch down panic flipped at jump
        spamton "WHAT DID YOU [[expected]?!{p=0.5}{noalt}*{/noalt} [[What is a Euphemism]???"
        show tenna upright chest angry at rise
        tenna "Alright,{w=0.2} I think we can move ON, now!"
        show spamton standing tilt laugh at jump
        spamton "EAHEHEHEAH!!{w=0.2} YOURE TOO PREDICTABLE!!"
        show tenna upright back confused at jump
        tenna "Okay,{w=0.2} well,{w=0.2} [persistent.mc]!{nw=0.5}"
        show spamton standing up glaree flipped at jump
        show tenna upright pointing oh at jump
        extend "{p=0}{noalt}*{/noalt} Tell us what we're supposed to do."
        show tenna upright chest neutral at jump
        $ multichar = False
        "You nod, guiding them to follow you as you go to lay down on the mattress."
        $ multichar = True
        scene black with Dissolve(2.0)
        play sfx cloth
        alt "You lay down on the mattress, and the other two follow suit."
        pause 3.0
        scene uniend spamtenna with Dissolve(2.0)
        pause 1.0
        tenna "Haha,{w=0.2} this isn't too much,{w=0.2} is it?"
        spamton "ASKING FOR [[forgiveness] NOT [[permission] ??"
        tenna "What?!{w=0.2} That's not what I..."
        tenna "[persistent.mc],{w=0.2} I can move,{w=0.2} if you'd prefer!"
        $ multichar = False
        "You tell Tenna not to worry about it."
        $ multichar = True
        tenna "Okay,{w=0.2} so long as you're certain."
        pause 1.0
        spamton "[persistent.mc!u].{p=0.5}{noalt}*{/noalt} [[What happens next?]"
        $ multichar = False
        "You say you'll figure that part out when you get to the Light World."
        $ multichar = True
        spamton "YOU'RE REALLY [[flyin' by the seat of your pants] HUH?"
        spamton "NEXT TIME [[put some more thought into it]!"
        tenna "NEXT time?!{p=0.5}{noalt}*{/noalt} Haha,{w=0.2} geez,{w=0.2} I really hope there won't BE a next time!!"
        tenna "The only \"next time\" I want right now is...{p=0.5}{noalt}*{/noalt} [persistent.mc]?"
        tenna "Next time we see you..."
        scene black with Dissolve(2.0)
        pause 1.0
        tenna "...{w=0.2} Well,{w=0.2} I hope that time isn't too long from now."
        spamton "YEAH SO,{w=0.2} [[ Make it snappy!]"
    
    ### TRANSITION TO CREDITS
    stop music fadeout 2.0
    $ renpy.pause(5.0,hard=True)
    jump credits