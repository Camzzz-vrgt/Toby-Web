############################################################################################################
################## LEGEND OF TENNA
image lot_dialogue = "gui/textbox lot.png"
image lot_ctc:
    "gui/lot ctc.png"
    shader "rgb_split"
    u_intensity 4.0
    u_angle 0
    xpos 1390
    ypos 820
    alpha 1.0
    pause 0.5
    alpha 0.0
    pause 0.5
    repeat

transform lot_full:
    "images/legend of tenna/health full.png"
transform lot_empty:
    "images/legend of tenna/health empty.png"

transform lot_boss_full:
    "images/legend of tenna/boss full.png"
transform lot_boss_empty:
    "images/legend of tenna/boss empty.png"

transform lot_full_rgb:
    "images/legend of tenna/health full.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0
transform lot_empty_rgb:
    "images/legend of tenna/health empty.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0

transform lot_boss_full_rgb:
    "images/legend of tenna/boss full.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0
transform lot_boss_empty_rgb:
    "images/legend of tenna/boss empty.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0

image lot_slash 1 = "images/legend of tenna/slash 1.png"
image lot_slash 2 = "images/legend of tenna/slash 2.png"
image lot_slash 3 = "images/legend of tenna/slash 3.png"
image lot_slash 4 = "images/legend of tenna/slash 4.png"
image lot_slash ani:
    "lot_slash 1"
    pause 0.1
    "lot_slash 3"
    pause 0.1
    "lot_slash 4"

image lot_sweat 1 = "images/legend of tenna/sweat.png"
image lot_sweat 2 = "images/legend of tenna/sweat2.png"
image lot_sweat flicker:
    "lot_sweat 1"
    pause 0.2
    "lot_sweat 2"
    pause 0.2
    repeat


######################################################
##### TV TIME 2
image lot_tvtime2_tenmap:
    "images/legend of tenna/map tenna.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0

image lot_tvtime2_tree:
    "images/legend of tenna/tvtime_tree1.png"
    pause 0.5
    "images/legend of tenna/tvtime_tree2.png"
    pause 0.5
    "images/legend of tenna/tvtime_tree3.png"
    pause 0.5
    "images/legend of tenna/tvtime_tree4.png"
    pause 0.5
    "images/legend of tenna/tvtime_tree5.png"
    pause 0.5
    repeat

image lot_tvtime2_map:
    "images/legend of tenna/tvtime_map.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0
    
image lot_house:
    "images/legend of tenna/tvtime_house.png"
    shader "rgb_split"
    u_intensity 0.3
    u_angle 0

image lot_houseH:
    "images/legend of tenna/tvtime_house h.png"
    shader "rgb_split"
    u_intensity 0.3
    u_angle 0

image lot_door:
    "images/legend of tenna/tvtime_door.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0

image lot_doorH:
    "images/legend of tenna/tvtime_door h.png"
    shader "rgb_split"
    u_intensity 5.0
    u_angle 0
    

######################################################
##### HERO_WIT_GNR AND TENNA
### hero_wit_gnr
image hero_wit_gnr idle = "images/legend of tenna/hero_wit_gnr idle.png"
image hero_wit_gnr idle2 = "images/legend of tenna/hero_wit_gnr idle2.png"

image hero_wit_gnr walk1 = "images/legend of tenna/hero_wit_gnr walk RL 1.png"
image hero_wit_gnr walk2 = "images/legend of tenna/hero_wit_gnr walk RL 2.png"
image hero_wit_gnr walk:
    "hero_wit_gnr walk1"
    pause 0.5
    "hero_wit_gnr walk2"
    pause 0.5
    repeat

image hero_wit_gnr walkL1 = Transform("images/legend of tenna/hero_wit_gnr walk RL 1.png", xzoom=-1.0)
image hero_wit_gnr walkL2 = Transform("images/legend of tenna/hero_wit_gnr walk RL 2.png", xzoom=-1.0)
image hero_wit_gnr walkL:
    "hero_wit_gnr walkL1"
    pause 0.5
    "hero_wit_gnr walkL2"
    pause 0.5
    repeat

image hero_wit_gnr walkD1 = "images/legend of tenna/hero_wit_gnr walk D 1.png"
image hero_wit_gnr walkD2 = "images/legend of tenna/hero_wit_gnr walk D 2.png"
image hero_wit_gnr walkD:
    "hero_wit_gnr walkD1"
    pause 0.5
    "hero_wit_gnr walkD2"
    pause 0.5
    repeat

image hero_wit_gnr walkU1 = "images/legend of tenna/hero_wit_gnr walk U 1.png"
image hero_wit_gnr walkU2 = "images/legend of tenna/hero_wit_gnr walk U 2.png"
image hero_wit_gnr walkU:
    "hero_wit_gnr walkU1"
    pause 0.5
    "hero_wit_gnr walkU2"
    pause 0.5
    repeat

image hero_wit_gnr damage = "images/legend of tenna/hero_wit_gnr damage.png"
image hero_wit_gnr damage2 = "images/legend of tenna/hero_wit_gnr damage2.png"
image hero_wit_gnr damage ani:
    "hero_wit_gnr damage2"
    pause 0.2
    "hero_wit_gnr walk2"
    pause 0.2
    "hero_wit_gnr damage2"
    pause 0.2
    "hero_wit_gnr walk2"
    pause 0.2
    "hero_wit_gnr damage2"
    pause 0.2
    "hero_wit_gnr walk2"

image hero_wit_gnr flirt1 = "images/legend of tenna/hero_wit_gnr flirt 1.png"
image hero_wit_gnr flirt2 = "images/legend of tenna/hero_wit_gnr flirt 2.png"
image hero_wit_gnr flirt3 = "images/legend of tenna/hero_wit_gnr flirt 3.png"
image hero_wit_gnr flirt4 = "images/legend of tenna/hero_wit_gnr flirt 4.png"
image hero_wit_gnr flirt5 = "images/legend of tenna/hero_wit_gnr flirt 5.png"
image hero_wit_gnr flirt:
    "hero_wit_gnr flirt5"
    pause 0.1
    "hero_wit_gnr flirt1"
    pause 0.1
    "hero_wit_gnr flirt2"
    pause 0.1
    "hero_wit_gnr flirt4"
    pause 0.1
    "hero_wit_gnr flirt5"

### tenna
image lot_tenna walk1 = "images/legend of tenna/tenna walk RL 1.png"
image lot_tenna walk2 = "images/legend of tenna/tenna walk RL 2.png"
image lot_tenna walk:
    "lot_tenna walk2"
    pause 0.5
    "lot_tenna walk1"
    pause 0.5
    repeat

image lot_tenna idle1 = "images/legend of tenna/tenna idle 1.png"
image lot_tenna idle2 = "images/legend of tenna/tenna idle 2.png"
image lot_tenna idle3 = "images/legend of tenna/tenna idle 3.png"
image lot_tenna idle:
    "lot_tenna idle1"
    pause 0.5
    "lot_tenna idle2"
    pause 0.5
    repeat

image lot_tenna idleB:
    "lot_tenna idle2"
    pause 0.5
    "lot_tenna idle3"
    pause 0.5
    repeat

image lot_tenna hurt = "images/legend of tenna/tenna hurt.png"


######################################################
##### ENEMIES
### shadowguy
image shadowguy idle1 = "images/legend of tenna/shadowguy idle 1.png"
image shadowguy idle2 = "images/legend of tenna/shadowguy idle 2.png"

image shadowguy walk:
    "shadowguy idle1"
    pause 0.5
    "shadowguy idle2"
    pause 0.5
    repeat

image shadowguy run1 = Transform("images/legend of tenna/shadowguy run 1.png", xzoom=-1.0)
image shadowguy run2 = Transform("images/legend of tenna/shadowguy run 2.png", xzoom=-1.0)
image shadowguy run:
    "shadowguy run1"
    pause 0.2
    "shadowguy run2"
    pause 0.2
    repeat

image shadowguy hurt = "images/legend of tenna/shadowguy hurt.png"
image shadowguy blush = "images/legend of tenna/shadowguy blush.png"

### pluey / cat mike
image pluey idle1 = "images/legend of tenna/pluey idle 1.png"
image pluey idle2 = "images/legend of tenna/pluey idle 2.png"
image pluey idle:
    "pluey idle1"
    pause 0.5
    "pluey idle2"
    pause 0.5
    repeat

image pluey blush1 = "images/legend of tenna/pluey blush 1.png"
image pluey blush2 = "images/legend of tenna/pluey blush 2.png"
image pluey blush1 flipped = Transform("images/legend of tenna/pluey blush 1.png", xzoom=-1.0)
image pluey blush2 flipped = Transform("images/legend of tenna/pluey blush 2.png", xzoom=-1.0)
image pluey blush:
    "pluey blush1"
    pause 0.5
    "pluey blush2"
    pause 0.5
    repeat

image pluey blushR:
    "pluey blush1 flipped"
    pause 0.2
    "pluey blush1 flipped"
    pause 0.2
    repeat

image pluey hurt1 = "images/legend of tenna/pluey hurt 1.png"
image pluey hurt2 = "images/legend of tenna/pluey hurt 2.png"
image pluey hurt:
    "pluey hurt1"
    pause 0.5
    "pluey hurt2"
    pause 0.5
    repeat

### jongler / cowboy mike
image jongler idle1 = "images/legend of tenna/jongler idle 1.png"
image jongler idle2 = "images/legend of tenna/jongler idle 2.png"
image jongler idle:
    "jongler idle1"
    pause 0.5
    "jongler idle2"
    pause 0.5
    repeat

image jongler blush1 = "images/legend of tenna/jongler blush 1.png"
image jongler blush2 = "images/legend of tenna/jongler blush 2.png"
image jongler blush1 flipped = Transform("images/legend of tenna/jongler blush 1.png", xzoom=-1.0)
image jongler blush2 flipped = Transform("images/legend of tenna/jongler blush 2.png", xzoom=-1.0)
image jongler blush:
    "jongler blush1"
    pause 0.5
    "jongler blush2"
    pause 0.5
    repeat

image jongler blushR:
    "jongler blush1 flipped"
    pause 0.2
    "jongler blush1 flipped"
    pause 0.2
    repeat

### battat / small mike
image battat idle1 = "images/legend of tenna/battat idle 1.png"
image battat idle2 = "images/legend of tenna/battat idle 2.png"
image battat idle:
    "battat idle1"
    pause 0.5
    "battat idle2"
    pause 0.5
    repeat

image battat walk1 = "images/legend of tenna/battat walk.png"
image battat walk:
    "battat idle1"
    pause 0.5
    "battat walk1"
    pause 0.5
    repeat

image battat blush1 = "images/legend of tenna/battat blush 1.png"
image battat blush2 = "images/legend of tenna/battat blush 2.png"
image battat blush:
    "battat blush1"
    pause 0.5
    "battat blush2"
    pause 0.5
    repeat

image battat run1 = Transform("images/legend of tenna/battat run.png", xzoom=-1.0)
image battat blush1 flipped = Transform("images/legend of tenna/battat blush 1.png", xzoom=-1.0)
image battat blushR:
    "battat blush1 flipped"
    pause 0.2
    "battat run1"
    pause 0.2
    repeat

image battat hurt1 = "images/legend of tenna/battat hurt 1.png"
image battat hurt2 = "images/legend of tenna/battat hurt 2.png"
image battat hurt:
    "battat hurt1"
    pause 0.5
    "battat hurt2"
    pause 0.5
    repeat

### friend
image friend walk = "images/legend of tenna/friend walk.png"
image friend idle = "images/legend of tenna/friend idle.png"

### dino
image dino idle1 = "images/legend of tenna/dino idle 1.png"
image dino idle2 = "images/legend of tenna/dino idle 2.png"
image dino idle:
    "dino idle1"
    pause 0.5
    "dino idle2"
    pause 0.5
    repeat

image dino walk1 = "images/legend of tenna/dino walk.png"
image dino walk:
    "dino idle1"
    pause 0.5
    "dino walk1"
    pause 0.5
    repeat

image dino blush = "images/legend of tenna/dino blush.png"
image dino run1 = Transform("images/legend of tenna/dino run 1.png", xzoom=-1.0)
image dino run2 = Transform("images/legend of tenna/dino run 2.png", xzoom=-1.0)
image dino run:
    "dino run1"
    pause 0.2
    "dino run2"
    pause 0.2
    repeat

### "flowey" (to avoid conflict w flower item lmao)
image flowey idle1 = "images/legend of tenna/flower idle 1.png"
image flowey idle2 = "images/legend of tenna/flower idle 2.png"
image flowey blush1 = "images/legend of tenna/flower blush 1.png"
image flowey blush2 = "images/legend of tenna/flower blush 2.png"
image flowey idle:
    "flowey idle1"
    pause 0.5
    "flowey idle2"
    pause 0.5
    repeat

image flowey blush:
    "flowey blush1"
    pause 0.5
    "flowey blush2"
    pause 0.5
    repeat


######################################################
##### WALKING / BG
image map start = "images/legend of tenna/map start.png"
image map battle = "images/legend of tenna/map battle.png"

image map world:
    "images/legend of tenna/map world.png"
    xpos 430
    linear 20.0 xoffset -3120

image map world2:
    "images/legend of tenna/map world2.png"
    xpos 430
    linear 25.0 xoffset -4160