﻿# The script of the game goes in this file.
# The game starts here.

label start:

    scene bg_black

    play music "audio/weirder_birds.mp3"

    pause 2.0

    "You wake up."
    "It’s… dark, far darker than you’ve ever known it can get."
    "You blink- but it's hard to tell if… you’re actually blinking because of how dark it really is."
    "You pull your hand up in front of your face- but still nothing."
    "You try to move along the ground but you can’t see the ground… or your feet."
    "The longer you spend trying to move around, feel for something, anything… you finally realize that… it doesn’t feel like. Anything."
    "Like you have no hands or feet at all."
    "But that can’t be right, you’ve only ever experienced this once before and that couldn’t possibly be what’s happening now… but as time stretches on."
    "Reality dawns on you… and… oh my god."

    scene bg_blackwsoul with dissolve

    Soul "I’m without a vessel. In a dark world."
    Soul "W-where’s Kris?! Did they leave me here??? Surely not- I mean, they’re not a perfect henchman for whatever evil scheme they’ve got going on-"
    Soul "but they CAN’T be dumb enough to take out their soul in the Dark World!!"
    Soul "I would hyperventilate but I don’t have lungs. Or need to breathe."
    Soul "The panic goes nowhere when it has nobody to go to. I just desperately spin in a circle. Or what I think is a circle- it’s IMPOSSIBLE to tell in this pitch black place."
    Soul "This can’t be Castle Town."
    Soul "But where is here…?"
    Soul "If I squint really hard maybe I can-"

    scene bg_blackwsoulglow with dissolve

    pause 1.0

    Soul "Ah, okay. Right. Let’s see…"

    scene bg_ch5start with dissolve

    Soul "I will never get over how pretty these places are. The flowers are perfectly in bloom- and the dew drops on them are like something straight out of a picture."
    Soul "This is no dark world i’ve ever seen- I’m not even sure where this one would be exactly in Kris’ little town, it’s not as if they have a field anywhere."
    Soul "But they do have a flowershop…"
    Soul "..."
    Soul "Oh god am I in Asgore’s flower shop?! What if he sees me-! WHAT IF HE FINDS KRIS BEFORE ME- Oh I’m gonna start panicking all over again."
    Soul "What am I supposed to do, I couldn’t possibly make it through a dark world alone-"

    stop music

    play sound "audio/Flowery_voiceclip_hey_there_little_guy.wav"

    Mist1 "Now who’s this I've found?"

    Soul "I feel everything in me freeze all at once. Ooooooohhh ffff-."
    Soul "Was this an enemy? Someone from town? It could be anyone and ANYONE was likely to freak out if they knew what a human soul was. I turn to face the source of voice and…"

    show flowery_nuetral with dissolve

    play sound "audio/Flowery_voiceclip_sorry_about_that_little_guy.wav"
    
    Mist1 "I was wondering where our 4th guest had gone!"

    play music "audio/dads_best_friend.mp3"

    Soul "…That’s an anime boy."
    Soul "I’ve seen a lot of Mew Mew Kissy-Cutie, and a lot of anime mentioned from a certain yellow lizard in this world… but to see an anime boy, actually moving around and talking, in what I could only guess was a dark fountain in Asgore’s shop…"
    Soul "It was strange. This is still really… really strange."

    hide flowery_nuetral
    show flowery_confusion

    Soul "It’s not strange enough to fully distract me from the fact that he called me the ‘4th’ guest however."
    Soul "If I had to take a guess, that MUST mean Susie, Ralsei, and most importantly KRIS are already here!"
    Soul "I suppose my excitement must’ve been visible because the anime boy flashes me with a warm smile."

    hide flowery_confusion
    show flowery_happier

    play sound "audio/Flowery_voiceclip_wow.wav"

    Mist1 "Well, you seem excited!"

    play sound "audio/Flowery_voiceclip_Kris.wav"

    Mist1 "Are you looking to get back to Kris?"

    Soul "He knows where Kris is! Will he… actually take me to them?"
    Soul "I think back on my previous experiences in the dark world…"
    Soul "Honestly, after that fight with the puppet, going with some rando, no matter how pretty and kind he seems, just feels like a bad idea."

    menu:
        "Run away as fast as possible":
            Soul "I can’t risk it…"

            play music "audio/tactics.mp3"

            Soul "I’m slow, but small and easy to lose track of- so I turn and move as fast as I can in the opposite direction of the man standing before me."
            Soul "I don’t know his name but I hear his melodious voice call out to me."

            hide flowery_happier
            show flowery_confusionreach

            Mist1 "Hey, where ya goin?!"

            hide flowery_confusionreach with dissolve

            Soul "But I don’t turn to face him, instead I let the theme of his music wash away in the depths of the darkness, as I get further and further away from him."
            Soul "The path ahead is damp and laden with flowers- not exactly scary… but my red glow doesn’t do much to light a path on my own."
            
            scene bg_black with dissolve

            Soul "Why did I have to get stuck here without a vessel- without Kris...?"
            Soul "No matter how peaceful, every Dark World has enemies and it’s only a matter of time till someone notices the red floating heart and decides to take me out before I can close the founta-"

            stop music

            play sound "audio/slash_attack.mp3"
            scene bg_soulhit with dissolve

            pause 3.0

            play music "audio/that_day.mp3"

            Soul "… I feel myself shatter. It seems… While I was busy panicking, an enemy came up behind me and took a slash at me with their sword."
            Soul "It’s a flowery snake monster, similar to that of a rudinn. I’d be more curious if I wasn’t so afraid…"
            
            scene bg_soulcracking1 with dissolve
           
            Soul "Will I respawn without Kris? Is… is this the end of me? I… I don’t want to die here…"
            Soul "I haven’t seen this story all the way through. I haven’t done everything. It was only just beginning and now… now I won’t exist huh…"
            Soul "As my vision blurs and my form cracks more and more on the verge of shattering, I see the rudinn-like monster scatter from the scene as if being shooed off…"
            
            scene bg_soulcracking2 with dissolve
            
            Soul "Yellow hands caress my heart shaped not-body gently, and I can barely make out what seems like a face in the blur…"
            
            scene bg_soulcracking3 with dissolve
            
            Soul "Kris? … No Kris would never hold me this gently… with hands as velveteen as a petal… and a voice as warm as honey…"
            Soul "Who…..are……y…ou……?"

            scene bg_badend1 with fade

            pause 3.0

            "Bad Ending 1 - No Vessel, No Chance"

            return
        "Hop into his anime yaoi hands":
            
            hide flowery_happier
            show flowery_surprised
            
            Soul "I waste no time launching my little red not-body into his much more solid body, giving him barely enough time to catch me with an airy laugh."
            
            hide flowery_surprised
            show flowery_nuetral

            Mist1 "Careful now, We wouldn’t want you getting hurt right princess?"

            Soul "I would gasp in offense if I could. Assuming my pronouns- or is everyone just princess to this guy???"
            Soul "Not that I particularly mind being called it but- Oh he’s…. still looking at me. He must have caught on to the fact that I was perturbed by the name."
            Soul "I watch as he hums softly to himself, and then leans down, pressing a soft kiss to the top of my not-body. My heart form shakes with the shock that courses through me."
            Soul "Oh. My God."

            play sound "audio/Flowery_voiceclip_flowers_blooms_in_your_heart.wav"

            Soul "A little flower blooms where he kisses. With his face on it."
            Soul "OH. MY GOD."

            hide flowery_nuetral
            show flowery_confusion

            Mist1 "Princess isn’t exactly the right word is it… You don’t even have a hand to kiss!"
            
            play sound "audio/Flowery_voiceclip_Kris.wav"
            
            Mist1 "If you’re the one looking after Kris then…"

            hide flowery_confusion
            show flowery_happier

            play sound "audio/Flowery_voiceclip_it's_so_human.wav"

            Mist1 "How about Angel!"

            Soul "… We’ll just ignore everything that just happened."
            Soul "Angel works. I’d nod if I could. Hopefully he’ll get the memo if I just jump up and down a little."
            
            hide flowery_happier
            show flowery_warm

            Soul "He smiles warmly at that."

            $ affec += 1
        "Try your best to nod":
            Soul "I decided to try nodding to him, jumping up and down in my little non-body. Though it doesn’t seem to come across just right as he laughs a bit with a quirked eyebrow."

            hide flowery_happier
            show flowery_confusion

            play sound "audio/Flowery_voiceclip_I'm_only_trying_to_help_you.wav"

            Mist1 "Don’t think I quite caught that one Princess."

            Soul "He kneels down regardless and offers his hand out to me."

            hide flowery_confusion
            show flowery_nuetral

            Mist1 "Let’s find your friends fast, alright?"

            Soul "I’m still a little caught up by the fact that he called me Princess of all things. I don’t exactly have a gender like this- is that okay for him to use?"
            
            hide flowery_nuetral
            show flowery_laugh

            Soul "I get onto his hand, and for a moment he almost feels like a mindreader as he tilts his head down at me and laughs a bit."

            hide flowery_laugh
            show flowery_confusion

            Mist1 "Sorry, I suppose you’re not really a Princess hm?"

            hide flowery_confusion
            show flowery_happier

            play sound "audio/Flowery_voiceclip_it's_so_human.wav"

            Mist1 "How about Angel for the time being?"

            Soul "I jump up and down again as a helpful nod and he tilts his head again."

            hide flowery_happier
            show flowery_nuetral

            play sound "audio/Flowery_voiceclip_yes.wav"

            Mist1 "Must be your way of saying yes, huh?"

            hide flowery_nuetral
            show flowery_warm

            Soul "He smiles warmly at that."
    
    hide flowery_warm
    show flowery_nuetral

    play sound "audio/Flowery_voiceclip_sorry_to_keep_you_waiting_1.wav"

    Mist1 "I just realized I haven’t introduced myself, Have I Angel?"

    play sound "audio/Flowery_voiceclip_it's_me_Flowery.wav"

    Flowery "My name’s Flowery!"

    Soul "Flowery cups his fingers over my small not-body as he begins walking."

    hide flowery_nuetral with dissolve

    scene bg_carry1 with fade

    play music "audio/sunset.mp3"

    Soul "And I can't help but notice that WALKING isn’t even quite the right word here."
    Soul "I hear his feet touch the ground but he moves like he's practically gliding. The ride is smooth, as if he’s capable of keeping his hand perfectly still to not rattle me."
    Soul "Darkners can glide around- I’ve seen them do it so it’s not unlikely or anything but…"
    Soul "I suppose it was just weird to experience it for myself instead of from within a vessel."
    Soul "And I take special note of how different his hold on me is from Kris. It doesn’t hurt. Crazy."

    scene bg_cherryblossom with dissolve

    Soul "We pass by several white flowers in a peaceful green field. It’s nice- a bit humid. But nice."
    Soul "Street lamps alight in the dark and multiple suns peeks over the mountains in the distance, illuminating fields of tall grass, giant vines, japanese archways, and in the very distance, a castle in the same theme."
    Soul "A castle in full bloom... Flower Castle."

    scene bg_carry2 with dissolve

    pause 1.0

    Flowery "Enjoying the view?"

    Soul "I was, it was absolutely breathtaking. Of all the dreary Dark Worlds i’ve seen- hell even the bright lights of TV World were nothing compared to this. Though I’d never say that to Tenna."

    play sound "audio/Flowery_voiceclip_yes.wav"

    Flowery "I’ll take your stunned silence as a yes!"

    scene bg_cherryblossom with dissolve

    show flowery_nuetral with dissolve

    Flowery "Why don’t we take a closer look? No need to go rushing off to Kris just yet if you want to have some fun first."
    
    play sound "audio/Flowery_voiceclip_no_no_no.wav"
    
    Flowery "They need to learn to share anyway!"

    Soul "I feel my heart…. Er… self? Something fluttered a little at that."
    Soul "If I want to have some fun huh…"

    hide flowery_nuetral with dissolve

    scene bg_black with fade

    stop music

    Soul "A voice echoes in my thoughts, darker yet darker…"

    scene bg_vessel1 with dissolve

    Soul "Does… what I want even matter?"

    scene bg_soulandgrass1

    Soul "I didn’t give him an answer, so caught up in my own choices that I failed to realize he’d even brought me down to the ground again,  as we had gotten away from… I guess the darker part of the dark world."
    Soul "I hesitantly bobbed off of his open palm into the grass-"
    Soul "Holy shit."
    Soul "This grass was soft as fuck. Like. Unbelievably soft."
    Soul "As if someone dreamed it up, specifically for resting and laying in without a care in the world."
    Soul "Maybe they did- afterall some nearby flowers seem to have Flowery's face on them…"

    menu:
        "Roll around in the grass":
            scene bg_soulandgrass2 with dissolve

            Soul "I faceplant into the soft blades of foliage without hesitation."
            Soul "Rolling my tiny form across the green field- I felt almost as if I could temporarily forgo my worry to get back to Kris."
            Soul "I hear a laugh at my side and freeze in my tracks as I look back at Flowery."

            scene bg_cherryblossom with dissolve

            show flowery_smug with dissolve

            Soul "He seems to be grinning with this smug look that makes me wish the ground would swallow me whole- For an Angel I’m sure he finds these actions rather childish."

            play sound "audio/Flowery_voiceclip_it's_so_human.wav"

            Flowery "What a cute little thing you are. I wouldn’t have imagined the Angel meant to seal us away could be so carefree."

            Soul "His words are laden with a sense of melancholy, as if this wasn’t exactly news he wanted to learn. Yet somehow it was refreshing, as if he valued my sense of self."
            Soul "My sense of self…"

            scene bg_black with fade

            Soul "It had truly been a while since I had gotten to do as I please hadn’t it?"

            play music "audio/that_day.mp3"

            Soul "A voice echoes in my memories. Forcing a shudder through my small heart shaped form."

            scene bg_vessel2 with dissolve

            pause 1.0

            "No one can choose who they are in this world."

            pause 1.0

            scene bg_cherryblossom

            play music "audio/glade.mp3"

            Soul "I have little time to dwell on that as I catch Flowery turning away from me in the corner of my eye."

            scene bg_grass1
            
            play sound "audio/Flowery_voiceclip_I'm_falling.wav"

            Soul "He allows his body to fall almost weightlessly into the grass beside me."
            Soul "His black coat splayed out underneath him. One of his arms folded under his head like a makeshift pillow, while the other curled in the foliage around me, encompassing me, holding me close without actually touching me."
            Soul "His body blocked the wind. His face was much closer now… I could see little peach fuzz on his cheeks, If his hands felt like soft petals than surely the rest of hi-"
            Soul "Stop. Pause. Rewind. Don’t think like that, you nasty."
            Soul "I end up glowing brighter subconsciously to rid myself of this extra energy, and though his eye does cast a glance and smile my way, He doesn’t appear bothered."

            play sound "audio/Flowery_voiceclip_mostlys.wav"

            Flowery "You really needn’t trouble yourself with light Angel. Though it is much prettier than our seven suns haha."

            Soul "Which… of course... just made me glow brighter, and him laugh harder."
            Soul "… Now what?"

            $ affec += 1
        "There could be monsters nearby, Stay alert":
            scene bg_cherryblossom

            show flowery_nuetral

            Soul "Unfortunately I don’t have time for that, I MUST find Kris."
            Soul "I’ve NEVER left Kris in a dark world before, as far as I know, this could be dangerous, very very dangerous!"
            Soul "Who knows what might happen if an opponent sees you!"

            hide flowery_nuetral
            show flowery_confusion

            Soul "What if they keep you for themselves, or worse! Break you on the spot!!"

            hide flowery_confusion with dissolve

            Soul "What if Kris feels it?! What if they get scared of being unable to see the enemy! WHAT IF-"

            play music "audio/glade.mp3"

            Soul "I hear a loud thump and rustle of grass around my tiny form, and turn to see Flowery in the previously mentioned soft grass."

            scene bg_grass2 with dissolve

            play sound "audio/Flowery_voiceclip_I'm_falling.wav"

            Soul "Taking what appears to be a break."
            Soul "He almost looks like he has the gall to judge you for still seeming so paranoid."

            play sound "audio/Flowery_voiceclip_smile_again.wav"

            Flowery "Why don’t you take a break! I know you want to get back to Kris-"
            Flowery "But that’s not gonna happen if you freak out and run off to the middle of nowhere!"

            Soul "He has a point, I don’t know where Kris is, and without him I’ve almost no shot at getting to them…a little break won’t kill me."

            scene bg_grass1 with dissolve

            Soul "Before I even finish deciding, it's like the flowers themself rush up to pull me into the soft grass- pushy aren't we."
            Soul "Oh well."
            Soul "Surely Flowery wouldn’t let his new friend bite the dust that soon."
            Soul "… Now what."
        "Make a break for it while you still can":
            scene bg_cherryblossom

            show flowery_nuetral
            
            Soul "The grass texture doesn’t matter- what DOES matter is that now that I’m not in someone’s hands and can actually see 5 feet ahead of me, I can make a run for it-"
            Soul "He was kind enough to lead me out of that dark spot and give me a lay of the land. That’s all I need from someone who could still potentially be very dangerous."

            play music "audio/tactics.mp3"

            Soul "I know my small floaty body isn’t exactly built with speed in mind. But surely a little BRAVERY will draw out my speed if I think about it hard enough."

            hide flowery_nuetral
            show flowery_confusionreach

            play sound "audio/Flowery_voiceclip_I'm_only_trying_to_help_you.wav"

            Flowery "Woah there little buddy! Where ya going?!"

            hide flowery_confusionreach with dissolve

            Soul "Flowery sounds properly flabbergasted by my change of heart. Heh, my masterful deception at work hehe-"
            Soul "I may not be fast, but at this size, even someone like him could lose me just like Kri-"

            scene bg_black

            stop music

            "You feel the full weight of something blue and heavy crashing into you."
            "In an instant your lightheadedness and general feeling of throwing up are gone. Some hair falls into your eyes, and your red cape flows behind you, catching the attention of your party."

            play music "audio/that_day.mp3"
            
            scene bg_krispov with fade

            Mist2 "Kris! Are you okay?"
            Mist3 "Dude! You got the wind knocked OUT of you, what was that?!"

            "Your friend’s sweet and loud voice respectively ring in your ears, and you feel fluffy and scaly hands help you back to your feet."

            scene bg_cherryblossom with dissolve

            show flowery_worry with dissolve

            Flowery "Heh... well if it isn’t my favorite three!"

            "Flowery had easily followed- You mean….found you again. Though he seems a little…down trodden? As if disappointed in something."
            
            hide flowery_worry
            show flowery_nuetral

            "Whatever the case, he shakes his head and plasters back on his award winning smile. Body relaxing back into his comfortable self."
            "Your heart beats fervently in your ears."
            "Your soul is back…"

            hide flowery_nuetral with dissolve

            scene bg_badend2 with fade

            pause 3.0

            "Bad Ending 2 - Reunited, At What Cost?"

            return
    Soul "I suppose I could just… lay here. It is surprisingly comfortable."
    Soul "I can hear the distant rustling of leaves, the occasional chirp- or…. no something stranger but, reminiscent of a bird? Somewhere in the flowers, and the gentle hum of Flowery's voice as he quietly sings to himself, some tune I’m unable to recognize."
    Soul "Probably his theme, hehe-"
    Soul "In my laughter, the music drifts off to the blissful silence of the dark world around us."
    Soul "I glance over at him. He is still laying there with his eyes closed, one arm tucked beneath his head."
    Soul "He looks… Peaceful."
    Soul "I have never seen someone look so comfortable doing absolutely nothing."
    Soul "And somehow, I am starting to feel a little comfortable too."
    Soul "Maybe…"

    scene bg_black with dissolve

    Soul "Maybe I can afford to stop panicking about Kris for the time being."

    stop music

    scene bg_vessel1 with dissolve
    pause 0.5
    scene bg_vessel2 with dissolve
    pause 0.5
    scene bg_vessel3 with dissolve
    pause 0.5
    play sound "audio/slash_attack.mp3"
    scene bg_vessel4 with dissolve
    pause 0.5

    scene bg_cherryblossom

    play music "audio/that_day.mp3"

    Soul "-!"
    Soul "What- What am I thinking- I can’t- I…. It isn’t up to me… !"
    Soul "My choices don’t-"

    show flowery_worry

    play sound "audio/Flowery_voiceclip_my_human.wav"

    Flowery "Angel?...You’re shaking."

    menu:
        "Turn away from him":
            Soul "I turn away from his voice on instinct. I want to hide away- I’m exposed. Easily wounded. I have no hands to hold me and no body to roam with."
            Soul "I am nothing. Nobody. My choices do not matter."
            Soul "He could not possibly understand this… What I have lost, what I will never have."
            Soul "I need to get back to Kris."

            hide flowery_worry
            show flowery_dark

            Soul "I cannot see him, but I hear him shift, picking up his jacket and standing from the grass."
            Soul "I feel his eyes bore into me with a look I can't quite place without meeting his eyes..."

            play sound "audio/Flowery_voiceclip_sorry_to_keep_you_waiting_1.wav"

            Flowery "Sorry to keep you waiting, I suppose I was just curious about that human soul the prophecy was referring to…"
            Flowery "Time well spent on my end! But I suppose you're dying to get back to your cage right?"

            Soul "I don’t turn to face him. I don’t bob along to his words… I cannot bear to see that smile."

            play sound "audio/Flowery_voiceclip_mini_peppers.wav"

            Flowery "Wait here Angel. I’ll retrieve Kris faster than you can say mini peppers!"

            hide flowery_dark

            Soul "I hear footsteps leave, and though a part of me, quiet and inconsequential as it is, longs to follow after."
            Soul "I shouldn’t. It would do nothing. Nothing but upset me anyways."
            Soul "I hope Kris will come get me discreetly…"

            scene bg_badend3 with fade

            pause 3.0

            "Bad Ending 3 - Time Well Spent"

            return
        "Look at Him":
            Soul "My form trembles as I turn to him, he does seem genuinely concerned."
            Soul "I hesitate, I don’t want to worry him or reveal more than I have to…"
            Soul "I tell him that I'm fine, though I obviously don’t look it..."
            Soul "I suppose I just… miss being allowed to be myself. It’s quite a bit more difficult than I remember to be without a vessel."

            stop music

            hide flowery_worry
            show flowery_nuetral

            Soul "His ears seem to perk up at that, and he..."

            hide flowery_nuetral
            show flowery_laugh

            play music "audio/garden.mp3"

            Soul "…laughs?"

            hide flowery_laugh
            show flowery_happier

            play sound "audio/Flowery_voiceclip_great_style.wav"

            Flowery "Goodness is that all?! Why don’t you just make your own?"

            Soul "…What."

            Flowery "You’re in a dark world Angel! Where objects become Darkners with nothing but the hope on their sleeve!"

            Soul "WHAT."

            hide flowery_happier
            show flowery_nuetral

            play sound "audio/Flowery_voiceclip_hey_Raly.wav"

            Flowery "...You seem surprised! I suppose I should have guessed Raly wouldn’t have given you that kind of information! After all, you are Kris’ Soul!"
            Flowery "But you’re allowed to have your own desires of course."

            Soul "Would… That really work? I suppose it only made sense since you are a soul, not a body- hey. Wait."
            Soul "You ask Flowery, rather agitated, if he’s calling you a mere object. Not the most romantic thing to say to someone..."

            hide flowery_nuetral
            show flowery_smug

            Soul "He grins and ignores the question with a shrug."

            Flowery "Just give it a try!"
        "Move closer to him":
            Soul "I barely hesitate, his voice is soothing on its own but I waste no time moving to nuzzle into his side."

            scene bg_hug with dissolve

            hide flowery_worry

            Soul "The smell of Golden flowers washes away the fear like water, his hand comes to close over me with a worry I am unacquainted with from this world…"
            Soul "I tell him that… it means a lot to me, all he’s done to calm and keep me protected while I’m away from Kris- that I should want to go back to them but…"
            Soul "Perhaps I just long for a vessel… Mine was discarded so long ago- I was told time and time again nothing I did mattered."
            Soul "My choices were merely Kris’, It’s not as if I made my own options."
            Soul "My actions are always limited by what they desire."
            Soul "It IS their body, it’s only fair... but..."

            scene bg_cherryblossom with dissolve

            show flowery_laugh

            play music "audio/garden.mp3"

            Soul "I feel his body shake a bit under me, like a genuine laugh that rattles him finally escapes his cool persona for the first time since meeting me."
            
            Flowery "Oh Angel- I’m sorry- I don’t mean to laugh at your plight, but…"

            hide flowery_laugh
            show flowery_warm

            play sound "audio/Flowery_voiceclip_great_style.wav"

            Flowery "Why don’t you just make your own?"

            Soul "…What."

            Flowery "You’re in a dark world Angel! Where objects become Darkners with nothing but the hope on their sleeve!"

            Soul "WHAT."

            play sound "audio/Flowery_voiceclip_hey_Raly.wav"

            hide flowery_warm
            show flowery_happier

            Flowery "...You seem surprised! I suppose I should have guessed Raly wouldn’t have given you that kind of information! After all, you are Kris’ Soul!"
            Flowery "But you’re allowed to have your own desires of course."

            Soul "Would… That really work? I suppose it only made sense since you are a soul, not a body- hey. Wait."
            Soul "You ask Flowery, rather agitated, if he’s calling you a mere object. Not the most romantic thing to say to someone..."

            hide flowery_happier
            show flowery_smug

            Soul "He grins and ignores the question with a shrug."

            Flowery "Just give it a try!"

            $ affec += 1
    scene bg_soulbodyform1 with dissolve

    Soul "I try to stop focusing on my surroundings, closing my metaphorical eyes and picturing in my head."
    Soul "My vessel."
    Soul "Something taken from me so long ago, their striped sweater, their face, their body. Something to really earn me that name Flowery gave me."
    Soul "Angel."

    scene bg_soulbodyform2 with dissolve

    Soul "I begin to glow brightly, and Flowery gasps slightly, needing to cover his eyes as the area is washed in a blinding spotlight."

    scene bg_white with dissolve
    pause 1.0
    scene bg_soulbodyform3 with dissolve

    "And when I blink again, the glow is gone."
    "In front of me were two red hands, on trembling red legs."
    "I can feel the weight of feathered wings on my back- hah, Angel wings, Classic. My new eyes drift up, and I see…"

    play music "audio/guess_im_in_love.mp3"

    scene bg_soulbodyform4 with dissolve
    pause 1.0

    "…Flowery’s flustered face."

    Angel "S…so uh…How do I look? Not bad right?"

    scene bg_cherryblossom

    show flowery_fluster

    "He hesitates- or perhaps, was too shocked to quite answer immediately."

    hide flowery_fluster
    show flowery_warm

    play sound "audio/Flowery_voiceclip_my_human.wav"

    Flowery "You… look amazing Angel…"

    play sound "audio/Flowery_voiceclip_flowers_blooms_in_your_heart.wav"

    Flowery "Like a flower in fullbloom."

    "I finally feel my own face heat up at his comments, and am forced to actually hide in my new striped sweater."
    "He steps forward to take my hand and place a small kiss on the back like a true flower prince."

    Angel "You’re so cheesey Flowery…"

    play sound "audio/Flowery_voiceclip_leaf_it_to_me.wav"

    hide flowery_warm
    show flowery_happier

    Flowery "Heh, Wouldn’t be me If I didn’t show the proper respect to someone so beautiful."

    Angel "StoPSTOPSTOP-!!!"

    hide flowery_happier
    show flowery_laugh

    "I flail my arms as he laughs and simply wraps his arms around me and holds me closer."

    stop music

    hide flowery_laugh
    show flowery_surprised

    Mist3 "Hey I think I heard him over here-"

    Mist2 "Why are we going TOWARDS him! We can do this on our own!"

    Mist3 "We just need a little help!"

    Mist2 "W-We can manage!"

    play music "audio/that_day.mp3"

    hide flowery_surprised
    show flowery_worry

    "But it seems our noise attracted some guests…"

    scene bg_confrontation with dissolve

    "As the two argue in the distance, a much calmer Kris steps into view, seemingly having gone in front of their friends to find the source of the commotion."
    "… Or perhaps, based on the way their eyes lock onto me… It was because they heard me specifically."
    "They seem out of breath honestly, like they were rushing to find me… I had almost assumed they'd pulled me out on purpose, but maybe that wasn’t the case?"

    if affec <= 1:
        "…Right. Well. This is to be expected. Better hurry before the other two catch up to Kris-"
        "I turn my attention off Kris and look at Flowery."

        scene bg_cherryblossom

        show flowery_worry

        "Who turns his attention to me."
        "It’s not easy to see past that award winning smile, only by having spent so much time with him now…"
        "Do I see the slight furrow of his brows, the concern in his hands that still held my waist."
        "I hope my new body’s face communicates what I fail to say."
        "All he’s done for me- keeping me safe while Kris tried to find me."
        "Teaching me how to do… all of this."
        "I… wish I could stay here forever. In his arms."
        "He clearly seemed to understand where this was going as his grip held tighter and he moved me slightly behind him, trying to address Kris directly-"

        hide flowery_worry
        show flowery_hiding

        play sound "audio/Flowery_voiceclip_Kris.wav"

        Flowery "Kris! I see you’re making good progress to the fountain. Have you been enjoying the view? Having fun I hope? Me and your friend here have been having a grand ol time you know-"

        "Kris makes a face that could only be described as a scowl, drawing their sword with a huff."

        hide flowery_hiding
        show flowery_surprised

        "They don’t get that far however- as a bright light fills the area, forcing Kris to cover their eyes and Flowery to turn back to me with wide eyes."

        scene bg_white with dissolve
        pause 1.0
        scene bg_cherryblossom with dissolve

        show flowery_confusionreach

        Soul "My body was gone. Back to the small unassuming heart, slipping free from his hands."
        Soul "…I tell him I'm sorry."

        hide flowery_confusionreach
        show flowery_warm

        Soul "He smiles warmly, much to my dismay."

        scene bg_black with dissolve

        Soul "He says when he proves to the fun gang that the prophecy didn’t have to be followed. He’ll get me back. His words echo in the dark…"
        Soul "... They haunt me even now, as I sit in my cage staring down at him."
        Soul "… I’m so sorry, Flowery."

        scene bg_badend4 with dissolve

        pause 3.0

        "Bad Ending 4 - Broken Heart"

        return
    else:
        "My body moves before I even think it through. Placing myself between Kris and Flowery with my arms outstretched."

        Angel "K-Kris! Check out the new me! Cool, huh? Ehehe…?"

        "Kris makes a face that could only be described as a scowl, drawing their sword with a huff."

        play sound "audio/Flowery_voiceclip_sorry_about_that_little_guy.wav"

        Flowery "Kris! Been having fun on your journey? Sorry I haven't been there to show you around- been a bit busy entertaining your Dad and Angel here!"

        "I feel Flowery’s hand drift back to my hip and hold me tightly."

        Flowery "You should really be nicer to your friends-"

        scene bg_confrontationeyes with dissolve

        "Kris takes a step forward, and outstretches their hand, interrupting the golden man’s lecture, looking directly at me without breaking eye contact."
        "The protagonist of the prophecy. The hero of the story."
        "The cage... My supposed vessel."
        "I should want to go back to them, I should want to return to them."
        "... But I don't"
        "Kris tilts their head, and I shake mine..."
        "I take a step back, leaning into Flowery’s arm with full commitment."

        Flowery "Angel…?"

        "He's sweating through his smile, but he holds me carefully, gently, like someone who understands what it means to choose to go against the impossible."
        "I stare at Kris, apologetic. I should be grateful for all they have done. For putting up with me, and carrying me through every Dark World, and giving me a body when I had none."
        "I wish I could say I love them and that I'm not leaving just because it’s them… but somehow, they must have gotten the memo, because their sword lowers."

        scene bg_cherryblossom

        show flowery_hiding

        "Both them and flowery share a look. For a moment, neither of them says anything."
        "Perhaps they both understood that this was never something either of them could decide for me. Kris nods once."

        hide flowery_hiding
        show flowery_warm

        play music "audio/diner.mp3"

        "Then turns and walks back toward the other two, who are still arguing in the distance."
        "I watch them go, and for the first time, I do not feel like I am being taken anywhere."
        "My choices, mattered."

        Flowery "Well…"

        "Flowery's arms tighten around me, solidifying the embrace with an air of anxiety I never thought could come from him."

        Flowery "I suppose I can live with that."
        Flowery "Though I must say, you have absolutely terrible manners when it comes to sharing with your pals."

        "Thankfully Kris doesn't turn around and attack him for that. Not easily ragebaited that one..."

        hide flowery_warm
        show flowery_bedroomeyes

        "Flowery turns back to me, eyes scanning over me like he is making absolutely certain that I am still here. For a man that spends a lot of time with his head in the clouds, I suppose that was the usual for him."

        Flowery "Angel… You really chose me?"

        "His voice is so soft now, and I snort a little at his question. Never thought i'd get to see him so timid so soon."

        Angel "Of course I did… You did say this is where I get what I want if I wish hard enough right?"

        "He laughs, a tiny breathless sound."

        Flowery "Oh…"

        "His arms tighten around me again."
        
        Flowery "You have no idea how much that means to me-!"

        scene bg_goodend with dissolve

        "And then, before I can even process that, I am practically swept off my feet with a squeal I did not know I could make."

        Angel "Flowery! Warn me!! I am not used to having my own two feet!!!"

        play sound "audio/Flowery_voiceclip_sorry_to_keep_you_waiting_1.wav"

        Flowery "Sorry, Angel!"

        "He laughs, holding me securely against his chest."

        play sound "audio/Flowery_voiceclip_smile_again.wav"

        Flowery "I am just so happy!"

        "He spins around with glee, and I can feel my entire body glow brighter with every rotation. He only slows down to gently rest his forehead against mine."

        Flowery "I promise I will make it worth it."
        Flowery "Now come along, Angel! Let us go meet the others!"
        
        "I barely have time to laugh before I am being carried away into the flowers, the castle looming beautifully in the distance."

        scene bg_black with dissolve

        "Kris, Ralsei, and Susie will try to seal the fountain at some point."
        "Kris may try to battle Flowery before then."
        "What would they do without their soul? Would they be okay? What about the Roaring?"
        "These are the questions one would ask. Probably should ask."
        "But if I can break the prophecy, free myself from my cage, and make my own choices, then who is to say others cannot?"
        "They will cross those bridges when they get there."
        "Right now… I have somewhere I want to be. Someone I want to be with, and for once, there is no doubt in my choices."
        "Just me and Flowery."
        "As he carries me deeper into this strange new world, I cannot help but glow brighter than any 7th sun he may need."
        "Maybe… This is what choosing someone feels like."

        stop music
        pause 0.5

        play sound "audio/Flowery_voiceclip_one_more_for_the_fans.wav"

        "True Ending - Soul Mate"
        if affec == 3:
            play sound "audio/deltarune-egg-sound.mp3"

            "UNLOCKED BONUS SCENE!"

            scene bg_bedroom

            play music "audio/guess_im_in_love.mp3"

            "A Kawkaw chirps somewhere in the distance, its cheerful call echoing through the castle and stirring its inhabitants from their sleep."
            "The golden glow of the seven suns spills over the horizon, their combined light pouring through the bedroom window and painting everything in a warm, honey-colored glow."
            "The bedroom itself is unmistakably theirs."
            "Its walls are painted a deep, cozy red and decorated with little yellow flowers, some carefully painted and others clearly stuck on whenever there was an empty patch of wall."
            "A wardrobe sits open in the corner, overflowing with the accumulated treasures of a life that has never quite learned the meaning of putting things away."
            "Clothes spill across the floor in a colorful mess. Among them are several red garments, a pink tutu, and a suspiciously familiar collection of accessories that have definitely been worn at least once."
            "Pinned carefully along one wall are crayon drawings."
            "Most of them depict the same two figures: a little red heart and a small cyan girl, sometimes holding hands, sometimes smiling beneath crooked suns, and sometimes surrounded by an assortment of flowers that look suspiciously more well drawn than the “human” little girl."
            "A stack of books recommended by a friend has been tucked into the bookshelf. Nestled between them are several playwrights and scripts from various cowboy-themed shows."
            "Somehow, it all belongs together."
            "Every little object is another piece of a life carefully cultivated, collected, and hoarded away in this bedroom. A record of all the things worth loving."
            "And, finally, your eyes may trail toward the two figures curled together on the bed."
            "The red glow slowly awakens to the sound of birds outside."

            scene bg_bonus1 with dissolve
            "The first thing I see upon opening my eyes is my dashing boyfriend."
            "I reach out, gently tucking a strand of his velvety hair away from his face."

            scene bg_bonus2 with dissolve
            "He hums softly in his sleep, and one eye cracks open just enough to look at me through large, hazy pupils."

            Flowery "Good morning, Angel…"

            "I can't help the airy little laugh that escapes me."

            Angel "Were you even sleeping…?"

            play sound "audio/Flowery_voiceclip_stingus.wav"

            Flowery "I’m sleeping as long as I believe I am."

            "His voice is still thick with sleep, but the smile on his face only grows."

            play sound "audio/Flowery_voiceclip_wow.wav"

            Flowery "But you’re so cute when you sleep. Why would I miss that…?"

            Angel "Pftt… weirdooo."

            "My hand gently presses against his chest in protest. He only catches it."
            "With tenderness, he links his fingers with mine and brings my hand to his lips, pressing a soft kiss against my knuckles."
            "Then another… And another."
            "Slowly, he peppers trailing kisses up my arm, leaning in closer and brushing his velvet lips against my jaw."
            "I giggle, trying and failing to squirm away as he nuzzles against me, stilling only when he leaves lingering open mouthed kisses on my neck I still feel even when he pulls away, eventually resting his forehead against mine."
            
            play sound "audio/Flowery_voiceclip_suckle_it_up.wav"
            
            Flowery "You’re glowing quite brightly for this weirdo, then… mh?"

            "I huff and look away, doing my very best to appear annoyed at both his ability to read me like a book and the stupid voice line. It doesn't work. Because my eyes always trail back to him anyway."
            "The sunlight catches against his golden skin, making him shimmer as though one of the seven suns itself had decided to crawl into bed beside me."
            "And when he looks at me… God. Those eyes."
            "They hold such unabashed love. So warm, steady, and impossibly gentle."
            "I reach up and brush my thumb against his cheek."

            Angel "I love you, Flowery…"

            "His expression softens. For just a moment, neither of us says anything."
            "And all at once, I remember what it feels like to be the flowery someone picked. Surely he knew that feeling, being cared for… but had he ever received it in return? How long had he spent believing he was just a useless flower…"
            "This life we now lived, brought about by our own choices. This was proof against that..."

            Flowery "I love you too, My Angel."

            scene bg_black with fade

            "I would never forget this quiet morning that belonged entirely to the two of us, nore the ones that came before, and long after."
        else:
            return

    # This ends the game.

    return
