# characters are defined here

define Soul = Character("Soul", color="ff0000")
define Angel = Character("Angel", color="ff0000")
define Flowery = Character("Flowery", color="FFD61F")
define Mist1 = Character("???", color="FFD61F")
define Mist2 = Character("???", color="21c450")
define Mist3 = Character("???", color="bc27d6")

image flowery_nuetral = "flowery sprite 1"
image flowery_happier = "flowery sprite 2.png"
image flowery_confusion = "flowery sprite 3.png"
image flowery_confusionreach = "flowery sprite 4.png"
image flowery_surprised = "flowery sprite 5.png"
image flowery_warm = "flowery sprite 6.png"
image flowery_worry = "flowery sprite 7.png"
image flowery_fluster = "flowery sprite 8.png"
image flowery_laugh = "flowery sprite 9.png"
image flowery_dark = "flowery sprite 10.png"
image flowery_smug = "flowery sprite 11.png"
image flowery_hiding = "flowery sprite 12.png"
image flowery_bedroomeyes = "flowery sprite 13.png"

#Attraction variables below here

default affec = 0